﻿namespace CovidCertificate.Backend.Models.ResponseDtos
{
    public class RemoteCodeResponseDto
    {
        public string RemoteCheckCode { get; set; }
    }
}
