using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;
using System.Security.Claims;
using CovidCertificate.Backend.Interfaces.RemoteAccessCodeService;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.ResponseDtos;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Models.Exceptions;
using System.Linq;
using System.Web.Http;
using Microsoft.Identity.Client;
using Microsoft.Graph;
using System.Net.Http.Headers;
using CovidCertificate.Backend.ThirdPartySharing;
using CovidCertificate.Backend.Interfaces;

namespace CovidCertificate.Backend
{
    /// <summary>
    /// Function app functions to fetch a code to share status with third parties
    /// and to be able to use the code to fetch the statuses
    /// </summary>
    public class GetRegRemoteCovidStatusFunction
    {
        private readonly ICovidCertificateCreator covidCertificateCreator;
        private readonly IRemoteAccessCodeService remoteAccess;
        private readonly ILogger logger;
        private readonly IMongoRepository<ThirdParty> mongoRepository;

        public GetRegRemoteCovidStatusFunction(IRemoteAccessCodeService remoteAccess,
                                                ICovidCertificateCreator covidCertificateCreator,
                                                IMongoRepository<ThirdParty> mongoRepository,
                                                ILogger<GetRegRemoteCovidStatusFunction> logger)
        {
            this.remoteAccess = remoteAccess;
            this.covidCertificateCreator = covidCertificateCreator;
            this.mongoRepository = mongoRepository;
            this.logger = logger;
        }

        /// <summary>
        /// Fetch the status from a shared code. The thirdparty will need to have an account in AAD and
        /// use this to use this function. The function will fail if the token is not provided.
        /// </summary>
        /// <param name="request">Returns <see cref="FetchRemoteCovidStatusDto"/></param>
        /// <param name="principal">Third party access token</param>
        /// <returns></returns>
        [FunctionName("GetRegRemoteCovidStatus")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest request, ClaimsPrincipal principal)
        {
            try
            {
                logger.LogDebug($"Got principal {principal?.Identity?.Name ?? "<null>"}");
                var thirdPartyDto = await GetPrincipalNameAndId(principal);
               
                //Validate Name, DoB and Remote Access Code
                var requestDto = JsonConvert.DeserializeObject<FetchRemoteCovidStatusDto>(await request.ReadAsStringAsync());
                await requestDto.ValidateObjectAndThrowOnFailuresAsync();
                
                //GetAuthRemoteCode - given the dt we have
                var remoteCode = await remoteAccess.GetRegRemoteCode(requestDto, thirdPartyDto);

                if (remoteCode == null)
                {
                    throw new InvalidRemoteCodeException("Unable to obtain remote code");
                }

                //GetRegRemoteCode - given the dto's we have
                var certificate = await covidCertificateCreator.GetCertificateByHash(remoteCode,requestDto);

                //Create response
                var response = GetResponse(certificate);

                //Return response
                return new OkObjectResult(response);
            }
            catch (Exception e) when (e is ThirdPartyException || e is InvalidRemoteCodeException || e is RemoteCodeStatusException || e is RemoteAccessCodeNotFoundException)
            {
                logger.LogWarning(e, e.Message);
                return new BadRequestObjectResult(e.Message);
            }
            catch (Exception e)
            {
                logger.LogCritical(e, e.Message + " : " + e.StackTrace);
                return new InternalServerErrorResult();
            }
        }
        
        /// <summary>
        /// Extract third party details from AAD token
        /// </summary>
        /// <param name="principle"></param>
        /// <returns></returns>
        private async Task<GetAuthCodeRequestDto> GetPrincipalNameAndId(ClaimsPrincipal principle)
        {
            var thirdpartyIdClaim = principle.Claims.FirstOrDefault<Claim>(x => x.Type.Contains("objectidentifier"));
            if (thirdpartyIdClaim == null) throw new ThirdPartyException("No object identifier found in token");
                
            var thirdpartyId = thirdpartyIdClaim.Value;

            var thirdParty = await mongoRepository.FindOneAsync(x => x.ThirdPartyId == thirdpartyId);
            var displayName = thirdParty?.ThirdPartyName;

            if (string.IsNullOrEmpty(displayName)) throw new ThirdPartyException("Third party not found in database");

            var thirdPartyDto = new GetAuthCodeRequestDto()
            {
                ThirdPartyName = displayName,
                ThirdPartyID = thirdpartyId
            };

            return thirdPartyDto;
        }

        private RemoteCovidStatusResponseDto GetResponse(Certificate certificate)
        {
            // This has been coded for security, default initialisation of no certificate unless proven otherwise
            var certificationStatus = "None";
            DateTime? certificationExpiry = null;

            if (certificate != null)
            {
                if (certificate.validityEndDate > DateTime.UtcNow)
                {
                    certificationStatus = "Valid";
                    certificationExpiry = certificate.validityEndDate;
                }
            }

            var response = new RemoteCovidStatusResponseDto()
            {
                CertificationStatus = certificationStatus,
                CertificationExpiry = certificationExpiry
            };

            return response;
        }
    }
}
