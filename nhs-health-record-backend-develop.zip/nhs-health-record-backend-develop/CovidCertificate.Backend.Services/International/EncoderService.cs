﻿using CovidCertificate.Backend.International.Interfaces;
using CovidCertificate.Backend.Models.Interfaces.UserInterfaces;
using CovidCertificate.Backend.Services.KeyServices;
using PeterO.Cbor;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.International.Services
{
    public class EncoderService : IEncoderService
    {
        private readonly ICondensorService condensor;
        private readonly ICBORFlow cborFlow;
        private readonly IKeyRing keyRing;


        public EncoderService(ICondensorService condensor, ICBORFlow cborFlow, IKeyRing keyRing)
        {
            this.condensor = condensor;
            this.cborFlow = cborFlow;
            this.keyRing = keyRing;
        }

        public async Task<string> EncodeFlowAsync<T>(IUserCBORInformation user, long certifiateGenerationTime, IEnumerable<T> results, string uniqueCertificateIdentifier, DateTime? validityEndDate, int resultIndex, string barcodeIssuerCountry = null)
        {
            CBORObject condensedCbor = condensor.CondenseCBOR<T>(user, certifiateGenerationTime, results, uniqueCertificateIdentifier, validityEndDate, resultIndex, barcodeIssuerCountry);
            var keyId = keyRing.GetRandomKey();
            byte[] originalCborBytes = condensedCbor.EncodeToBytes();
            byte[] alteredCborBytes = await cborFlow.AddMetaDataToCbor(originalCborBytes, keyId);
            //ZLib Compression
            byte[] compressedSignedCborBytes = await ZlibCompression.CompressData(alteredCborBytes);
            //Base45 Encode
            string encodedString = Base45Encoding.Encode(compressedSignedCborBytes);
            // Add HC1 to start of string
            encodedString = $"HC1:{encodedString}";

            return encodedString;
        }
    }
}
