﻿using CovidCertificate.Backend.Models.DataModels;
using Hl7.Fhir.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IFhirBundleMapper<T> where T:IGenericResult
    {
        Task<IEnumerable<T>> ConvertBundle(Bundle bundle);
    }
}
