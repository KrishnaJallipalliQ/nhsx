﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using CovidCertificate.Backend.Models.Exceptions;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Services.BlobService;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class BlobServiceTest
    {
        private readonly Mock<ILogger<BlobService>> loggerMock = new Mock<ILogger<BlobService>>();
       
        private readonly IConfiguration configuration;

        private readonly BlobServiceSettings settings = new BlobServiceSettings(){
                GetImageRetryCount = 3,
                GetImageRetrySleepDurationInMilliseconds = 500
            };
        private readonly string validContainer = "Test";
        private readonly string invalidContainer = "";
        private readonly string validLocation = "Test";
        private readonly string invalidLocation = "";
        private readonly string containerArgumentNullExceptionMessage = "Value cannot be null. (Parameter 'container')";
        private readonly string locationArgumentNullExceptionMessage = "Value cannot be null. (Parameter 'location')";
        private readonly string configurationExceptionMessage = "Connection string does not exist";

        public BlobServiceTest()
        {
            var inMemorySettings = new Dictionary<string, string> {
                {"TestKey", "TestValue"},
                {"Test2", "Test2"}
            };

             configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();
        }

        [Fact]
        public async Task GetObjectFromBlob_InvalidContainer_ReturnsArgumentNullException()
        {
            //Assign
            var uat = new BlobService(configuration, loggerMock.Object, settings);

            //Act
            var result = await Assert.ThrowsAsync<ArgumentNullException>(() => uat.GetObjectFromBlob<Dictionary<string, string>>(invalidContainer, validLocation));

            //Assert
            Assert.Equal(containerArgumentNullExceptionMessage, result.Message);
        }

        [Fact]
        public async Task GetObjectFromBlob_InvalidLocation_ReturnsArgumentNullException()
        {
            //Assign
            var uat = new BlobService(configuration, loggerMock.Object, settings);

            //Act
            var result = await Assert.ThrowsAsync<ArgumentNullException>(() => uat.GetObjectFromBlob<Dictionary<string, string>>(validContainer, invalidLocation));

            //Assert
            Assert.Equal(locationArgumentNullExceptionMessage, result.Message);
        }

        [Fact]
        public async Task GetObjectFromBlob_InvalidConnectionString_ReturnsConfigurationException()
        {
            //Assign
            var uat = new BlobService(configuration, loggerMock.Object, settings);

            //Act
            var result = await Assert.ThrowsAsync<ConfigurationException>(() => uat.GetObjectFromBlob<Dictionary<string, string>>(validContainer, validLocation));

            //Assert
            Assert.Equal(configurationExceptionMessage, result.Message);
        }

        [Fact]
        public async Task GetImageFromBlob_InvalidContainer_ReturnsArgumentNullException()
        {
            //Assign
            var uat = new BlobService(configuration, loggerMock.Object, settings);

            //Act
            var result = await Assert.ThrowsAsync<ArgumentNullException>(() => uat.GetImageFromBlobWithRetryAsync(invalidContainer, validLocation));

            //Assert
            Assert.Equal(containerArgumentNullExceptionMessage, result.Message);
        }

        [Fact]
        public async Task GetImageFromBlob_InvalidLocation_ReturnsArgumentNullException()
        {
            //Assign
            var uat = new BlobService(configuration, loggerMock.Object, settings);

            //Act
            var result = await Assert.ThrowsAsync<ArgumentNullException>(() => uat.GetImageFromBlobWithRetryAsync(validContainer, invalidLocation));

            //Assert
            Assert.Equal(locationArgumentNullExceptionMessage, result.Message);
        }

        [Fact]
        public async Task GetImageFromBlob_InvalidConnectionString_ReturnsConfigurationException()
        {
            //Assign
            var uat = new BlobService(configuration, loggerMock.Object, settings);

            //Act
            var result = await Assert.ThrowsAsync<ConfigurationException>(() => uat.GetImageFromBlobWithRetryAsync(validContainer, validLocation));

            //Assert
            Assert.Equal(configurationExceptionMessage, result.Message);
        }

        [Fact]
        public async Task GetStringFromBlob_InvalidContainer_ReturnsArgumentNullException()
        {
            //Assign
            var uat = new BlobService(configuration, loggerMock.Object, settings);
            
            //Act
            var result = await Assert .ThrowsAsync<ArgumentNullException>(() => uat.GetStringFromBlob(invalidContainer, validLocation));

            //Assert
            Assert.Equal(containerArgumentNullExceptionMessage, result.Message);
        }
        
        [Fact]
        public async Task GetStringFromBlob_InvalidLocation_ReturnsArgumentNullException()
        {
            //Assign
            var uat = new BlobService(configuration, loggerMock.Object, settings);

            //Act
            var result = await Assert.ThrowsAsync<ArgumentNullException>(() => uat.GetStringFromBlob(validContainer, invalidLocation));

            //Assert
            Assert.Equal(locationArgumentNullExceptionMessage, result.Message);
        }
        
        [Fact]
        public async Task GetStringFromBlob_InvalidConnectionString_ReturnsConfigurationException()
        {
            //Assign
            var uat = new BlobService(configuration, loggerMock.Object, settings);

            //Act
            var result = await Assert.ThrowsAsync<ConfigurationException>(() => uat.GetStringFromBlob(validContainer, validLocation));

            //Assert
            Assert.Equal(configurationExceptionMessage, result.Message);
        }

        [Fact]
        public async Task SaveToBlob_InvalidLocation_ReturnsArgumentNullException()
        {
            //Assign
            var uat = new BlobService(configuration, loggerMock.Object, settings);
            object keys = new List<string>();

            //Act
            var result = await Assert.ThrowsAsync<ArgumentNullException>(() => uat.SaveToBlob(keys, validContainer, invalidLocation));

            //Assert
            Assert.Equal(locationArgumentNullExceptionMessage, result.Message);
        }

        [Fact]
        public async Task SaveToBlob_InvalidContainer_ReturnsArgumentNullException()
        {
            //Assign
            var uat = new BlobService(configuration, loggerMock.Object, settings);
            object keys = new List<string>();

            //Act
            var result = await Assert.ThrowsAsync<ArgumentNullException>(() => uat.SaveToBlob(keys, invalidContainer, validLocation));

            //Assert
            Assert.Equal(containerArgumentNullExceptionMessage, result.Message);
        }

        [Fact]
        public async Task SaveToBlob_InvalidConnectionString_ReturnsConfigurationException()
        {
            //Assign
            var uat = new BlobService(configuration, loggerMock.Object, settings);
            object keys = new List<string>();

            //Act
            var result = await Assert.ThrowsAsync<ConfigurationException>(() => uat.SaveToBlob(keys, validContainer, validLocation));

            //Assert
            Assert.Equal(configurationExceptionMessage, result.Message);
        }
    }
}
