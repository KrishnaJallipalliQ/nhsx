﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security;
using System.Threading.Tasks;
using System.Web;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.NhsApiIntegration.Deserializers;
using CovidCertificate.Backend.NhsApiIntegration.Interfaces;
using CovidCertificate.Backend.Utils;
using Hl7.Fhir.Model;
using Microsoft.Extensions.Logging;
using Polly.Wrap;

namespace nhs.vaccination.registry.externalApiIntegration.Services
{
    public class NhsdFhirApiService : INhsdFhirApiService
    {
        private readonly ILogger<NhsdFhirApiService> logger;
        private readonly HttpClient httpClient;
        private readonly NhsTestResultsHistoryApiSettings settings;
        private readonly INhsTestResultsHistoryApiAccessTokenService nhsTestResultsHistoryApiAccessTokenService;
        private AsyncPolicyWrap<HttpResponseMessage> retryPolicy;

        public NhsdFhirApiService(
            ILogger<NhsdFhirApiService> logger,
            HttpClient httpClient,
            NhsTestResultsHistoryApiSettings settings,
            INhsTestResultsHistoryApiAccessTokenService nhsTestResultsHistoryApiAccessTokenService)
        {
            this.logger = logger;
            this.httpClient = httpClient;
            this.settings = settings;
            this.nhsTestResultsHistoryApiAccessTokenService = nhsTestResultsHistoryApiAccessTokenService;
            SetupRetryPolicy();
        }

        private void SetupRetryPolicy()
        {
            int retryCount = settings.NhsDiagnosticApiRetryCount;
            int retrySleepDuration = settings.NhsDiagnosticApiRetrySleepDurationInMilliseconds;
            int timeout = settings.NhsDiagnosticApiTimeoutInMilliseconds;

            retryPolicy = HttpRetryPolicyUtils.CreateRetryPolicyWrap(retryCount, retrySleepDuration, timeout, "retrieving Test results from NHS Test results API", logger);
        }

        public async Task<Bundle> GetAntibodyTestResults(string identityToken)
        {
            var antibodyTestsBundle = await GetTestResults(new[] { settings.AntibodyTestSNOMEDCode }, identityToken);

            return antibodyTestsBundle;
        }

        public async Task<Bundle> GetDiagnosticTestResults(string identityToken)
        {
            return await GetTestResults(new []{ settings.AntigenTestSNOMEDCode, settings.VirusTestSNOMEDCode }, identityToken);
        }

        private async Task<Bundle> GetTestResults(string[] testSNOMEDCodes, string identityToken)
        {
            VerifyProofingLevel(identityToken);

            logger.LogInformation("Trying to get access token for Test Results History API.");
            var accessToken = await nhsTestResultsHistoryApiAccessTokenService.GetAccessTokenAsync(identityToken);

            logger.LogInformation("Get NhsNumber from IdToken to make call to Test Results History API.");
            var nhsNumber = GetNhsNumberFromUserToken(identityToken);

            logger.LogInformation("Preparing request to Test Results History API.");
            var baseUrl = settings.NhsTestResultsHistoryApiBaseUrl;
            var system = "https://fhir.nhs.uk/Id/nhs-number";

            var query = HttpUtility.ParseQueryString(string.Empty);
            query["patient.identifier"] = $"{system}|{nhsNumber}";
            query["code"] = string.Join(',', testSNOMEDCodes);
            var queryString = query.ToString();
            var endpoint = settings.NhsTestResultsHistoryApiEndpoint;
            var correlationId = Guid.NewGuid().ToString();


            logger.LogInformation("Sending request to Test Results History API.");
            var response = await retryPolicy.ExecuteAsync(() => httpClient.SendAsync(CreateRequest(identityToken, baseUrl, endpoint, queryString, accessToken, correlationId)));

            var responseMessage = response.Content != null ? await response.Content.ReadAsStringAsync() : "";

            if (response.IsSuccessStatusCode)
            {
                logger.LogInformation("Success in obtaining data from Test Results History API. Deserializing response.");
                var bundle = FHIRDeserializer.Deserialize<Bundle>(responseMessage);
                RemoveSensitiveDataFromTheTestsBundle(bundle);

                return bundle;
            }

            var message = $"Error during accessing Test Results History API. ResponseStatusCode: {response.StatusCode}, Error message: '{responseMessage}', headers: {response.Headers}, correlationId: {correlationId}.";

            logger.LogCritical(message);
            throw new Exception(message);
        }

        private void VerifyProofingLevel(string identityToken)
        {
            if (settings.DisableP5 && IsP5ProofingLevel(identityToken))
            {
                logger.LogWarning("P5 proofing level detected but is disabled.");

                throw new SecurityException(
                    "Users with P5 proofing level are not allowed to access Test Results History API.");
            }

            if (settings.DisableP9 && IsP9ProofingLevel(identityToken))
            {
                logger.LogWarning("P9 proofing level detected but is disabled.");

                throw new SecurityException(
                    "Users with P9 proofing level are not allowed to access Test Results History API.");
            }

            if (!settings.AllowAllOtherThanP5AndP9 && !IsP9OrP5ProofingLevel(identityToken))
            {
                var proofingLevel = JwtTokenUtils.GetClaim(identityToken, "identity_proofing_level");

                logger.LogWarning(
                    $"Proofing level '{proofingLevel}' detected, but profiles other than P5 and P9 are not allowed.");

                throw new SecurityException(
                    $"Users with '{proofingLevel}' proofing level are not allowed to access Test Results History API.");
            }
        }

        private HttpRequestMessage CreateRequest(string nhsdUserIdentityToken, string baseUrl, string endpoint, string queryString,
            string accessToken, string correlatioId)
        {
            var request = new HttpRequestMessage(
                HttpMethod.Get,
                $"{baseUrl}{endpoint}?{queryString}");

            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

            // Id token header
            request.Headers.Add(JwtTokenUtils.IdTokenHeaderName, nhsdUserIdentityToken);
            request.Headers.Add("X-Correlation-ID", correlatioId);

            if (settings.UseTestResultsHistoryMock)
            {
                // This header is only needed for Mock on Azure
                request.Headers.Add("x-functions-key", settings.TestResultsHistoryMockApiKey);
            }

            return request;
        }

        private string GetNhsNumberFromUserToken(string nhsdUserIdentityToken)
        {
            var nhsNumberFromToken = JwtTokenUtils.GetClaim(nhsdUserIdentityToken, JwtTokenUtils.NhsNumberClaimName);

            return nhsNumberFromToken;
        }

        private void RemoveSensitiveDataFromTheTestsBundle(Bundle bundle)
        {
            foreach (var entry in bundle.Entry)
            {
                if (entry?.Resource is Observation observation)
                {
                    var nhsId = observation?.Subject?.Identifier;
                    if (nhsId != null)
                        nhsId.Value = "";
                }
            }
        }

        private bool IsP5ProofingLevel(string idToken)
        {
            var identityProofingLevel = JwtTokenUtils.GetClaim(idToken, "identity_proofing_level");

            return identityProofingLevel == "P5";
        }

        private bool IsP9ProofingLevel(string idToken)
        {
            var identityProofingLevel = JwtTokenUtils.GetClaim(idToken, "identity_proofing_level");

            return identityProofingLevel == "P9";
        }

        private bool IsP9OrP5ProofingLevel(string idToken)
        {
            var identityProofingLevel = JwtTokenUtils.GetClaim(idToken, "identity_proofing_level");

            return identityProofingLevel == "P9" || identityProofingLevel == "P5";
        }
    }
}
