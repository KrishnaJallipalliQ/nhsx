﻿using System;

namespace CovidCertificate.Backend.Interfaces
{
    public interface ITableNameGenerator
    {
        /// <summary>
        /// Generates the PartitionKey based on current Utc date
        /// </summary>
        /// <returns></returns>
        string GetTableName();

        /// <summary>
        /// Generates the PartitionKey based on based on given date
        /// </summary>
        /// <param name="value">Value used to generate PartitionKey</param>
        /// <returns></returns>
        string GetTableName(DateTime value);
    }
}
