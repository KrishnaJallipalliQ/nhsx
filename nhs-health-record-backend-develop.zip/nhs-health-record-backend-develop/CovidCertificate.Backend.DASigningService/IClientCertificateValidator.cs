﻿using CovidCertificate.Backend.DASigningService.ErrorHandling;
using Microsoft.AspNetCore.Http;

namespace CovidCertificate.Backend.DASigningService
{
    public interface IClientCertificateValidator
    {
        void ValidateRequest(HttpRequest request, ErrorHandler errorHandler);
    }
}
