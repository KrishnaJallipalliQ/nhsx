﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.Exceptions
{
    public class VaccineMappingException : Exception
    {
        public VaccineMappingException(string message) : base(message)
        {
        }
    }
}