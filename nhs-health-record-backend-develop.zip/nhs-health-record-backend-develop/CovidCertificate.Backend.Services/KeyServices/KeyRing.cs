﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Azure.Core;
using Azure.Identity;
using Microsoft.Extensions.Configuration;
using Azure.Security.KeyVault.Keys;
using Azure.Security.KeyVault.Keys.Cryptography;

namespace CovidCertificate.Backend.Services.KeyServices
{
    public interface IKeyRing
    {
        Task<byte[]> SignData(string keyId, byte[] data);
        bool VerifyData(string keyId, byte[] data, byte[] signature);
        string GetRandomKey();
        IEnumerable<JsonWebKey> ExtractPublicKeys();
        IEnumerable<SubjectPublicKeyInfoDto> ExtractPublicKeyInfos();
        Task ReinitializeKeys(Func<Dictionary<string, KeyRing.KeyOps>> keySetup = null);
    }

    public class KeyRing : IKeyRing
    {
        private IDictionary<string, KeyOps> keys;
        private readonly IEnumerable<string> keyVaultUris;
        private readonly TokenCredential credential;
        private readonly IEnumerable<KeyClient> keyClients;

        private int _keyNum;
        private int KeyNum
        {
            get => _keyNum;
            set => _keyNum = value % keys.Count;
        }

        public KeyRing(IConfiguration configuration, Func<Dictionary<string, KeyOps>> keySetup = null)
        {
            keyVaultUris = configuration["KeyVaultUris"]?.Split(',').Select(x => x.Trim()) ?? new List<string> { configuration["VaultUri"] };
            credential = new DefaultAzureCredential(new DefaultAzureCredentialOptions { ExcludeSharedTokenCacheCredential = true });
            keyClients = keyVaultUris.Select(x => new KeyClient(new Uri(x), credential, new KeyClientOptions
            {
                Retry =
                {
                    Delay = TimeSpan.FromSeconds(2),
                    MaxDelay = TimeSpan.FromSeconds(32),
                    MaxRetries = 5,
                    Mode = RetryMode.Exponential
                }
            }));
            keys = keySetup?.Invoke() ?? SetupKeys().Result;
        }

        public async Task<byte[]> SignData(string keyId, byte[] data)
        {
            if (data == null || data.Length == 0)
            {
                throw new ArgumentNullException(nameof(data), "Cannot sign null object");
            }

            if (keys.ContainsKey(keyId))
                return await keys[keyId].Sign(data);

            throw new KeyNotFoundException($"Key with id {keyId} could not be found.");
        }

        public bool VerifyData(string keyId, byte[] data, byte[] signature)
            => keys.ContainsKey(keyId) && keys[keyId].Verify(data, signature);

        public string GetRandomKey()
            => keys.ElementAt(KeyNum++).Key;

        public IEnumerable<JsonWebKey> ExtractPublicKeys()
            => keys.Select(x => x.Value.Extract());

        public IEnumerable<SubjectPublicKeyInfoDto> ExtractPublicKeyInfos()
            => keys.Select(x => x.Value.ExtractSubjectPublicKeyInfo());

        public async Task ReinitializeKeys(Func<Dictionary<string, KeyOps>> keySetup = null)
            => keys = keySetup?.Invoke() ?? await SetupKeys();

        private async Task<Dictionary<string, KeyOps>> SetupKeys()
        {
            var setupKeys = new Dictionary<string, KeyOps>();
            foreach (var keyClient in keyClients)
            {
                await foreach (var kp in keyClient.GetPropertiesOfKeysAsync())
                {
                    try
                    {
                        if (!kp.Enabled ?? false)
                        {
                            continue;
                        }

                        var k = await keyClient.GetKeyAsync(kp.Name);
                        setupKeys.Add(k.Value.Name, new KeyOps(k.Value, credential));
                    }
                    catch
                    {
                        /* Intentionally empty */
                    }
                }
            }

            return setupKeys;
        }

        public class KeyOps
        {
            public Func<byte[], byte[], bool> Verify { get; }
            public Func<byte[], Task<byte[]>> Sign { get; }
            public Func<JsonWebKey> Extract { get; }
            public Func<SubjectPublicKeyInfoDto> ExtractSubjectPublicKeyInfo { get; }

            public KeyOps(KeyVaultKey kvk, TokenCredential credential)
            {
                var pub = kvk.Key;
                pub.Id = Convert.ToBase64String(Encoding.UTF8.GetBytes(kvk.Name));
                pub.KeyType = KeyType.EcHsm;
                Extract = () => pub;

                var ec = pub.ToECDsa();
                Verify = (x, y) => ec.VerifyData(x, y, HashAlgorithmName.SHA256);

                var priv = new CryptographyClient(kvk.Id, credential, new CryptographyClientOptions
                {
                    Retry =
                    {
                        Delay = TimeSpan.FromSeconds(2),
                        MaxDelay = TimeSpan.FromSeconds(32),
                        MaxRetries = 5,
                        Mode = RetryMode.Exponential
                    }
                });
                Sign = async x => (await priv.SignDataAsync(SignatureAlgorithm.ES256, x)).Signature;

                var keyBytes = new Span<byte>(new byte[256]);
                var exportRes = ec.TryExportSubjectPublicKeyInfo(keyBytes, out var bytesWritten);
                var res = string.Empty;

                if (exportRes)
                {
                    var toEncode = keyBytes.Slice(0, bytesWritten).ToArray();
                    res = Convert.ToBase64String(toEncode);
                }

                ExtractSubjectPublicKeyInfo = () =>
                    exportRes
                        ? new SubjectPublicKeyInfoDto { Kid = pub.Id, PublicKey = res }
                        : throw new Exception($"Failed to extract Subject Public Key info from key {kvk.Name}");
            }

            public KeyOps(Func<JsonWebKey> extract, Func<byte[], Task<byte[]>> sign, Func<byte[], byte[], bool> verify, Func<SubjectPublicKeyInfoDto> extractSubjectPublicKeyInfo)
            {
                Extract = extract;
                Sign = sign;
                Verify = verify;
                ExtractSubjectPublicKeyInfo = extractSubjectPublicKeyInfo;
            }
        }
    }
}
