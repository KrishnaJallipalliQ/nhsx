using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using CovidCertificate.Backend.Configuration.Bases.BaseFunctions;
using CovidCertificate.Backend.Interfaces.Delegates;
using Microsoft.Extensions.Configuration;
using CovidCertificate.Backend.Utils.Extensions;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Utils;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.Exceptions;

namespace CovidCertificate.Backend
{
    public class GetUserPreferences : BaseSecureFunction
    {
        private readonly IUserPreference userPreferences;
        public GetUserPreferences(JwtValidatorResolver jwtValidator, IConfiguration configuration, IUserPreference userPreferences,
            ILogger<AddTermsAndConditionsAcceptance> logger) : base(jwtValidator, configuration, logger)
        {
            this.userPreferences = userPreferences;
        }
        [FunctionName("GetUserPreferences")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "GetUserPreferences")] HttpRequest req,
            ILogger log)
        {
            try
            {
                logger.LogInformation("GetUserPreferences was invoked");
                var validationResult = await base.AuthoriseEndpoint(req);
                logger.LogTraceAndDebug($"validationResult: IsValid {validationResult?.IsValid}, Response is {validationResult?.Response}, TokenClaims are {validationResult?.TokenClaims}");
                if (base.responseInvalid(validationResult))
                {
                    logger.LogInformation("GetUserPreferences has finished");
                    return validationResult.Response;
                }

                var nhsID = JwtTokenUtils.CalculateHashFromIdToken(base.GetIdToken(req));
                var userPreferenceDto = await userPreferences.getPreferences(nhsID);

                return new OkObjectResult(userPreferenceDto);
            }
            catch(NoResultsException e)
            {
                logger.LogWarning(e, e.Message);
                return new NoContentResult();
            }
            catch (Exception e)
            {
                logger.LogError(e, e.Message);
                return new BadRequestResult();
            }
        }

    }
}
