﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Models.Exceptions;
using CovidCertificate.Backend.Services;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CovidCertificate.Backend.Tests.TestHelpers;
using Xunit;
using CovidCertificate.Backend.Utils;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class GeneratePassDataTest
    {
        private GeneratePassData service;
        private readonly Mock<ILogger<GeneratePassData>> loggerMock = new Mock<ILogger<GeneratePassData>>();
        private readonly Mock<ICovidCertificateCreator> covidCertificateCreatorMock = new Mock<ICovidCertificateCreator>();
        private string mockBearer = "bearer";
        private CovidPassportUser validUser = new CovidPassportUser("Test McTestPerson", DateTime.UtcNow.AddYears(-20), "test@test.com", "0123456789", "0000000000");
        private readonly Mock<IGetTimeZones> timeZonesMock = new Mock<IGetTimeZones>();
        public GeneratePassDataTest()
        {
            timeZonesMock.Setup(m => m.GetTimeZoneInfo()).Returns(TimeZoneInfo.Utc);
            service = new GeneratePassData(loggerMock.Object,timeZonesMock.Object, covidCertificateCreatorMock.Object);
            
        }

        [Fact]
        public async Task GeneratePassData_DomesticCert()
        {
            var certResponse = new Certificate("Test McTestPerson", DateTime.UtcNow.AddYears(-20), DateTime.UtcNow.AddDays(30), DateTime.UtcNow.AddDays(100), CertificateType.Diagnostic, CertificateScenario.International);
            covidCertificateCreatorMock.Setup(m => m.GetDomesticCertificate(It.IsAny<CovidPassportUser>(), mockBearer)).ReturnsAsync(certResponse);
            (QRcodeResponse qr, Certificate cert) data = await service.GetPassDataAsync(validUser, mockBearer, QRType.Domestic);
            
            Assert.Equal(StringUtils.GetFormattedDateTime(TimeZoneInfo.ConvertTimeFromUtc(certResponse.validityEndDate, TimeZoneInfo.Utc)), data.qr.ValidityEndDate);
            Assert.Equal(StringUtils.GetFormattedDate(TimeZoneInfo.ConvertTimeFromUtc(certResponse.eligibilityEndDate, TimeZoneInfo.Utc)), data.qr.EligibilityEndDate);
        }

        [Fact]
        public async Task GeneratePassData_InternationalCert_ValidData()
        {
            var validVaccines = new List<Vaccine>();
            validVaccines.Add(new Vaccine(DateTime.MinValue, "Test"));
            var validCertificate = VaccinationMapperHelper.SetUpVaccineCertificateModel(CertificateType.Vaccination, CertificateScenario.International);

            covidCertificateCreatorMock.Setup(x => x.GetInternationalCertificate(It.IsAny<CovidPassportUser>(), It.IsAny<string>(), It.IsAny<CertificateType>()))
                                       .ReturnsAsync(validCertificate);

            (QRcodeResponse qr, Certificate cert) data = await service.GetPassDataAsync(validUser, mockBearer, (QRType)1);
            Assert.Equal(validCertificate, data.cert);
            Assert.Equal(StringUtils.GetFormattedDate(TimeZoneInfo.ConvertTimeFromUtc(validCertificate.validityEndDate, TimeZoneInfo.Utc)), data.qr.ValidityEndDate);
            Assert.Equal(StringUtils.GetFormattedDate(TimeZoneInfo.ConvertTimeFromUtc(validCertificate.eligibilityEndDate, TimeZoneInfo.Utc)), data.qr.EligibilityEndDate);
        }

      

        [Fact]
        public async Task GeneratePassData_RecoveryCert_ValidData()
        {
            Tuple<string, string> diseaseTargeted = new Tuple<string, string>("41523432", "COVID-19");
            var testResultNhs = new TestResultNhs(DateTime.Now.AddDays(-30), "Positive", "Type", "41241231", "Kit", diseaseTargeted, "NHS", "GB");

            var validCertificate = new Certificate("name", DateTime.UtcNow, DateTime.UtcNow.AddDays(-30), DateTime.UtcNow.AddDays(180), CertificateType.Recovery, CertificateScenario.International, new List<IGenericResult>() { testResultNhs });
            covidCertificateCreatorMock.Setup(x => x.GetInternationalCertificate(It.IsAny<CovidPassportUser>(), It.IsAny<string>(), It.IsAny<CertificateType>()))
                                       .ReturnsAsync(validCertificate);

            (QRcodeResponse qr, Certificate cert) data = await service.GetPassDataAsync(validUser, mockBearer, (QRType)2);
            Assert.Equal(validCertificate, data.cert);
            Assert.Equal(StringUtils.GetFormattedDate(TimeZoneInfo.ConvertTimeFromUtc(validCertificate.validityEndDate, TimeZoneInfo.Utc)), data.qr.ValidityEndDate);
            Assert.Equal(StringUtils.GetFormattedDate(TimeZoneInfo.ConvertTimeFromUtc(validCertificate.eligibilityEndDate, TimeZoneInfo.Utc)), data.qr.EligibilityEndDate);
        }

    

        [Fact]
        public async Task GeneratePassData_InvalidQRType()
        {
            var data = await service.GetPassDataAsync(validUser, mockBearer, (QRType)99);
            Assert.Null(data.cert);
            Assert.Null(data.qr);
        }
    }
}
