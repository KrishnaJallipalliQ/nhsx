﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.Settings;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using StackExchange.Redis;
using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Security.Authentication;
using System.Threading.Tasks;
using MongoDB.Driver.Core.Configuration;
using CovidCertificate.Backend.Utils.Extensions;

namespace CovidCertificate.Backend.Services
{
    public class RedisCacheService : IRedisCacheService
    {
        private readonly ILogger<RedisCacheService> logger;
        private readonly RedisCacheSettings redisCacheSettings;
        private static IConfiguration configuration;
        private static ConcurrentBag<Lazy<ConnectionMultiplexer>> connections;
        private static bool redisDisabled;

        public RedisCacheService(RedisCacheSettings _redisCacheSettings, ILogger<RedisCacheService> _logger, IConfiguration _configuration)
        {
            redisDisabled = Environment.GetEnvironmentVariable("RedisDisabled") == bool.TrueString;

            if (redisDisabled)
            {
                return;
            }

            logger = _logger;
            redisCacheSettings = _redisCacheSettings;
            configuration = _configuration;

            var redisConnection = configuration["RedisConnectionString"];

            if (redisConnection == default)
            {
                logger.LogError(LogType.Redis, "Redis cache connection is not setup");
                return;
            }

            Initialize();
        }

        private void Initialize()
        {
            try
            {
               connections = new ConcurrentBag<Lazy<ConnectionMultiplexer>>();
               const int defaultIntConnectionTimeout = 30000;
               var connectRetry= int.TryParse(configuration["RedisConnectRetries"], out var retries) ? retries : 1;
               var abortOnFail=(configuration["RedisAbortOnConnectFail"] ?? "False") == bool.TrueString;
               var connectTimeout=int.TryParse(configuration["RedisConnectionTimeout"],out var connectionTimeout) ? connectionTimeout:defaultIntConnectionTimeout;
               var connectionString =ConfigurationOptions.Parse(configuration["RedisConnectionString"]);
               
               var options = connectionString;
               options.ConnectRetry = connectRetry;
               options.AbortOnConnectFail = abortOnFail;
               options.ConnectTimeout = connectTimeout;
               options.Ssl=true;
               options.SslProtocols=SslProtocols.Tls12;
               options.ReconnectRetryPolicy= new ExponentialRetry(5000,10000);

               logger.LogInformation($"Redis connection options: connectionString:{connectionString}, " +
                                      $"connectRetry:{connectRetry}, connectTimeout:{connectTimeout}");
                
                var poolSize = int.TryParse(configuration["RedisPoolSize"], out var size) ? size : 5;
                for (var i = 0; i < poolSize; i++)
                    connections.Add(new Lazy<ConnectionMultiplexer>(() =>
                        ConnectionMultiplexer.Connect(options)));
            }
            catch (Exception e)
            {
                logger.LogError(LogType.Redis, e.Message);
            }
        }

        private static IConnectionMultiplexer GetConnection()
        {
            var loadedLazys = connections.Where(lazy => lazy.IsValueCreated);

            var response = loadedLazys.Count() == connections.Count
                ? connections.OrderBy(x => x.Value.GetCounters().TotalOutstanding).First()
                : connections.First(lazy => !lazy.IsValueCreated);

            return response.Value;
        }

        private static IDatabase GetDatabase => GetConnection().GetDatabase();

        private TimeSpan GetExpirationTime(RedisLifeSpanLevel redisLifeSpanLevel)
        {
            TimeSpan cacheExpirationTimeSpan = redisLifeSpanLevel switch
            {
                RedisLifeSpanLevel.Short => TimeSpan.FromSeconds(redisCacheSettings.RedisExpiryShort),
                RedisLifeSpanLevel.Medium => TimeSpan.FromSeconds(redisCacheSettings.RedisExpiryMedium),
                RedisLifeSpanLevel.Long => TimeSpan.FromSeconds(redisCacheSettings.RedisExpiryLong),
                _ => new TimeSpan(0, 0, 280),
            };
            return cacheExpirationTimeSpan;
        }

        public async Task<bool> AddKeyAsync(string key, object value, RedisLifeSpanLevel redisLifeSpanLevel)
        {
            if (redisDisabled)
            {
                return true; //Successfully decided to not use Redis at all
            }

            bool IsSuccess = false;
            try
            {
                IDatabase db = GetDatabase;
                if (db.IsConnected(key))
                {
                    IsSuccess = await db.StringSetAsync(key, JsonConvert.SerializeObject(value),
                        GetExpirationTime(redisLifeSpanLevel));
                    logger.LogDebug(LogType.Redis, $"Key {key} {(IsSuccess ? string.Empty : "not")} added to Redis cache.");
                }
                else
                {
                    logger.LogInformation(LogType.Redis, $"No connection available to add the value for key:{key}");
                    return true;
                }
            }
            catch (Exception ex)
            {
                logger.LogError(LogType.Redis, $"Error in adding key {key} to Redis cache.", ex);
            }
            return IsSuccess;
        }

        /// <summary>
        /// Returns value of the provided key
        /// </summary>
        /// <typeparam name="T">Return Type</typeparam>
        /// <param name="key"></param>
        /// <returns>
        /// </returns>
        public async Task<(T, bool)> GetKeyValueAsync<T>(string key)
        {
            if (redisDisabled)
            {
                return (default, false);
            }

            try
            {
                IDatabase db = GetDatabase;
                if (db.IsConnected(key))
                {
                    var item = await db.StringGetAsync(key);
                    bool IsExist = !item.IsNullOrEmpty;
                    logger.LogDebug(LogType.Redis, $"Key {key} {(IsExist ? string.Empty : "not")} found in Redis cache.");
                    return IsExist ? (JsonConvert.DeserializeObject<T>(item), true) : (default(T), false);
                }
                else
                {
                    logger.LogInformation(LogType.Redis, $"No connection available to get the value based on key:{key}");
                    
                    return (default, false);
                }
            }
            catch (Exception ex)
            {
                logger.LogError(LogType.Redis, $"Error in getting value from Redis cache for key {key}.", ex);
                return (default(T), false);
            }
        }
    }
}
