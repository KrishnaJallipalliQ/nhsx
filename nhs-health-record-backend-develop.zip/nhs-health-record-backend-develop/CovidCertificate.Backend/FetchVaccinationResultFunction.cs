using CovidCertificate.Backend.Configuration.Bases.BaseFunctions;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Delegates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Utils.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SendGrid.Helpers.Errors.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace CovidCertificate.Backend
{
    public class FetchVaccinationResultFunction : BaseSecureFunction
    {
        private readonly IVRService vrService;
        private readonly IConfiguration configuration;
        private readonly IPilotFilterService pilotFilterService;
        private readonly TimeZoneInfo timeZoneInfo;
        public FetchVaccinationResultFunction(
            IVRService vRService,
            IPilotFilterService pilotFilterService,
            IConfiguration configuration,
            JwtValidatorResolver jwtTokenValidator,
            ILogger<FetchVaccinationResultFunction> logger, 
            IGetTimeZones timeZones)
            : base(jwtTokenValidator, configuration, logger)
        {
            this.vrService = vRService;
            this.configuration = configuration;
            this.pilotFilterService = pilotFilterService;
            timeZoneInfo = timeZones.GetTimeZoneInfo();
        }

        [FunctionName("GetVaccinationResults")]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "get", Route = "GetVaccinationResults")] HttpRequest request)
        {
            try
            {
                logger.LogInformation("GetVaccinationResults was invoked");

                var validationResult = await base.AuthoriseEndpoint(request, "NhsLogin");
                logger.LogTraceAndDebug($"validationResult: IsValid {validationResult?.IsValid}, Response is {validationResult?.Response}, TokenClaims are {validationResult?.TokenClaims}");

                if (base.responseInvalid(validationResult))
                {
                    logger.LogInformation($"validationResults is invalid or forbidden");
                    logger.LogInformation("GetVaccinationResults has finished");
                    return validationResult.Response;
                }

                var covidUser = new CovidPassportUser(validationResult.TokenClaims);
                logger.LogTraceAndDebug($"covidUser: {covidUser?.ToString()}");
                logger.LogInformation($"covidUser: {covidUser?.ToNhsNumberAndDobHashKey()}");

                IEnumerable<Vaccine> vaccineresults = new List<Vaccine>();
                if (Environment.GetEnvironmentVariable("ViewOnlyPilotUsersData") == "true" && !(await pilotFilterService.IsPilotUser(covidUser.ToPilotUser())))
                {
                    logger.LogWarning("This user is not a pilot user");
                    logger.LogInformation("User Hash" + covidUser.ToPilotUser().UserHash);
                    logger.LogInformation("GetVaccinationResults has finished");
                    return new OkObjectResult(vaccineresults);
                }

                vaccineresults = await vrService.GetVaccines(base.GetIdToken(request, true), covidUser);

                if (vaccineresults is null)
                {
                    logger.LogTraceAndDebug($"vaccineresults is null");
                    logger.LogInformation("GetVaccinationResults has finished");
                    return new BadRequestObjectResult("Invalid Authorisation Level");
                }
                logger.LogTraceAndDebug($"vaccineresults is {vaccineresults}");

                logger.LogInformation("GetVaccinationResults has finished");
                return new OkObjectResult(vaccineresults.Select(x => new VaccineResponse(x, timeZoneInfo)));
            }
            catch (Exception e) when (e is BadRequestException || e is ArgumentNullException)
            {
                logger.LogWarning(e, e.Message);
                return new BadRequestObjectResult("There seems to be a problem: bad request");
            }
            catch (UnauthorizedException e)
            {
                logger.LogWarning(e, e.Message);
                return new UnauthorizedObjectResult("There seems to be a problem: unauthorized");
            }
            catch (ForbiddenException e)
            {
                logger.LogWarning(e, e.Message);
                return new ObjectResult("There seems to be a problem: forbidden") { StatusCode = StatusCodes.Status403Forbidden };
            }
            catch (HttpRequestException e)
            {
                logger.LogCritical(e, e.Message);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
            catch (Exception e)
            {
                logger.LogError(e, e.Message);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}
