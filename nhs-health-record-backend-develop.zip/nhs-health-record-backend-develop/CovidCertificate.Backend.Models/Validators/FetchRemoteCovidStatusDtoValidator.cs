﻿using CovidCertificate.Backend.Models.RequestDtos;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.Validators
{
    public class FetchRemoteCovidStatusDtoValidator : AbstractValidator<FetchRemoteCovidStatusDto>
    {
        public FetchRemoteCovidStatusDtoValidator()
        {
            RuleFor(x => x.Name).NotEmpty();

            RuleFor(x => x.DateOfBirth).NotEmpty();

            RuleFor(x => x.RemoteAccessCode).NotEmpty();

            RuleFor(x => x.RemoteAccessCode).Length(9).Matches(ValidatorConsts.RemoteCheckCodeRegex);
        }
    }
}
