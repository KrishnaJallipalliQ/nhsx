using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using CovidCertificate.Backend.Configuration.Bases.BaseFunctions;
using CovidCertificate.Backend.Interfaces.Delegates;
using Microsoft.Extensions.Configuration;
using CovidCertificate.Backend.Utils.Extensions;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Utils;
using CovidCertificate.Backend.Interfaces;

namespace CovidCertificate.Backend
{
    public class AddTermsAndConditionsAcceptance : BaseSecureFunction
    {
        private readonly IUserPreference userPreferences;
        public AddTermsAndConditionsAcceptance(JwtValidatorResolver jwtValidator, IConfiguration configuration, IUserPreference userPreferences,
            ILogger<AddTermsAndConditionsAcceptance> logger) : base(jwtValidator, configuration, logger)
        {
            this.userPreferences = userPreferences;
        }
        [FunctionName("UpdateTCAcceptance")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "UpdateTCAcceptance")] HttpRequest req,
            ILogger log)
        {
            try
            {
                logger.LogInformation("UpdateTCAcceptance was invoked");
                var validationResult = await base.AuthoriseEndpoint(req);
                logger.LogTraceAndDebug($"validationResult: IsValid {validationResult?.IsValid}, Response is {validationResult?.Response}, TokenClaims are {validationResult?.TokenClaims}");
                if (base.responseInvalid(validationResult))
                {
                    logger.LogInformation("UpdateTCAcceptance has finished");
                    return validationResult.Response;
                }


                var nhsID = JwtTokenUtils.CalculateHashFromIdToken(base.GetIdToken(req));
                await userPreferences.UpdateTermsAndConditions(nhsID);

                return new OkResult();
            }
            catch (Exception e)
            {
                logger.LogError(e, e.Message);
                return new BadRequestResult();
            }
        }
    }
}
