﻿using System;

namespace CovidCertificate.Backend.Models.RequestDtos
{
    public class GenerateRemoteCodeRequestDto
    {
        public int UseCount { get; set; } = 1;
        public DateTime ExpirationDateTime { get; set; } = DateTime.UtcNow.AddDays(1);
    }
}
