﻿using CovidCertificate.Backend.Models.RequestDtos;
using PdfSharp.Pdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IPdfGeneratorService
    {
        Task<string> GeneratePdfDocument(PdfGenerationRequestDto dto);

        Task<Stream> GeneratePdfDocumentStream(PdfGenerationRequestDto dto);
    }
}
