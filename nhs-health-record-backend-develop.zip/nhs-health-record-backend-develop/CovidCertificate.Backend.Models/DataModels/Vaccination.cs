﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.DataModels
{
    public class Vaccination
    {
        public int BatchId { get; set; }
        public string ProviderRowID { get; set; }
        public string AdministrationDate { get; set; }
        public string SiteCode { get; set; }
        public string VaccineManufacturer { get; set; }
        public double DoseAmount { get; set; }
        public object DoseUnit { get; set; }
        public int DoseSequenceNumber { get; set; }
        public object ProductCode { get; set; }
        public object ProductTerm { get; set; }
        public object PerformingProfessionalFirstname { get; set; }
        public object PerformingProfessionalSurname { get; set; }
        public object PerformingProfessionalJobRole { get; set; }
        public object VaccinationProcedureCode { get; set; }
        public object VaccinationProcedureTerm { get; set; }
        public object VaccinationSituationCode { get; set; }
        public object VaccinationSituationTerm { get; set; }
        public string VaccineExpiryDate { get; set; }
    }
}
