﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.RequestDtos
{
    public class AddInternationalDynamicPdfRequestDto
    {
        public bool PrintVaccinePage { get; set; }
        public bool PrintRecoveryPage { get; set; }

        public AddInternationalVaccinePdfRequestDto VaccineCertificate { get; set; }

        public AddInternationalRecoveryPdfRequestDto RecoveryCertificate { get; set; }

        public string Name { get; set; }
        public string DateOfBirth { get; set; }
        public string Email { get; set; }
        public string TemplateName { get; set; }

        public AddInternationalDynamicPdfRequestDto(AddInternationalVaccinePdfRequestDto vaccine, AddInternationalRecoveryPdfRequestDto recovery,
                                                    string name, string dateOfBirth, string email, string templateName)
        {
            VaccineCertificate = vaccine;
            PrintVaccinePage = vaccine != null;
            RecoveryCertificate = recovery;
            PrintRecoveryPage = recovery != null;
            Name = name;
            DateOfBirth = dateOfBirth;
            Email = email;
            TemplateName = templateName;
        }
    }
}
