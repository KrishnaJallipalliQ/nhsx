﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Text;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IAssertedLoginIdentityService
    {
        public string GenerateAssertedLoginIdentity(JwtSecurityToken jtiValue);
    }
}
