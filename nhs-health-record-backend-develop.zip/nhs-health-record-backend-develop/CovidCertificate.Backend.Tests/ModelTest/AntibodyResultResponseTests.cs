﻿using System;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Tests.TestHelpers;
using Microsoft.Extensions.Configuration;
using Moq;
using Xunit;

namespace CovidCertificate.Backend.Tests.ModelTest
{
    public class AntibodyResultResponseTests
    {
        private readonly Mock<IConfiguration> mockConfig = new Mock<IConfiguration>();
        private readonly Mock<IGetTimeZones> mockGetTimeZones;

        public AntibodyResultResponseTests()
        {
            mockConfig.SetupGet<string>(m => m["TimeZoneWindows"]).Returns("GMT Standard Time");
            mockConfig.SetupGet<string>(m => m["TimeZoneLinux"]).Returns("Europe/London");
            mockGetTimeZones = new Mock<IGetTimeZones>();
            mockGetTimeZones.Setup(x => x.GetTimeZoneInfo()).Returns(TimeZoneInfo.Local);
        }

        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public void AntibodyResultResponse_InstantiateAntibodyResultResponse(CovidPassportUser user)
        {
            // Arrange
            var antibodyResult = AntibodyTestHelper.CreateAntibodyResult(user);

            // Act
            var antibodyResultResponse = new AntibodyResultResponse(antibodyResult, mockGetTimeZones.Object);

            // Assert
            Assert.NotNull(antibodyResultResponse);
        }

        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public void AntibodyResultResponse_GetHashCode(CovidPassportUser user)
        {
            // Arrange
            var antibodyResultOne = AntibodyTestHelper.CreateAntibodyResult(user);
            var antibodyResultTwo = AntibodyTestHelper.CreateAntibodyResult(user);
            var antibodyResultResponseOne = new AntibodyResultResponse(antibodyResultOne, mockGetTimeZones.Object);
            var antibodyResultResponseTwo = new AntibodyResultResponse(antibodyResultTwo, mockGetTimeZones.Object);

            // Act
            var antibodyResultResponseOneHashCodeOne = antibodyResultResponseOne.GetHashCode();
            var antibodyResultResponseOneHashCodeTwo = antibodyResultResponseOne.GetHashCode();
            var antibodyResultResponseTwoHashCode = antibodyResultResponseTwo.GetHashCode();

            // Assert
            Assert.Equal(antibodyResultResponseOneHashCodeOne, antibodyResultResponseOneHashCodeTwo);
            Assert.NotEqual(antibodyResultResponseOneHashCodeOne, antibodyResultResponseTwoHashCode);
        }

        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public void AntibodyResultResponse_Equals_ShouldReturnTrue(CovidPassportUser user)
        {
            // Arrange
            var antibodyResult = AntibodyTestHelper.CreateAntibodyResult(user);
            var antibodyResultResponseOne = new AntibodyResultResponse(antibodyResult, mockGetTimeZones.Object);
            var antibodyResultResponseTwo = new AntibodyResultResponse(antibodyResult, mockGetTimeZones.Object);
            var antibodyResultResponseThree = new AntibodyResultResponse(antibodyResult, mockGetTimeZones.Object);

            // Act & Assert
            Assert.True(antibodyResultResponseOne.Equals(antibodyResultResponseOne)); // reflexive 
            Assert.True(antibodyResultResponseOne.Equals(antibodyResultResponseTwo)); // symmetric
            Assert.True(antibodyResultResponseTwo.Equals(antibodyResultResponseOne)); // symmetric 
            Assert.True(antibodyResultResponseTwo.Equals(antibodyResultResponseThree)); // symmetric
            Assert.True(antibodyResultResponseOne.Equals(antibodyResultResponseThree)); // symmetric & transitive
        }

        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public void AntibodyResultResponse_Equals_ShouldReturnFalse(CovidPassportUser user)
        {
            // Arrange
            var antibodyResultOne = AntibodyTestHelper.CreateAntibodyResult(user);
            var antibodyResultTwo = AntibodyTestHelper.CreateAntibodyResult(user);
            var antibodyResultResponseOne = new AntibodyResultResponse(antibodyResultOne, mockGetTimeZones.Object);
            var antibodyResultResponseTwo = new AntibodyResultResponse(antibodyResultTwo, mockGetTimeZones.Object);
            var obj = new object();

            // Act & Assert
            Assert.False(antibodyResultResponseOne.Equals(antibodyResultResponseTwo));
            Assert.False(antibodyResultResponseOne.Equals(obj));
        }
    }
}
