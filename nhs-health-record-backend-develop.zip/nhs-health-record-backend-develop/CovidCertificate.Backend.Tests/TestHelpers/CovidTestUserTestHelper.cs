﻿using CovidCertificate.Backend.Models.DataModels;
using System;
using System.Collections.Generic;

namespace CovidCertificate.Backend.Tests.TestHelpers
{
    /// <summary>
    /// A static class containing essential methods for creating <see cref="CovidTestUser"/> data for unit tests.
    /// </summary>
    public static class CovidTestUserTestHelper
    {
        public static readonly Random random;
        // Specifies the minimum length for an user's name
        public const int MinNameLength = 2;
        // Specifies the maximum length for an user's name
        public const int MaxNameLength = 255;
        // Specifies the minimum length for the 'Username' part of an email address
        public const int MinEmailUsernameLength = 1;
        // Specifies the maximum length for the 'Username' part of an email address
        public const int MaxEmailUsernameLength = 64;
        // Specifies the minimum length for the 'DomainName' part of an email address
        public const int MinEmailDomainNameLength = 2; // Note: this is allowed to be 1, however, to avoid hitting emails below 6 characters, we raise it to 2
        // Specifies the maximum length for the 'DomainName' part of an email address
        public const int MaxEmailDomainNameLength = 64;
        // Specifies the minimum length for the 'Domain' part of an email address
        public const int MinEmailDomainLength = 2; // Note: this is allowed to be 1, however, to avoid hitting emails below 6 characters, we raise it to 2
        // Specifies the maximum length for the 'Domain' part of an email address
        public const int MaxEmailDomainLength = 64;
        // Specifies the minimum length for an user's 'PhoneNumber'
        public const int MinPhoneNumberLength = 8;
        // Specifies the maximum length for an user's 'PhoneNumber'
        public const int MaxPhoneNumberLength = 10;
        // Specifies the earliest possible date of birth for an user
        public static readonly DateTime minDateOfBirth;


        static CovidTestUserTestHelper() 
        {
            random = new Random();
            minDateOfBirth = new DateTime(1900, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        } 


        public static IEnumerable<object[]> GetUserScenarios()
        {
            return new List<object[]>
            {
                new object[] { CreateUserUsingEmailAddress() },
                new object[] { CreateUserUsingPhoneNumber() }
            };
        }

        public static IEnumerable<object[]> GetUserUsingBothEmailAddressAndPhoneNumber() => new List<object[]> { new object[] { CreateUserUsingBothEmailAddressAndPhoneNumber() } };

        public static IEnumerable<object[]> GetUserUsingEmailAddress() => new List<object[]> { new object[] { CreateUserUsingEmailAddress() } };

        public static IEnumerable<object[]> GetUserUsingPhoneNumber() => new List<object[]> { new object[] { CreateUserUsingPhoneNumber() } };

        public static CovidPassportUser CreateUserUsingBothEmailAddressAndPhoneNumber() =>
            new CovidPassportUser(
                ArrangeTestHelper.CreateRandomString(random.Next(MinNameLength, MaxNameLength)),
                ArrangeTestHelper.CreateRandomDateTimeBetweenDates(minDateOfBirth, DateTime.UtcNow),
                ArrangeTestHelper.CreateRandomEmailString(
                    random.Next(MinEmailUsernameLength, MaxEmailUsernameLength),
                    random.Next(MinEmailDomainNameLength, MaxEmailDomainNameLength),
                    random.Next(MinEmailDomainLength, MaxEmailDomainLength)),
                ArrangeTestHelper.CreateRandomNumberString(random.Next(MinPhoneNumberLength, MaxPhoneNumberLength)));
        

        public static CovidPassportUser CreateUserUsingEmailAddress() => 
            new CovidPassportUser(
                ArrangeTestHelper.CreateRandomString(random.Next(MinNameLength, MaxNameLength)),
                ArrangeTestHelper.CreateRandomDateTimeBetweenDates(minDateOfBirth, DateTime.UtcNow),
                ArrangeTestHelper.CreateRandomEmailString(
                    random.Next(MinEmailUsernameLength, MaxEmailUsernameLength),
                    random.Next(MinEmailDomainNameLength, MaxEmailDomainNameLength),
                    random.Next(MinEmailDomainLength, MaxEmailDomainLength)),
                string.Empty, string.Empty, string.Empty, string.Empty,"P9");
        

        public static CovidPassportUser CreateUserUsingPhoneNumber() =>
            new CovidPassportUser(
                ArrangeTestHelper.CreateRandomString(random.Next(MinNameLength, MaxNameLength)),
                ArrangeTestHelper.CreateRandomDateTimeBetweenDates(minDateOfBirth, DateTime.UtcNow),
                string.Empty,
                ArrangeTestHelper.CreateRandomNumberString(random.Next(MinPhoneNumberLength, MaxPhoneNumberLength)));

        public static CovidPassportUser CreateNewP9User()
        {
            CovidPassportUser validUser = new CovidPassportUser("Test McTestPerson", DateTime.UtcNow.AddYears(-20), "test@test.com", "0123456789", "0000000000", "", "", "P9");
            return validUser;
        }
    }
}
