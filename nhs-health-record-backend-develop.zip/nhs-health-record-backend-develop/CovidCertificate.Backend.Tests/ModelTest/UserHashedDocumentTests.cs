﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Tests.TestHelpers;
using CovidCertificate.Backend.Utils;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace CovidCertificate.Backend.Tests.ModelTest
{
    public class UserHashedDocumentTests
    {
        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public void UserHashedDocument_InstantiateUserHashedDocument(CovidPassportUser user)
        {
            // Arrange
            var userHashedDocument = new UserHashedDocument(user.Name, user.DateOfBirth, user.PhoneNumber, user.EmailAddress, user.NhsNumber);
            var jsonUserHashedDocument = JsonConvert.SerializeObject(userHashedDocument);

            // Act
            var deserializedUserHashedDocument = JsonConvert.DeserializeObject<UserHashedDocument>(jsonUserHashedDocument);

            // Assert
            Assert.NotNull(userHashedDocument);
            Assert.NotNull(userHashedDocument.PartitionKey);

            Assert.NotNull(deserializedUserHashedDocument);
            Assert.NotNull(deserializedUserHashedDocument.PartitionKey);
            Assert.Equal(deserializedUserHashedDocument.PartitionKey, StringUtils.GetValueHash(user.Name, user.DateOfBirth));

        }
    }
}
