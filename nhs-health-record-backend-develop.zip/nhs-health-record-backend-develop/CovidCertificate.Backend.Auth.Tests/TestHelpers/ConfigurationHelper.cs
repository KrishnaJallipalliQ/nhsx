﻿using System;
using CovidCertificate.Backend.Models.Settings;
using Microsoft.Extensions.Configuration;

namespace CovidCertificate.Backend.Auth.Tests.TestHelpers
{
    public class ConfigurationHelper
    {
        public static IConfigurationRoot GetIConfigurationRoot()
        {
            var path = AppContext.BaseDirectory + "Settings/";

            return new ConfigurationBuilder()
                .SetBasePath(path)
                .AddJsonFile("appsettings.json", optional: true)
                .AddJsonFile("appsettings.local.json", optional:true)
                .AddEnvironmentVariables()
                .Build();
        }

        public static NhsLoginSettings GetNhsLoginSettings()
        {
            var configuration = new NhsLoginSettings();

            var iConfig = GetIConfigurationRoot();

            iConfig
                .GetSection("NhsLoginConfig")
                .Bind(configuration);

            return configuration;
        }
    }
}
