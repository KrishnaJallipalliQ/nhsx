﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.ResponseDtos;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IDomesticExemptionCache
    {
        public Task<IDictionary<string, DomesticExemption>> GetDomesticExemptions();
    }
}
