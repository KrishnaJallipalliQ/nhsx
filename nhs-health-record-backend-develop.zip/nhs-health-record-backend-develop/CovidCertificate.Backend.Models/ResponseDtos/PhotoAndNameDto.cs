﻿namespace CovidCertificate.Backend.Models.ResponseDtos
{
    public class PhotoAndNameDto
    {
        public string Name { get; set; }
        public string Picture { get; set; }
    }
}
