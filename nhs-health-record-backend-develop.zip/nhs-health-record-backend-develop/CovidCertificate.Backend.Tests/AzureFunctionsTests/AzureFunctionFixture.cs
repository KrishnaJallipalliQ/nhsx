﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Delegates;
using CovidCertificate.Backend.Models.Interfaces;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Services;
using CovidCertificate.Backend.Services.KeyServices;
using CovidCertificate.Backend.Tests.TestHelpers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using MongoDB.Bson;
using Moq;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using JsonWebKey = Azure.Security.KeyVault.Keys.JsonWebKey;

namespace CovidCertificate.Backend.Tests.AzureFunctionsTests
{
    public class AzureFunctionFixture<T> : IDisposable where T : class, IMongoDocument
    {
        public Mock<IMongoRepository<T>> MongoRepository { get; private set; }
        public IJwtValidator JwtValidator { get; private set; }
        public IJwtGenerator JwtGenerator { get; private set; }
        public List<T> Collection { get; private set; }
        public Mock<IQueueService> QueueServiceMock { get; private set; }
        /// <summary>
        /// The Azure service bus queue name the <see cref="QueueServiceMock"/> are mocked with.
        /// </summary>
        public string AzureServiceBusQueueName { get; private set; }


        public AzureFunctionFixture()
        {
            this.MongoRepository = SetupMongoRepository();
            this.JwtValidator = SetupJwtValidator();
            var keyRing = SetupKeyRing();
            this.JwtGenerator = SetupJwtGenerator(keyRing);
            this.AzureServiceBusQueueName = ArrangeTestHelper.CreateRandomString(8);
            this.QueueServiceMock = SetupQueueServiceMock();
        }



        public void Dispose() => Collection.Clear();

        private Mock<IMongoRepository<T>> SetupMongoRepository()
        {
            Collection = new List<T>();
            var mongoRepositoryMock = new Mock<IMongoRepository<T>>();

            mongoRepositoryMock.Setup(x => x.DeleteById(It.IsAny<string>())).Callback<string>(str =>
            {
                var tempObjectId = new ObjectId(str);
                var toRemove = Collection.Find(doc => doc.Id == tempObjectId);
                Collection.Remove(toRemove);
            });
            mongoRepositoryMock.Setup(x => x.DeleteByIdAsync(It.IsAny<string>())).Callback<string>(str =>
            {
                var tempObjectId = new ObjectId(str);
                var toRemove = Collection.Find(doc => doc.Id == tempObjectId);
                Collection.Remove(toRemove);
            });
            mongoRepositoryMock.Setup(x => x.DeleteMany(It.IsAny<Expression<Func<T, bool>>>())).Callback<Expression<Func<T, bool>>>(e => Collection.RemoveAll(e.Compile().Invoke));
            mongoRepositoryMock.Setup(x => x.DeleteManyAsync(It.IsAny<Expression<Func<T, bool>>>())).Callback<Expression<Func<T, bool>>>(e => Collection.RemoveAll(e.Compile().Invoke));
            mongoRepositoryMock.Setup(x => x.DeleteOne(It.IsAny<Expression<Func<T, bool>>>())).Callback<Expression<Func<T, bool>>>(e =>
            {
                var doc = Collection.Find(e.Compile().Invoke);
                Collection.Remove(doc);
            });
            mongoRepositoryMock.Setup(x => x.DeleteOneAsync(It.IsAny<Expression<Func<T, bool>>>())).Callback<Expression<Func<T, bool>>>(e =>
            {
                var doc = Collection.Find(e.Compile().Invoke);
                Collection.Remove(doc);
            });
            mongoRepositoryMock.Setup(x => x.FindAll(It.IsAny<Expression<Func<T, bool>>>())).Returns((Expression<Func<T, bool>> e) => Collection.FindAll(e.Compile().Invoke));
            mongoRepositoryMock.Setup(x => x.FindAllAsync(It.IsAny<Expression<Func<T, bool>>>())).ReturnsAsync((Expression<Func<T, bool>> e) => Collection.FindAll(e.Compile().Invoke));
            mongoRepositoryMock.Setup(x => x.FindById(It.IsAny<string>())).Returns<string>(str => Collection.FindAll(doc => doc.Id == new ObjectId(str)).FirstOrDefault());
            mongoRepositoryMock.Setup(x => x.FindByIdAsync(It.IsAny<string>())).ReturnsAsync((string str) => Collection.FindAll(doc => doc.Id == new ObjectId(str)).FirstOrDefault());
            mongoRepositoryMock.Setup(x => x.FindOne(It.IsAny<Expression<Func<T, bool>>>())).Returns((Expression<Func<T, bool>> e) => Collection.FirstOrDefault(e.Compile().Invoke));
            mongoRepositoryMock.Setup(x => x.FindOneAsync(It.IsAny<Expression<Func<T, bool>>>())).ReturnsAsync((Expression<Func<T, bool>> e) => Collection.FirstOrDefault(e.Compile().Invoke));
            mongoRepositoryMock.Setup(x => x.InsertMany(It.IsAny<ICollection<T>>())).Callback<ICollection<T>>(docs => Collection.AddRange(docs));
            mongoRepositoryMock.Setup(x => x.InsertManyAsync(It.IsAny<ICollection<T>>())).Callback<ICollection<T>>(docs => Collection.AddRange(docs));
            mongoRepositoryMock.Setup(x => x.InsertOne(It.IsAny<T>())).Callback<T>(doc => Collection.Add(doc));
            mongoRepositoryMock.Setup(x => x.InsertOneAsync(It.IsAny<T>())).Callback<T>(doc => Collection.Add(doc));
            mongoRepositoryMock.Setup(x => x.ReplaceOne(It.IsAny<T>())).Callback<T>(newDoc =>
            {
                var oldDoc = Collection.Find(doc => doc.Id == newDoc.Id);
                Collection.Remove(oldDoc);
                Collection.Add(newDoc);
            });
            mongoRepositoryMock.Setup(x => x.ReplaceOneAsync(It.IsAny<T>())).Callback<T>(newDoc =>
            {
                var oldDoc = Collection.Find(doc => doc.Id == newDoc.Id);
                Collection.Remove(oldDoc);
                Collection.Add(newDoc);
            });

            return mongoRepositoryMock;
        }

        private KeyRing SetupKeyRing()
        {
            var memoryConfigurationProvider = new MemoryConfigurationProvider(new MemoryConfigurationSource());
            var configurationRoot = new ConfigurationRoot(new List<IConfigurationProvider> { memoryConfigurationProvider });
            configurationRoot["VaultUri"] = "https://localhost";
            return new KeyRing(configurationRoot, () => new Dictionary<string, KeyRing.KeyOps>());
        }

        private JwtValidator SetupJwtValidator()
        {
            var JwtValidationParameterFetcherMock = new Mock<IJwtValidationParameterFetcher>(MockBehavior.Strict);
            JwtValidationParameterFetcherMock.Setup(x => x.GetValidationParameters()).ReturnsAsync(new TokenValidationParameters()
            {
                ValidateIssuer = false,
                ValidateAudience = false,
                ValidateIssuerSigningKey = false,
                ValidateLifetime = false,
                RequireExpirationTime = false,
                RequireAudience = false,
                RequireSignedTokens = false,
                ValidateActor = false,
                ValidateTokenReplay = false,
                TryAllIssuerSigningKeys = false,
                SignatureValidator = (token, validationParameters) => new JwtSecurityToken(token),
            });

            var ValidationServiceResolverMock = new Mock<ValidationServiceResolver>(MockBehavior.Strict);
            ValidationServiceResolverMock.Setup(x => x.Invoke(It.IsAny<string>())).Returns(JwtValidationParameterFetcherMock.Object);
            return new JwtValidator(ValidationServiceResolverMock.Object, new Mock<ILogger<JwtValidator>>().Object);
        }

        private JwtGeneratorService SetupJwtGenerator(KeyRing keyRing)
        {
            var covidJwtSettings = new CovidJwtSettings() { Audience = string.Empty, Issuer = "https://nhsx.gov" };
            return new JwtGeneratorService(covidJwtSettings, new Mock<ILogger<JwtGeneratorService>>().Object, keyRing);
        }

        private Mock<IQueueService> SetupQueueServiceMock()
        {
            var queueServiceMock = new Mock<IQueueService>();
            queueServiceMock.Setup(x => x.SendMessage<T>(AzureServiceBusQueueName, It.IsAny<T>())).ReturnsAsync(true);
            queueServiceMock.Setup(x => x.SendMessage(AzureServiceBusQueueName, It.IsAny<string>())).ReturnsAsync(true);
            queueServiceMock.Setup(x => x.SendMessages(AzureServiceBusQueueName, It.IsAny<IEnumerable<T>>())).ReturnsAsync((string queueName, IEnumerable<T> messages) => messages.Count());
            queueServiceMock.Setup(x => x.SendMessages<T>(AzureServiceBusQueueName, It.IsAny<IEnumerable<T>>())).ReturnsAsync((string queueName, IEnumerable<T> messages) => messages.Count());
            return queueServiceMock;
        }
    }
}
