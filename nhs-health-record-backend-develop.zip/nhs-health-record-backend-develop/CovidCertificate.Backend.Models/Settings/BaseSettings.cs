﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.Settings
{
    public class BaseSettings
    {
        public string KeyVaultSecret { get; set; }

        public BaseSettings(IConfiguration configuration, string secretName)
        {
            KeyVaultSecret = configuration[secretName];
        }

        public BaseSettings() { }
    }


}