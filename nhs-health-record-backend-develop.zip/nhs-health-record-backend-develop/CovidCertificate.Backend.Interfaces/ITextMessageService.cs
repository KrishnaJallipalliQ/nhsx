﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface ITextMessageService
    {
        public Task SendTwoFactorTextMessage(string phoneNumber, string twoFactorCode);
    }
}
