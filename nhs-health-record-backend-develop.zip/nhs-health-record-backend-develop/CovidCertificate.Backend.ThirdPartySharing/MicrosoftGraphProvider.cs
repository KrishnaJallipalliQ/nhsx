﻿using System;
using System.Threading.Tasks;
using Microsoft.Graph;

namespace CovidCertificate.Backend.ThirdPartySharing
{
    public class MicrosoftGraphProvider : IGraphProvider
    {
        private readonly IGraphServiceClient _graphServiceClient;

        public MicrosoftGraphProvider(IGraphServiceClient graphServiceClient)
        {
            _graphServiceClient = graphServiceClient;
        }


        public async Task<string> GetDisplayNameByApplicationId(string applicationId)
        {
            var apps = await _graphServiceClient.Applications.Request()
                            .Filter($"appId eq '{applicationId}'")
                            .GetAsync();

            if (apps == null || apps.Count == 0 || string.IsNullOrEmpty(apps[0].DisplayName))
            {
                return string.Empty;
            }

            return apps[0].DisplayName;
        }
    }
}
