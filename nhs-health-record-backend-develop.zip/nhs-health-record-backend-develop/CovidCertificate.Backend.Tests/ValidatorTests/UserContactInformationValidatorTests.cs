﻿using System;

using System.Threading.Tasks;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Validators;
using CovidCertificate.Backend.Tests.TestHelpers;
using FluentValidation;
using Xunit;

namespace CovidCertificate.Backend.Tests.ValidatorTests
{
    public class UserContactInformationValidatorTests
    {
        private readonly UserContactInformationValidator uat;
        private const string ValidEmail = "name@domain.it";
        private const string ValidName = "Maria Tester Jorgensen";
        private readonly DateTime validDateOfBirth = DateTime.UtcNow.AddYears(-20);
        private const string ValidPhoneNumber = "+447000123456";

        public UserContactInformationValidatorTests()
        {
            uat = new UserContactInformationValidator();
        }

        [Fact]
        public async Task ValidateAndThrowOnAsync_ThrowException_PhoneAndEmailBothEmpty()
        {
            // Arrange
            CovidPassportUser user =
                new CovidPassportUser(ValidName, validDateOfBirth, string.Empty, string.Empty);

            // Act
            Func<Task> act = async () => await uat.ValidateAndThrowAsync(user);

            // Assert
            var exEmptyContact = await Assert.ThrowsAsync<ValidationException>(act);
            Assert.Equal("Either a phone number or email address must be specified.", exEmptyContact.Message);
        }

        [Fact]
        public async Task ValidateAndThrowOnAsync_ThrowException_PhoneAndEmailBothNull()
        {
            // Arrange
            CovidPassportUser user =
                new CovidPassportUser(ValidName, validDateOfBirth, null, null);

            // Act
            Func<Task> act = async () => await uat.ValidateAndThrowAsync(user);

            // Assert
            var ex = await Assert.ThrowsAsync<ValidationException>(act);
            Assert.Equal("Either a phone number or email address must be specified.", ex.Message);
        }

        [Fact]
        public async Task ValidateAndThrowOnAsync_ThrowException_InvalidEmailAddressFormat()
        {
            // Arrange
            CovidPassportUser user =
                new CovidPassportUser(ValidName, validDateOfBirth, "INVALID", ValidPhoneNumber);

            // Act
            Func<Task> act = async () => await uat.ValidateAndThrowAsync(user);

            // Assert
            var ex = await Assert.ThrowsAsync<ValidationException>(act);
            Assert.Equal("Invalid email format.", ex.Message);
        }

        [Fact]
        public async Task ValidateAndThrowOnAsync_ThrowException_InvalidPhoneNumberFormat()
        {
            // Arrange
            CovidPassportUser user =
                new CovidPassportUser(ValidName, validDateOfBirth, ValidEmail, "INVALID");

            // Act
            Func<Task> act = async () => await uat.ValidateAndThrowAsync(user);

            // Assert
            var ex = await Assert.ThrowsAsync<ValidationException>(act);
            Assert.Equal("Invalid phone number format.", ex.Message);
        }

        [Theory]
        [InlineData(1, 1, 2)]
        [InlineData(1, 2, 1)]
        [InlineData(2, 1, 1)]
        public async Task ValidateAndThrowOnAsync_NoExceptions_ValidShortEmailAddress(int usernameLength, int domainNameLength, int domainLength)
        {
            // Arrange
            var validShortEmail =
                ArrangeTestHelper.CreateRandomEmailString(usernameLength, domainNameLength, domainLength);
            CovidPassportUser user =
                new CovidPassportUser(ValidName, validDateOfBirth, validShortEmail, ValidPhoneNumber);

            // Act
            Func<Task> act = async () => await uat.ValidateAndThrowAsync(user);

            // Assert
            var ex = await Record.ExceptionAsync(act);
            Assert.Null(ex);
        }

        [Fact]
        public async Task ValidateAndThrowOnAsync_ThrowExceptions_InvalidShortEmailAddress()
        {
            // Arrange
            var tooShortEmail =
                ArrangeTestHelper.CreateRandomEmailString(1, 1, 1);
            CovidPassportUser user =
                new CovidPassportUser(ValidName, validDateOfBirth, tooShortEmail, ValidPhoneNumber);

            // Act
            Func<Task> act = async () => await uat.ValidateAndThrowAsync(user);

            // Assert
            var ex = await Assert.ThrowsAsync<ValidationException>(act);
            Assert.Equal("Minimum characters in email address is 6", ex.Message);
        }

        [Theory]
        [InlineData(64, 1, 187)]
        [InlineData(64, 187, 1)]
        [InlineData(1, 1, 250)]
        [InlineData(1, 250, 1)]
        public async Task ValidateAndThrowOnAsync_NoExceptions_ValidLongEmailAddress(int usernameLength, int domainNameLength, int domainLength)
        {
            // Arrange
            var validLongEmail =
                ArrangeTestHelper.CreateRandomEmailString(usernameLength, domainNameLength, domainLength);
            CovidPassportUser user =
                new CovidPassportUser(ValidName, validDateOfBirth, validLongEmail, ValidPhoneNumber);

            // Act
            Func<Task> act = async () => await uat.ValidateAndThrowAsync(user);

            // Assert
            var ex = await Record.ExceptionAsync(act);
            Assert.Null(ex);
        }

        [Theory]
        [InlineData("stuff.and.nonsense@domain.co.uk")]
        [InlineData("emailaddress+1@domain.com")]
        [InlineData("stuff.and-nonsense@test-test.domain.org")]
        public async Task ValidateAndThrowOnAsync_NoExceptions_ValidEmailFormats(string email)
        {
            // Arrange
            CovidPassportUser user =
                new CovidPassportUser(ValidName, validDateOfBirth, email, ValidPhoneNumber);

            // Act
            Func<Task> act = async () => await uat.ValidateAndThrowAsync(user);

            // Assert
            var ex = await Record.ExceptionAsync(act);
            Assert.Null(ex);
        }

        [Theory]
        [InlineData(64, 1, 188)]
        [InlineData(64, 188, 1)]
        [InlineData(1, 1, 251)]
        [InlineData(1, 251, 1)]
        public async Task ValidateAndThrowOnAsync_ThrowExceptions_InvalidLongEmailAddress(int usernameLength, int domainNameLength, int domainLength)
        {
            // Arrange
            var invalidLongEmail =
                ArrangeTestHelper.CreateRandomEmailString(usernameLength, domainNameLength, domainLength);
            CovidPassportUser user =
                new CovidPassportUser(ValidName, validDateOfBirth, invalidLongEmail, ValidPhoneNumber);

            // Act
            Func<Task> act = async () => await uat.ValidateAndThrowAsync(user);

            // Assert
            var ex = await Assert.ThrowsAsync<ValidationException>(act);
            Assert.Equal("Maximum characters in email address is 254", ex.Message);
        }

        [Theory]
        [InlineData(65, 1, 1)]
        public async Task ValidateAndThrowOnAsync_ThrowExceptions_InvalidLongUserNameEmailAddress(int usernameLength, int domainNameLength, int domainLength)
        {
            // Arrange
            var invalidLongEmail =
                ArrangeTestHelper.CreateRandomEmailString(usernameLength, domainNameLength, domainLength);
            CovidPassportUser user =
                new CovidPassportUser(ValidName, validDateOfBirth, invalidLongEmail, ValidPhoneNumber);

            // Act
            Func<Task> act = async () => await uat.ValidateAndThrowAsync(user);

            // Assert
            var ex = await Assert.ThrowsAsync<ValidationException>(act);
            Assert.Equal("Maximum characters before “@”: 64", ex.Message);
        }
    }
}
