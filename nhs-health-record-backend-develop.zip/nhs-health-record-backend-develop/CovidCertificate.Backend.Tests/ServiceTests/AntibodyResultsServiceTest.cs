﻿using CovidCertificate.Backend.Services;
using Moq;
using System;
using Xunit;
using Microsoft.Extensions.Logging;
using CovidCertificate.Backend.Interfaces;
using Microsoft.Extensions.Configuration;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.NhsApiIntegration.Interfaces;
using System.Collections.Generic;
using Hl7.Fhir.Model;
using static CovidCertificate.Backend.Tests.TestHelpers.FhirBundleMapperTestHelper;
using System.Linq;
using Task = System.Threading.Tasks.Task;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class AntibodyResultsServiceTest
    {
        private readonly Mock<ILogger<AntibodyResultsService>> antibodyResultsServiceLogger = new Mock<ILogger<AntibodyResultsService>>();
        private readonly Mock<ILogger<TestResultFilter>> testResultFilterLogger = new Mock<ILogger<TestResultFilter>>();
        private readonly Mock<IConfiguration> configurationMock = new Mock<IConfiguration>();
        private readonly Mock<IRedisCacheService> redisCache = new Mock<IRedisCacheService>();
        private readonly Mock<IMappingCache> mappingMock = new Mock<IMappingCache>();
        private readonly Mock<INhsdFhirApiService> nhsdFhirApiServiceMock = new Mock<INhsdFhirApiService>();
        private readonly Mock<IMongoRepository<AntibodyResult>> antibodyMongoRepositoryMock = new Mock<IMongoRepository<AntibodyResult>>();
        private readonly Mock<IFhirBundleMapper<AntibodyResultNhs>> fhirBundleMapperMock = new Mock<IFhirBundleMapper<AntibodyResultNhs>>();
        private readonly Mock<IAntibodyResultsService> antibodyResultsService = new Mock<IAntibodyResultsService>();
        private readonly TestResultFilter testResultFilter;
        private readonly string idToken = "eyJzdWIiOiJhMzMyYjE0ZS02NTQzLTRkODktYjVhYy0xZTU4MmJlOTdkZDUiLCJhdWQiOiJoZWFsdGhyZWNvcmRzIiwia2lkIjoiZjYwZWI0NmZmOGFiZjBiZjllOTE3ZWVlNjA4NmM1ZmE0YTE2MmE1ZCIsImlzcyI6Imh0dHBzOi8vYXV0aC5hb3Muc2lnbmluLm5ocy51ayIsInR5cCI6IkpXVCIsImV4cCI6MTYxODMxNTU2MCwiaWF0IjoxNjE4MzExOTYwLCJhbGciOiJSUzUxMiIsImp0aSI6Ijg5MTE1ZjBjLTQ0OWYtNGUzYS04NjFhLTc5ZmU0OGFiMGYwZCJ9.eyJzdWIiOiJhMzMyYjE0ZS02NTQzLTRkODktYjVhYy0xZTU4MmJlOTdkZDUiLCJiaXJ0aGRhdGUiOiIxOTEwLTEyLTIyIiwibmhzX251bWJlciI6Ijk0Mzc1NzM5OTkiLCJpc3MiOiJodHRwczovL2F1dGguYW9zLnNpZ25pbi5uaHMudWsiLCJ2dG0iOiJodHRwczovL2F1dGguYW9zLnNpZ25pbi5uaHMudWsvdHJ1c3RtYXJrL2F1dGguYW9zLnNpZ25pbi5uaHMudWsiLCJhdWQiOiJoZWFsdGhyZWNvcmRzIiwiaWRfc3RhdHVzIjoidmVyaWZpZWQiLCJ0b2tlbl91c2UiOiJpZCIsInN1cm5hbWUiOiJBQkVMUyIsImF1dGhfdGltZSI6MTYxODMxMTk1OCwidm90IjoiUDkuQ3AuQ2QiLCJpZGVudGl0eV9wcm9vZmluZ19sZXZlbCI6IlA5IiwiZXhwIjoxNjE4MzE1NTYwLCJpYXQiOjE2MTgzMTE5NjAsImZhbWlseV9uYW1lIjoiQUJFTFMiLCJqdGkiOiI4OTExNWYwYy00NDlmLTRlM2EtODYxYS03OWZlNDhhYjBmMGQifQ.CFmG8x6t4AoJuWS-3POo-VsqrTRUc_i-18ZFtpV4OzIuYwNq3fmhVLQOHetda2p6TEaYx-asu2iuEPBJSc339xstkQio_9Zxfe19In9sfa0VQlXr0XDM8K5IPk0XTrAaMSTmTj6IlMr8AWtWqS09kMFMIoPBwqTUCgUX4eVA9JKtkIFZwHkWUbK77E_SAW97XJs_LPHENic6E5iAN4EA2iGNLZSgiPa3mzENU3tjg3tE84JSJxRVsFlLlCKhHuFH1iCuuiPVjmi02l81Vn78k3-yy3cWGhPbQvn8H8KZs9-flYa_nIT-brGVdmMD50P1FqF1wNZJCnk2rmL84a73_g";
        private readonly string positive = "Positive";
        private readonly string empty = string.Empty;
        private readonly string positiveCode = "1240581000000104";
        private readonly string testKitLFT = "LFT";
        private readonly string testKitTest = "test";
        private readonly string processingLabCodeMK = "MK";
        private readonly string validityTypeTest = "test";

        public AntibodyResultsServiceTest()
        {
            testResultFilter = new TestResultFilter(testResultFilterLogger.Object);
        }

        [Fact]
        public async Task GetAntibody_ReturnsAntibodyResults()
        {
            //Arrange
            Bundle bundle = new Bundle();
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit(positiveCode, testKitLFT, processingLabCodeMK));

            List<AntibodyResultNhs> antibodyResults = new List<AntibodyResultNhs>();
            antibodyResults.Add(new AntibodyResultNhs(DateTime.Today, positive, validityTypeTest, testKitTest));

            nhsdFhirApiServiceMock.Setup(x => x.GetAntibodyTestResults(It.IsAny<string>())).ReturnsAsync(bundle);
            fhirBundleMapperMock.Setup(x => x.ConvertBundle(It.IsAny<Bundle>())).ReturnsAsync(antibodyResults);

            var service = new AntibodyResultsService(antibodyResultsServiceLogger.Object,
               nhsdFhirApiServiceMock.Object,
               fhirBundleMapperMock.Object,
               redisCache.Object,
               configurationMock.Object);


            //Act
            var results = (await service.GetAntibodyResults(idToken)).ToList();

            //Assert
            Assert.Equal(positive, results.FirstOrDefault()?.Result);
        }
    }
}
