﻿using CovidCertificate.Backend.International.Interfaces;
using CovidCertificate.Backend.International.Services;
using CovidCertificate.Backend.Models.DataModels;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CovidCertificate.Backend.International.Tests.Helpers;
using CovidCertificate.Backend.Models.Interfaces.UserInterfaces;
using CovidCertificate.Backend.Services.KeyServices;
using FluentAssertions;
using Microsoft.Extensions.Configuration;
using PeterO.Cbor;

namespace CovidCertificate.Backend.International.Tests
{
    public class EncoderServiceTest
    {
        private readonly Mock<ICondensorService> condensorMock;
        private readonly Mock<ICBORFlow> cborFlowMock;

        public EncoderServiceTest()
        {
            condensorMock = new Mock<ICondensorService>();
            condensorMock.Setup(x => x.CondenseCBOR(It.IsAny<IUserCBORInformation>(), It.IsAny<long>(),
                It.IsAny<List<Vaccine>>(), It.IsAny<string>(), It.IsAny<DateTime?>(), It.IsAny<int>(),
                It.IsAny<string>())).Returns(CBORObject.NewMap());

            cborFlowMock = new Mock<ICBORFlow>();

            var KeyRing = TestHelpers.SetupKeyRing();
            
            condensorMock.Setup(m => m.CondenseCBOR<Vaccine>(It.IsAny<CovidPassportUser>(), DateTimeOffset.UtcNow.ToUnixTimeSeconds(), It.IsAny<IEnumerable<Vaccine>>(), It.IsAny<string>(), It.IsAny<DateTime>(),  0, null));
        }

        [Fact]
        public async Task ShouldEncodePassedData()
        {
            // Arrange
            var user = new DAUser("name", "familyName", "givenName", DateTime.Now.AddYears(-20));

            var certificateGenerationTime = DateTimeOffset.Now.ToUnixTimeSeconds();

            var vaccines = new List<Vaccine>
            {
                new Vaccine(
                    1,
                    DateTime.Now.AddDays(-20),
                    Tuple.Create<string, string>("manufacturer1", "m1"),
                    Tuple.Create<string, string>("disease1", "d1"),
                    Tuple.Create<string, string>("vaccineType1", "vt1"),
                    Tuple.Create<string, string>("produce1", "p1"),
                    "NLZMVQEATNZQBXLVHUCG",
                    "GB",
                    "NHS Digital",
                    2,
                    "Site",
                    "Display Name",
                    "Snomed Code",
                    DateTime.MinValue
                )
            };

            var keyRingMock = new Mock<IKeyRing>();
            keyRingMock.Setup(x => x.GetRandomKey()).Returns("keyId");

            var encoderService = new EncoderService(condensorMock.Object, cborFlowMock.Object,
                keyRingMock.Object);
            // Act
            var result = await encoderService.EncodeFlowAsync(
                user,
                certificateGenerationTime,
                vaccines,
                "SomeUVCI",
                DateTime.Now.AddMonths(6),
                0,
                "UK");

            // Assert
            result.Should().NotBeEmpty();
            result.Should().StartWith("HC1:");
        }

    }
}
