﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Exceptions;
using CovidCertificate.Backend.Services;
using Hl7.Fhir.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;
using static CovidCertificate.Backend.Tests.TestHelpers.FhirBundleMapperTestHelper;
using Task = System.Threading.Tasks.Task;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class FhirBundleMapperTest
    {
        private readonly AntibodyFhirBundleMapper antibodyFhirBundleMapper;
        private readonly DiagnosticTestFhirBundleMapper diagnosticTestFhirBundleMapper;
        private readonly Mock<IMappingCache> mockMappings = new Mock<IMappingCache>();
        private readonly Mock<ILogger<DiagnosticTestFhirBundleMapper>> mockLogger = new Mock<ILogger<DiagnosticTestFhirBundleMapper>>(); 
        private readonly string positive = "Positive";
        private readonly string negative = "Negative";
        private readonly string voidResult = "Void";
        private readonly string selfTest = "SelfTest";
        private readonly string assist = "Assist";
        private readonly string positiveCode = "1240581000000104";
        private readonly string negativeCode = "1322791000000100";
        private readonly string voidCode = "1322821000000105";
        private readonly string testKitLFT = "LFT";
        private readonly string processingLabCodeMK = "MK";
        private readonly string processingLabCodeLfdSelfTest = "LFDSELFTEST";
        private readonly string processingLabCodeLftSelfTest = "LFTSELFTEST";
        private readonly string processingLabCodeSelfServe = "SELFSERVE";
        private readonly string processingLabCodeLfdSelfImageReader = "LFDSELFIMAGEREADER";
        private readonly string pcrString = "PCR";
        private readonly string unknownString = "UNKNOWN";

        private Dictionary<string, Dictionary<string, string>> mappings;

        public FhirBundleMapperTest()
        {
            var json = GetMapperJson();
            mappings = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, string>>>(json);
            mockMappings.Setup(m => m.GetMappings()).ReturnsAsync(mappings);
            antibodyFhirBundleMapper = new AntibodyFhirBundleMapper(mockMappings.Object);
            diagnosticTestFhirBundleMapper = new DiagnosticTestFhirBundleMapper(mockMappings.Object, mockLogger.Object);
        }

        #region DiagnosticMapper
        [Fact]
        public async Task FhirBundleMapperTest_MapBundleToTestResultReturnType()
        {
            //Arrange
            Bundle bundle = new Bundle();

            //Act
            var result = (await diagnosticTestFhirBundleMapper.ConvertBundle(bundle)).ToList();

            //Assert
            Assert.IsType<List<TestResultNhs>>(result);
        }

        [Fact]
        public async Task FhirBundleMapperTest_MapNullBundleToTestResult()
        {
            //Arrange
            Bundle bundle = null;
            List<TestResultNhs> emptyTestResultList = new List<TestResultNhs>();

            //Act
            var result = (await diagnosticTestFhirBundleMapper.ConvertBundle(bundle)).ToList();

            //Assert
            Assert.Equal(emptyTestResultList, result);
        }

        [Fact]
        public async Task FhirBundleMapperTest_MapBundleToTestResultCode()
        {
            //Arrange
            Bundle bundle = new Bundle();
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit(positiveCode, testKitLFT, processingLabCodeMK));
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit(negativeCode, testKitLFT, processingLabCodeMK));
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit(voidCode, testKitLFT, processingLabCodeMK));

            //Act
            var result = (await diagnosticTestFhirBundleMapper.ConvertBundle(bundle)).ToList();

            //Assert
            Assert.Equal(positive, result[0].Result);
            Assert.Equal(negative, result[1].Result);
            Assert.Equal(voidResult, result[2].Result);
        }


        [Fact]
        public async Task FhirBundleMapperTest_MapBundleToTestResultProcessingCode()
        {
            //Arrange
            Bundle bundle = new Bundle();
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit(positiveCode, testKitLFT, processingLabCodeLfdSelfTest));
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit(positiveCode, testKitLFT, processingLabCodeLftSelfTest));
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit(positiveCode, testKitLFT, processingLabCodeSelfServe));
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit(positiveCode, testKitLFT, processingLabCodeLfdSelfImageReader));
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit(positiveCode, testKitLFT, string.Empty));

            //Act
            var result = (await diagnosticTestFhirBundleMapper.ConvertBundle(bundle)).ToList();

            //Assert
            Assert.Equal(selfTest, result[0].ProcessingCode);
            Assert.Equal(selfTest, result[1].ProcessingCode);
            Assert.Equal(selfTest, result[2].ProcessingCode);
            Assert.Equal(selfTest, result[3].ProcessingCode);
            Assert.Equal(assist, result[4].ProcessingCode);
        }

        [Fact]
        public async Task FhirBundleMapperTest_MapNullDeviceIdentifierToPCR()
        {
            //Arrange
            var bundle = new Bundle();
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit(positiveCode, null, processingLabCodeMK));

            //Act
            var result = (await diagnosticTestFhirBundleMapper.ConvertBundle(bundle)).ToList();

            //Assert
            Assert.Equal(string.Empty, result.First().TestKit);
            Assert.Equal(pcrString, result.First().ValidityType);
        }

        [Fact]
        public async Task FhirBundleMapperTest_MapNullDeviceToUnknown()
        {
            //Arrange
            var bundle = new Bundle();
            Identifier identifier = null;
            bundle.Entry.Add(CreateObservationEntryComponentWithIdentifier(positiveCode, identifier, processingLabCodeMK));

            //Act
            var result = (await diagnosticTestFhirBundleMapper.ConvertBundle(bundle)).ToList();

            //Assert
            Assert.Null(result.First().TestKit);
            Assert.Equal(unknownString, result.First().ValidityType);
        }

        [Fact]
        public async Task FhirBundleMapperTest_MapUnseenTestKitToUnknown()
        {
            //Arrange
            var bundle = new Bundle();
            var testKit = "UnseenTestKit";
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit(positiveCode, testKit, processingLabCodeMK));

            //Act
            var result = (await diagnosticTestFhirBundleMapper.ConvertBundle(bundle)).ToList();

            //Assert
            Assert.Equal(testKit.ToUpper(), result.First().TestKit);
            Assert.Equal(unknownString, result.First().ValidityType);
        }

        [Fact]
        public async Task FhirBundleMapperTest_NullDateTimeThrowsAwayData()
        {
            //Arrange
            var bundle = new Bundle();
            bundle.Entry.Add(CreateObservationEntryComponentWithDateTime(positiveCode, testKitLFT, processingLabCodeSelfServe, null));

            //Act
            var result = (await diagnosticTestFhirBundleMapper.ConvertBundle(bundle)).ToList();

            //Assert
            Assert.Empty(result);
        }

        [Fact]
        public async Task FhirBundleMapperTest_DiagnosticTestMappingExceptionThrowsAwayDataAndKeepsCorrectData()
        {
            //Arrange
            var bundle = new Bundle();
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit(negativeCode, pcrString, processingLabCodeMK));
            bundle.Entry.Add(CreateObservationEntryComponentWithDateTime(positiveCode, testKitLFT, processingLabCodeSelfServe, null));
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit(negativeCode, pcrString, processingLabCodeMK));

            //Act
            var result = (await diagnosticTestFhirBundleMapper.ConvertBundle(bundle)).ToList();

            //Assert
            Assert.Equal(2, result.Count());
            foreach(var test in result)
            {
                Assert.Equal(pcrString, test.ValidityType);
                Assert.Equal("Negative", test.Result);
            }
        }

        [Fact]
        public async Task FhirBundleMapperTest_NullResultCodeThrowsAwayData()
        {
            //Arrange
            var bundle = new Bundle();
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit(null, testKitLFT, processingLabCodeSelfServe));

            //Act
            var result = (await diagnosticTestFhirBundleMapper.ConvertBundle(bundle)).ToList();

            //Assert
            Assert.Empty(result);
        }

        [Fact]
        public async Task FhirBundleMapperTest_UnseenResultCodeThrowsAwayData()
        {
            //Arrange
            var bundle = new Bundle();
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit("UnseenResultCode", testKitLFT, processingLabCodeSelfServe));

            //Act
            var result = (await diagnosticTestFhirBundleMapper.ConvertBundle(bundle)).ToList();

            //Assert
            Assert.Empty(result);
        }

        [Theory]
        [InlineData("result")]
        [InlineData("selfTestValues")]
        [InlineData("staticValues")]
        [InlineData("type")]
        public async Task FhirBundleMapperTest_MissingKeysFromMappingThrowsException(string key)
        {
            //Arrange
            var bundle = new Bundle();
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit(negativeCode, pcrString, processingLabCodeMK));

            mappings.Remove(key);

            //Act & Assert
            await Assert.ThrowsAsync<Exception>(async () => await diagnosticTestFhirBundleMapper.ConvertBundle(bundle));
        }
        #endregion

        #region AntibodyMapper
        [Fact]
        public async Task MapBundleToAntibodyResultReturnType()
        {
            //Arrange
            Bundle bundle = new Bundle();

            //Act
            var result = (await antibodyFhirBundleMapper.ConvertBundle(bundle)).ToList();

            //Assert
            Assert.IsType<List<AntibodyResultNhs>>(result);
        }

        [Fact]
        public async Task MapNullBundleToAntibodyResult()
        {
            //Arrange
            Bundle bundle = null;
            List<AntibodyResultNhs> emptyAntibodyResultList = new List<AntibodyResultNhs>();

            //Act
            var result = (await antibodyFhirBundleMapper.ConvertBundle(bundle)).ToList();

            //Assert
            Assert.Equal(emptyAntibodyResultList, result);
        }

        [Fact]
        public async Task MapBundleToAntibodyResultCode()
        {
            //Arrange
            Bundle bundle = new Bundle();
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit(positiveCode, testKitLFT, processingLabCodeLfdSelfTest));
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit(negativeCode, testKitLFT, processingLabCodeLfdSelfTest));
            bundle.Entry.Add(CreateObservationEntryComponentWithTestKit(voidCode, testKitLFT, processingLabCodeLfdSelfTest));

            //Act
            var result = (await antibodyFhirBundleMapper.ConvertBundle(bundle)).ToList();

            //Assert
            Assert.Equal(positive, result[0].Result);
            Assert.Equal(negative, result[1].Result);
            Assert.Equal(voidResult, result[2].Result);
        }
        #endregion
    }
}