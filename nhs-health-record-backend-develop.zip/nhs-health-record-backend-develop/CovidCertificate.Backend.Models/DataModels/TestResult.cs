using CovidCertificate.Backend.Interfaces;
using Newtonsoft.Json;
using System;
using System.Text;

namespace CovidCertificate.Backend.Models.DataModels
{
    [Collection("Current-Test-Data")]
    public class TestResult : UserHashedDocument, IGenericResult
    {
        public TestResult(string name, DateTime dateOfBirth, string emailAddress, string phoneNumber, string nhsNumber, DateTime dateTimeOfTest, string result, string validityType,string testKit,string processingCode)
            : base(name, dateOfBirth, phoneNumber, emailAddress, nhsNumber)
        {
            this.DateTimeOfTest = dateTimeOfTest;
            this.Result = result;
            this.ValidityType = validityType;
            this.TestKit = testKit;
            this.ProcessingCode = processingCode;
        }
        [JsonConstructor]
        private TestResult(string id, [JsonProperty("PartitionKey")] string keyHash, [JsonProperty("PhoneHash")] string phoneNameAndDateOfBirthHash, [JsonProperty("EmailHash")] string emailNameAndDateOfBirthHash, [JsonProperty("NhsNumberHash")] string nhsNumberAndDateOfBirthHash,
           DateTime dateTimeOfTest, string result, string validityType,string testKit,string processingCode) : base(id, keyHash, phoneNameAndDateOfBirthHash, emailNameAndDateOfBirthHash, nhsNumberAndDateOfBirthHash)
        {
            this.DateTimeOfTest = dateTimeOfTest;
            this.Result = result;
            this.ValidityType = validityType;
            this.TestKit = testKit;
            this.ProcessingCode = processingCode;
        }

        [JsonRequired]
        public DateTime DateTimeOfTest { get; set; }
        [JsonRequired]
        public string Result { get; set; }
        [JsonRequired]
        public string ValidityType { get; set; }
        [JsonRequired]
        public string TestKit { get; set; }
        
        public string ProcessingCode { get; set; }
       
        public bool IsPositive() => string.Equals("Positive", Result, StringComparison.CurrentCultureIgnoreCase);

        public bool IsNegative() => string.Equals("Negative", Result, StringComparison.CurrentCultureIgnoreCase);
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("").Append(this.Result??"").AppendLine();
            sb.Append("").Append(this.ProcessingCode??"").AppendLine();
            sb.Append("").Append(this.TestKit??"").AppendLine();
            sb.Append("").Append(this.ValidityType??"").AppendLine();
            sb.Append("").Append(this.DateTimeOfTest).AppendLine();
            sb.Append("").Append(base.ToString()).AppendLine();
           
            return sb.ToString();
        }
    }
}
