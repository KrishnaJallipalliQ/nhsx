﻿namespace CovidCertificate.Backend.Models.Interfaces
{
    public interface IUserNhsInformation : IValidator
    {
        string NhsNumber { get; }
    }
}
