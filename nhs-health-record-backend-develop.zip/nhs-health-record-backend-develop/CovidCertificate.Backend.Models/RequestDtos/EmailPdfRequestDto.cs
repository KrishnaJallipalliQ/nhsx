﻿using System.Text;

namespace CovidCertificate.Backend.Models.RequestDtos
{
    public class EmailPdfRequestDto
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string PdfData { get; set; }
        public string LanguageCode { get; set; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Name:").Append(this.Name??"").AppendLine();
            sb.Append("Email:").Append(this.Email??"").AppendLine();
            sb.Append("PdfData:").Append(this.PdfData??"").AppendLine();
            sb.Append("LanguageCode:").Append(this.LanguageCode??"").AppendLine();
            return sb.ToString();
        }
    }
}
