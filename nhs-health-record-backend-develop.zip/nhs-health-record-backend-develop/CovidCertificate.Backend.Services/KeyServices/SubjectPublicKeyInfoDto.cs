﻿using Newtonsoft.Json;

namespace CovidCertificate.Backend.Services.KeyServices
{
    public class SubjectPublicKeyInfoDto
    {
        [JsonProperty("kid")]
        public string Kid { get; set; }
        [JsonProperty("publicKey")]
        public string PublicKey { get; set; }
    }
}
