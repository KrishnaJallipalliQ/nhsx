﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Utils;
using CovidCertificate.Backend.Utils.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Globalization;
using System.Threading.Tasks;

namespace CovidCertificate.Backend
{
    public class GetDomesticExemptionFunction
    {
        private readonly IDomesticExemptionService service;
        private readonly ILogger<GetDomesticExemptionFunction> logger;

        public GetDomesticExemptionFunction
            (IDomesticExemptionService domesticExemptionService, ILogger<GetDomesticExemptionFunction> logger)
        {
            this.service = domesticExemptionService;
            this.logger = logger;
        }
        [FunctionName("GetDomesticExemption")]
        public async Task<IActionResult> GetDomesticExemption(
            [HttpTrigger(AuthorizationLevel.Function, "get")] HttpRequest request)
        {
            logger.LogInformation($"{nameof(GetDomesticExemption)} was invoked");

            var nhsNumberRequest = request.Query["nhsNumber"];
            logger.LogTraceAndDebug($"nhsNumber: {nhsNumberRequest}");
            var dateOfBirthRequest = request.Query["dateOfBirth"];
            logger.LogTraceAndDebug($"dateOfBirth: {dateOfBirthRequest}");
            DateTime.TryParseExact(dateOfBirthRequest, DateUtils.DomesticExemptionDateFormat, null, DateTimeStyles.None, out DateTime dateOfBirth);

            var result = await service.GetDomesticExemption(nhsNumberRequest, dateOfBirth);
            logger.LogTraceAndDebug($"result data: {result}");
            logger.LogInformation($"{nameof(GetDomesticExemption)} has finished");

            if (result == default)
            {
                logger.LogInformation($"No domestic exemption data can be retrieved");
                return new NoContentResult();
            }
               

            return new OkObjectResult($"Found with reason: {result.Reason}");
        }
    }
}
