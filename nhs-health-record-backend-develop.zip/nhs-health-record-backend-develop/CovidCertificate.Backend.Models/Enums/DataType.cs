﻿namespace CovidCertificate.Backend.Models.Enums
{
    public enum DataType
    {
        Diagnostic,
        Vaccination,
        Immunity
    }
}
