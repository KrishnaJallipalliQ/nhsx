﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.RequestDtos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces.RemoteAccessCodeService
{
    public interface IRemoteAccessCodeService
    {
        /// <summary>
        /// Creates a two factor authorisation code
        /// </summary>
        /// <param name="remoteCodeRequest">The details of the remote code that needs creating</param>
        /// <returns></returns>
        Task<RemoteAccessCode> CreateCode(GenerateRemoteCodeRequestDto remoteCodeRequest, CovidPassportUser covidUser);

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="validationDto"></param>
        /// <returns></returns>
        Task<RemoteAccessCode> GetRemoteCode(FetchRemoteCovidStatusDto validationDto);


        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="thirdPartyDto"></param>
        /// <returns></returns>
        Task<RemoteAccessCode> GetRegRemoteCode(FetchRemoteCovidStatusDto requestDto, GetAuthCodeRequestDto thirdPartyDto);

        /// <summary>
        /// Revokes a remote code tied to covidUser
        /// </summary>
        /// <param name="covidUser">The user who is requesting to revoke a code. Is used to ensure that the requester is the owner of the code to be revoked</param>
        /// <param name="revokeRemoteCheckCodeDto">Contains the code to be revoked</param>
        /// <returns></returns>
        Task RevokeRemoteCode(CovidPassportUser covidUser, RevokeRemoteCheckCodeDto revokeRemoteCheckCodeDto);

        /// <summary>
        /// Returns all the active codes belonging to a user
        /// </summary>
        /// <param name="covidUser">The user for which the active codes are to be retreived</param>
        /// <returns>Returns all the active codes</returns>
        Task<IEnumerable<RemoteAccessCode>> GetActiveRemoteCheckCodes(CovidPassportUser covidUser);
    }

}
