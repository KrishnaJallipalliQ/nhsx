﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.International.Interfaces;
using CovidCertificate.Backend.International.Tests.Helpers;
using CovidCertificate.Backend.Services.PdfGeneration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Xunit;
using Moq;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Interfaces.BlobService;

namespace CovidCertificate.Backend.International.Tests
{
    public class GenerateInternationalHtmlTest
    {
        private readonly Mock<ILogger<HtmlGeneratorService>> loggerMock = new Mock<ILogger<HtmlGeneratorService>>();
        private readonly Mock<IConfiguration> mockConfig;
        private readonly Mock<IGetTimeZones> mockGetTimeZones;
        private readonly Mock<IEncoderService> encoderMock = new Mock<IEncoderService>();
        private readonly Mock<IBlobService> blobStorageMock = new Mock<IBlobService>();
        private readonly IConfiguration configuration;
        private readonly Mock<IQrImageGenerator> qrMock = new Mock<IQrImageGenerator>();
        private readonly IConfigurationRoot iConfig = GetIConfigurationRoot();

        public GenerateInternationalHtmlTest()
        {
            var inMemorySettings = new Dictionary<string, string> {
                {"TestKey", "TestValue"},
                {"PdfBlobStorageConnectionString", iConfig.GetSection("PdfBlobStorageConnectionString").Value},
                {"connectionString", "Test2"}
            };

            configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();

            qrMock.Setup(c => c.GenerateQrCodeString(It.IsAny<string>(), It.IsAny<int>())).Returns("012101210210");

            mockConfig = new Mock<IConfiguration>();
            mockConfig.SetupGet<string>(m => m["TimeZoneWindows"]).Returns("GMT Standard Time");
            mockConfig.SetupGet<string>(m => m["TimeZoneLinux"]).Returns("Europe/London");
            blobStorageMock.Setup(m => m.GetStringFromBlob(
                It.Is<string>(s => s.Equals("email-views")), 
                It.Is<string>(s => s.Equals("en-international"))))
                .Returns(Task.FromResult("test"));

            mockGetTimeZones = new Mock<IGetTimeZones>();
            mockGetTimeZones.Setup(x => x.GetTimeZoneInfo()).Returns(TimeZoneInfo.Utc);
        }

        private static IConfigurationRoot GetIConfigurationRoot()
        {
            var path = AppContext.BaseDirectory + "Settings/";

            return new ConfigurationBuilder()
                .SetBasePath(path)
                .AddJsonFile("appsettings.json", optional: true)
                .AddJsonFile("secrets.json", optional: true)
                .Build();
        }

        [Fact]
        public async Task GenerateInternationalHtml_ValidHtml_String()
        {
            //Arrange
            var covidUser = TestHelpers.SetUpUser();
            var vaccines = TestHelpers.SetUpVaccinationCertificate(DateTime.UtcNow.AddDays(2), DateTime.UtcNow.AddDays(2));
            var recoveryModel = TestHelpers.SetUpRecoveryCertificate();
            var encodedRecoveryString = string.Empty;
            var encodedVaccineString = string.Empty;

            //Act
            var uat = new HtmlGeneratorService(configuration, qrMock.Object, loggerMock.Object, mockGetTimeZones.Object, blobStorageMock.Object);
            encoderMock.Setup(m => m.EncodeFlowAsync<Vaccine>(It.IsAny<CovidPassportUser>(), It.IsAny<long>(), It.IsAny<IEnumerable<Vaccine>>(), It.IsAny<string>(), It.IsAny<DateTime>(), 0, null)).ReturnsAsync(encodedVaccineString);
            encoderMock.Setup(m => m.EncodeFlowAsync<TestResultNhs>(It.IsAny<CovidPassportUser>(), It.IsAny<long>(), It.IsAny<IEnumerable<TestResultNhs>>(), It.IsAny<string>(), It.IsAny<DateTime>(), 0, null)).ReturnsAsync(encodedRecoveryString);

            var result = await uat.GenerateInternationalHtml(covidUser, encodedVaccineString, vaccines, encodedRecoveryString, recoveryModel, "email-views", "en-international");

            //Assert
            Assert.IsType<string>(result);
        }

        [Fact]
        //What does the encoded string even do when generate international html works without it? 
        public async Task GenerateInternationalHtml_EncodedString_Null()
        {
            //Arrange
            var covidUser = TestHelpers.SetUpUser();
            var vaccine = TestHelpers.SetUpVaccinationCertificate(DateTime.UtcNow.AddDays(2), DateTime.UtcNow.AddDays(2));
            var recovery = TestHelpers.SetUpRecoveryCertificate();

            //Act
            var uat = new HtmlGeneratorService(configuration, qrMock.Object, loggerMock.Object, mockGetTimeZones.Object, blobStorageMock.Object);

            var result = await uat.GenerateInternationalHtml(covidUser, null, vaccine, null, recovery, "email-views", "en-international");

            //Assert
            Assert.IsType<string>(result);
        }

        [Fact]
        public async Task GenerateInternationalHtml_CovidUser_Null()
        {
            //Act
            var uat = new HtmlGeneratorService(configuration, qrMock.Object, loggerMock.Object, mockGetTimeZones.Object, blobStorageMock.Object);
            var result = await Assert.ThrowsAsync<ArgumentNullException>(() => uat.GenerateInternationalHtml(null, null, null, null, null, "email-views", "en-international"));

            //Assert
            Assert.IsType<ArgumentNullException>(result);
            Assert.Equal("covidUser", result.ParamName);
        }

        [Fact]
        public async Task GenerateInternationalHtml_templateFolder_Null()
        {
            //Arrange
            var covidUser = TestHelpers.SetUpUser();
            var vaccine = TestHelpers.SetUpVaccinationCertificate(DateTime.UtcNow.AddDays(2), DateTime.UtcNow.AddDays(2));
            var recovery = TestHelpers.SetUpRecoveryCertificate();
            var encodedRecoveryString = string.Empty;
            var encodedVaccineString = string.Empty;

            //Act
            var uat = new HtmlGeneratorService(configuration, qrMock.Object, loggerMock.Object, mockGetTimeZones.Object, blobStorageMock.Object);
            encoderMock.Setup(m => m.EncodeFlowAsync<Vaccine>(It.IsAny<CovidPassportUser>(), It.IsAny<long>(), It.IsAny<IEnumerable<Vaccine>>(), It.IsAny<string>(), It.IsAny<DateTime>(), 0, null)).ReturnsAsync(encodedVaccineString);
            encoderMock.Setup(m => m.EncodeFlowAsync<TestResultNhs>(It.IsAny<CovidPassportUser>(), It.IsAny<long>(), It.IsAny<IEnumerable<TestResultNhs>>(), It.IsAny<string>(), It.IsAny<DateTime>(), 0, null)).ReturnsAsync(encodedRecoveryString);

            var result = await Assert.ThrowsAsync<ArgumentNullException>(() => uat.GenerateInternationalHtml(covidUser, encodedVaccineString, vaccine, encodedRecoveryString, recovery, null, "en-international"));

            //Assert
            Assert.IsType<ArgumentNullException>(result);
            Assert.Equal("templateFolder", result.ParamName);
        }
    }
}
