using System;
using CovidCertificate.Backend.Interfaces;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using System.Threading.Tasks;
using CovidCertificate.Backend.Services.KeyServices;

namespace CovidCertificate.Backend.Services
{
    public class NhsIdTokenValidationFetcher : IJwtValidationParameterFetcher
    {
        private readonly ILogger<NhsIdTokenValidationFetcher> logger;
        private readonly IPublicKeyService publicKeyService;
        private JsonWebKey publicJwk;

        public NhsIdTokenValidationFetcher(ILogger<NhsIdTokenValidationFetcher> logger, IPublicKeyService publicKeyService)
        {
            this.logger = logger;
            this.publicKeyService = publicKeyService;
        }

        /// <summary>
        /// Gets the validation parameters for the token validation
        /// </summary>
        /// <returns></returns>
        public async Task<TokenValidationParameters> GetValidationParameters()
        {
            try
            {
                publicJwk = await publicKeyService.GetPublicKey();
            }
            catch (Exception e)
            {
                logger.LogCritical(e,"User token validation fail, unable to get public NHS key ");
                return null;
            }

            return new TokenValidationParameters()
            {
                ValidateAudience = false,
                ValidateActor = false,
                ValidateIssuer = false,
                ValidateLifetime = true,
                IssuerSigningKey = publicJwk
            };
        }
    }
}