﻿using CovidCertificate.Backend.Models.Enums;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace CovidCertificate.Backend.Models.DataModels
{
    public class EligibilityRules
    {
        public string ConfigurationName { get; private set; }
        public CertificateType CertificateType { get; private set; }
        public CertificateScenario Scenario { get; private set; }
        public IEnumerable<EligibilityCondition> Conditions { get; private set; }
        public int ValidityPeriodHours { get; private set; }
        public TimeFormat FormatExpiry { get; private set; }

        [JsonConstructor]
        public EligibilityRules(string configurationName, CertificateType certificateType, CertificateScenario scenario, IEnumerable<EligibilityCondition> conditions, int validityPeriodHours, TimeFormat formatExpiry)
        {
            ConfigurationName = configurationName;
            CertificateType = certificateType;
            Scenario = scenario;
            Conditions = conditions;
            ValidityPeriodHours = validityPeriodHours;
            FormatExpiry = formatExpiry;
        }
    }
}
