﻿using CovidCertificate.Backend.Models.Interfaces;
using FluentValidation;
using System.Linq;

namespace CovidCertificate.Backend.Models.Validators.UserValidators
{
    public class UserNhsInformationValidator : AbstractValidator<IUserNhsInformation>
    {
        public UserNhsInformationValidator()
        {
            #region NhsNumber Rules

            When(x => !string.IsNullOrEmpty(x.NhsNumber), () =>
            {
                RuleFor(x => x.NhsNumber).MaximumLength(10).OnFailure(x =>
                {
                    throw new ValidationException($"The specified NHS number exceed the character limit of 10.");
                });

                RuleFor(x => x.NhsNumber).Must(y => y.All(char.IsDigit)).OnFailure(x =>
                {
                    throw new ValidationException($"The specified NHS number contained characters other than digits.");
                });
            });

            #endregion
        }
    }
}
