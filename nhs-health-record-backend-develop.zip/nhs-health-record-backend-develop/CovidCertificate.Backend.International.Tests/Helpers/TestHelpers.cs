﻿using System;
using System.Collections.Generic;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Services.KeyServices;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Memory;

namespace CovidCertificate.Backend.International.Tests.Helpers
{
    public class TestHelpers
    {
        public static List<Vaccine> SetUpVaccines()
        {
            List<Vaccine> vaccines = new List<Vaccine>();
            var doseNumber = 1;
            var vaccinationDate = DateTime.UtcNow.AddDays(-7);
            var vaccineManufacturer = Tuple.Create<string, string>("CODE", "MANUFACTURER");
            var diseaseTargeted = Tuple.Create<string, string>("CODE", "DISEASE");
            var vaccineType = Tuple.Create<string, string>("CODE", "TYPE");
            var product = Tuple.Create<string, string>("CODE", "PRODUCT");
            var vaccineBatchNumber = "BATCH";
            var countryOfVaccination = "UK";
            var authority = "NHS";
            var totalSeriesOfDoses = 2;
            var site = "Driffield Ambulance Station";
            var displayName = "Product Display Name";
            var snomedCode = "SNOMED";
            Vaccine v = new Vaccine(doseNumber, vaccinationDate, vaccineManufacturer, diseaseTargeted, vaccineType, product, vaccineBatchNumber, countryOfVaccination, authority, totalSeriesOfDoses, site, displayName, snomedCode, vaccinationDate);
            vaccines.Add(v);
            return vaccines;
        }

        public static IEnumerable<TestResultNhs> SetUpRecoveryTestResults()
        {
            return new List<TestResultNhs>
            {
                getDiagnostic(DateTime.Now),
                getDiagnostic(DateTime.Now.AddDays(-7))
            };
        }

        public static Certificate SetUpVaccinationCertificate(DateTime validity, DateTime eligibility)
        {
            var mockCert = new Certificate("name", DateTime.UtcNow, validity, eligibility, Backend.Models.Enums.CertificateType.Vaccination, Backend.Models.Enums.CertificateScenario.Domestic, SetUpVaccines());
            mockCert.QrCodeTokens.Add("");
            return mockCert;

        }

        private static TestResultNhs getDiagnostic(DateTime now)
        {
            Tuple<string, string> diseaseTargeted = new Tuple<string, string>("41523432", "COVID-19");
            return new TestResultNhs(now.AddDays(-30), "Positive", "Type", "41241231", "Kit", diseaseTargeted, "NHS", "GB");
        }

        public static Certificate SetUpRecoveryCertificate()
        {
            var homeTests = SetUpRecoveryTestResults();

            var cert = new Certificate("name", DateTime.UtcNow, DateTime.UtcNow.AddDays(-30), DateTime.UtcNow.AddDays(180), Backend.Models.Enums.CertificateType.Recovery, CertificateScenario.International, homeTests);
            cert.UniqueCertificateIdentifier = "URN:UVCI:01:GB:1620401381701ABCDEFGH#L";
            cert.QrCodeTokens.Add("");

            return cert;
        }

        public static CovidPassportUser SetUpUser()
        {
            var name = "Test McTestPerson";
            var familyName = "McTestPerson";
            var givenName = "Test";
            var dob = DateTime.UtcNow.AddYears(-21);
            var email = "test@test.com";
            var phone = "0123456789";
            var nhsNumber = "0000000000";
            return new CovidPassportUser(name, dob, email, phone, nhsNumber, familyName, givenName);
        }

        public static CovidPassportUser SetUpForeignCharacterUser()
        {
            var name = "Æ-Ñ-Ü Õ-Þ";
            var familyName = "Õ-Þ";
            var givenName = "Æ-Ñ-Ü";
            var dob = DateTime.UtcNow.AddYears(-21);
            var email = "test@test.com";
            var phone = "0123456789";
            var nhsNumber = "0000000000";
            return new CovidPassportUser(name, dob, email, phone, nhsNumber, familyName, givenName);
        }

        public static KeyRing SetupKeyRing()
        {
            var memoryConfigurationProvider = new MemoryConfigurationProvider(new MemoryConfigurationSource());
            var configurationRoot = new ConfigurationRoot(new List<IConfigurationProvider> { memoryConfigurationProvider });
            configurationRoot["VaultUri"] = "https://localhost";

            return new KeyRing(configurationRoot, () => new Dictionary<string, KeyRing.KeyOps>());
        }
    }
}
