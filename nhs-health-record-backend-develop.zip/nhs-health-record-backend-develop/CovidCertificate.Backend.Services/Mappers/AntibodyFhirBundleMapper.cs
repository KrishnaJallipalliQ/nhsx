﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using Hl7.Fhir.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services
{
    public class AntibodyFhirBundleMapper : IFhirBundleMapper<AntibodyResultNhs>
    {
        private readonly IMappingCache mappingCache;

        public AntibodyFhirBundleMapper(IMappingCache mappingCache)
        {
            this.mappingCache = mappingCache;
        }


        public async Task<IEnumerable<AntibodyResultNhs>> ConvertBundle(Bundle bundle)
        {
            var antibodyResults = new List<AntibodyResultNhs>();

            if (bundle != null)
            {
                var mappings = await mappingCache.GetMappings();

                foreach (var entry in bundle.Entry)
                {
                    if (entry?.Resource is Observation observation)
                    {
                        var testKit = observation.Device?.Identifier?.Value ?? string.Empty;
                        var successful = mappings.TryGetValue("type", out var mapping);
                        if (!successful)
                        {
                            throw new Exception("Type mapping does not exist.");
                        }
                        var validityType = mapping.TryGetValue(testKit.ToUpperInvariant(), out var a) ? a : string.Empty;
                        var processingLabCode = observation.Performer.FirstOrDefault()?.Identifier?.Value;
                        var fhirDateTimeOfTest = (FhirDateTime)observation.Effective;
                        var dateTimeOfTest = fhirDateTimeOfTest.ToDateTimeOffset(TimeZoneInfo.Utc.GetUtcOffset(DateTime.Now)).DateTime;
                        var codeableConcept = (CodeableConcept)observation.Value;
                        successful = mappings.TryGetValue("result", out mapping);
                        if (!successful)
                        {
                            throw new Exception("Result mapping does not exist.");
                        }
                        var result = mapping.TryGetValue(codeableConcept.Coding?.FirstOrDefault()?.Code, out var b) ? b : string.Empty;
                        antibodyResults.Add(new AntibodyResultNhs(dateTimeOfTest, result, validityType, testKit));
                    }
                }
            }

            return antibodyResults;
        }
    }
}
