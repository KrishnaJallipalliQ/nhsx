﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.BlobService;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Utils;
using CovidCertificate.Backend.Utils.Extensions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Passbook.Generator;
using Passbook.Generator.Fields;
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services
{
    public class ApplePassGenerator : IGenerateApplePass
    {
        private readonly IConfiguration configuration;
        private readonly ICovidCertificateCreator covidCertificateCreator;
        private readonly IBlobService blobService;
        private readonly ILogger<ApplePassGenerator> logger;
        private readonly IGeneratePassData generatePassData;
        private readonly IHtmlGeneratorService htmlGenerator;
        private readonly PassSettings settings;
        private readonly string secretPassCert = default;
        private byte[] secretAppleCert = default;
        private byte[] image = default;
        private readonly string PassTypeIdentifier = "pass.uk.gov.dhsc.healthrecord";
        private readonly string TeamIdentifier = "877YMUFLMF";
        private readonly string SerialNumber = "e1732f13";
        private readonly string WhiteHex = "#FFFFFF";

        public ApplePassGenerator(IConfiguration configuration, ICovidCertificateCreator covidCertificateCreator, IBlobService blobService,
            ILogger<ApplePassGenerator> logger, PassSettings settings, IGeneratePassData passData, IHtmlGeneratorService htmlGenerator)
        {
            this.configuration = configuration;
            this.covidCertificateCreator = covidCertificateCreator;
            this.blobService = blobService;
            this.logger = logger;
            this.settings = settings;
            this.generatePassData = passData;
            this.htmlGenerator = htmlGenerator;
            secretPassCert ??= configuration["AppleWalletPassCert"];
        }

        public async Task<MemoryStream> GeneratePass(CovidPassportUser covidPassportUser, QRType qrType, string idToken = "",int doseNumber = 0)
        {
            logger.LogInformation("GeneratePass was invoked");

            var generator = new PassGenerator();
            var request = await PrepareRequestObject(covidPassportUser, idToken, qrType,doseNumber);
            logger.LogTraceAndDebug($"request is {request}");
            var generatedPass = generator.Generate(request);
            logger.LogTraceAndDebug($"generatedPass is {generatedPass}");
            var memoryStream = new MemoryStream(generatedPass);
            logger.LogTraceAndDebug($"memoryStream is {memoryStream}");
            logger.LogInformation("GeneratePass has finished");
            return memoryStream;
        }

        // extracted this functionality to make more testable.
        // unit tests done on this method, the above method is trusted code
        public async Task<PassGeneratorRequest> PrepareRequestObject(CovidPassportUser covidTestUser, string idToken, QRType type,int doseNumber)
        {
            logger.LogInformation("PrepareRequestObject was invoked");
            logger.LogTraceAndDebug($"secretPassCert is {secretPassCert}");

            var request = new PassGeneratorRequest();

            var data = await generatePassData.GetPassDataAsync(covidTestUser, idToken, type);

            var qrCode = data.qr;
            var cert = data.cert;
            if (qrCode == null || cert == null)
            {
                throw new InvalidDataException("Invalid pass type");
            }

            switch (type)
            {
                case QRType.Domestic:
                    request.AddBarcode(BarcodeType.PKBarcodeFormatQR, cert.QrCodeTokens[0], "UTF-8");
                    break;
                case QRType.International:
                    request = await PrepareInternationalPassAsync(request, cert,doseNumber,covidTestUser);
                    break;
                case QRType.Recovery:
                    request.AddBarcode(BarcodeType.PKBarcodeFormatQR, cert.QrCodeTokens[0], "UTF-8");
                    request = await PrepareRecoveryPassAsync(request, cert,covidTestUser);
                    break;
                default:
                    logger.LogWarning("Unknown QR Type");
                    break;
            }

            secretAppleCert ??= await blobService.GetImageFromBlobWithRetryAsync("pubkeys", "AppleWWDRCA.cer");
            image ??= await blobService.GetImageFromBlobWithRetryAsync("images", "nhs_covid_status.png");

            StringBuilder sb = new StringBuilder().Append("To keep your data safe, the 2D barcode expires on the designated expiry date.");
            sb.Append(" You can generate a new one by logging in to the NHS App and downloading a new barcode to your Apple Wallet.");

            request = AddPassSetings(request);
            request.Certificate = Convert.FromBase64String(secretPassCert);
            request.AppleWWDRCACertificate = secretAppleCert;

            request = AddPassImages(request);
            request.Style = PassStyle.Generic;

            request.AddPrimaryField(new StandardField("Name", "NAME", covidTestUser.Name.ToUpper()));

            request.AddSecondaryField(new StandardField("Validity", "VALIDITY", "Valid in England"));
            request.AddSecondaryField(new StandardField("DateOfBirth", "DATE OF BIRTH", StringUtils.GetFormattedDate(covidTestUser.DateOfBirth)));

            request.AddAuxiliaryField(new StandardField("Expiry2", "BARCODE VALID UNTIL", qrCode.ValidityEndDate));
          
            request.AddBackField(new StandardField("Expiry3", "What to do when your barcode expires", sb.ToString()));
            request.TransitType = TransitType.PKTransitTypeAir;

            logger.LogTraceAndDebug($"request is {request}");
            logger.LogInformation("PrepareRequestObject has finished");

            return request;
        }

        private async Task<PassGeneratorRequest> PrepareInternationalPassAsync(PassGeneratorRequest request, Certificate certificate,int doseNumber, CovidPassportUser covidTestUser)
        {
            try
            {
                var vaccine = certificate.GetAllVaccinationsFromEligibleResults().OrderBy(x => x.VaccinationDate).ToArray()[doseNumber-1];
                var passData = new ApplePassVaccine(vaccine);
                passData.Uvci = certificate.UniqueCertificateIdentifier;
                var vaccineFieldData = await htmlGenerator.getApplePassHtml(passData, PassData.vaccine);
                request.AddBackField(new StandardField("Vaccine 1", "Dose " + vaccine.DoseNumber, vaccineFieldData));
                request.AddBackField(new StandardField("Spacing", " ", ""));
                request.AddSecondaryField(new StandardField("DateOfBirth", "DATE OF BIRTH", StringUtils.GetFormattedDate(covidTestUser.DateOfBirth)));
                request.AddBarcode(BarcodeType.PKBarcodeFormatQR, certificate.QrCodeTokens[doseNumber-1], "UTF-8");
                logger.LogTraceAndDebug("International Pass is generated");
                return request;
            }
            catch (IndexOutOfRangeException)
            {
                throw new InvalidDataException("Vaccine Dose does not exist");
            }
        }

        private async Task<PassGeneratorRequest> PrepareRecoveryPassAsync(PassGeneratorRequest request, Certificate certificate, CovidPassportUser covidTestUser)
        {
            var result = certificate.GetLatestDiagnosticResultFromEligibleResults().First();
            var passData = new ApplePassRecovery(result);
            passData.CertificateValidUntil = certificate.validityEndDate.ToString("dd MMMM yyyy");
            passData.Uvci = certificate.UniqueCertificateIdentifier;
            var recoveryFieldData = await htmlGenerator.getApplePassHtml(passData, PassData.recovery);
            request.AddBackField(new StandardField("Recovery 1", "Recovery Test", recoveryFieldData));
            request.AddBackField(new StandardField("Spacing", " ", ""));
            request.AddSecondaryField(new StandardField("DateOfBirth", "DATE OF BIRTH", StringUtils.GetFormattedDate(covidTestUser.DateOfBirth)));
            logger.LogTraceAndDebug("Recovery Pass is generated");
            return request;
        }

        private PassGeneratorRequest AddPassSetings(PassGeneratorRequest request)
        {
            request.PassTypeIdentifier = PassTypeIdentifier;
            request.TeamIdentifier = TeamIdentifier;
            request.SerialNumber = SerialNumber;
            request.Description = settings.PassProvider + " " + settings.PassName;
            request.OrganizationName = settings.PassOrigins;
            request.LogoText = settings.PassProvider + " " + settings.PassName;
            request.CertificatePassword = "";
            request.BackgroundColor = settings.BackgroundColour;
            request.LabelColor = WhiteHex;
            request.ForegroundColor = WhiteHex;
            return request;
        }
        private PassGeneratorRequest AddPassImages(PassGeneratorRequest request)
        {
            request.Images.Add(PassbookImage.Icon, image);
            request.Images.Add(PassbookImage.Icon2X, image);
            request.Images.Add(PassbookImage.Icon3X, image);
            request.Images.Add(PassbookImage.Logo, image);
            request.Images.Add(PassbookImage.Logo2X, image);
            request.Images.Add(PassbookImage.Logo3X, image);
            return request;
        }
    }
}