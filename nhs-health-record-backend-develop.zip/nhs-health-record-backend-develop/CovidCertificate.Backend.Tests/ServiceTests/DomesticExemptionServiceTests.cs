﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Services.DomesticExemptions;
using CovidCertificate.Backend.Utils;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class DomesticExemptionServiceTests
    {
        private readonly Mock<ILogger<DomesticExemptionService>> logger = new Mock<ILogger<DomesticExemptionService>>();
        private readonly Mock<IMongoRepository<DomesticExemption>> mongoRepository = new Mock<IMongoRepository<DomesticExemption>>();
        private readonly Mock<IDomesticExemptionCache> domesticExemptionCache = new Mock<IDomesticExemptionCache>();
        private readonly IDomesticExemptionService domesticExemptionService;

        public DomesticExemptionServiceTests()
        {
            domesticExemptionService = new DomesticExemptionService(logger.Object, mongoRepository.Object, domesticExemptionCache.Object);
        }

        [Fact]
        public async Task SaveExemption_NoExemptionExists_ReturnsRecord()
        {
            // Arrange
            var exemption = new DomesticExemption("hash", "reason");
            mongoRepository.Setup(x => x.FindOneAsync(It.IsAny<Expression<Func<DomesticExemption, bool>>>())).ReturnsAsync((DomesticExemption)null);

            mongoRepository.Setup(x => x.InsertOneAsync(It.IsAny<DomesticExemption>())).Verifiable();

            // Act
            var result = await domesticExemptionService.SaveDomesticExemption(exemption);

            // Assert
            mongoRepository.Verify(x => x.InsertOneAsync(It.IsAny<DomesticExemption>()), Times.Once);
            Assert.True(result);
        }

        [Fact]
        public async Task SaveExemption_ExemptionExists_ReturnsRecord()
        {
            // Arrange
            var exemption = new DomesticExemption("hash", "reason");
            mongoRepository.Setup(x => x.FindOneAsync(It.IsAny<Expression<Func<DomesticExemption, bool>>>()))
                .ReturnsAsync(exemption);

            mongoRepository.Setup(x => x.ReplaceOneAsync(It.IsAny<DomesticExemption>())).Verifiable();

            // Act
            var result = await domesticExemptionService.SaveDomesticExemption(exemption);

            // Assert
            mongoRepository.Verify(x => x.ReplaceOneAsync(It.IsAny<DomesticExemption>(), It.IsAny<Expression<Func<DomesticExemption, bool>>>()), Times.Once);
            Assert.True(result);
        }

        [Fact]
        public async Task SaveExemption_BadHashAndReason_ReturnsNull()
        {
            // Arrange
            var exemption = new DomesticExemption("", "");

            // Act
            var result = await domesticExemptionService.SaveDomesticExemption(exemption);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task IsUserExempt_ExemptionsExist_ExemptionForUser_ShouldReturnTrue()
        {
            // Arrange
            var nhsNumber = "1234567890";
            var dateOfBirth = new DateTime(1990, 10, 10);
            var userHash = HashUtils.GenerateHash(nhsNumber, dateOfBirth);
            var reason = "some reason";

            // Arrange
            var exemption = new DomesticExemption(userHash, reason);
            domesticExemptionCache.Setup(x => x.GetDomesticExemptions()).ReturnsAsync(new Dictionary<string, DomesticExemption>() { [userHash] = exemption });

            // Act
            var result = await domesticExemptionService.IsUserExempt(nhsNumber, dateOfBirth);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public async Task IsUserExempt_ExemptionsExists_NoneForUser_ShouldReturnFalse()
        {
            // Arrange
            var nhsNumber = "1234567890";
            var dateOfBirth = new DateTime(1980, 10, 10);

            var dateOfBirth2 = new DateTime(1990, 10, 10);
            var nhsNumber2 = "0987654321";
            var userHash2 = HashUtils.GenerateHash(nhsNumber2, dateOfBirth2);
            var reason2 = "some reason";

            // Arrange
            var exemption = new DomesticExemption(userHash2, reason2);
            domesticExemptionCache.Setup(x => x.GetDomesticExemptions()).ReturnsAsync(new Dictionary<string, DomesticExemption>() { [userHash2] = exemption });

            // Act
            var result = await domesticExemptionService.IsUserExempt(nhsNumber, dateOfBirth);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task GetExemption_MissingDateOfBirth_ShouldReturnFalse()
        {
            // Arrange
            var nhsNumber = "1234567890";
            DateTime dateOfBirth = default;

            // Act
            var result = await domesticExemptionService.GetDomesticExemption(nhsNumber, dateOfBirth);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetExemption_MissingNhsNumber_ShouldReturnFalse()
        {
            // Arrange
            var nhsNumber = "";
            var dateOfBirth = new DateTime(1980, 10, 10);

            domesticExemptionCache.Setup(x => x.GetDomesticExemptions()).Verifiable();

            // Act
            var result = await domesticExemptionService.GetDomesticExemption(nhsNumber, dateOfBirth);

            // Assert
            domesticExemptionCache.Verify(x => x.GetDomesticExemptions(), Times.Never);
            Assert.Null(result);
        }

        [Fact]
        public async Task GetExemption_ExemptionExists_ReturnsExemption()
        {
            // Arrange
            var nhsNumber = "1234567890";
            var dateOfBirth = new DateTime(2000, 10, 5);
            var userHash = HashUtils.GenerateHash(nhsNumber, dateOfBirth);
            var reason = "some reason";

            // Arrange
            var exemption = new DomesticExemption(userHash, reason);
            domesticExemptionCache.Setup(x => x.GetDomesticExemptions()).ReturnsAsync(new Dictionary<string, DomesticExemption>() { [userHash] = exemption });

            // Act
            var result = await domesticExemptionService.GetDomesticExemption(nhsNumber, dateOfBirth);

            // Assert
            Assert.Equal(exemption, result);
        }

        [Fact]
        public async Task GetExemption_NoExemptionExists_ReturnsNull()
        {
            // Arrange
            var nhsNumber = "1234567890";
            var dateOfBirth = new DateTime(2000, 10, 5);
            var userHash = HashUtils.GenerateHash(nhsNumber, dateOfBirth);

            // Arrange
            domesticExemptionCache.Setup(x => x.GetDomesticExemptions()).ReturnsAsync(new Dictionary<string, DomesticExemption>() { });

            // Act
            var result = await domesticExemptionService.GetDomesticExemption(nhsNumber, dateOfBirth);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task RemoveExemption_ExemptionExists_ReturnsTrue()
        {
            // Arrange
            var nhsNumber = "1234567890";
            var dateOfBirth = new DateTime(2000, 10, 5);
            var userHash = HashUtils.GenerateHash(nhsNumber, dateOfBirth);
            var reason = "some reason";
            var exemption = new DomesticExemption(userHash, reason);

            mongoRepository.Setup(x => x.DeleteOneAsync(It.IsAny<Expression<Func<DomesticExemption, bool>>>()))
                .ReturnsAsync(exemption)
                .Verifiable();

            // Act
            var result = await domesticExemptionService.RemoveDomesticExemption(exemption);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public async Task RemoveExemption_NoExemptionExists_ReturnsFalse()
        {
            // Arrange
            var nhsNumber = "1234567890";
            var dateOfBirth = new DateTime(2000, 10, 5);
            var userHash = HashUtils.GenerateHash(nhsNumber, dateOfBirth);
            var reason = "some reason";
            var exemption = new DomesticExemption(userHash, reason);

            mongoRepository.Setup(x => x.DeleteOneAsync(It.IsAny<Expression<Func<DomesticExemption, bool>>>()))
                .ReturnsAsync((DomesticExemption)null)
                .Verifiable();

            // Act
            var result = await domesticExemptionService.RemoveDomesticExemption(exemption);

            // Assert
            Assert.False(result);
        }

    }
}
