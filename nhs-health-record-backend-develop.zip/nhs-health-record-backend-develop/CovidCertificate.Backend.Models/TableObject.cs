﻿using Microsoft.Azure.Cosmos.Table;
using Newtonsoft.Json;
using System;

namespace CovidCertificate.Backend.Models
{
    public class TableObject<T> : TableEntity
    {

        public TableObject()
        {

        }
        public TableObject(T tableData, string partitionKey, string keyId)
        {
            RowKey = keyId;
            PartitionKey = partitionKey;
            TableData = tableData;
        }
        public T TableData { get; set; }
        
        public string SerializedData
        {
            get { return JsonConvert.SerializeObject(TableData); }
            set { TableData = JsonConvert.DeserializeObject<T>(value); }
        }
    }
}