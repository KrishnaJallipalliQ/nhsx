﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Net.Http;
using System.Security.Cryptography;
using System.Threading.Tasks;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.NhsApiIntegration.Interfaces;
using CovidCertificate.Backend.NhsApiIntegration.Responses;
using CovidCertificate.Backend.Utils;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using Polly.Retry;
using Polly.Timeout;
using Polly.Wrap;

namespace CovidCertificate.Backend.NhsApiIntegration.Services
{
    public class NhsTestResultsHistoryApiAccessTokenService : INhsTestResultsHistoryApiAccessTokenService
    {
        private readonly ILogger<NhsTestResultsHistoryApiAccessTokenService> logger;
        private readonly IConfiguration configuration;
        private readonly NhsTestResultsHistoryApiSettings settings;
        private readonly HttpClient httpClient;
        private readonly IRedisCacheService redisCacheService;

        private const string redisAccessTokenKey = "TestResults:AccessToken";
        private string accessToken;
        private DateTime accessTokenExpiry;
        private static readonly AsyncLock Mutex = new AsyncLock();
        private AsyncPolicyWrap<HttpResponseMessage> getAccessTokenRetryPolicy;

        private bool IsTokenValid => !string.IsNullOrEmpty(accessToken) && accessTokenExpiry != default &&
                                    accessTokenExpiry > DateTime.UtcNow;

        public NhsTestResultsHistoryApiAccessTokenService(
            ILogger<NhsTestResultsHistoryApiAccessTokenService> logger,
            IConfiguration configuration,
            NhsTestResultsHistoryApiSettings settings,
            HttpClient httpClient,
            IRedisCacheService redisCacheService)
        {
            this.logger = logger;
            this.configuration = configuration;
            this.settings = settings;
            this.httpClient = httpClient;
            this.redisCacheService = redisCacheService;
            this.getAccessTokenRetryPolicy = HttpRetryPolicyUtils.CreateRetryPolicyWrap(settings.AccessTokenRetryCount,
                           settings.AccessTokenRetrySleepDurationInMilliseconds,
                           settings.AccessTokenTimeoutInMilliseconds,
                           " acquiring access token ",
                           logger);
        }

        public async Task<string> GetAccessTokenAsync(string identityToken)
        {
            if (settings.UseAccessTokenUserRestrictedMode)
            {
                logger.LogInformation($"{nameof(GetUserRestrictedTokenAsync)} was invoked.");

                var tokenResult = await GetUserRestrictedTokenAsync(identityToken);

                logger.LogInformation($"{nameof(GetUserRestrictedTokenAsync)} has finished.");

                return tokenResult.AccessToken;
            }
            logger.LogInformation($"{nameof(GetAccessTokenAsync)} was invoked.");

            if (IsTokenValid)
            {
                logger.LogInformation("Access token is valid, returning access token.");
                return accessToken;
            }

            using (await Mutex.LockAsync())
            {
                if (IsTokenValid)
                {
                    logger.LogInformation("Access token is valid, returning access token (mutex).");
                    return accessToken;
                }

                logger.LogInformation("In-memory token is not found or invalid. Attempting to update with one from cache.");

                (TokenResponse cachedAccessToken, bool tokenExistsInCache) = await redisCacheService.GetKeyValueAsync<TokenResponse>(redisAccessTokenKey);

                if (tokenExistsInCache)
                {
                    SaveObtainedAccessTokenToPrivateFields(cachedAccessToken);
                }

                if (IsTokenValid)
                {
                    logger.LogInformation($"{nameof(GetAccessTokenAsync)} was finished.");
                    return accessToken;
                }

                // This scenario is worst-case and should never happen as the FetchTestResultAccessTokenFunction should always keep a fresh access token in the cache.
                logger.LogInformation("Could not find token in cache. Refreshing the token directly from service.");
                var tokenResult = await RefreshAccessTokenInRedisAsync();
                logger.LogInformation($"{nameof(RefreshAccessTokenInRedisAsync)} has finished.");

                SaveObtainedAccessTokenToPrivateFields(tokenResult);

                return tokenResult.AccessToken;
            }
        }

        public async Task<TokenResponse> RefreshAccessTokenInRedisAsync()
        {
            logger.LogInformation($"{nameof(GetAccessTokenFromNhs)} was invoked with user restriction disabled.");

            var accessTokenResult = await GetAccessTokenFromNhs();

            return await DeserializeAccessTokenResult(accessTokenResult.isSuccessStatusCode, accessTokenResult.responseString, true);
        }

        public async Task<TokenResponse> GetUserRestrictedTokenAsync(string identityToken)
        {
            logger.LogInformation($"{nameof(GetAccessTokenFromNhs)} was invoked with user restriction enabled.");

            var accessTokenResult = await GetAccessTokenFromNhs(identityToken);
            return await DeserializeAccessTokenResult(accessTokenResult.isSuccessStatusCode, accessTokenResult.responseString);
        }

        private async Task<TokenResponse> DeserializeAccessTokenResult(bool statusCodeSuccess, string response, bool storeInRedisCache = false)
        {
            if (statusCodeSuccess)
            {
                var tokenResult = JsonConvert.DeserializeObject<TokenResponse>(response);
                if (storeInRedisCache) { await redisCacheService.AddKeyAsync(redisAccessTokenKey, tokenResult, RedisLifeSpanLevel.Medium); }

                return tokenResult;
            }

            var message = $"Error during obtaining access token. Error message: '{response}'.";
            logger.LogCritical(message);

            throw new Exception(message);
        }

        private void SaveObtainedAccessTokenToPrivateFields(TokenResponse token)
        {
            this.accessToken = token.AccessToken;
            this.accessTokenExpiry =
                DateTimeOffset.FromUnixTimeMilliseconds(token.IssuedAt).UtcDateTime
                    .AddSeconds(token.ExpiresIn)
                    .AddSeconds(-10); // we added -10seconds here to be sure token is always valid (in case of delays etc.)
        }

        private async Task<(bool isSuccessStatusCode, string responseString)> GetAccessTokenFromNhs(string identityToken = null)
        {
            logger.LogInformation("Sending request to obtain access token for Test Results History API.");

            string nhsAccessTokenEndpoint = settings.NhsTestResultsHistoryApiAccessTokenBaseUrl + "/oauth2/token";

            var response = await getAccessTokenRetryPolicy.ExecuteAsync(() => SendRequest(identityToken, nhsAccessTokenEndpoint));

            var responseMessage = await response.Content.ReadAsStringAsync();

            logger.LogInformation($"{nameof(GetAccessTokenFromNhs)} finished.");

            return (response.IsSuccessStatusCode, responseMessage);
        }

        private Task<HttpResponseMessage> SendRequest(string identityToken, string nhsAccessTokenEndpoint)
        {
            return httpClient.SendAsync(CreateAccessTokenRequest(nhsAccessTokenEndpoint, GenerateRequestContent(identityToken, nhsAccessTokenEndpoint)));
        }

        private Dictionary<string, string> GenerateRequestContent(string identityToken, string nhsAccessTokenEndpoint)
        {
            string token = GenerateJwtToken(nhsAccessTokenEndpoint);

            var content = new Dictionary<string, string>()
            {
                { "grant_type", "client_credentials" },
                { "client_assertion_type", "urn:ietf:params:oauth:client-assertion-type:jwt-bearer" },
                { "client_assertion", token },
            };

            if (!string.IsNullOrEmpty(identityToken))
            {
                content.Add("subject_token", identityToken);
                content.Add("subject_token_type", "urn:ietf:params:oauth:token-type:id_token");
                content["grant_type"] = "urn:ietf:params:oauth:grant-type:token-exchange";
            }

            return content;
        }

        private string GenerateJwtToken(string nhsAccessTokenEndpoint)
        {
            logger.LogInformation("Creating JWT to obtain access token for Test Results History API for application.");

            var privateKey = configuration["NhsTestResultsHistoryApiAccessTokenPrivateKey"];
            using RSA rsaPrivateKey = RSA.Create();
            rsaPrivateKey.ImportRSAPrivateKey(privateKey.FromBase64StringToByteArray(), out _);

            var appKid = settings.NhsTestResultsHistoryApiAccessTokenAppKid;
            var appKey = settings.NhsTestResultsHistoryApiAccessTokenAppKey;

            var jwtHeader = new JwtHeader(
                signingCredentials: new SigningCredentials(new RsaSecurityKey(rsaPrivateKey),
                    SecurityAlgorithms.RsaSha512)
                {
                    CryptoProviderFactory = new CryptoProviderFactory { CacheSignatureProviders = false }
                });
            jwtHeader.Add("kid", appKid);

            var jwtPayload = new JwtPayload
            {
                {"iss", appKey},
                {"sub", appKey},
                {"aud", nhsAccessTokenEndpoint},
                {"jti", Guid.NewGuid().ToString()},
                {"exp", new DateTimeOffset(DateTime.Now.AddMinutes(4)).ToUnixTimeSeconds()},
            };

            var jwt = new JwtSecurityToken(jwtHeader, jwtPayload);
            var token = new JwtSecurityTokenHandler().WriteToken(jwt);

            return token;
        }

        private HttpRequestMessage CreateAccessTokenRequest(string nhsAccessTokenEndpoint, Dictionary<string, string> content)
        {
            var request = new HttpRequestMessage(HttpMethod.Post, nhsAccessTokenEndpoint)
            {
                Content = new FormUrlEncodedContent(content)
            };

            if (settings.UseTestResultsHistoryMock)
            {
                // This header is only needed for Mock on Azure
                request.Headers.Add("x-functions-key", settings.AuthMockApiKey);
            }

            return request;
        }
    }
}
