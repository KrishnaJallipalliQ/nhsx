﻿using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Models.DataModels;
using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;
using System.Text;
using CovidCertificate.Backend.Interfaces;

namespace CovidCertificate.Backend.Models.DataModels
{
    [Collection("AntibodyResults")]
    public class AntibodyResult : UserHashedDocument, IGenericResult
    {
        public AntibodyResult(AntibodyRequestDto requestDto) : base(requestDto.Name, requestDto.DateOfBirth, requestDto.PhoneNumber, requestDto.EmailAddress, requestDto.NhsNumber)
        {
            this.DateTimeOfTest = requestDto.DateTimeOfTest;
            this.ValidityType = requestDto.TestType;
            this.TestResult = requestDto.TestResult;
            this.TestKit = requestDto.TestKit;
        }

        [JsonConstructor]
        public AntibodyResult(string id, [JsonProperty("PartitionKey")] string keyHash, [JsonProperty("PhoneHash")] string phoneNameAndDateOfBirthHash, [JsonProperty("EmailHash")] string emailNameAndDateOfBirthHash, [JsonProperty("NhsNumberHash")] string nhsNumberAndDateOfBirthHash, 
            DateTime dateTimeOfTest, string testType, string testResult, string testKit) : base(id, keyHash, phoneNameAndDateOfBirthHash, emailNameAndDateOfBirthHash, nhsNumberAndDateOfBirthHash)
        {
            this.DateTimeOfTest = dateTimeOfTest;
            this.ValidityType = testType;
            this.TestResult = testResult;
            this.TestKit = testKit;
        }

        public AntibodyResult(string name, DateTime dateOfBirth, string emailAddress, string phoneNumber, string nhsNumber, DateTime dateTimeOfTest, string result, string validityType, string testKit)
            : base(name, dateOfBirth, phoneNumber, emailAddress, nhsNumber)
        {
            this.DateTimeOfTest = dateTimeOfTest;
            this.TestResult = result;
            this.ValidityType = validityType;
            this.TestKit = testKit;
           
        }


        [JsonRequired, BsonRequired]
        public DateTime DateTimeOfTest { get; private set; }
        [JsonRequired, BsonRequired]
        public string ValidityType { get; private set; }
        [JsonRequired, BsonRequired]
        public string TestKit { get; private set; }
        [JsonRequired, BsonRequired]
        public string TestResult { get; private set; }
        
        //Implement interface fields without having to rename existing models
        public string Result => TestResult;


        public override bool Equals(object obj)
        {
            //Check for null and compare run-time types.
            if ((obj == null) || !this.GetType().Equals(obj.GetType()))
                return false;

            var castedObj = (AntibodyResult)obj;
            return (Id == castedObj.Id) && 
                (EmailHash == castedObj.EmailHash) && 
                (PhoneHash == castedObj.PhoneHash) &&
                (NhsNumberHash == castedObj.NhsNumberHash) &&
                (DateTimeOfTest == castedObj.DateTimeOfTest) && 
                (ValidityType == castedObj.ValidityType) && 
                (TestResult == castedObj.TestResult);
        }

        public override int GetHashCode() => 
            Id.GetHashCode() ^
            EmailHash.GetHashCode() ^
            PhoneHash.GetHashCode() ^
            NhsNumberHash.GetHashCode() ^
            DateTimeOfTest.GetHashCode() ^ 
            ValidityType.GetHashCode() ^ 
            TestResult.GetHashCode();

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Result:" + this.Result ?? "").AppendLine();
            sb.Append("TestKit:" + this.TestKit ?? "").AppendLine();
            sb.Append("TestResult:" + this.TestResult ?? "").AppendLine();
            sb.Append("ValidityType" + this.ValidityType ?? "").AppendLine();
            sb.Append("DateTimeOfTest" + this.DateTimeOfTest ?? "").AppendLine();
            sb.Append("Id:" + this.Id ?? "").AppendLine();
            sb.Append("EmailHash:" + this.EmailHash ?? "").AppendLine();
            sb.Append("PartitionKey:" + this.PartitionKey ?? "").AppendLine();
            sb.Append("PhoneHash:" + this.PhoneHash ?? "").AppendLine();
            sb.Append("NhsNumberHash:" + this.NhsNumberHash ?? "").AppendLine();
            return sb.ToString();
        }

        public bool IsPositive() => string.Equals("Positive", TestResult, StringComparison.CurrentCultureIgnoreCase);
        public bool IsNotPositive() => !IsPositive();
        public bool IsNegative() => string.Equals("Negative", TestResult, StringComparison.CurrentCultureIgnoreCase);
    }
}
