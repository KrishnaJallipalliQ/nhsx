﻿using System.Linq;
using CovidCertificate.Backend.DASigningService.ErrorHandling;
using CovidCertificate.Backend.Utils;
using FluentValidation;
using FluentValidation.Results;
using Hl7.Fhir.Model;

namespace CovidCertificate.Backend.DASigningService.Validators
{
    public class FhirImmunizationValidator : AbstractValidator<Immunization>
    {
        public FhirImmunizationValidator()
        {
            RuleFor(x => x.VaccineCode).Cascade(CascadeMode.Stop).NotNull()
                .WithMessage("Immunization.VaccineCode missing.")
                .WithErrorCode(
                    ErrorCode.FHIR_IMMUNIZATION_VACCINECODE_MISSING.ToString(StringUtils.NumberFormattedEnumFormat));

            RuleFor(x => x.VaccineCode.Coding).Cascade(CascadeMode.Stop).NotEmpty()
                .When(x => x.VaccineCode != null)
                .WithMessage("Immunization.VaccineCode.Coding missing or empty.")
                .WithErrorCode(
                    ErrorCode.FHIR_IMMUNIZATION_VACCINECODE_MISSING.ToString(StringUtils.NumberFormattedEnumFormat));

            RuleFor(x => x.VaccineCode.Coding.FirstOrDefault()).Cascade(CascadeMode.Stop).NotEmpty()
                .When(x => x.VaccineCode?.Coding != null)
                .WithMessage("Immunization.VaccineCode.Coding[0] missing.")
                .WithErrorCode(
                    ErrorCode.FHIR_IMMUNIZATION_VACCINECODE_CODE_MISSING.ToString(StringUtils.NumberFormattedEnumFormat));

            RuleFor(x => x.VaccineCode.Coding.FirstOrDefault().Code).Cascade(CascadeMode.Stop).NotEmpty()
                .When(x => x.VaccineCode?.Coding != null)
                .When(x => x.VaccineCode?.Coding.Count > 0)
                .WithMessage("Immunization.VaccineCode.Coding[0].Code missing.")
                .WithErrorCode(
                    ErrorCode.FHIR_IMMUNIZATION_VACCINECODE_CODE_MISSING.ToString(StringUtils.NumberFormattedEnumFormat));

            RuleFor(x => x.Occurrence).Cascade(CascadeMode.Stop).NotNull()
                .WithMessage("Immunization.Occurence missing.")
                .WithErrorCode(
                    ErrorCode.FHIR_IMMUNIZATION_OCCURENCEDATETIME_MISSING.ToString(StringUtils.NumberFormattedEnumFormat));

            RuleFor(x => x.LotNumber).Cascade(CascadeMode.Stop).NotNull()
                .WithMessage("Immunization.LotNumber missing.")
                .WithErrorCode(
                    ErrorCode.FHIR_IMMUNIZATION_LOTNUMBER_MISSING.ToString(StringUtils.NumberFormattedEnumFormat));

            RuleFor(x => x.ProtocolApplied).Cascade(CascadeMode.Stop).NotEmpty()
                .WithMessage("Immunization.ProtocolApplied missing or empty.")
                .WithErrorCode(
                    ErrorCode.FHIR_IMMUNIZATION_PROTOCOLAPPLIED_DOSENUMBER_MISSING.ToString(StringUtils.NumberFormattedEnumFormat));

            RuleFor(x => x.ProtocolApplied.FirstOrDefault()).Cascade(CascadeMode.Stop).NotEmpty()
                .When(x => x.ProtocolApplied != null)
                .WithMessage("Immunization.ProtocolApplied[0] missing or empty.")
                .WithErrorCode(
                    ErrorCode.FHIR_IMMUNIZATION_PROTOCOLAPPLIED_DOSENUMBER_MISSING.ToString(StringUtils.NumberFormattedEnumFormat));

            RuleFor(x => x.ProtocolApplied.FirstOrDefault().DoseNumber).Cascade(CascadeMode.Stop).NotEmpty()
                .When(x => x.ProtocolApplied?.FirstOrDefault() != null)
                .WithMessage("Immunization.ProtocolApplied[0].DoseNumber missing or empty.")
                .WithErrorCode(
                    ErrorCode.FHIR_IMMUNIZATION_PROTOCOLAPPLIED_DOSENUMBER_MISSING.ToString(StringUtils.NumberFormattedEnumFormat));
        }

        protected override bool PreValidate(ValidationContext<Immunization> context, ValidationResult result)
        {
            if (context.InstanceToValidate.Id == null)
            {
                var validationFailureObj = new ValidationFailure("", "Immunization Missing.");
                validationFailureObj.ErrorCode = ErrorCode.FHIR_IMMUNIZATION_MISSING.ToString(StringUtils.NumberFormattedEnumFormat);
                result.Errors.Add(validationFailureObj);
                return false;
            }
            return base.PreValidate(context, result);
        }
    }
}
