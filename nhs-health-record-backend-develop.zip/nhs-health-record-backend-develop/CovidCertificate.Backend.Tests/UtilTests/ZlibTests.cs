﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using SharpCompress.Compressors;
using SharpCompress.Compressors.Deflate;
using Xunit;
using zlib;

namespace CovidCertificate.Backend.Tests.UtilTests
{
    public class ZlibTests
    {
        [Fact]
        public async Task CompressionsAreEqual()
        {
            var loremIpsum =
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ut lorem egestas, ultricies lorem at, efficitur urna. Etiam egestas lorem erat, vel lobortis leo iaculis id. Sed aliquet imperdiet nibh, vel ultrices lectus malesuada id. Integer sem tellus, malesuada non arcu eu, viverra mollis diam. Nullam id neque quis dolor sagittis elementum. Nulla facilisi. Cras lobortis lacus a arcu fringilla, quis molestie lacus condimentum. Sed quis lorem bibendum libero porta aliquet. Vestibulum finibus est vel maximus gravida.\r\n\r\nVestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Ut leo neque, tempor eu tellus sit amet, interdum suscipit lorem. Donec varius eleifend nunc, vitae facilisis quam elementum vitae. Cras nec libero nec massa sollicitudin fringilla non ac erat. Donec id tincidunt lectus. Duis eleifend fermentum urna id commodo. Donec porttitor et purus quis scelerisque. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur condimentum mi lobortis, imperdiet libero quis, iaculis elit.\r\n\r\nVivamus efficitur arcu ligula, id condimentum justo dapibus sit amet. Aliquam iaculis commodo tortor et vulputate. Cras cursus fringilla mauris, vel tincidunt est porta ac. Cras viverra egestas orci, et tincidunt nibh efficitur id. Donec cursus, augue id varius volutpat, libero ligula porttitor leo, vitae mollis enim orci ac magna. Nullam tempor tincidunt lacus, sed interdum lorem ultrices sit amet. Morbi vitae turpis pellentesque dui pretium rutrum at at tortor. Fusce mattis tincidunt elit, vitae ultrices mauris tempus in. Aliquam venenatis lacus quis diam congue tristique. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer hendrerit nisi a vehicula cursus. In sit amet magna magna.\r\n\r\nSed arcu urna, cursus ut ipsum et, porttitor molestie dolor. Duis eget orci imperdiet, tempus dui non, consectetur urna. Pellentesque sed odio maximus mi laoreet vestibulum. Suspendisse a finibus nulla. Praesent et erat non turpis pretium tincidunt sed at neque. Cras ultrices mauris sit amet massa ullamcorper, sodales pretium odio mollis. Quisque nec arcu lectus. Nunc congue viverra neque vitae fermentum. Mauris tristique mauris ipsum, et varius risus porta ut. Vivamus luctus laoreet risus vel sodales. Nam elementum diam vel auctor congue.\r\n\r\nDonec odio augue, consectetur in orci quis, bibendum molestie dolor. Fusce egestas, ipsum eget feugiat euismod, metus quam placerat augue, interdum convallis tortor nisi at dui. Mauris tincidunt porttitor nunc, vitae maximus eros ultrices eu. Sed mollis fringilla metus, at scelerisque est aliquam eget. Praesent viverra feugiat augue, id molestie diam pulvinar vel. Aliquam erat volutpat. Sed eu quam euismod, viverra enim eu, rutrum eros. Suspendisse sodales tortor nec dolor bibendum vehicula. Aenean laoreet, nisi sit amet suscipit volutpat, dolor est mattis est, vel elementum lorem leo quis lectus. Nullam sit amet convallis nibh, et iaculis sapien. Vivamus iaculis ex quam, sit amet aliquam nisl dignissim ornare. Fusce elementum velit et lobortis bibendum. Nulla quam eros, accumsan vitae magna vitae, sollicitudin cursus massa.";
            var inData = Encoding.UTF8.GetBytes(loremIpsum);

            var res1 = string.Empty;
            var res2 = string.Empty;

            using (MemoryStream outMemoryStream = new MemoryStream())
            using (ZOutputStream outZStream = new ZOutputStream(outMemoryStream, zlibConst.Z_DEFAULT_COMPRESSION))
            using (var inMemoryStream = new MemoryStream(inData))
            {
                CopyStream(inMemoryStream, outZStream);
                outZStream.finish();
                byte[] outData = outMemoryStream.ToArray();
                res1 = Convert.ToBase64String(outData);
            }

            using (MemoryStream outMemoryStream2 = new MemoryStream())
            using (ZlibStream outZStream2 = new ZlibStream(outMemoryStream2, CompressionMode.Compress, CompressionLevel.Default))
            using (var inMemoryStream2 = new MemoryStream(inData))
            {
                outZStream2.FlushMode = FlushType.Finish;
                await inMemoryStream2.CopyToAsync(outZStream2);
                outZStream2.Flush();
                byte[] outData = outMemoryStream2.ToArray();
                res2 = Convert.ToBase64String(outData);
            }

            Assert.Equal(res1, res2);
        }

        public static void CopyStream(Stream input, Stream output)
        {
            byte[] buffer = new byte[2000];
            int len;
            while ((len = input.Read(buffer, 0, 2000)) > 0)
            {
                output.Write(buffer, 0, len);
            }
            output.Flush();
        }

    }
}
