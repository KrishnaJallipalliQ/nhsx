﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.RequestDtos;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace CovidCertificate.Backend.Tests.TestHelpers
{
    /// <summary>
    /// Specifies the available <see cref="AntibodyResult.ValidityType"/> values.
    /// </summary>
    public enum AntibodyResultTestType
    {
        Random = -1,
        Positive = 0,
        Negative = 1,
        Void = 2
    }

    /// <summary>
    /// A static class containing essential methods for testing Antibody functionality.
    /// </summary>
    public static class AntibodyTestHelper
    {
        private static Random random;
        // Specifies the earliest possible date of an antibody test
        private static readonly DateTime minDateOfTest;
        // Specifies the possible types for an AntibodyResult
        private static readonly string[] antibodyResultTypes;
        // Specifies the minimum length for the name of a AntibodyResult type
        private const int MinTypeLength = 4;
        // Specifies the maximum length for the name of a AntibodyResult type
        private const int MaxTypeLength = 20;


        static AntibodyTestHelper() 
        {
            random = new Random();
            minDateOfTest = new DateTime(2020, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            antibodyResultTypes = new string[] { "positive", "negative", "void" };
        }


        #region AntibodyRequestDto Methods

        /// <summary>
        /// Creates the specified number of <see cref="AntibodyRequestDto"/> objects using the parameters <paramref name="user"/> and <paramref name="numberOfDtosToCreate"/>.
        /// </summary>
        /// <param name="user">The <see cref="CovidTestUser"/> the created <see cref="AntibodyRequestDto"/> objects should belong to.</param>
        /// <param name="numberOfDtosToCreate">The number of <see cref="AntibodyRequestDto"/> objects to be created.</param>
        /// <param name="testType">The <see cref="AntibodyRequestDto.TestType"/> that <see cref="AntibodyRequestDto"/> objects will be created with.</param>
        /// <returns>An <see cref="IEnumerable{T}"/> of type <see cref="AntibodyRequestDto"/> consisting of <paramref name="numberOfDtosToCreate"/> objects belonging to the specified <paramref name="user"/>.</returns>
        public static IEnumerable<AntibodyRequestDto> CreateAntibodyRequestDto(CovidPassportUser user, int numberOfDtosToCreate, AntibodyResultTestType testType = AntibodyResultTestType.Random)
        {
            for (int i = 0; i < numberOfDtosToCreate; i++)
                yield return CreateAntibodyRequestDto(user, testType);
        }

        /// <summary>
        /// Creates an <see cref="AntibodyRequestDto"/> using the specified <paramref name="user"/>.
        /// </summary>
        /// <param name="user">The <see cref="CovidTestUser"/> the created <see cref="AntibodyRequestDto"/> object should belong to.</param>
        /// <param name="testType">The <see cref="AntibodyRequestDto.TestType"/> that <see cref="AntibodyRequestDto"/> objects will be created with.</param>
        /// <returns>A new <see cref="AntibodyRequestDto"/> belonging to the specified <paramref name="user"/>.</returns>
        public static AntibodyRequestDto CreateAntibodyRequestDto(CovidPassportUser user, AntibodyResultTestType testType = AntibodyResultTestType.Random)
        {
            var dateOfTest = ArrangeTestHelper.CreateRandomDateTimeBetweenDates(minDateOfTest, DateTime.UtcNow);
            var antibodyType = ArrangeTestHelper.CreateRandomString(random.Next(MinTypeLength, MaxTypeLength));
            var antibodyResult = testType == AntibodyResultTestType.Random ? antibodyResultTypes[random.Next(0, antibodyResultTypes.Length)] : antibodyResultTypes[(int)testType];

            //Adding in temporary test kit. Antibody needs merging into testResult and this all needs updating
            return new AntibodyRequestDto(user.Name, user.DateOfBirth, user.EmailAddress, user.PhoneNumber, dateOfTest, antibodyType, antibodyResult, "ELISA");
        }

        /// <summary>
        /// Gets the required <see cref="AntibodyRequestDto"/> properties that will throw a <see cref="JsonSerializationException"/> during deserialization if not specified.
        /// </summary>
        /// <returns>An <see cref="IEnumerable{T}"/> of type <see cref="string"/> of the required JSON fields for deserialization of <see cref="AntibodyRequestDto"/>.</returns>
        public static IEnumerable<string> GetRequiredAntibodyRequestDtoProperties()
        {
            yield return nameof(AntibodyRequestDto.Name);
            yield return nameof(AntibodyRequestDto.TestResult);
            yield return nameof(AntibodyRequestDto.TestType);
        }

        #endregion

        #region AntibodyResult Methods

        /// <summary>
        /// Creates an <see cref="AntibodyResult"/> using the specified <paramref name="user"/>.
        /// </summary>
        /// <param name="user">The <see cref="CovidTestUser"/> the created <see cref="AntibodyResult"/> object should belong to.</param>
        /// <param name="testType">The <see cref="AntibodyResult.ValidityType"/> that <see cref="AntibodyResult"/> objects will be created with.</param>
        /// <returns>A new <see cref="AntibodyResult"/> belonging to the specified <paramref name="user"/>.</returns>
        public static AntibodyResult CreateAntibodyResult(CovidPassportUser user, AntibodyResultTestType testType = AntibodyResultTestType.Random)
        {
            var antibodyRequestDto = CreateAntibodyRequestDto(user, testType);
            return new AntibodyResult(antibodyRequestDto);
        }

        /// <summary>
        /// Creates the specified number of <see cref="AntibodyResult"/> objects using the parameters <paramref name="user"/> and <paramref name="numberOfResultsToCreate"/>.
        /// </summary>
        /// <param name="user">The <see cref="CovidTestUser"/> the created <see cref="AntibodyResult"/> objects should belong to.</param>
        /// <param name="numberOfResultsToCreate">The number of <see cref="AntibodyResult"/> objects to be created.</param>
        /// <param name="testType">The <see cref="AntibodyResult.ValidityType"/> that <see cref="AntibodyResult"/> objects will be created with.</param>
        /// <returns>An <see cref="IEnumerable{T}"/> of type <see cref="AntibodyResult"/> consisting of <paramref name="numberOfResultsToCreate"/> objects belonging to the specified <paramref name="user"/>.</returns>
        public static IEnumerable<AntibodyResult> CreateAntibodyResult(CovidPassportUser user, int numberOfResultsToCreate, AntibodyResultTestType testType = AntibodyResultTestType.Random)
        {
            for (int i = 0; i < numberOfResultsToCreate; i++)
                yield return CreateAntibodyResult(user, testType);
        }

        /// <summary>
        /// Gets the required <see cref="AntibodyResult"/> properties that will throw a <see cref="JsonSerializationException"/> during deserialization if not specified.
        /// </summary>
        /// <returns>An <see cref="IEnumerable{T}"/> of type <see cref="string"/> of the required JSON fields for deserialization of <see cref="AntibodyResult"/>.</returns>
        public static IEnumerable<string> GetRequiredAntibodyProperties()
        {
            // Note: Property 'Id' is currently not a required property as it is not set to be nullable. If this changes, the property should be added here. 
            yield return nameof(AntibodyResult.TestResult);
            yield return nameof(AntibodyResult.ValidityType);
        }

        #endregion
    }
}
