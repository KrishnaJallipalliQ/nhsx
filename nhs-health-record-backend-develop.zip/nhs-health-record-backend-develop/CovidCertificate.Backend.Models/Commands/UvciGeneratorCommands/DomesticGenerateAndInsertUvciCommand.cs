﻿using System;
using CovidCertificate.Backend.Models.Enums;

namespace CovidCertificate.Backend.Models.Commands.UvciGeneratorCommands
{
    public class DomesticGenerateAndInsertUvciCommand : GenerateAndInsertUvciCommand
    {
        public DomesticGenerateAndInsertUvciCommand(
            string issuer, 
            string country,
            string userHash, 
            CertificateType certificateType, 
            CertificateScenario certificateScenario, 
            DateTime dateOfCertificateExpiration) : base(issuer, country, userHash, certificateType, certificateScenario, dateOfCertificateExpiration)
        {
        }
    }
}
