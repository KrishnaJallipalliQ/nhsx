﻿namespace CovidCertificate.Backend.Models.Enums
{
    public enum CertificateType
    {
        Diagnostic,
        Vaccination,
        Immunity,
        Recovery,
        Exemption,
        None
    }
}