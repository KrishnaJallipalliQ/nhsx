﻿using CovidCertificate.Backend.DASigningService.Requests;
using Hl7.Fhir.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.DASigningService.Tests.ValidatorTests.TestHelpers
{
    class Create2DVaccinationBarcodeRequestValidatorTestHelper
    {
        public static Create2DVaccinationBarcodeRequest CreateValidMock2DBarcodeRequest()
        {
            var mockBarcode = new Create2DVaccinationBarcodeRequest();

            mockBarcode.Type = "international";
            mockBarcode.Body = "body";
            mockBarcode.RegionSubscriptionNameHeader = "header";

            return mockBarcode;
        }
    }
}
