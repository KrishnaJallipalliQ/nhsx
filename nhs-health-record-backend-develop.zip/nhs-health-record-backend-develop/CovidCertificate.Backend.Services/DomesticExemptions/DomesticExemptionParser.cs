﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Models.Validators;
using CovidCertificate.Backend.Utils;
using CsvHelper;
using CsvHelper.Configuration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services.DomesticExemptions
{
    public class DomesticExemptionParser : IDomesticExemptionParser
    {
        private ILogger<DomesticExemptionParser> logger;
        private DateTime maxDateOfBirth;
        private DateTime minDateOfBirth;

        public DomesticExemptionParser(ILogger<DomesticExemptionParser> logger, IConfiguration config)
        {
            this.logger = logger;
            this.maxDateOfBirth = DateTime.Parse(config["MaxDateOfBirth"], CultureInfo.InvariantCulture);
            this.minDateOfBirth = DateTime.Parse(config["MinDateOfBirth"], CultureInfo.InvariantCulture);
        }

        public async Task<(List<DomesticExemption> parsedExemptions, List<string> failedUsers)> ParseStringInputToDomesticExemptions(string request, string defaultReason = "")
        {
            logger.LogInformation($"{nameof(ParseStringInputToDomesticExemptions)} was invoked");

            var ingestedExemptions = new List<DomesticExemptionDto>();
            var failedExemptions = new List<string>();
            var isRecordBad = false;
            using (var reader = new StringReader(request))
            {
                var stringBuilder = new StringBuilder();
                for (string line = reader.ReadLine(); !String.IsNullOrEmpty(line); line = reader.ReadLine())
                {
                    stringBuilder.AppendLine(line.Trim('"'));
                }

                var conf = new CsvConfiguration(CultureInfo.InvariantCulture)
                {
                    Mode = CsvMode.Escape,
                    HasHeaderRecord = false,
                    BadDataFound = context =>
                    {
                        isRecordBad = true;
                        logger.LogWarning($"Incorrect data format:" + context.RawRecord);
                        failedExemptions.Add(context.RawRecord);
                    },
                    MissingFieldFound = null
                };

                using (var csv = new CsvReader(new StringReader(stringBuilder.ToString()), conf))
                {
                    while (csv.Read())
                    {
                        var record = csv.GetRecord<DomesticExemptionDto>();
                        if (String.IsNullOrEmpty(record.Reason))
                            record.Reason = defaultReason;
                        if (!ValidateDoB(record.DateOfBirth))
                        {
                            logger.LogWarning($"Invalid date of birth: " + record.DateOfBirth);
                            failedExemptions.Add(record.ToString());
                            continue;
                        }
                        if (record.ValidateObjectAsync().Result.IsValid && !isRecordBad)
                        {
                            ingestedExemptions.Add(record);
                        }

                        isRecordBad = false;
                    }
                }
            }

            var parsedExemptions = ingestedExemptions
                .Select(x => x.ToDomesticExemption()).ToList();

            logger.LogInformation($"{nameof(ParseStringInputToDomesticExemptions)} has finished");
            return (parsedExemptions, failedExemptions);
        }

        private bool ValidateDoB(DateTime dateOfBirth)
        {
            return dateOfBirth > minDateOfBirth && dateOfBirth < maxDateOfBirth;
        }
    }
}
