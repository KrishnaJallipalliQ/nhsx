﻿using CovidCertificate.Backend.Models.Enums;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace CovidCertificate.Backend.Models.DataModels
{
    [Collection("RegionUvci")]
    public class RegionUvciGeneratorModel : MongoDocument
    {
        [BsonRequired]
        public string UniqueCertificateId { get; set; }
        public CertificateType CertificateType { get; set; }
        public CertificateScenario CertificateScenario { get; set; }
        public string CertificateIssuer { get; set; }
        public string UserHash { get; set; }
        public DateTime DateOfCertificateCreation { get; set; }
        public DateTime DateOfCertificateExpiration { get; set; }

        public RegionUvciGeneratorModel(string uvci) : base()
        {
            UniqueCertificateId = uvci;
        }

        public RegionUvciGeneratorModel(string uvci, CertificateType certificateType, CertificateScenario certificateScenario, string certificateIssuer, string userHash, DateTime dateOfCertificateCreation, DateTime dateOfCertificateExpiration) : base()
        {
            UniqueCertificateId = uvci;
            CertificateType = certificateType;
            CertificateScenario = certificateScenario;
            CertificateIssuer = certificateIssuer;
            UserHash = userHash;
            DateOfCertificateCreation = dateOfCertificateCreation;
            DateOfCertificateExpiration = dateOfCertificateExpiration;
        }
    }
}
