﻿using MongoDB.Bson.Serialization.Attributes;

namespace CovidCertificate.Backend.Models.DataModels
{
    public class EligibilityDomesticExemptions
    {
        public int CertificateExpiresInHours { get; private set; }

        public EligibilityDomesticExemptions(int certificateExpiresInHours)
        {
            this.CertificateExpiresInHours = certificateExpiresInHours;
        }
    }
}
