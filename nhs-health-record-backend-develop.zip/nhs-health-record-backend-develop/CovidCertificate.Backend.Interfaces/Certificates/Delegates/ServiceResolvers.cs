﻿namespace CovidCertificate.Backend.Interfaces.Delegates
{
    public delegate IJwtValidationParameterFetcher ValidationServiceResolver(string bearerType);
    public delegate IJwtValidator JwtValidatorResolver(string bearerType);
}
