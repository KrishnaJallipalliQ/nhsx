﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.RequestDtos;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces.Certificates
{
    public interface IExpirationConfigurationRetriever
    {
        /// <summary>
        /// Fetches the configuration for our expiry logic
        /// </summary>
        /// <param name="tests"></param>
        /// <returns></returns>
        Task<TimeSpan> GetExpirationAsync(IEnumerable<TestResult> tests);
    }
}
