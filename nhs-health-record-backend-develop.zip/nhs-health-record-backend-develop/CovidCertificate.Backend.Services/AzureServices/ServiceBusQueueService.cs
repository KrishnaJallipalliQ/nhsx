﻿using Azure.Messaging.ServiceBus;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.Exceptions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services
{
    public class ServiceBusQueueService : IQueueService
    {
        private readonly ILogger<ServiceBusQueueService> logger;
        private readonly string ServiceBusConnection;
        private readonly ServiceBusClient client;
        private readonly Dictionary<string, ServiceBusSender> senders = new Dictionary<string, ServiceBusSender>();

        public ServiceBusQueueService(IConfiguration configuration, ILogger<ServiceBusQueueService> logger)
        {
            this.ServiceBusConnection = configuration["ServiceBusConnectionString"];
            if (ServiceBusConnection == default)
                throw new ApplicationException("Service Bus connection is not setup");

            client = new ServiceBusClient(ServiceBusConnection);
            this.logger = logger;
        }

        private ServiceBusSender GetServiceBusSender(string queueName)
        {
            if (!senders.ContainsKey(queueName))
            {
                senders[queueName] = client.CreateSender(queueName);
            }

            return senders[queueName];
        }

        /// <summary>
        /// Sends a batch of messages using the azure service bus
        /// </summary>
        /// <param name="queueName"></param>
        /// <param name="messages"></param>
        /// <returns></returns>
        public async Task<int> SendMessages(string queueName, IEnumerable<string> messages)
        {
            if (messages == default)
                return -1;

            try
            {
                var sender = GetServiceBusSender(queueName);
                var sbMessages = CreateMessages(messages);

                var initialCount = sbMessages.Count;
                var sentMessages = 0;

                var messageBatches = new List<ServiceBusMessageBatch>();
                while (sbMessages.Count > 0)
                {
                    using var messageBatch = await sender.CreateMessageBatchAsync();

                    if (!messageBatch.TryAddMessage(sbMessages.Peek()))
                        throw new ServiceBusMessageException($"Message {initialCount - sbMessages.Count} is too large and cannot be sent.");

                    sbMessages.Dequeue();

                    while (sbMessages.Count > 0 && messageBatch.TryAddMessage(sbMessages.Peek()))
                    {
                        sbMessages.Dequeue();
                        sentMessages++;
                    }
                };

                var messageBatchSendTasks = new List<Task>();

                foreach (var batch in messageBatches)
                {
                    messageBatchSendTasks.Add(sender.SendMessagesAsync(batch));
                }

                await Task.WhenAll(messageBatchSendTasks);

                return sentMessages;
            }
            catch (Exception e)
            {
                logger.LogCritical(e, e.Message);
                throw;
            }
        }

        private static Queue<ServiceBusMessage> CreateMessages(IEnumerable<string> messages)
        {
            var sbMessages = new Queue<ServiceBusMessage>();
            foreach (var message in messages)
            {
                sbMessages.Enqueue(new ServiceBusMessage(message));
            }

            return sbMessages;
        }

        public async Task<bool> SendMessage(string queueName, string message)
        {
            if (string.IsNullOrEmpty(message))
                return false;

            try
            {
                var sender = GetServiceBusSender(queueName);
                var queueMessage = new ServiceBusMessage(message);

                // send the message
                await sender.SendMessageAsync(queueMessage);

                return true;
            }
            catch (Exception e)
            {
                logger.LogCritical(e, e.Message);
                throw;
            }
        }

        public async Task<int> SendMessages<T>(string queueName, IEnumerable<T> messages) where T : class
        {
            var messageTasks = new List<Task<string>>();

            foreach (var message in messages)
            {
                messageTasks.Add(Task.Run(() => JsonConvert.SerializeObject(message)));
            }
            var messageStrings = await Task.WhenAll(messageTasks);

            return await SendMessages(queueName, messageStrings);
        }

        public async Task<bool> SendMessage<T>(string queueName, T messageObject) where T : class
        {
            var message = JsonConvert.SerializeObject(messageObject);
            return await SendMessage(queueName, message);
        }
    }
}
