using System;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using CovidCertificate.Backend.Models.Commands.UvciGeneratorCommands;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Utils;

namespace CovidCertificate.Backend.Services.Certificates
{
    public class UvciGenerator : IUvciGenerator
    {
        private const string Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

        private readonly IMongoRepository<UvciGeneratorModel> mongoRepository;
        private readonly IMongoRepository<RegionUvciGeneratorModel> regionMongoRepository;
        private readonly ILogger<UvciGenerator> logger;
        private readonly IConfiguration configuration;

        public UvciGenerator(IConfiguration configuration,
                             ILogger<UvciGenerator> logger,
                             IMongoRepository<UvciGeneratorModel> mongoRepository,
                             IMongoRepository<RegionUvciGeneratorModel> regionMongoRepository
                             )
        {
            this.configuration = configuration;
            this.mongoRepository = mongoRepository;
            this.regionMongoRepository = regionMongoRepository;
            this.logger = logger;
        }

        public async Task<bool> UvciExistsForUser(CovidPassportUser user, CertificateScenario scenario)
        {
            logger.LogInformation($"{nameof(UvciExistsForUser)} was invoked");

            var userHash = StringUtils.GetValueHash(user.Name, user.DateOfBirth);
            var result = await mongoRepository.FindOneAsync(x => x.UserHash == userHash && x.CertificateScenario.Equals(scenario));

            logger.LogInformation($"{nameof(UvciExistsForUser)} has finished");
            return result != null;
        }

        public async Task<string> TryGenerateAndInsertUvci(GenerateAndInsertUvciCommand command)
        {
            logger.LogInformation("TryGenerateAndInsertUvci invoked.");

            var uvci = "";

            var prefix = configuration["UVCIPrefix"];
            var version = configuration["UVCIVersion"];

            var addedToMongo = false;

            while (!addedToMongo)
            {
                var certificateGenerationTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

                uvci = GenerateUvciString(version, prefix, command.Country, certificateGenerationTime);

                DateTime certificateGenerationTimeDateTime = DateTimeOffset.FromUnixTimeMilliseconds(certificateGenerationTime).DateTime;

                addedToMongo = await TryInsertUvciMetadata(uvci, certificateGenerationTimeDateTime, command);
            }

            logger.LogInformation("TryGenerateAndInsertUvci finished.");

            return uvci;
        }

        private async Task<bool> TryInsertUvciMetadata(
            string uvci, 
            DateTime certificateGenerationDateTime, 
            GenerateAndInsertUvciCommand command)
        {
            var result = await mongoRepository.FindOneAsync(x => x.UniqueCertificateId == uvci);
            
            if (result is null)
            {
                switch (command)
                {
                    case RegionalGenerateAndInsertUvciCommand regionalCommand:
                        await InsertRegionUvci(uvci, certificateGenerationDateTime, regionalCommand);
                        break;
                    case DomesticGenerateAndInsertUvciCommand domesticCommand:
                        await InsertDomesticUvci(uvci, certificateGenerationDateTime, domesticCommand);
                        break;
                    default:
                        throw new NotSupportedException("Other types of commands for UVCI creation are not supported.");
                }

                return true;
            }
            
            return false;
        }

        private async Task InsertDomesticUvci(string uvci, DateTime certificateGenerationDateTime,
            GenerateAndInsertUvciCommand command)
        {
            var document = new UvciGeneratorModel(
                uvci,
                command.CertificateType,
                command.CertificateScenario,
                command.Issuer,
                command.UserHash,
                certificateGenerationDateTime,
                command.DateOfCertificateExpiration);

            await mongoRepository.InsertOneAsync(document);
        }

        private async Task InsertRegionUvci(string uvci, DateTime certificateGenerationDateTime,
            GenerateAndInsertUvciCommand command)
        {
            var document = new RegionUvciGeneratorModel(
                uvci,
                command.CertificateType,
                command.CertificateScenario,
                command.Issuer,
                command.UserHash,
                certificateGenerationDateTime,
                command.DateOfCertificateExpiration);

            await regionMongoRepository.InsertOneAsync(document);
        }

        private string GenerateUvciString(string uvciVersion, string uvciPrefix, string uvciIssuer, long certificateGenerationTime)
        {
            var sb = new StringBuilder("");

            var randomString = new string(Enumerable.Repeat(Chars, 8).Select(s => s[RandomNumberGenerator.GetInt32(s.Length)]).ToArray());

            var uvciString = sb
                .Append(uvciPrefix).Append(":")
                .Append(uvciVersion).Append(":")
                .Append(uvciIssuer).Append(":")
                .Append(certificateGenerationTime)
                .Append(randomString).ToString();

            char checkSumChar = GenerateCheckCharacter(uvciString);

            return $"{uvciString}#{checkSumChar}";
        }

        private char GenerateCheckCharacter(string input)
        {
            const string charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/:";
            int factor = 2;
            int sum = 0;
            int charsetSize = charset.Length;

            foreach (var inputChar in input.Reverse())
            {
                int codePoint = charset.IndexOf(inputChar);

                if (codePoint == -1)
                {
                    continue;
                }

                int addend = factor * codePoint;
                factor = (factor == 2) ? 1 : 2;
                int baseAddend = (addend / charsetSize) + (addend % charsetSize);
                sum += baseAddend;
            }

            int remainder = sum % charsetSize;
            int checkCodePoint = (charsetSize - remainder) % charsetSize;

            return charset[checkCodePoint];
        }
    }
}
