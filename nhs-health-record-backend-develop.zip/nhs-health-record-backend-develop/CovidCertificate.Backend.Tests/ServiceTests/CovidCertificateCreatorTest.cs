using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Services.Certificates;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using Xunit;
using CovidCertificate.Backend.Models.Enums;
using System.Threading.Tasks;
using CovidCertificate.Backend.Tests.TestHelpers;
using Microsoft.Extensions.Configuration;
using CovidCertificate.Backend.Services;
using CovidCertificate.Backend.International.Interfaces;
using System.Linq;
using CovidCertificate.Backend.Models.Commands.UvciGeneratorCommands;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class CovidCertificateCreatorTest
    {
        private readonly CovidCertificateCreator service;
        private readonly Mock<IQRCodeGenerator> QRCodeGeneratorMock = new Mock<IQRCodeGenerator>(MockBehavior.Strict);
        private readonly Mock<ILogger<CovidCertificateCreator>> loggerMock = new Mock<ILogger<CovidCertificateCreator>>();
        private readonly Mock<ILogger<TestResultFilter>> TRLoggerMock = new Mock<ILogger<TestResultFilter>>();
        private readonly Mock<IVRService> mockVRService = new Mock<IVRService>();
        private readonly Mock<IBlobFilesInMemoryCache<EligibilityConfiguration>> mockBlobCache = new Mock<IBlobFilesInMemoryCache<EligibilityConfiguration>>();
        private readonly Mock<IConfigurationValidityCalculator> mockConfigurationValidityCalculator = new Mock<IConfigurationValidityCalculator>();
        private readonly Mock<IMappingCache> mockMappings = new Mock<IMappingCache>();
        private readonly TestResultFilter mockTestResultFilter;
        private readonly Mock<IConfiguration> mockConfig = new Mock<IConfiguration>();
        private readonly Mock<IPilotFilterService> mockPilotFilter = new Mock<IPilotFilterService>();
        private readonly Mock<IDiagnosticTestResultsService> mockTestResultsService = new Mock<IDiagnosticTestResultsService>();
        private readonly Mock<IAntibodyResultsService> mockAntibodyResultsService = new Mock<IAntibodyResultsService>();
        private readonly Mock<IDomesticExemptionService> mockDomesticExemptionService = new Mock<IDomesticExemptionService>();
        private readonly Mock<IGetTimeZones> mockGetTimeZones = new Mock<IGetTimeZones>();
        private readonly Mock<IDomesticExemptionCertificateGenerator> mockDomesticExemptionCertificateGeneration = new Mock<IDomesticExemptionCertificateGenerator>();
        private readonly Mock<IUvciGenerator> mockUvciGenerator = new Mock<IUvciGenerator>();
        private readonly Mock<IEncoderService> mockEncoderService = new Mock<IEncoderService>();
        private readonly Mock<IRedisCacheService> mockRedisService = new Mock<IRedisCacheService>();
        private string idToken;
        private readonly CovidPassportUser validUser = CovidTestUserTestHelper.CreateNewP9User();

        private readonly EligibilityConfiguration testConfiguration = EligibilityConfigurationHelper.CreatedConfiguration();

        public CovidCertificateCreatorTest()
        {
            idToken = "eyJzdWIiOiJjNzE0ZDM2Ny0wMWY4LTRkNzgtOWYwNi01ZTkxNDZhZjA2ZjEiLCJhdWQiOiJoZWFsdGhyZWNvcmRzIiwia2lkIjoiZjYwZWI0NmZmOGFiZjBiZjllOTE3ZWVlNjA4NmM1ZmE0YTE2MmE1ZCIsImlzcyI6Imh0dHBzOi8vYXV0aC5hb3Muc2lnbmluLm5ocy51ayIsInR5cCI6IkpXVCIsImV4cCI6MTYyNDM3MTk4NywiaWF0IjoxNjI0MzY4Mzg3LCJhbGciOiJSUzUxMiIsImp0aSI6IjAzZWY4ZGM4LTEwNjktNDdmMi04ZDQ2LWFjMjliMGIzYWI4NCJ9.eyJzdWIiOiJjNzE0ZDM2Ny0wMWY4LTRkNzgtOWYwNi01ZTkxNDZhZjA2ZjEiLCJiaXJ0aGRhdGUiOiIxOTEwLTA2LTE0IiwibmhzX251bWJlciI6Ijk0NDI2MTY4NjIiLCJpc3MiOiJodHRwczovL2F1dGguYW9zLnNpZ25pbi5uaHMudWsiLCJ2dG0iOiJodHRwczovL2F1dGguYW9zLnNpZ25pbi5uaHMudWsvdHJ1c3RtYXJrL2F1dGguYW9zLnNpZ25pbi5uaHMudWsiLCJhdWQiOiJoZWFsdGhyZWNvcmRzIiwiaWRfc3RhdHVzIjoidmVyaWZpZWQiLCJ0b2tlbl91c2UiOiJpZCIsInN1cm5hbWUiOiJDSE9VREhVUlkiLCJhdXRoX3RpbWUiOjE2MjQzNjgzODIsInZvdCI6IlA1LkNwLkNkIiwiaWRlbnRpdHlfcHJvb2ZpbmdfbGV2ZWwiOiJQOSIsImV4cCI6MTYyNDM3MTk4NywiaWF0IjoxNjI0MzY4Mzg3LCJmYW1pbHlfbmFtZSI6IkNIT1VESFVSWSIsImp0aSI6IjAzZWY4ZGM4LTEwNjktNDdmMi04ZDQ2LWFjMjliMGIzYWI4NCJ9.OUgxDDbVp_x7KK4EJRwMmYmM4mPJu-Jv60zVfnCouOA7tg_5K5K64QIi87F19d7AuwEDPe1Rtfas9i1cD5desIW8h9_wyfTsiCr8Oeo1nTBqz3qVEE-xOWqWQ8xQgFZk4Y-4x7ay8BohmvxRqiD-cYVeI5gp_bwG_lnIBEE-iBEIWnOnyyqgfOMRt3fCf6NIIrT2JJOd2J35C8tZdNPV_4k3AObyg1laHg-6JTtVCkfcRFAFhwfV5nB3deu-k4NldZMBVscpq0sovAgytAPx_ZrnD06eT7TPQd7WeYIxqRYECNI8bzLz0TnFjQE2u1xIzl_bE3oVpffALUafwyR12g";
            mockTestResultFilter = new TestResultFilter(TRLoggerMock.Object);
            SetupUvciGeneratorMock();

            service = new CovidCertificateCreator(mockVRService.Object,
                                                  QRCodeGeneratorMock.Object,
                                                  mockBlobCache.Object,
                                                  mockConfigurationValidityCalculator.Object, loggerMock.Object,
                                                  mockTestResultFilter,
                                                  mockConfig.Object,
                                                  mockPilotFilter.Object,
                                                  mockTestResultsService.Object,
                                                  mockAntibodyResultsService.Object,
                                                  mockDomesticExemptionService.Object,
                                                  mockDomesticExemptionCertificateGeneration.Object,
                                                  mockGetTimeZones.Object,
                                                  mockUvciGenerator.Object,
                                                  mockEncoderService.Object,
                                                  mockRedisService.Object
                                                 );
        }

        [Fact]
        public async Task GetCertificate_ReturnError_WhenUserNull()
        {
            CovidPassportUser nullUser = null;
            var result = await Assert.ThrowsAsync<ArgumentNullException>(() => service.GetDomesticCertificate(nullUser, idToken));
            Assert.NotNull(result);
            Assert.IsType<ArgumentNullException>(result);
            var inner = (ArgumentNullException)result;
            Assert.NotNull(inner.Message);
            Assert.StartsWith("No user to get certificate for", inner.Message);
        }

        [Fact]
        public async Task GetCertificate_ReturnCertificate_ValidUserWithAllHashes()
        {
            mockBlobCache.Setup(m => m.GetFile()).ReturnsAsync(new EligibilityConfiguration(It.IsAny<IEnumerable<EligibilityRules>>(), It.IsAny<EligibilityDomesticExemptions>()));
            Certificate blankVaccineCert = new Certificate(null, default, DateTime.UtcNow.AddDays(5), DateTime.UtcNow.AddDays(15), CertificateType.Vaccination, CertificateScenario.International);
            mockUvciGenerator.Setup(x => x.TryGenerateAndInsertUvci(It.IsAny<DomesticGenerateAndInsertUvciCommand>()))
                .ReturnsAsync("test:uvci");

            mockConfigurationValidityCalculator.Setup(m => m.GenerateCertificatesUsingRules(It.IsAny<IEnumerable<IGenericResult>>(), It.IsAny<IEnumerable<EligibilityRules>>(), It.IsAny<CovidPassportUser>())).Returns(new List<Certificate>() { blankVaccineCert });
            QRCodeGeneratorMock.Setup(m => m.GenerateQRCodeForCertificate(It.IsAny<Certificate>())).ReturnsAsync((string)null);
            mockVRService.Setup(m => m.GetVaccines(It.IsAny<string>(), It.IsAny<CovidPassportUser>())).ReturnsAsync(new List<Vaccine>());
            mockGetTimeZones.Setup(m => m.GetTimeZoneInfo()).Returns(TimeZoneInfo.Utc);
            var result = await service.GetDomesticCertificate(validUser, idToken);
            Assert.NotNull(result);
            Assert.IsType<Certificate>(result);
            Assert.Equal(validUser.Name, result.Name);
        }

        [Fact]
        public async Task GetCertificate_ReturnsNoCert_WhenHomeTestsExcluded()
        {
            mockBlobCache.Setup(m =>m.GetFile()).ReturnsAsync(new EligibilityConfiguration(It.IsAny<IEnumerable<EligibilityRules>>(), It.IsAny<EligibilityDomesticExemptions>()));
            mockVRService.Setup(m => m.GetVaccines(It.IsAny<string>(), It.IsAny<CovidPassportUser>())).ReturnsAsync(new List<Vaccine>());
            var homeTests = new List<TestResult>
            {
                getDiagnostic(validUser,DateTime.Now,"SelfTest"),
                getDiagnostic(validUser,DateTime.Now.AddDays(-7),"SelfTest")

            };
            Environment.SetEnvironmentVariable("UsePCRSelfTests", "false");
            Environment.SetEnvironmentVariable("UseLFTSelfTests", "false");
            var result = await service.GetDomesticCertificate(validUser, idToken);
            Assert.Null(result);
        }

        [Fact]
        public async Task GetCertificateByHash_ReturnError_WhenParamsNull()
        {
            RemoteAccessCode code = null;
            FetchRemoteCovidStatusDto dto = null;
            var result = await Assert.ThrowsAsync<ArgumentNullException>(() => service.GetCertificateByHash(code, dto, idToken));
            Assert.NotNull(result);
            Assert.IsType<ArgumentNullException>(result);
            var inner = (ArgumentNullException)result;
            Assert.NotNull(inner.Message);
            Assert.StartsWith("No user to get certificate for", inner.Message);
        }

        [Fact]
        public async Task GetDomesticCertificate_ReturnsCertificate_WhenUserIsExemp()
        {
            // Arrange
            CovidPassportUser user = new CovidPassportUser("Test McTestPerson", DateTime.UtcNow.AddYears(-20), "test@test.com", "0123456789", "0000000000");

            mockVRService.Setup(x => x.GetVaccines(It.IsAny<string>(), It.IsAny<CovidPassportUser>())).Verifiable();
            mockDomesticExemptionService.Setup(m => m.IsUserExempt(It.IsAny<string>(), It.IsAny<DateTime>())).ReturnsAsync(true);
            mockDomesticExemptionCertificateGeneration.Setup(m => m.GenerateCertificate(It.IsAny<CovidPassportUser>()))
                .ReturnsAsync(new Certificate(user.Name, user.DateOfBirth, DateTime.Now.AddMonths(1), DateTime.Now.AddYears(1), CertificateType.Exemption, CertificateScenario.Domestic))
                .Verifiable();
            mockUvciGenerator.Setup(x => x.TryGenerateAndInsertUvci(It.IsAny<DomesticGenerateAndInsertUvciCommand>()))
                .ReturnsAsync("test:uvci");

            mockVRService.Setup(m => m.GetVaccines(It.IsAny<string>(), It.IsAny<CovidPassportUser>())).ReturnsAsync(new List<Vaccine>());
            mockTestResultsService.Setup(m => m.GetDiagnosticTestResults(It.IsAny<string>())).ReturnsAsync(new List<TestResultNhs>());
            mockAntibodyResultsService.Setup(m => m.GetAntibodyResults(It.IsAny<string>())).ReturnsAsync(new List<AntibodyResultNhs>());
            mockBlobCache.Setup(m =>m.GetFile()).ReturnsAsync(new EligibilityConfiguration(It.IsAny<IEnumerable<EligibilityRules>>(), It.IsAny<EligibilityDomesticExemptions>()));

            mockVRService.Setup(m => m.GetVaccines(It.IsAny<string>(), It.IsAny<CovidPassportUser>())).ReturnsAsync(new List<Vaccine>());
            mockTestResultsService.Setup(m => m.GetDiagnosticTestResults(It.IsAny<string>())).ReturnsAsync(new List<TestResultNhs>());
            mockAntibodyResultsService.Setup(m => m.GetAntibodyResults(It.IsAny<string>())).ReturnsAsync(new List<AntibodyResultNhs>());
            mockBlobCache.Setup(m =>m.GetFile()).ReturnsAsync(new EligibilityConfiguration(It.IsAny<IEnumerable<EligibilityRules>>(), It.IsAny<EligibilityDomesticExemptions>()));

            // Act
            var result = await service.GetDomesticCertificate(user, idToken);

            // Assert
            mockDomesticExemptionCertificateGeneration.Verify(x => x.GenerateCertificate(It.IsAny<CovidPassportUser>()), Times.Once);
            mockVRService.Verify(x => x.GetVaccines(It.IsAny<string>(), It.IsAny<CovidPassportUser>()), Times.Once);
        }

        [Fact(Skip = "Disabled as long as no longer retrieving certificates by hash")]
        public async Task GetCertificateByHash_ReturnNoCertificate_WhenNoTypeIsValid()
        {
            CovidPassportUser userNoDetails = new CovidPassportUser("Test McTestPerson", DateTime.UtcNow.AddYears(-20), "", "", "");
            RemoteAccessCode code = new RemoteAccessCode("Test", 1, DateTime.UtcNow.AddYears(1), "", userNoDetails);
            FetchRemoteCovidStatusDto dto = new FetchRemoteCovidStatusDto("Test McTestPerson", DateTime.UtcNow.AddYears(-20), "");
            mockBlobCache.Setup(m =>m.GetFile()).ReturnsAsync(new EligibilityConfiguration(It.IsAny<IEnumerable<EligibilityRules>>(), It.IsAny<EligibilityDomesticExemptions>()));
            var result = await service.GetCertificateByHash(code, dto, idToken);
            Assert.Null(result);
        }
        /*[Fact]
        public async void GetCertificateByHash_ReturnCertificate_AllHashValues()
        {
            CovidPassportUser validUser = new CovidPassportUser("Test McTestPerson", DateTime.UtcNow.AddYears(-20), "test@test.com", "0123456789", "0000000000");
            RemoteAccessCode code = new RemoteAccessCode("Test", 1, DateTime.UtcNow.AddYears(1), "", validUser);
            FetchRemoteCovidStatusDto dto = new FetchRemoteCovidStatusDto("Test McTestPerson", DateTime.UtcNow.AddYears(-20), "");
            var validVaccines = new List<Vaccine>()
            {
                new Vaccine{Date = DateTime.UtcNow.AddDays(-10),Product="Oxford"},
                new Vaccine{Date = DateTime.UtcNow.AddDays(-5),Product="Oxford"}
            };
            mockVRService.Setup(m => m.GetVaccines(It.IsAny<string>())).ReturnsAsync(validVaccines);
            var antibodyResults = new List<AntibodyResult>()
            {
                getAntibody(validUser,DateTime.UtcNow.AddDays(-1))
            };
            mockAntibodyMongo.Setup(m => m.FindAllAsync(It.IsAny<Expression<Func<AntibodyResult, bool>>>())).ReturnsAsync(antibodyResults);
            var testResults = new List<TestResult>()
            {
                getDiagnostic(validUser,DateTime.UtcNow.AddDays(-5))
            };
            mockTestMongo.Setup(m => m.FindAllAsync(It.IsAny<Expression<Func<TestResult, bool>>>())).ReturnsAsync(testResults);
            mockBlobCache.Setup(m =>m.GetFile()).ReturnsAsync(new EligibilityConfiguration(It.IsAny<IEnumerable<EligibilityRules>>(), true));
            Certificate blankVaccineCert = new Certificate(null, default, DateTime.UtcNow.AddDays(5), CertificateType.Vaccination);
            mockConfigurationValidityCalculator.Setup(m => m.GenerateCertificatesUsingRules(It.IsAny<IEnumerable<IGenericResult>>(), It.IsAny<EligibilityConfiguration>())).Returns(blankVaccineCert);
            QRCodeGeneratorMock.Setup(m => m.GenerateQRCodeForCertificate(It.IsAny<Certificate>())).ReturnsAsync((string)null);
            var result = await service.GetCertificateByHash(code, dto, idToken);
            Assert.IsType<Certificate>(result);
            Assert.Equal(validUser.Name, result.Name);

        }
        [Fact]
        public async void GetCertificateByHash_ReturnCertificate_EmailHash()
        {
            CovidPassportUser validUser = new CovidPassportUser("Test McTestPerson", DateTime.UtcNow.AddYears(-20), "test@test.com", "", "0000000000");
            RemoteAccessCode code = new RemoteAccessCode("Test", 1, DateTime.UtcNow.AddYears(1), "", validUser);
            FetchRemoteCovidStatusDto dto = new FetchRemoteCovidStatusDto("Test McTestPerson", DateTime.UtcNow.AddYears(-20), "");
            var validVaccines = new List<Vaccine>()
            {
                new Vaccine{Date = DateTime.UtcNow.AddDays(-10),Product="Oxford"},
                new Vaccine{Date = DateTime.UtcNow.AddDays(-5),Product="Oxford"}
            };
            mockVRService.Setup(m => m.GetVaccines(It.IsAny<string>())).ReturnsAsync(validVaccines);
            var antibodyResults = new List<AntibodyResult>()
            {
                getAntibody(validUser,DateTime.UtcNow.AddDays(-1))
            };
            mockAntibodyMongo.Setup(m => m.FindAllAsync(It.IsAny<Expression<Func<AntibodyResult, bool>>>())).ReturnsAsync(antibodyResults);
            var testResults = new List<TestResult>()
            {
                getDiagnostic(validUser,DateTime.UtcNow.AddDays(-5))
            };
            mockTestMongo.Setup(m => m.FindAllAsync(It.IsAny<Expression<Func<TestResult, bool>>>())).ReturnsAsync(testResults);
            mockBlobCache.Setup(m =>m.GetFile()).ReturnsAsync(new EligibilityConfiguration(It.IsAny<IEnumerable<EligibilityRules>>(), true));
            Certificate blankVaccineCert = new Certificate(null, default, DateTime.UtcNow.AddDays(5), CertificateType.Vaccination);
            mockConfigurationValidityCalculator.Setup(m => m.GenerateCertificatesUsingRules(It.IsAny<IEnumerable<IGenericResult>>(), It.IsAny<EligibilityConfiguration>())).Returns(blankVaccineCert);
            QRCodeGeneratorMock.Setup(m => m.GenerateQRCodeForCertificate(It.IsAny<Certificate>())).ReturnsAsync((string)null);
            var result = await service.GetCertificateByHash(code, dto, idToken);
            Assert.IsType<Certificate>(result);
            Assert.Equal(validUser.Name, result.Name);

        }*/
        private AntibodyResult getAntibody(CovidPassportUser validUser, DateTime time)
        {
            AntibodyRequestDto req = new AntibodyRequestDto(validUser.Name, validUser.DateOfBirth, validUser.EmailAddress, validUser.PhoneNumber, time, "Type", "Positive", "test kit");

            return new AntibodyResult(req);
        }
        private TestResult getDiagnostic(CovidPassportUser validUser, DateTime time, string TestKit = "TEST")
        {
            return new TestResult(validUser.Name, validUser.DateOfBirth, validUser.EmailAddress, validUser.PhoneNumber, validUser.NhsNumber, time, "Negative", "PCR", "Kit", TestKit);
        }

        [Fact]
        public async Task GetCertificate_ReturnsNoCert_IfUserIsP5()
        {
            validUser.IdentityProofingLevel = "P5";
            mockBlobCache.Setup(m =>m.GetFile()).ReturnsAsync(new EligibilityConfiguration(It.IsAny<IEnumerable<EligibilityRules>>(), It.IsAny<EligibilityDomesticExemptions>()));
            mockVRService.Setup(m => m.GetVaccines(It.IsAny<string>(), It.IsAny<CovidPassportUser>())).ReturnsAsync(new List<Vaccine>());
            var homeTests = new List<TestResult>
            {
                getDiagnostic(validUser,DateTime.Now,"SelfTest"),
                getDiagnostic(validUser,DateTime.Now.AddDays(-7),"SelfTest")

            };
            Environment.SetEnvironmentVariable("UsePCRSelfTests", "false");
            Environment.SetEnvironmentVariable("UseLFTSelfTests", "false");
            var result = await service.GetDomesticCertificate(validUser, idToken);
            Assert.Null(result);
        }

        [Fact]
        public async Task GetDomesticCertificate_ValidCertificate_P9User_SuccessfulConfiguration()
        {
            // Arrange
            List<Vaccine> validVaccines = new List<Vaccine>();
            validVaccines.Add(VaccinationMapperHelper.Setup_Minus25Days_Vaccine());
            validVaccines.Add(VaccinationMapperHelper.Setup_Minus1Day_Vaccine());
            List<Certificate> validCertificates = new List<Certificate>();
            validCertificates.Add(VaccinationMapperHelper.SetUpVaccineCertificateModel(CertificateType.Vaccination, CertificateScenario.Domestic));
            var allTestResults = new List<IGenericResult>();
            allTestResults.AddRange(validVaccines);

            mockVRService.Setup(m => m.GetVaccines(It.IsAny<string>(), validUser)).ReturnsAsync(validVaccines);
            mockBlobCache.Setup(m =>m.GetFile())
                .ReturnsAsync(testConfiguration).Verifiable();
            mockUvciGenerator.Setup(x => x.TryGenerateAndInsertUvci(It.IsAny<DomesticGenerateAndInsertUvciCommand>()))
                .ReturnsAsync("test:uvci");

            var expectedRules = testConfiguration.Rules.Where(x => x.Scenario.Equals(CertificateScenario.Domestic));

            mockConfigurationValidityCalculator.Setup(x =>
            x.GenerateCertificatesUsingRules(allTestResults,
            expectedRules, validUser)).Returns(validCertificates).Verifiable();
            QRCodeGeneratorMock.Setup(m => m.GenerateQRCodeForCertificate(It.IsAny<Certificate>())).ReturnsAsync((string)null);

            var result = await service.GetDomesticCertificate(validUser, idToken);
            
            Assert.NotNull(result);
            Assert.IsType<Certificate>(result);
            mockBlobCache.Verify(m =>m.GetFile(), Times.Once);
            mockConfigurationValidityCalculator.Verify(m => m.GenerateCertificatesUsingRules(allTestResults, expectedRules, validUser), Times.Once);
        }

        [Fact]
        public async Task GetInternationalCertificate_ValidCertificate_P9User_SuccessfulConfiguration()
        {
            // Arrange
            List<Vaccine> validVaccines = new List<Vaccine>();
            validVaccines.Add(VaccinationMapperHelper.Setup_Minus25Days_Vaccine());
            validVaccines.Add(VaccinationMapperHelper.Setup_Minus1Day_Vaccine());
            List<Certificate> validCertificates = new List<Certificate>();
            validCertificates.Add(VaccinationMapperHelper.SetUpVaccineCertificateModel(CertificateType.Vaccination, CertificateScenario.International));
            var allTestResults = new List<IGenericResult>();
            allTestResults.AddRange(validVaccines);

            mockVRService.Setup(m => m.GetVaccines(It.IsAny<string>(), validUser)).ReturnsAsync(validVaccines);
            mockBlobCache.Setup(m =>m.GetFile())
                .ReturnsAsync(testConfiguration).Verifiable();
            mockUvciGenerator.Setup(x => x.TryGenerateAndInsertUvci(It.IsAny<DomesticGenerateAndInsertUvciCommand>()))
                .ReturnsAsync("test:uvci");

            var expectedRules = testConfiguration.Rules.Where(x => x.Scenario.Equals(CertificateScenario.International));

            mockConfigurationValidityCalculator.Setup(x =>
            x.GenerateCertificatesUsingRules(allTestResults,
            expectedRules, validUser)).Returns(validCertificates).Verifiable();
            QRCodeGeneratorMock.Setup(m => m.GenerateQRCodeForCertificate(It.IsAny<Certificate>())).ReturnsAsync((string)null);

            var result = await service.GetInternationalCertificate(validUser, idToken, CertificateType.Vaccination);

            Assert.NotNull(result);
            Assert.IsType<Certificate>(result);
            mockBlobCache.Verify(m =>m.GetFile(), Times.Once);
            mockConfigurationValidityCalculator.Verify(m => m.GenerateCertificatesUsingRules(allTestResults, expectedRules, validUser), Times.Once);
        }

        [Fact]
        public async Task GetDomesticCertificate_ValidCertificate_P5User_SuccessfulConfiguration()
        {
            // Arrange
            validUser.IdentityProofingLevel = "P5";
            List<Vaccine> validVaccines = new List<Vaccine>();
            validVaccines.Add(VaccinationMapperHelper.Setup_Minus25Days_Vaccine());
            validVaccines.Add(VaccinationMapperHelper.Setup_Minus1Day_Vaccine());
            List<Certificate> validCertificates = new List<Certificate>();
            validCertificates.Add(VaccinationMapperHelper.SetUpVaccineCertificateModel(CertificateType.Vaccination, CertificateScenario.Domestic));
            var allTestResults = new List<IGenericResult>();
            allTestResults.AddRange(validVaccines);

            mockVRService.Setup(m => m.GetVaccines(It.IsAny<string>(), validUser)).ReturnsAsync(validVaccines);
            mockBlobCache.Setup(m =>m.GetFile())
                .ReturnsAsync(testConfiguration).Verifiable();
            mockUvciGenerator.Setup(x => x.TryGenerateAndInsertUvci(It.IsAny<DomesticGenerateAndInsertUvciCommand>()))
                .ReturnsAsync("test:uvci");

            var expectedRules = testConfiguration.Rules.Where(x => x.Scenario.Equals(CertificateScenario.Domestic));

            mockConfigurationValidityCalculator.Setup(x =>
            x.GenerateCertificatesUsingRules(allTestResults,
            expectedRules, validUser)).Returns(validCertificates).Verifiable();
            QRCodeGeneratorMock.Setup(m => m.GenerateQRCodeForCertificate(It.IsAny<Certificate>())).ReturnsAsync((string)null);

            var result = await service.GetDomesticCertificate(validUser, idToken);

            Assert.NotNull(result);
            Assert.IsType<Certificate>(result);
            mockBlobCache.Verify(m =>m.GetFile(), Times.Once);
            mockConfigurationValidityCalculator.Verify(m => m.GenerateCertificatesUsingRules(allTestResults, expectedRules, validUser), Times.Once);
        }

        [Fact]
        public async Task GetInternationalCertificate_ValidCertificate_P5User_SuccessfulConfiguration()
        {
            // Arrange
            validUser.IdentityProofingLevel = "P5";
            List<Vaccine> validVaccines = new List<Vaccine>();
            validVaccines.Add(VaccinationMapperHelper.Setup_Minus25Days_Vaccine());
            validVaccines.Add(VaccinationMapperHelper.Setup_Minus1Day_Vaccine());
            List<Certificate> validCertificates = new List<Certificate>();
            validCertificates.Add(VaccinationMapperHelper.SetUpVaccineCertificateModel(CertificateType.Vaccination, CertificateScenario.International));
            var allTestResults = new List<IGenericResult>();
            allTestResults.AddRange(validVaccines);

            mockVRService.Setup(m => m.GetVaccines(It.IsAny<string>(), validUser)).ReturnsAsync(validVaccines);
            mockBlobCache.Setup(m =>m.GetFile())
                .ReturnsAsync(testConfiguration).Verifiable();
            mockUvciGenerator.Setup(x => x.TryGenerateAndInsertUvci(It.IsAny<DomesticGenerateAndInsertUvciCommand>()))
                .ReturnsAsync("test:uvci");

            var expectedRules = testConfiguration.Rules.Where(x => x.Scenario.Equals(CertificateScenario.International));

            mockConfigurationValidityCalculator.Setup(x =>
            x.GenerateCertificatesUsingRules(allTestResults,
            expectedRules, validUser)).Returns(validCertificates).Verifiable();
            QRCodeGeneratorMock.Setup(m => m.GenerateQRCodeForCertificate(It.IsAny<Certificate>())).ReturnsAsync((string)null);

            var result = await service.GetInternationalCertificate(validUser, idToken, CertificateType.Vaccination);

            Assert.NotNull(result);
            Assert.IsType<Certificate>(result);
            mockBlobCache.Verify(m =>m.GetFile(), Times.Once);
            mockConfigurationValidityCalculator.Verify(m => m.GenerateCertificatesUsingRules(allTestResults, expectedRules, validUser), Times.Once);
        }

        private void SetupUvciGeneratorMock()
        {
            mockUvciGenerator.Setup(x => x.TryGenerateAndInsertUvci(It.IsAny<DomesticGenerateAndInsertUvciCommand>()))
                .ReturnsAsync("test-uvci");
        }
    }
}

