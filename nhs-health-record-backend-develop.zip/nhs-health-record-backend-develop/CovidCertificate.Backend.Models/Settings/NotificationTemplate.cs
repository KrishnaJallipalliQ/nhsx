﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.Settings
{
    public class NotificationTemplate
    {
        public Guid EmailTemplateId { get; set; }

        public Guid TextMessageTemplateId { get; set; }
    }
}
