﻿using CovidCertificate.Backend.Auth;
using CovidCertificate.Backend.Configuration.Bases;
using CovidCertificate.Backend.Configuration.Extensions;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Services;
using CovidCertificate.Backend.Services.KeyServices;
using CovidCertificate.Backend.Services.SecurityServices;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics.CodeAnalysis;

[assembly: FunctionsStartup(typeof(Startup))]
namespace CovidCertificate.Backend.Auth
{
    [ExcludeFromCodeCoverage]
    public class Startup : StartupBase
    {
        public override void SetupFunctionSpecificSettings(IFunctionsHostBuilder builder)
        {
            builder.AddSetting<NhsLoginSettings>(Configuration, "NhsLoginConfig");
            builder.AddSetting<MongoDbSettings>(Configuration, "MongoDbSettings");
            builder.AddSetting<RedisCacheSettings>(Configuration, "RedisCacheSettings");
        }

        public override void SetupDI(IFunctionsHostBuilder builder)
        {
            builder.Services.AddScoped<INhsLoginService, NhsLoginService>();
            builder.Services.AddScoped<IAssertedLoginIdentityService, AssertedLoginIdentityService>();
            builder.Services.AddScoped<IJwtGenerator, JwtGeneratorService>();
            builder.Services.AddScoped<IUserPreference, UserPreferenceService>();
            builder.Services.AddScoped(typeof(IMongoRepository<>), typeof(MongoRepository<>));
            AddMongoDBClient(builder, Configuration);
            builder.Services.AddSingleton<IRedisCacheService, RedisCacheService>();
            builder.Services.AddSingleton<NhsKeyRing>();
            GetJwtValidator(builder);
            builder.Services.AddSingleton<IPublicKeyService, PublicKeyService>();
            builder.Services.AddHttpClient();
        }
    }
}
