﻿using System;

namespace CovidCertificate.Backend.Models.Exceptions
{
    public class ThirdPartyException : Exception
    {
        public ThirdPartyException(string message) : base(message)
        {

        }
    }
}
