﻿using CovidCertificate.Backend.Models.RequestDtos;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.Validators
{
    public class GenerateRemoteCodeRequestDtoValidator : AbstractValidator<GenerateRemoteCodeRequestDto>
    {
        public GenerateRemoteCodeRequestDtoValidator() 
        {
            RuleFor(x => x.UseCount).GreaterThan(0);
            RuleFor(x => x.ExpirationDateTime).GreaterThan(DateTime.UtcNow);
        }
    }
}
