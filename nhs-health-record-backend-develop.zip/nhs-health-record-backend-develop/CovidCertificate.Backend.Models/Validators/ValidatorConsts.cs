﻿
namespace CovidCertificate.Backend.Models.Validators
{
    public class ValidatorConsts
    {
        public const string PhoneRegex = @"^[+]{0,1}[0-9]{8,13}$";
        public const string RemoteCheckCodeRegex = "^[a-zA-Z0-9]*$";
        public const string TwoFactorAuthCodeRegex = @"^[a-zA-Z0-9]{6}$";
    }
}
