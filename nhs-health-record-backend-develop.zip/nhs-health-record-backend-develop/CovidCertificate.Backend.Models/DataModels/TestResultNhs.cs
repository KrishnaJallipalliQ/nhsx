﻿using CovidCertificate.Backend.Interfaces;
using Newtonsoft.Json;
using System;
using System.Text;

namespace CovidCertificate.Backend.Models.DataModels
{
    public class TestResultNhs : IGenericResult
    {
        public TestResultNhs(TestResult dto) : this(dto.DateTimeOfTest, dto.Result, dto.ValidityType, dto.ProcessingCode, dto.TestKit, null, null, null) { }

        [JsonConstructor]
        public TestResultNhs(DateTime dateTimeOfTest, string result, string validityType, string processingCode, string testKit, Tuple<string, string> diseaseTargeted, string authority, string countryOfAuthority)
        {
            this.DateTimeOfTest = dateTimeOfTest;
            this.Result = result;
            this.ValidityType = validityType;
            this.ProcessingCode = processingCode;
            this.TestKit = testKit;
            this.DiseaseTargeted = diseaseTargeted;
            this.Authority = authority;
            this.CountryOfAuthority = countryOfAuthority;
        }
        public TestResultNhs(TestResultNhs t)
        {
            DateTimeOfTest = t.DateTimeOfTest;
            Result = t.Result;
            ValidityType = t.ValidityType;
            ProcessingCode = t.ProcessingCode;
            TestKit = t.TestKit;
            DiseaseTargeted = t.DiseaseTargeted;
            Authority = t.Authority;
            CountryOfAuthority = t.CountryOfAuthority;
        }
        public DateTime DateTimeOfTest { get; }
        public string Result { get; }
        public string ValidityType { get; }
        public string ProcessingCode { get; }
        public string TestKit { get; }
        public Tuple<string, string> DiseaseTargeted { get; }
        public string Authority { get; }
        public string CountryOfAuthority { get; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Authority:").Append(this.Authority??"").AppendLine();
            sb.Append("Result:").Append(this.Result??"").AppendLine();
            sb.Append("DiseaseTargeted:").Append(this.DiseaseTargeted?.ToString()).AppendLine();
            sb.Append("ProcessingCode:").Append(this.ProcessingCode??"").AppendLine();
            sb.Append("TestKit:").Append(this.TestKit??"").AppendLine();
            sb.Append("ValidityType:").Append(this.ValidityType??"").AppendLine();
            sb.Append("CountryOfAuthority:").Append(this.CountryOfAuthority??"").AppendLine();
            sb.Append("DateTimeOfTest:").Append(this.DateTimeOfTest).AppendLine();
          
            return sb.ToString();
        }
    }
}