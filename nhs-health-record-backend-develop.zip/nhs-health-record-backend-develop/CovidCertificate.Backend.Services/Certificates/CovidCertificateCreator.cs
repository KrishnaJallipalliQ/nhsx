using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CovidCertificate.Backend.Models.RequestDtos;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using CovidCertificate.Backend.Utils.Extensions;
using System.Linq;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.International.Interfaces;
using CovidCertificate.Backend.Models.Commands.UvciGeneratorCommands;
using CovidCertificate.Backend.Utils;

namespace CovidCertificate.Backend.Services.Certificates
{
    public class CovidCertificateCreator : ICovidCertificateCreator
    {
        private readonly IVRService vaccineRegistryQueryService;
        private readonly IQRCodeGenerator qRCodeGenerator;
        private readonly IBlobFilesInMemoryCache<EligibilityConfiguration> eligibilityConfigurationBlobCache;
        private readonly IConfigurationValidityCalculator configurationValidityCalculator;
        private readonly ILogger<CovidCertificateCreator> logger;
        private readonly TestResultFilter resultFilter;
        private readonly IConfiguration configuration;
        private readonly IPilotFilterService pilotFilterService;
        private readonly IDiagnosticTestResultsService testResultsService;
        private readonly IAntibodyResultsService antibodyResultsService;
        private readonly IGetTimeZones getTimeZones;
        private readonly IDomesticExemptionService domesticExemptionService;
        private readonly IDomesticExemptionCertificateGenerator domesticExemptionCertificateGenerator;
        private readonly IUvciGenerator uvciGenerator;
        private readonly IEncoderService encoder;
        private readonly bool supportP5TestResults;
        private readonly IRedisCacheService redisCacheService;


        public CovidCertificateCreator(
            IVRService vaccineRegistryQueryService,
            IQRCodeGenerator qRCodeGenerator,
            IBlobFilesInMemoryCache<EligibilityConfiguration> eligibilityConfigurationBlobCache,
            IConfigurationValidityCalculator configurationValidityCalculator,
            ILogger<CovidCertificateCreator> logger,
            TestResultFilter resultFilter,
            IConfiguration configuration,
            IPilotFilterService pilotFilterService,
            IDiagnosticTestResultsService testResultsService,
            IAntibodyResultsService antibodyResultsService,
            IDomesticExemptionService domesticExemptionService,
            IDomesticExemptionCertificateGenerator domesticExemptionCertificateGenerator,
            IGetTimeZones getTimeZones,
            IUvciGenerator uvciGenerator,
            IEncoderService encoder,
            IRedisCacheService redisCacheService
            )
        {
            this.vaccineRegistryQueryService = vaccineRegistryQueryService;
            this.qRCodeGenerator = qRCodeGenerator;
            this.eligibilityConfigurationBlobCache = eligibilityConfigurationBlobCache;
            this.configurationValidityCalculator = configurationValidityCalculator;
            this.resultFilter = resultFilter;
            this.pilotFilterService = pilotFilterService;
            this.configuration = configuration;
            this.logger = logger;
            this.testResultsService = testResultsService;
            this.antibodyResultsService = antibodyResultsService;
            this.domesticExemptionService = domesticExemptionService;
            this.getTimeZones = getTimeZones;
            this.domesticExemptionCertificateGenerator = domesticExemptionCertificateGenerator;
            this.uvciGenerator = uvciGenerator;
            this.encoder = encoder;
            this.redisCacheService = redisCacheService;
            supportP5TestResults = bool.TryParse(configuration["SupportP5TestResults"] ?? "false", out var supportTestData) ? supportTestData : false;
        }

        public async Task<Certificate> GetDomesticCertificate(CovidPassportUser user, string idToken)
        {
            logger.LogInformation("GetDomesticCertificate was invoked");

            var certificates = await GetCertificates(user, idToken, CertificateScenario.Domestic);

            logger.LogInformation("GetDomesticCertificate has finished");
            return certificates.Any() ? certificates.First() : null;
        }

        public async Task<bool> ExpiredCertificateExists(CovidPassportUser user, Certificate certificate)
        {
            logger.LogInformation($"{nameof(ExpiredCertificateExists)} was invoked");

            var expiredCertificateExists = true;
            if (certificate == null)
            {
                expiredCertificateExists = await uvciGenerator.UvciExistsForUser(user, CertificateScenario.Domestic);
            }                

            logger.LogInformation($"{nameof(ExpiredCertificateExists)} has finished");
            return expiredCertificateExists;
        }

        public async Task<Certificate> GetInternationalCertificate(CovidPassportUser user, string idToken, CertificateType type)
        {
            logger.LogInformation("GetInternationalRecoveryCertificate was invoked");

            var certificates = await GetCertificates(user, idToken, CertificateScenario.International, type);

            logger.LogInformation("GetInternationalRecoveryCertificate has finished");

            return certificates.Any() ? certificates.First() : null;
        }

        private async Task<IEnumerable<Certificate>> GetCertificates(CovidPassportUser user, string idToken, CertificateScenario scenario, CertificateType? type = null)
        {
            logger.LogInformation("GetCertificates was invoked");

            if (user == default)
            {
                logger.LogTraceAndDebug($"covidTestUser == default");
                throw new ArgumentNullException(nameof(user), "No user to get certificate for");
            }

            if (Environment.GetEnvironmentVariable("ViewOnlyPilotUsersData") == "true" && !(await pilotFilterService.IsPilotUser(user.ToPilotUser())))
            {
                logger.LogWarning("This user is not a pilot user");
                logger.LogInformation("User Hash" + user.ToPilotUser().UserHash);
                logger.LogInformation("GetDomesticCertificate has finished");
                return null;
            }

            var vaccinationResultsTask = (scenario == CertificateScenario.International && type == CertificateType.Recovery)
                                                             ? Task.FromResult(new List<Vaccine>())
                                                             : vaccineRegistryQueryService.GetVaccines(idToken, user);

            Task<IEnumerable<TestResultNhs>> diagnosticTestResultsTask;
            Task<IEnumerable<AntibodyResultNhs>> antibodyTestResultsTask;

            var identityProofingLevel = JwtTokenUtils.GetClaim(idToken, "identity_proofing_level");

            if (scenario == CertificateScenario.Domestic && !identityProofingLevel.Equals("P9", StringComparison.InvariantCultureIgnoreCase) && !supportP5TestResults)
            {
                diagnosticTestResultsTask = Task.FromResult(Enumerable.Empty<TestResultNhs>());
                antibodyTestResultsTask = Task.FromResult(Enumerable.Empty<AntibodyResultNhs>());
            }
            else
            {
                diagnosticTestResultsTask = testResultsService.GetDiagnosticTestResults(idToken);
                antibodyTestResultsTask = antibodyResultsService.GetAntibodyResults(idToken);
            }

            await Task.WhenAll(vaccinationResultsTask, diagnosticTestResultsTask, antibodyTestResultsTask);

            vaccinationResultsTask.Result.ToList().ForEach(x => logger.LogTraceAndDebug($"vaccinationResult:{x?.ToString()}"));
            diagnosticTestResultsTask.Result.ToList().ForEach(x => logger.LogTraceAndDebug($"testResult:{x?.ToString()}"));
            antibodyTestResultsTask.Result.ToList().ForEach(x => logger.LogTraceAndDebug($"antibodyResult: {x?.ToString()}"));

            var certificatesFromResults = await CertificatesFromResults(diagnosticTestResultsTask.Result, vaccinationResultsTask.Result, antibodyTestResultsTask.Result, user, scenario, type);
            logger.LogTraceAndDebug($"certificateFromResults: {certificatesFromResults?.ToString()}");

            if (!certificatesFromResults.Any() && scenario.Equals(CertificateScenario.Domestic))
            {
                var isUserExempt = await domesticExemptionService.IsUserExempt(user.NhsNumber, user.DateOfBirth);

                if (isUserExempt)
                {
                    var certificateFromExemption = await domesticExemptionCertificateGenerator.GenerateCertificate(user);

                    logger.LogInformation("GetResultsAndCertificate has finished");
                    return new List<Certificate> { certificateFromExemption };
                }
            }

            logger.LogInformation("GetCertificates has finished");

            return certificatesFromResults;
        }

        private async Task<IEnumerable<Certificate>> CertificatesFromResults(IEnumerable<TestResultNhs> diagnosticTestResults, IEnumerable<Vaccine> vaccinations, IEnumerable<AntibodyResultNhs> antibodyTestResults, CovidPassportUser user, CertificateScenario scenario, CertificateType? type = null)
        {
            logger.LogInformation("CertificatesFromResults was invoked");
            //Get the curent configuration settings for the certificates
            var configuration = await eligibilityConfigurationBlobCache.GetFile();

            var allTests = diagnosticTestResults;

            if (Environment.GetEnvironmentVariable("UsePCRSelfTests") == "false")
            {
                allTests = resultFilter.FilterOutHomeTest(diagnosticTestResults, "PCR");
                logger.LogInformation("PCR HomeTests filtered out");
            }

            if (Environment.GetEnvironmentVariable("UseLFTSelfTests") == "false")
            {
                allTests = resultFilter.FilterOutHomeTest(diagnosticTestResults, "LFT");
                logger.LogInformation("LFT HomeTests filtered out");
            }

            //Compile all diagnostic, antibody and vaccination results into one list of a generic type
            var allTestResults = new List<IGenericResult>();
            allTestResults.AddRange(allTests);
            allTestResults.AddRange(vaccinations);
            allTestResults.AddRange(antibodyTestResults);

            var rules = configuration.Rules != null ? configuration.Rules.Where(x => x.Scenario.Equals(scenario)) : Enumerable.Empty<EligibilityRules>();
            var certificates = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, rules, user);

            if (type != null)
                certificates = certificates.Where(x => x.CertificateType.Equals(type));

            //var cacheKey = "CertResults" + StringUtils.GetValueHash(user.NhsNumber, user.DateOfBirth) + scenario.GetType().GetEnumName(scenario) + type.ToString();

            //(var cachedcertificates, var found) = await redisCacheService.GetKeyValueAsync<IEnumerable<Certificate>>(cacheKey);

            //if (!found)
            //{
            foreach (var certificate in certificates)
            {
                certificate.Name = user.Name;
                certificate.DateOfBirth = user.DateOfBirth;
                certificate.UniqueCertificateIdentifier = await uvciGenerator.TryGenerateAndInsertUvci(
                    new DomesticGenerateAndInsertUvciCommand(
                        certificate.CertificateScenario.Equals(CertificateScenario.International) ? this.configuration["InternationalAuthority"] : this.configuration["DomesticAuthority"],
                        this.configuration["CountryOfIssuer"],
                        StringUtils.GetValueHash(certificate.Name, certificate.DateOfBirth),
                        certificate.CertificateType,
                        certificate.CertificateScenario,
                        certificate.validityEndDate));
                        
                //Conversion added here so that the datetimes in the QR code match
                certificate.ConvertTimeZone(getTimeZones.GetTimeZoneInfo());
                if (scenario.Equals(CertificateScenario.International))
                {
                    if(type == CertificateType.Recovery)
                    {
                        certificate.QrCodeTokens.Add(await GenerateInternationalQr(certificate, user, 0));
                    }
                    else
                    {
                        for (int i = 0; i < certificate.EligibilityResults.Count() && i <= 1; i++)
                        {
                            certificate.QrCodeTokens.Add(await GenerateInternationalQr(certificate, user, i));
                        }
                    }                    
                }
                else
                {
                    certificate.QrCodeTokens.Add(await qRCodeGenerator.GenerateQRCodeForCertificate(certificate));
                }
            }
            //await redisCacheService.AddKeyAsync(cacheKey, certificates, Models.Settings.RedisLifeSpanLevel.Medium);
            //}
            //else
            //{
            //    certificates = cachedcertificates;
            //}
            logger.LogInformation("CertificatesFromResults has finished");
            return certificates;
        }

        private async Task<IEnumerable<TestResultNhs>> GetEmptyDiagnosticTestResults()
        {
            return Enumerable.Empty<TestResultNhs>();
        }
        private async Task<string> GenerateInternationalQr(Certificate certificate, CovidPassportUser user, int resultIndex)
        {
            var dateTimeOffset = DateTimeOffset.Now.ToUnixTimeSeconds();
            return certificate.CertificateType.Equals(CertificateType.Vaccination) ?
                                     await encoder.EncodeFlowAsync<Vaccine>(user, dateTimeOffset, certificate.GetAllVaccinationsFromEligibleResults(), certificate.UniqueCertificateIdentifier, certificate.validityEndDate, resultIndex)
                                    : await encoder.EncodeFlowAsync<TestResultNhs>(user, dateTimeOffset, certificate.GetLatestDiagnosticResultFromEligibleResults(), certificate.UniqueCertificateIdentifier, certificate.validityEndDate, resultIndex);
        }

        //Deprecated
        public async Task<Certificate> GetCertificateByHash(Models.DataModels.RemoteAccessCode remoteCode, FetchRemoteCovidStatusDto requestDto, string idToken = "")
        {
            if (remoteCode == null || requestDto == null)
                throw new ArgumentNullException("", "No user to get certificate for");

            if (remoteCode.PhoneHash == null && remoteCode.EmailHash == null)
            {
                throw new ArgumentNullException("", "No user details to get certificate for");
            }

            var user = new CovidPassportUser(requestDto.Name, requestDto.DateOfBirth, null, null, null);

            var certificates = await GetCertificates(user, idToken, CertificateScenario.Domestic);
            return certificates.FirstOrDefault();
        }
    }
}
