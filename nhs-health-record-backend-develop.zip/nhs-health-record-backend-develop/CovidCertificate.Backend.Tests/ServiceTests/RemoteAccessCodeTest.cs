﻿using Castle.Core.Configuration;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Services.RemoteAccessCode;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using CovidCertificate.Backend.Services;
using CovidCertificate.Backend.Models.Exceptions;
using System.Linq.Expressions;
using CovidCertificate.Backend.Utils;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class RemoteAccessCodeTest
    {
        private RemoteAccessCodeService RemoteAccessCodeServiceSIT;

        private readonly Mock<IMongoRepository<RemoteAccessCode>> MongoMock;
        private readonly Mock<IConfiguration> ConfigurationMock;
        private readonly Mock<ILogger<RemoteAccessCodeService>> LoggerMock;

        private FetchRemoteCovidStatusDto MockRequestDto;
        private GetAuthCodeRequestDto MockThirdPartyDto;
        private CovidPassportUser MockCovidUser;
        private RevokeRemoteCheckCodeDto MockRevokeRemoteCheckCodeDto;

        public RemoteAccessCodeTest()
        {          
            MongoMock = new Mock<IMongoRepository<RemoteAccessCode>>();
            ConfigurationMock = new Mock<IConfiguration>();
            LoggerMock = new Mock<ILogger<RemoteAccessCodeService>>();

            RemoteAccessCodeServiceSIT = new RemoteAccessCodeService(LoggerMock.Object, MongoMock.Object);

            //Create a Mock MockRequestDto 
            MockRequestDto = new FetchRemoteCovidStatusDto("Marek Canavan", 
                                                           new DateTime(1998, 05, 27, 0, 0, 0, DateTimeKind.Utc), 
                                                           "123456789");
            //Create a Mock MockThirdPartyDto
            MockThirdPartyDto = new GetAuthCodeRequestDto()
            {
                ThirdPartyName = "British Airways",
                ThirdPartyID = "1"
            };

            MockCovidUser = new CovidPassportUser("john test", DateTime.UtcNow, "john.test@test.com", "43888472647");
            MockRevokeRemoteCheckCodeDto = new RevokeRemoteCheckCodeDto()
            {
                RemoteCheckCode = "code"
            };
        }

        #region GetRegRemoteCodeTests
        [Fact]
        public async Task TestRegCode_IsSuccessful()
        {
            //Arrange 
            RemoteAccessCodeServiceSIT = new RemoteAccessCodeService(LoggerMock.Object,
                                                               MongoMock.Object);
            var remoteCode = new RemoteAccessCode("123456789", 10, DateTime.UtcNow.AddDays(1), "123456789", MockCovidUser);            
            MongoMock.Setup(m => m.FindOneAsync(It.IsAny<Expression<Func<RemoteAccessCode, bool>>>())).ReturnsAsync(remoteCode);

            //Act 
            RemoteAccessCode act = await RemoteAccessCodeServiceSIT.GetRegRemoteCode(MockRequestDto, MockThirdPartyDto);

            //Assert
            Assert.True(act.CodeStatus == CodeStatusType.Registered && act.ThirdPartyName == "British Airways");
        }

        [Fact]
        public async Task TestRegCode_IsExpired()
        {
            //Arrange 
            RemoteAccessCodeServiceSIT = new RemoteAccessCodeService(LoggerMock.Object,
                                                               MongoMock.Object);
            var remoteCode = new RemoteAccessCode("123456789", 10, DateTime.UtcNow.AddDays(-34), "123456789", MockCovidUser);
            MongoMock.Setup(m => m.FindOneAsync(It.IsAny<Expression<Func<RemoteAccessCode, bool>>>())).ReturnsAsync(remoteCode);

            //Act 
            Func<Task> act = () => RemoteAccessCodeServiceSIT.GetRegRemoteCode(MockRequestDto, MockThirdPartyDto);

            //Assert
            await Assert.ThrowsAsync<InvalidRemoteCodeException>(act);
        }

        [Fact]
        public async Task TestRegCode_IsUnregistered()
        {
            //Arrange 
            RemoteAccessCodeServiceSIT = new RemoteAccessCodeService(LoggerMock.Object,
                                                               MongoMock.Object);
            var remoteCode = new RemoteAccessCode("123456789", 10, DateTime.UtcNow, "123456789", MockCovidUser);
            remoteCode.CodeStatus = CodeStatusType.Unregistered; 
            MongoMock.Setup(m => m.FindOneAsync(It.IsAny<Expression<Func<RemoteAccessCode, bool>>>())).ReturnsAsync(remoteCode);

            //Act 
            Func<Task> act = () => RemoteAccessCodeServiceSIT.GetRegRemoteCode(MockRequestDto, MockThirdPartyDto);

            //Assert
            await Assert.ThrowsAsync<RemoteCodeStatusException>(act);
        }

        [Fact]
        public async Task TestRegCode_IsRevoked()
        {
            //Arrange 
            RemoteAccessCodeServiceSIT = new RemoteAccessCodeService(LoggerMock.Object,
                                                               MongoMock.Object);
            var remoteCode = new RemoteAccessCode("123456789", 10, DateTime.UtcNow, "123456789", MockCovidUser);
            remoteCode.CodeStatus = CodeStatusType.Revoked; 
            MongoMock.Setup(m => m.FindOneAsync(It.IsAny<Expression<Func<RemoteAccessCode, bool>>>())).ReturnsAsync(remoteCode);

            //Act 
            Func<Task> act = () => RemoteAccessCodeServiceSIT.GetRegRemoteCode(MockRequestDto, MockThirdPartyDto);

            //Assert
            await Assert.ThrowsAsync<RemoteCodeStatusException>(act);
        }

        [Fact]
        public async Task TestRegCode_IsRegistered_WrongName()
        {
            //Arrange 
            RemoteAccessCodeServiceSIT = new RemoteAccessCodeService(LoggerMock.Object,
                                                               MongoMock.Object);
            var remoteCode = new RemoteAccessCode("123456789", 10, DateTime.UtcNow, "123456789", MockCovidUser);
            remoteCode.CodeStatus = CodeStatusType.Registered;
            remoteCode.ThirdPartyName = "BA"; 
            MongoMock.Setup(m => m.FindOneAsync(It.IsAny<Expression<Func<RemoteAccessCode, bool>>>())).ReturnsAsync(remoteCode);

            //Act 
            Func<Task> act = () => RemoteAccessCodeServiceSIT.GetRegRemoteCode(MockRequestDto, MockThirdPartyDto);

            //Assert
            await Assert.ThrowsAsync<RemoteCodeStatusException>(act);
        }

        [Fact]
        public async Task TestRegCode_NullCode()
        {
            //Arrange 
            RemoteAccessCode remoteCode = null;            
            MongoMock.Setup(m => m.FindOneAsync(It.IsAny<Expression<Func<RemoteAccessCode, bool>>>())).ReturnsAsync(remoteCode);

            //Act 
            Func<Task> act = () => RemoteAccessCodeServiceSIT.GetRegRemoteCode(MockRequestDto, MockThirdPartyDto);

            //Assert
            await Assert.ThrowsAsync<RemoteAccessCodeNotFoundException>(act);
        }

        [Fact]
        public async Task TestRegCode_Insert_Unused()
        {
            //Arrange 
            var remoteCode = new RemoteAccessCode("123456789", 10, DateTime.UtcNow, "123456789", MockCovidUser);
            remoteCode.CodeStatus = CodeStatusType.Unused;            
            MongoMock.Setup(m => m.FindOneAsync(It.IsAny<Expression<Func<RemoteAccessCode, bool>>>())).ReturnsAsync(remoteCode);

            //Act 
            await RemoteAccessCodeServiceSIT.GetRegRemoteCode(MockRequestDto, MockThirdPartyDto);

            //Assert
            MongoMock.Verify(x => x.ReplaceOneAsync(It.IsAny<RemoteAccessCode>()), Times.Once());
        }
        #endregion

        #region UnregRemoteAccessCodeTests
        [Fact]
        public async Task TestUnregCode_IsSuccessful()
        {
            //Arrange 
            RemoteAccessCodeServiceSIT = new RemoteAccessCodeService(LoggerMock.Object,
                                                               MongoMock.Object);
            var remoteCode = new RemoteAccessCode("123456789", 10, DateTime.UtcNow.AddDays(1), "123456789", MockCovidUser); 
            MongoMock.Setup(m => m.FindOneAsync(It.IsAny<Expression<Func<RemoteAccessCode, bool>>>())).ReturnsAsync(remoteCode);

            //Act 
            RemoteAccessCode act = await RemoteAccessCodeServiceSIT.GetRemoteCode(MockRequestDto);

            //Assert
            Assert.True(act.CodeStatus == CodeStatusType.Unregistered && act.AccessCode == "123456789");
        }

        [Fact]
        public async Task TestUnregCode_RemoteCodeNull()
        {
            //Arrange 
            RemoteAccessCodeServiceSIT = new RemoteAccessCodeService(LoggerMock.Object,
                                                               MongoMock.Object);
            var remoteCode = new RemoteAccessCode("123456789", 10, DateTime.UtcNow.AddDays(1), "123456789", MockCovidUser);
            remoteCode = null; 
            MongoMock.Setup(m => m.FindOneAsync(It.IsAny<Expression<Func<RemoteAccessCode, bool>>>())).ReturnsAsync(remoteCode);

            //Act 
            Func<Task> act = () => RemoteAccessCodeServiceSIT.GetRemoteCode(MockRequestDto);

            //Assert
            await Assert.ThrowsAsync<RemoteAccessCodeNotFoundException>(act);
        }

        [Fact]
        public async Task TestUnregCode_CodeExpired()
        {
            //Arrange 
            RemoteAccessCodeServiceSIT = new RemoteAccessCodeService(LoggerMock.Object,
                                                               MongoMock.Object);
            var remoteCode = new RemoteAccessCode("123456789", 10, DateTime.UtcNow.AddDays(-34), "123456789", MockCovidUser);
            MongoMock.Setup(m => m.FindOneAsync(It.IsAny<Expression<Func<RemoteAccessCode, bool>>>())).ReturnsAsync(remoteCode);

            //Act 
            Func<Task> act = () => RemoteAccessCodeServiceSIT.GetRemoteCode(MockRequestDto);

            //Assert
            await Assert.ThrowsAsync<RemoteAccessCodeNotFoundException>(act);
        }

        [Fact]
        public async Task TestUnregCode_CodeRegistered()
        {
            //Arrange 
            RemoteAccessCodeServiceSIT = new RemoteAccessCodeService(LoggerMock.Object,
                                                               MongoMock.Object);
            var remoteCode = new RemoteAccessCode("123456789", 10, DateTime.UtcNow.AddDays(1), "123456789", MockCovidUser);
            remoteCode.CodeStatus = CodeStatusType.Registered;
            MongoMock.Setup(m => m.FindOneAsync(It.IsAny<Expression<Func<RemoteAccessCode, bool>>>())).ReturnsAsync(remoteCode);

            //Act 
            Func<Task> act = () => RemoteAccessCodeServiceSIT.GetRemoteCode(MockRequestDto);

            //Assert
            await Assert.ThrowsAsync<RemoteAccessCodeNotFoundException>(act);
        }

        [Fact]
        public async Task TestUnregCode_CodeRevoked()
        {
            //Arrange 
            RemoteAccessCodeServiceSIT = new RemoteAccessCodeService(LoggerMock.Object,
                                                               MongoMock.Object);
            var remoteCode = new RemoteAccessCode("123456789", 10, DateTime.UtcNow.AddDays(1), "123456789", MockCovidUser);
            remoteCode.CodeStatus = CodeStatusType.Revoked;
            MongoMock.Setup(m => m.FindOneAsync(It.IsAny<Expression<Func<RemoteAccessCode, bool>>>())).ReturnsAsync(remoteCode);

            //Act 
            Func<Task> act = () => RemoteAccessCodeServiceSIT.GetRemoteCode(MockRequestDto);

            //Assert
            await Assert.ThrowsAsync<RemoteAccessCodeNotFoundException>(act);
        }
        #endregion

        #region RevokeRemoteCodeTests
        [Fact]
        public async Task TestRevokeRemoteCode_NullRemoteCode_ThrowsException()
        {
            //Arrange
            MongoMock.Setup(m => m.FindOneAsync(It.IsAny<Expression<Func<RemoteAccessCode, bool>>>())).ReturnsAsync((RemoteAccessCode)null);

            //Act
            Func<Task> act = async () => await RemoteAccessCodeServiceSIT.RevokeRemoteCode(MockCovidUser, MockRevokeRemoteCheckCodeDto);

            //Assert
            await Assert.ThrowsAsync<RemoteAccessCodeNotFoundException>(act);
        }

        [Fact]
        public async Task TestRevokeRemoteCode_RemoteCodeRevoked()
        {
            //Arrange
            var remoteCode = new RemoteAccessCode("123456789", 10, DateTime.UtcNow, "123456789", MockCovidUser);
            MongoMock.Setup(m => m.FindOneAsync(It.IsAny<Expression<Func<RemoteAccessCode, bool>>>())).ReturnsAsync(remoteCode);

            //Act
            await RemoteAccessCodeServiceSIT.RevokeRemoteCode(MockCovidUser, MockRevokeRemoteCheckCodeDto);

            //Assert
            MongoMock.Verify(x => x.ReplaceOneAsync(It.Is<RemoteAccessCode>(code => code.CodeStatus == CodeStatusType.Revoked)), Times.Once());
            MongoMock.Verify(x => x.ReplaceOneAsync(It.Is<RemoteAccessCode>(code => code.CodeStatus != CodeStatusType.Revoked)), Times.Never());
        }
        [Fact]
        public async Task TestRevokeRemoteCode_CheckHashCalculatedCorrectly()
        {
            //Arrange 
            var newMockCovidUser = new CovidPassportUser(MockCovidUser.Name, MockCovidUser.DateOfBirth, MockCovidUser.EmailAddress, "something different");
            var mockRevokeRemoteCheckDto = new RevokeRemoteCheckCodeDto()
            {
                RemoteCheckCode = "code"
            };

            var mockRemoteAccessCode = new RemoteAccessCode("code", 1, DateTime.UtcNow.AddDays(2), "hash", newMockCovidUser);
            mockRemoteAccessCode.CodeStatus = CodeStatusType.Registered;

            Expression<Func<RemoteAccessCode, bool>> actualLambda = null;
            MongoMock.Setup(x => x.FindOneAsync(It.IsAny<Expression<Func<RemoteAccessCode, bool>>>()))
                     .Callback((Expression<Func<RemoteAccessCode, bool>> e) => actualLambda = e)
                     .ReturnsAsync(mockRemoteAccessCode);

            //Act
            await RemoteAccessCodeServiceSIT.RevokeRemoteCode(MockCovidUser, mockRevokeRemoteCheckDto);
            var actual = actualLambda.Compile().Invoke(mockRemoteAccessCode);

            //Assert
            Assert.True(actual);
        }
        #endregion
        #region GetActiveRemoteCheckCodesTests

        [Theory()]
        [InlineData(false, CodeStatusType.Revoked, 2)]
        [InlineData(true, CodeStatusType.Registered, 2)]
        [InlineData(false, CodeStatusType.Registered, -34)]
        public async Task TestGetActiveRemoteCheckCodes_MongoCalledAndLambdaEvaluatesCorrectly(bool expected, CodeStatusType status, int expiryDays)
        {
            //Arrange
            var expiryDateTime = DateTime.UtcNow.AddDays(expiryDays);
            var mockRemoteAccessCode = new RemoteAccessCode("code", 1, expiryDateTime, "hash", MockCovidUser);
            mockRemoteAccessCode.CodeStatus = status;

            Expression<Func<RemoteAccessCode, bool>> actualLambda = null;
            MongoMock.Setup(x => x.FindAllAsync(It.IsAny<Expression<Func<RemoteAccessCode, bool>>>()))
                     .Callback((Expression<Func<RemoteAccessCode, bool>> e) => actualLambda = e);

            //Act
            await RemoteAccessCodeServiceSIT.GetActiveRemoteCheckCodes(MockCovidUser);
            var actual = actualLambda.Compile().Invoke(mockRemoteAccessCode);

            //Assert
            MongoMock.Verify(x => x.FindAllAsync(It.IsAny<Expression<Func<RemoteAccessCode, bool>>>()), Times.Once);
            Assert.Equal(expected, actual);
        }

        [Fact]
        public async Task TestGetActiveRemoteCheckCodes_CheckHashCalculatedCorrectly()
        {
            //Arrange 
            var newMockCovidUser = new CovidPassportUser(MockCovidUser.Name, MockCovidUser.DateOfBirth, MockCovidUser.EmailAddress, "something different");
            var mockRemoteAccessCode = new RemoteAccessCode("code", 1, DateTime.UtcNow.AddDays(2), "hash", newMockCovidUser);
            mockRemoteAccessCode.CodeStatus = CodeStatusType.Registered;

            Expression<Func<RemoteAccessCode, bool>> actualLambda = null;
            MongoMock.Setup(x => x.FindAllAsync(It.IsAny<Expression<Func<RemoteAccessCode, bool>>>()))
                     .Callback((Expression<Func<RemoteAccessCode, bool>> e) => actualLambda = e);

            //Act
            await RemoteAccessCodeServiceSIT.GetActiveRemoteCheckCodes(MockCovidUser);
            var actual = actualLambda.Compile().Invoke(mockRemoteAccessCode);

            //Assert
            Assert.True(actual);
        }

        #endregion
    }
}
