﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.BlobService;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CovidCertificate.Backend.Utils;
using Microsoft.Extensions.DependencyInjection;

namespace CovidCertificate.Backend.Services
{
    public class MappingCache : IMappingCache
    {
        private readonly IConfiguration configuration;
        private readonly ILogger<MappingCache> logger;
        private readonly IBlobService blobService;
        private const string TestResultContainer = "test-results-configuration";
        private const string TestResultMappingLocation = "test-results-mapping.json";

        private Dictionary<string, Dictionary<string, string>> mappings;
        private DateTime mappingsCacheExpiry;
        private static readonly AsyncLock MappingsMutex = new AsyncLock();

        private bool IsMappingsCacheValid =>
            mappingsCacheExpiry > DateTime.UtcNow && mappings != default;

        public MappingCache(
            IConfiguration configuration,
            ILogger<MappingCache> logger,
            IBlobService blobService)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.blobService = blobService;
        }
        
        public async Task<Dictionary<string, Dictionary<string, string>>> GetMappings()
        {
            logger.LogInformation($"{nameof(GetMappings)} was invoked.");

            if (IsMappingsCacheValid)
            {
                logger.LogInformation("Mappings cache is valid, returning Mappings.");

                return mappings;
            }

            using (await MappingsMutex.LockAsync())
            {
                if (IsMappingsCacheValid)
                {
                    logger.LogInformation("Mappings cache is valid, returning Mappings (mutex).");

                    return mappings;
                }

                logger.LogInformation("In-memory Mappings not found or invalid. Attempting to fetch mappings from blob storage.");

                mappings = await GetObjectFromBlobStorage();
                mappingsCacheExpiry =
                    DateTime.UtcNow.AddSeconds(int.TryParse(configuration["TestMapperCacheTime"], out var cacheTime) ? cacheTime : 600);

                return mappings;
            }
        }

        private async Task<Dictionary<string, Dictionary<string, string>>> GetObjectFromBlobStorage()
        {
            return await blobService.GetObjectFromBlob<Dictionary<string, Dictionary<string, string>>>(
                TestResultContainer, TestResultMappingLocation);
        }
    }
}
