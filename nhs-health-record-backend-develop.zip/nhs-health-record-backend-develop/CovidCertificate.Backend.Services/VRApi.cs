﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.ResponseDtos;
using CovidCertificate.Backend.Models.Settings;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace CovidCertificate.Backend.Services
{
    public class VRApi : IVRApi
    {
        private readonly VRSettings _vrSettings;
        private readonly ILogger<IVRApi> _logger;
        private readonly string _clientSecret;
        private static HttpClient _httpClient;
        private BearerToken _curentToken;
        private DateTime _tokenRefreshTime = DateTime.MinValue;

        public VRApi(VRSettings vrSettings, ILogger<VRApi> logger, IConfiguration configuration)
        {
            _vrSettings = vrSettings;
            _logger = logger;
            _clientSecret = configuration[_vrSettings.ClientSecretKey];
            if (_httpClient == null)
            {
                _httpClient = new HttpClient
                {
                    BaseAddress = new Uri(vrSettings.RegistryUrl +
                                          (vrSettings.RegistryUrl.EndsWith('/') ? string.Empty : "/")),
                    Timeout = TimeSpan.FromMinutes(1)
                };
            }
        }

        public async Task<HttpResponseMessage> GetFHIRVaccines(string idToken)
        {
            var req = new HttpRequestMessage(HttpMethod.Get, "VaccinationDataByIdentityToken");
            await SetHeaders(req, idToken);

            return await _httpClient.SendAsync(req);
        }

        private async Task SetHeaders(HttpRequestMessage req, string idToken)
        {
            req.Headers.Add("Ocp-Apim-Subscription-Key", _vrSettings.SubscriptionKey);
            req.Headers.Add("Accept", "text/plain");
            req.Headers.Add("Authorization", "Bearer " + (await GetBearer()).Access_Token);
            req.Headers.Add("NHSD-User-Identity", idToken);
        }

        private async Task<BearerToken> GetBearer()
        {
            _logger.LogInformation("GetBearer was invoked");

            if (DateTime.UtcNow > _tokenRefreshTime || _curentToken == null)
            {
                var req = new HttpRequestMessage(HttpMethod.Post, _vrSettings.TokenUrl)
                {
                    Content = new FormUrlEncodedContent(new Dictionary<string, string>
                    {
                        {"grant_type", "client_credentials"}, {"scope", _vrSettings.Scope}
                    })
                };
                req.Headers.Add("Authorization",
                    $"Basic {Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_vrSettings.ClientID}:{_clientSecret}"))}");
                req.Headers.Add("Accept", "application/json");

                _logger.LogInformation("Sending request");
                var response = await _httpClient.SendAsync(req);
                BearerToken token = null;
                try
                {
                    _logger.LogInformation("Response received");
                    response.EnsureSuccessStatusCode();
                    _logger.LogInformation("Response is successful");
                    if (response.Content != null)
                    {
                        token = JsonConvert.DeserializeObject<BearerToken>(await response.Content.ReadAsStringAsync());
                        _tokenRefreshTime = DateTime.UtcNow.AddSeconds(token.Expires_In).AddMinutes(-1); //Refresh 1 minute before token expires
                        _curentToken = token;
                    }
                }
                finally
                {
                    _logger.LogInformation("GetBearer has finished");
                    response.Dispose();
                }
            }

            return _curentToken;
        }
    }
}
