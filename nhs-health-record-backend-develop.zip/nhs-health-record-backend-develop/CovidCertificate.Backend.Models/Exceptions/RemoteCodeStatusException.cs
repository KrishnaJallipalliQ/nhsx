﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.Exceptions
{
    public class RemoteCodeStatusException : Exception
    {
        public RemoteCodeStatusException(string message) : base(message)
        {

        }
    }
}
