﻿using System.Security.Claims;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IJwtValidator
    {
        Task<bool> IsValidToken(string token, string authSchema = "CovidCertificate");

        Task<ClaimsPrincipal> GetClaims(string token, string authSchema = "CovidCertificate");
    }
}
