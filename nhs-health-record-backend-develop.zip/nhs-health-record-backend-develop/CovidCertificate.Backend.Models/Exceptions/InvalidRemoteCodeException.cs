﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.Exceptions
{
    public class InvalidRemoteCodeException : Exception
    {
        public InvalidRemoteCodeException(string message) : base(message)
        {
        }
    }
}
