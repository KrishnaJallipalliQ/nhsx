﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.NhsApiIntegration.Responses;
using CovidCertificate.Backend.NhsApiIntegration.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using CovidCertificate.Backend.Utils;
using FluentAssertions;
using Xunit;

namespace CovidCertificate.Backend.NhsApiIntegration.Tests
{
    public class NhsTestResultsHistoryApiAccessTokenServiceTests
    {
        private const string accessToken = "eyJzdWIiOiI0Y2JkZThkZC00NjA2LTRiNjUtYThhYy0wM2JiZjMwMTNkNWIiLCJhdWQiOiJoZWFsdGhyZWNvcmRzIiwia2lkIjoiZjYwZWI0NmZmOGFiZjBiZjllOTE3ZWVlNjA4NmM1ZmE0YTE2MmE1ZCIsImlzcyI6Imh0dHBzOi8vYXV0aC5hb3Muc2lnbmluLm5ocy51ayIsInR5cCI6IkpXVCIsImV4cCI6MTYyMTMyOTkyOSwiaWF0IjoxNjIxMzI5NjI5LCJhbGciOiJSUzUxMiIsImp0aSI6IjE4MTQzNjU3LTUxMjEtNDdiMS1iNWIzLTFkMzA4NGFhNzc4MiJ9.eyJzdWIiOiI0Y2JkZThkZC00NjA2LTRiNjUtYThhYy0wM2JiZjMwMTNkNWIiLCJuaHNfbnVtYmVyIjoiOTY1ODQ3Nzg2MCIsImlzcyI6Imh0dHBzOi8vYXV0aC5hb3Muc2lnbmluLm5ocy51ayIsInZlcnNpb24iOjAsInZ0bSI6Imh0dHBzOi8vYXV0aC5hb3Muc2lnbmluLm5ocy51ay90cnVzdG1hcmsvYXV0aC5hb3Muc2lnbmluLm5ocy51ayIsImNsaWVudF9pZCI6ImhlYWx0aHJlY29yZHMiLCJyZXF1ZXN0aW5nX3BhdGllbnQiOiI5NjU4NDc3ODYwIiwiYXVkIjoiaGVhbHRocmVjb3JkcyIsInRva2VuX3VzZSI6ImFjY2VzcyIsImF1dGhfdGltZSI6MTYyMTMyOTYyNiwic2NvcGUiOiJvcGVuaWQgZW1haWwgcHJvZmlsZSBwaG9uZSBwcm9maWxlX2V4dGVuZGVkIiwidm90IjoiUDkuQ3AuQ2QiLCJleHAiOjE2MjEzMjk5MjksImlhdCI6MTYyMTMyOTYyOSwicmVhc29uX2Zvcl9yZXF1ZXN0IjoicGF0aWVudGFjY2VzcyIsImp0aSI6IjE4MTQzNjU3LTUxMjEtNDdiMS1iNWIzLTFkMzA4NGFhNzc4MiJ9.ym0O4slJybaxETk1YyYrJvwLi15CCB9n0F0k61hRMHs7zRB-ARuzRVu1UI7MbGNwbc_LgNxJTzNwW1N3LkXRYouKX_EF-T4jEY1vwtTbtNfKB0TWqA3tPkM21XHETembrkEnEcRqG9c1_mOkzDTPcU3zmGYEN3LnO4glDuGLjEcey8Vb-QblqW91HhkPsXa2BBcSPH3StspIg0BYB_COWDVl5Hl8GNpbt-BSebNahNKCM5nfhcftGyE08gEuysnrDqSd9t1eN3TuqRRCdaQU5t4HtnWsNfvjvkNhRGVh4rt4e-r15k7vExFxK3F51QZf2X8x7DB-wla9Un6kboIahA";

        private const string privateKey =
            "MIIJJwIBAAKCAgBpLbix/UzBdsgzDqP2PjgCKuxA7z+JoAQmvABkup1SOKZm2BuRqIV79p7zhO40Er4pinYl+G0qiI5fgAWRzNndAZ2mDZCENuLRi2+XT33LWmKdbjkUE9iuTu1R/s7D5ODGZBZSwMRchRGYtsR0oNKlScOYQaqoHAbWwphzOuz5x/dIJrl5Eq5Ri7ynMQNBW/TgYJ4sFdRISgUGBEHHe5winahEjCeXGwsIKenUFb2fpijVmODOsZJ+ntLO1/nVgx70Hnk6LNwN6+0Y7d3omROLjbeDYjXGALD1sjGU/ZjwqWAqhZvSSyHVefaFWak7o3l4IbidEMnDz7uniiVeitZw6pq6bzW4Arpf/PBZGKZ4EFHZT7C/7pW8K0G8+w3MLrTzL/mcPqfnZOVRCr3xHGQ0bcRsBJlyNDGypw/Ux8XRd9hbxCxP4lKoCQ3dwQeb5SW/1fod4tqAkFXC6oPoL6Glu9pa+OE6qGm5WHF/P4bJ+hYH4vLW3bEkZ2Do/VyJwcdhHMkqjbkldb3Uj0mt3PFJLChAsHjAFpgpVL4QZJE/DBPIG6lChGL8yIDKozrscS1YxlfN30j+I5V+OJrME5oBVfz47CPjurUFmjjrEdU0S67/iOaXWU0CWPxhcZFemnLB0HMG1E+6nUtJZX4C3naQYxHjqG1Kp/XxPXik7DA5DQIDAQABAoICADrBIcW8HB6OvjNXYFx0UVFUrPlxLOsyil8g8o9SeAOwRbR50JzDqR2gnRaoEXDhb31BLdL0PfdepTnQCEx0RNfiyTAzr6FMD9TCsamy7DCm4yPSqOwAUjC9QnFliBeCSdZJnvbHXGnapAPNRV1pYYKX/D2XoT+buG5L8mGcbzjxbb/OchmiR+KhztcO2CSwu9CD6Jfz8cwYHUpJIn3PHV9w9sikCpGst7LtxwOEyZLffTwk1KBiLdWx301Q9O1C/A2e4FWRLbRRMPeWGTqQGI0Cs5sfR66+QBxgWLZEHCWEWIYocO0+rz3TjdTcS19XaMmk/L4w3KUX7FohH9L6d+OLfDewRCclclGaHsh9enOYJR+138+0rovN5cwITAxmbtnYGUeU3Bu0bSPbydVgRHFyn31HKiYnSQFsXGVctcG/8wp1GkfqcKbvOc6uVkG2soqm21AOnnmX9p0f3HYjSwt3U8rQmmxc/BcjuzBy7+cFeNCXG0Br2hMZlHgj7ZJkIuy9295mB+cBBiTYOO0fCUme9jFRTkAFEN6PA6HMpoOvparTi69YjU38xqUNz4xmGVdsVjO4rHUAhZRabu6rExv1iU+8XWEjtGHNCZMtVg91/mplgzXlGEYXvZPw7Lj/N6bGIdDi1d3W715iZWaLsu0lO7roYlwpKRGAmuehOybBAoIBAQDQOtF6t96qn8a209BjRg4WNUxaJqOj347bEvn/NfH7cayRnKXvBsiHO3CZ+s1hLCkApGjZkYtvp/culk3fqcKzo/iDYJaAS2S0+ys9Cm51092qFAZ6fasUDvRs7LldifYd9BVDclm2ySkDglFjR7DG5RJelvubec9wNhp58e1SWVdzC1NFVg/016fVtdahtnRnn3AL/4RiwsDEuuGcf1rX60qXk2/jE2zJLf8sSL2iqHnKRmzn4o1kxPyUfCdiKdRCPsv6A8ypSYU8mF7hV4qD0Re8OsSChNmh9iw9b12ej+ItpoazRLO1fDg3FE1v4XHLb+VkVlNGa5iozYWY/rH1AoIBAQCBTsio43Ekkm5WCbg27exX5D88crO/p48b5QSWgWeWdyUsWPbwfWmLGk1Z4nHEsC4PbmoUunhJyAgZp+6V6RQG5Q9+k9T8GZL2FkOjtwbw1eF9i4CpQB7nqvmwDV9Llo4MsiJhFFTYAMgM3bJCAC3YuMiKf9uZvxDqamnfadbzm/WL+ggbIPDFkpmKpQTr430XqgADlxxEtu/tNXQ69N6i8JoX5Et2BZrOsTlxAxbsIKuI//d7yIVvyzMrdb/vs7tJ4odANhB8xihDQVzND6K7Vj7tmF/O5JxYSlw0elI9GEwbZ0vOQlV7pwg36RDYiddrlkzyOaVcYp+O48LPxMO5AoIBAB9yEnpu1AB+Wnr3p8umI7B04g/nL+UqeJ9a0UgaNG3db8sZlfFv286YSlvmhSd8jMCdE3xvv1fgTLLLXf093LpWM8xbRL8hI5c1KwVv0tiWYy4xEf1jhvdjfsQIR8H5eKJzXtatqSCyZjAyeOn+RJL0uv5v3JVRIuN2OC9cOpOqDEvCVRPueEBoZN8gM8Z+EDwp1rjpIGvtr0DGXBXPIb/jt4MGb+oh39bNzHA6l/C9co76ba3jB6lFGkOuMCBh4r0SUKlz829JPAa3l/R9zNw1Mllpoo13VIph67JnZALzBZwRPtxJrr3kgXTH6x3PNOkc/85UPwUucIJlbxx4shUCggEAOkOfksn4/zujz8zNXqLSLcBA5iHg8Gi1ySHmcVKZtGi3LUZg7nf0CKOvWuL31GJ2PqnHztM+xDAHxleu34mIZprr4mMGQxna6Fub2rbrv7T/x6wGKz0jL8wQec1stQh/tSTG7OtWV4Xynil+2tJt1gtdAVsfPiWjn5yXW/26x0Xs3EerQ14SX1PxL1Gv6AI3KWSGYRfDuwqbDU1as/4GG3FCXaWWgvV/jca5VTzJJViLMk3z26i8x2TOB7Uk6QMZTu9tdfdmcnJvTe6zvAphjvwLms9fzD+iWv4WkebUC4dZM7fVpnipP/BBeb/gwVFK6cVtom9rHTerIZ1q+Gd2sQKCAQEAqvm9VBcm0L5eQwbYetGWa9/Rf/2JiIaF5RXIUMahvNuvLePg8dRB0mme17+vQe2jEEFpbWio5/x+w0Y3MKwYPueXsd6AWtzGit4gxq5s1wk6tkXLllQ7Ku78VN52omr+UM3rT4dsbeNR0qDiRWo8yZCB3JUn6OXe86nfzK6/qUVEj6Mt1pe2I9gm/VgNgvnKCZTlNllnzeyovnME1QGOrYSSTyEuKVtLliknU15GApWJGlkMOYmoS9QMwkf02ak8jatmw0Ce5P62oD6FRud8EFYkwzxngIcK/57ml3l3jh0umekSAcZbteQmmy6Hg0W1MAQlSU0SDSBE82Vlc7ZR9A==";

        Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);

        private List<string> JtiList = new List<string>();
        private Mock<ILogger<NhsTestResultsHistoryApiAccessTokenService>> loggerMock;
        private Mock<IRedisCacheService> redisCacheServiceMock;
        private Mock<IConfiguration> configurationMock;

        private NhsTestResultsHistoryApiSettings GenerateApplicationRestrictedSettings()
        {
            var settings = new NhsTestResultsHistoryApiSettings
            {
                AccessTokenRetryCount = 1,
                AccessTokenRetrySleepDurationInMilliseconds = 1,
                AccessTokenTimeoutInMilliseconds = 1,
                UseAccessTokenUserRestrictedMode = false
            };
            return settings;
        }

        public NhsTestResultsHistoryApiAccessTokenServiceTests()
        {
            loggerMock = new Mock<ILogger<NhsTestResultsHistoryApiAccessTokenService>>();
            redisCacheServiceMock = new Mock<IRedisCacheService>();
            redisCacheServiceMock.Setup(x => x.AddKeyAsync(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<RedisLifeSpanLevel>())).Verifiable();
            configurationMock = new Mock<IConfiguration>();
            configurationMock.SetupGet<string>(m => m["NhsTestResultsHistoryApiAccessTokenPrivateKey"]).Returns(privateKey);
        }

        [Fact]
        public async Task RefreshAccessTokenInRedis_SuccessTokenRetrieval()
        {
            // Arrange
            var settings = GenerateApplicationRestrictedSettings();

            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(new TokenResponse { AccessToken = accessToken })),
                })
                .Verifiable();

            var httpClient = new HttpClient(handlerMock.Object)
            {
                BaseAddress = new Uri("http://test.com/"),
            };

            var accessTokenService = new NhsTestResultsHistoryApiAccessTokenService(
                loggerMock.Object, configurationMock.Object, settings, httpClient, redisCacheServiceMock.Object);

            // Act
            var token = await accessTokenService.RefreshAccessTokenInRedisAsync();

            // Assert
            redisCacheServiceMock.Verify(x => x.AddKeyAsync(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<RedisLifeSpanLevel>()), Times.Once);
        }

        [Fact]
        public async Task UserRestriced_SuccessTokenRetrieval_NoStoreInRedis()
        {
            // Arrange
            var handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(new TokenResponse { AccessToken = accessToken })),
                })
                .Verifiable();

            var httpClient = new HttpClient(handlerMock.Object)
            {
                BaseAddress = new Uri("http://test.com/"),
            };

            var userRestrictedSettings = new NhsTestResultsHistoryApiSettings
            {
                AccessTokenRetryCount = 1,
                AccessTokenRetrySleepDurationInMilliseconds = 1,
                AccessTokenTimeoutInMilliseconds = 1,
                UseAccessTokenUserRestrictedMode = true
            };

            var accessTokenService = new NhsTestResultsHistoryApiAccessTokenService(
                loggerMock.Object, configurationMock.Object, userRestrictedSettings, httpClient, redisCacheServiceMock.Object);

            // Act
            var token = await accessTokenService.GetAccessTokenAsync("testIdToken");

            // Assert
            redisCacheServiceMock.Verify(x => x.AddKeyAsync(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<RedisLifeSpanLevel>()), Times.Never);
        }

        [Fact]
        public async Task RefreshAccessTokenInRedis_UnauthorizedTokenRetrieval()
        {
            // Arrange
            var settings = GenerateApplicationRestrictedSettings();

            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.Unauthorized,
                    Content = new StringContent("Unauthorized"),
                })
                .Verifiable();

            var httpClient = new HttpClient(handlerMock.Object)
            {
                BaseAddress = new Uri("http://test.com/"),
            };

            var accessTokenService = new NhsTestResultsHistoryApiAccessTokenService(
                loggerMock.Object, configurationMock.Object, settings, httpClient, redisCacheServiceMock.Object);

            // Act
            var token = Assert.ThrowsAsync<Exception>(async () => await accessTokenService.RefreshAccessTokenInRedisAsync());

            // Assert
            redisCacheServiceMock.Verify(x => x.AddKeyAsync(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<RedisLifeSpanLevel>()), Times.Never);
        }

        [Fact]
        public async Task GetAccessTokenAsync_FoundValidToken_InCache()
        {
            // Arrange
            var settings = GenerateApplicationRestrictedSettings();
            int expiresIn = (int)DateTimeOffset.UtcNow.AddMinutes(10).ToUnixTimeSeconds();
            var tokenResponse = new TokenResponse() { AccessToken = accessToken, ExpiresIn = expiresIn };

            redisCacheServiceMock.Setup(x => x.GetKeyValueAsync<TokenResponse>(It.IsAny<string>())).ReturnsAsync((tokenResponse, true)).Verifiable();

            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(tokenResponse)),
                })
                .Verifiable();

            var httpClient = new HttpClient(handlerMock.Object)
            {
                BaseAddress = new Uri("http://test.com/"),
            };

            var accessTokenService = new NhsTestResultsHistoryApiAccessTokenService(
                loggerMock.Object, configurationMock.Object, settings, httpClient, redisCacheServiceMock.Object);

            // Act
            var accessTokenResult = await accessTokenService.GetAccessTokenAsync("test");

            // Assert
            Assert.Equal(accessToken, accessTokenResult);
            redisCacheServiceMock.Verify(x => x.GetKeyValueAsync<TokenResponse>(It.IsAny<string>()), Times.Once);
        }


        [Fact]
        public async Task GetAccessTokenAsync_FoundValidToken_InMemory()
        {
            // Arrange
            var settings = GenerateApplicationRestrictedSettings();
            int expiresIn = (int)DateTimeOffset.UtcNow.AddMinutes(10).ToUnixTimeSeconds();
            var tokenResponse = new TokenResponse() { AccessToken = accessToken, ExpiresIn = expiresIn };

            redisCacheServiceMock.Setup(
                x => x.GetKeyValueAsync<TokenResponse>(It.IsAny<string>())).ReturnsAsync((tokenResponse, true)).Verifiable();

            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(tokenResponse)),
                })
                .Verifiable();

            var httpClient = new HttpClient(handlerMock.Object)
            {
                BaseAddress = new Uri("http://test.com/"),
            };

            var accessTokenService = new NhsTestResultsHistoryApiAccessTokenService(
                loggerMock.Object, configurationMock.Object, settings, httpClient, redisCacheServiceMock.Object);

            // Act
            await accessTokenService.GetAccessTokenAsync("test");
            var accessTokenResult = await accessTokenService.GetAccessTokenAsync("test");

            // Assert
            Assert.Equal(accessToken, accessTokenResult);
            redisCacheServiceMock.Verify(x => x.GetKeyValueAsync<TokenResponse>(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task WhenInternalServerErrorResponse_ShouldRetry_And_ThrowTimeoutException()
        {
            // Arrange
            var settings = GenerateApplicationRestrictedSettings();
            var stringContent = new StringContent("error");
            MockSetup(stringContent, HttpStatusCode.InternalServerError, out HttpClient httpClient);

            handlerMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    nameof(HttpClient.SendAsync),
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ThrowsAsync(new HttpRequestException("some exc message")).Verifiable();

            httpClient = new HttpClient(handlerMock.Object)
            {
                BaseAddress = new Uri("http://test.com/")
            };

            int expiresIn = (int)DateTimeOffset.UtcNow.AddMinutes(10).ToUnixTimeSeconds();
            var tokenResponse = new TokenResponse() { AccessToken = accessToken, ExpiresIn = expiresIn };
 
            redisCacheServiceMock.Setup(
                x => x.GetKeyValueAsync<TokenResponse>(It.IsAny<string>())).ReturnsAsync((tokenResponse, false)).Verifiable();

            var accessTokenService = new NhsTestResultsHistoryApiAccessTokenService(
                loggerMock.Object, configurationMock.Object, settings, httpClient, redisCacheServiceMock.Object);

            // Act
            Func<Task> act = async () => await accessTokenService.GetAccessTokenAsync("test"); ;

            // Assert
            await act.Should().ThrowAsync<Exception>();
            handlerMock
                .Protected()
                .Verify(
                    nameof(HttpClient.SendAsync), Times.Exactly(settings.AccessTokenRetryCount + 1), ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>());
        }

        [Fact]
        public async Task WhenTimeoutException_ShouldRetry_And_UpdateJtiValueInJwtPayload()
        {
            // Arrange
            var settings = GenerateApplicationRestrictedSettings();
            var stringContent = new StringContent("error");
            MockSetup(stringContent, HttpStatusCode.InternalServerError, out HttpClient httpClient);

            int expiresIn = (int)DateTimeOffset.UtcNow.AddMinutes(10).ToUnixTimeSeconds();
            var tokenResponse = new TokenResponse() { AccessToken = accessToken, ExpiresIn = expiresIn };

            handlerMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    nameof(HttpClient.SendAsync),
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .Returns<HttpRequestMessage, CancellationToken>(async (x, c) => await ObtainJtiAndReturnDelayedResponse(x, tokenResponse));

            httpClient = new HttpClient(handlerMock.Object)
            {
                BaseAddress = new Uri("http://test.com/")
            };
          
            redisCacheServiceMock.Setup(
                x => x.GetKeyValueAsync<TokenResponse>(It.IsAny<string>())).ReturnsAsync((tokenResponse, false)).Verifiable();

            var accessTokenService = new NhsTestResultsHistoryApiAccessTokenService(
                loggerMock.Object, configurationMock.Object, settings, httpClient, redisCacheServiceMock.Object);

            // Act
            await accessTokenService.GetAccessTokenAsync(null);

            // Assert
            Assert.Equal(2, JtiList.Count);
            Assert.NotEqual(JtiList[0], JtiList[1]); // Jti should be different for each request

        }

        private async Task<HttpResponseMessage> ObtainJtiAndReturnDelayedResponse(HttpRequestMessage requestMessage, TokenResponse tokenResponse)
        {
            var responseString = await requestMessage.Content.ReadAsStringAsync();

            var token = responseString
                .Substring(responseString.IndexOf("client_assertion=", StringComparison.Ordinal))
                .Replace("client_assertion=", "");

            var jti = JwtTokenUtils.GetClaim(token, "jti");

            JtiList.Add(jti);

            if (JtiList.Count < 2)
            {
                return new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.TooManyRequests,
                    Content = new StringContent(JsonConvert.SerializeObject(tokenResponse)),
                };
            }

            return new HttpResponseMessage()
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(JsonConvert.SerializeObject(tokenResponse)),
            };

        }

        private void MockSetup(StringContent stringContent, HttpStatusCode statusCode, out HttpClient httpClient)
        {
            handlerMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = statusCode,
                    Content = stringContent,
                })
                .Verifiable();
            httpClient = new HttpClient(handlerMock.Object)
            {
                BaseAddress = new Uri("http://test.com/"),
            };
        }
    }
}
