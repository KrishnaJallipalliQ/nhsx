﻿using CovidCertificate.Backend.Models.Enums;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using Hl7.Fhir.Model;

namespace CovidCertificate.Backend.Models.DataModels
{
    [Collection("Transliterations-Collection")]
    public class TransliterationsModel
    {
        public string Unicode { get; set; }
        public string Description { get; set; }
        public string RecommendedTransliteration { get; set; }

        public TransliterationsModel()
        {
        }

        public TransliterationsModel(string unicode, string description, string recommendedTransliteration)
        {
            Unicode = unicode;
            Description = description;
            RecommendedTransliteration = recommendedTransliteration;
        }
    }
}