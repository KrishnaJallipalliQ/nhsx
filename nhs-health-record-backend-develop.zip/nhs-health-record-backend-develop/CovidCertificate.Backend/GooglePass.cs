﻿using CovidCertificate.Backend.Configuration.Bases.BaseFunctions;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Delegates;
using CovidCertificate.Backend.Models.DataModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using CovidCertificate.Backend.Utils.Extensions;
using Newtonsoft.Json;
using CovidCertificate.Backend.Models.Enums;

namespace CovidCertificate.Backend
{
    public class GooglePass : BaseSecureFunction
    {
        private readonly IGooglePassJwt JWT;
        public GooglePass(JwtValidatorResolver jwtValidator, IGooglePassJwt googlePassJwt, IConfiguration configuration, ILogger<GooglePass> logger) : base(jwtValidator, configuration, logger)
        {
            this.JWT = googlePassJwt;
        }

        [FunctionName("WalletPassGoogle")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "WalletPassGoogle")] HttpRequest req, ILogger log)
        {
            logger.LogInformation("WalletPassGoogle was invoked");

            var authorisationResult = await base.AuthoriseEndpoint(req);
            logger.LogTraceAndDebug($"validationResult: IsValid {authorisationResult?.IsValid}, Response is {authorisationResult?.Response}, TokenClaims are {authorisationResult?.TokenClaims}");
            if (base.responseInvalid(authorisationResult))
            {
                logger.LogInformation("WalletPassGoogle has finished");
                return authorisationResult.Response;
            }
            var covidUser = new CovidPassportUser(authorisationResult.TokenClaims);
            var result = 0;
            var jwt = await JWT.GenerateJwt(covidUser, (QRType)result, base.GetIdToken(req));

            var jsonJwt = JsonConvert.SerializeObject(jwt);

            logger.LogInformation("WalletPassGoogle has finished");

            return new OkObjectResult(jsonJwt);
        }
    }
}
