﻿namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class NhsTokenValidationFetcherTest
    {
    }
}
