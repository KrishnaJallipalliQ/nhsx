﻿using System;
using CovidCertificate.Backend.Interfaces;

namespace CovidCertificate.Backend.Models.DataModels
{
    public class AntibodyResultResponse
    {
        public AntibodyResultResponse(AntibodyResult res, IGetTimeZones timeZones)
        {
            var timeZoneInfo = timeZones.GetTimeZoneInfo();
            this.DateTimeOfTest = TimeZoneInfo.ConvertTime(res.DateTimeOfTest, timeZoneInfo);
            this.TestType = res.ValidityType;
            this.TestResult = res.TestResult;
        }

        public AntibodyResultResponse(AntibodyResultNhs res, IGetTimeZones timeZones)
        {
            var timeZoneInfo = timeZones.GetTimeZoneInfo();
            this.DateTimeOfTest = TimeZoneInfo.ConvertTime(res.DateTimeOfTest, timeZoneInfo);
            this.TestType = res.ValidityType;
            this.TestResult = res.Result;
        }


        public DateTime DateTimeOfTest { get; }
        public string TestType { get; }
        public string TestResult { get; }


        public override bool Equals(object obj)
        {
            //Check for null and compare run-time types.
            if ((obj == null) || !this.GetType().Equals(obj.GetType()))
                return false;

            var castedObj = (AntibodyResultResponse)obj;                        
            return (DateTimeOfTest == castedObj.DateTimeOfTest) && (TestType == castedObj.TestType) && (TestResult == castedObj.TestResult);
        }

        public override int GetHashCode() => DateTimeOfTest.GetHashCode() ^ TestType.GetHashCode() ^ TestResult.GetHashCode();
    }
}
