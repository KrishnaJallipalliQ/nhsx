﻿using CovidCertificate.Backend.Models.Interfaces;
using CovidCertificate.Backend.Models.Validators.UserValidators;
using FluentValidation;

namespace CovidCertificate.Backend.Models.Validators
{
    public class UserInformationValidator : AbstractValidator<IUserInformation>
    {
        public UserInformationValidator()
        {
            Include(new UserNhsInformationValidator());
            Include(new UserBaseInformationValidator());          
        }
    }
}
