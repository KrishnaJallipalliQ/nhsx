﻿namespace CovidCertificate.Backend.Models.Enums
{
    public enum ResultStatus
    {
        Negative,
        Positive,
        Void
    }
}
