﻿namespace CovidCertificate.Backend.Models.Interfaces
{
    public interface IUserInformation : IUserBaseInformation, IUserNhsInformation
    { }
}
