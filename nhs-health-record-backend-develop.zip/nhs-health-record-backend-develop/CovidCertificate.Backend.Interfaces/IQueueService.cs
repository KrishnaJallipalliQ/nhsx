﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    /// <summary>
    /// Queue service adds a series of messages or objects to a queue, whether this is cloud or local hosted
    /// </summary>
    public interface IQueueService
    {
        /// <summary>
        /// Sends a single message to a queue
        /// </summary>
        /// <param name="queueName">The queue to add it too</param>
        /// <param name="message">The message to add to a queue</param>
        /// <returns></returns>
        Task<bool> SendMessage(string queueName, string message);

        /// <summary>
        /// Adds a batch of messages to a queue
        /// </summary>
        /// <param name="queueName">the queue to add them too</param>
        /// <param name="messages">The messages to add</param>
        /// <returns>How many messages were added</returns>
        Task<int> SendMessages(string queueName, IEnumerable<string> messages);

        /// <summary>
        /// Adds an object to the message queue
        /// </summary>
        /// <typeparam name="T">The object type to add</typeparam>
        /// <param name="queueName">The queue to add it too</param>
        /// <param name="messageObject">The object to add</param>
        /// <returns></returns>
        Task<bool> SendMessage<T>(string queueName, T messageObject) where T : class;

        /// <summary>
        /// Adds a collection of objects to a queue
        /// </summary>
        /// <typeparam name="T">The type of objects to add</typeparam>
        /// <param name="queueName">The queue to add them too</param>
        /// <param name="messageObjects">The objects to add</param>
        /// <returns></returns>
        Task<int> SendMessages<T>(string queueName, IEnumerable<T> messageObjects) where T : class;
    }
}
