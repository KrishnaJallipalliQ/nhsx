﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Utils;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Tests.AzureFunctionsTests.DomesticExemptionTests
{
    public class GetDomesticExemptionFunctionTests
    {
        private readonly Mock<IDomesticExemptionService> domesticExemptionService;
        private readonly Mock<ILogger<GetDomesticExemptionFunction>> logger;
        private readonly GetDomesticExemptionFunction getDomesticExemptionFunction;

        public GetDomesticExemptionFunctionTests()
        {
            this.domesticExemptionService = new Mock<IDomesticExemptionService>();
            this.logger = new Mock<ILogger<GetDomesticExemptionFunction>>();
            this.getDomesticExemptionFunction = new GetDomesticExemptionFunction(domesticExemptionService.Object, logger.Object);

        }

        [Fact]
        public async Task GetExemption_ExemptionDoesntExist_Returns204()
        {
            // Arrange
            var nhsNumber = "1234567890";
            var dateOfBirth = "1990-10-10";
            var reason = "some reason";

            var mockRequest = new Mock<HttpRequest>();
            mockRequest.Setup(x => x.Query["nhsNumber"]).Returns(nhsNumber);
            mockRequest.Setup(x => x.Query["dateOfBirth"]).Returns(dateOfBirth);

            DomesticExemption exemption = null;

            domesticExemptionService
                .Setup(x => x.GetDomesticExemption(It.IsAny<string>(), It.IsAny<DateTime>()))
                .ReturnsAsync(exemption);

            // Act
            var result = await getDomesticExemptionFunction.GetDomesticExemption(mockRequest.Object);

            // Assert
            Assert.Equal(typeof(NoContentResult), result.GetType());
        }

        [Fact]
        public async Task GetExemption_ExemptionExist_Returns200()
        {
            // Arrange
            var nhsNumber = "1234567890";
            var dateOfBirth = "1990-10-10";
            var reason = "some reason";
            var hash = "some hash";

            var mockRequest = new Mock<HttpRequest>();
            mockRequest.Setup(x => x.Query["nhsNumber"]).Returns(nhsNumber);
            mockRequest.Setup(x => x.Query["dateOfBirth"]).Returns(dateOfBirth);

            DomesticExemption exemption = new DomesticExemption(hash, reason);

            domesticExemptionService
                .Setup(x => x.GetDomesticExemption(It.IsAny<string>(), It.IsAny<DateTime>()))
                .ReturnsAsync(exemption);

            // Act
            var result = await getDomesticExemptionFunction.GetDomesticExemption(mockRequest.Object);

            // Assert
            Assert.Equal(typeof(OkObjectResult), result.GetType());
        }
    }
}
