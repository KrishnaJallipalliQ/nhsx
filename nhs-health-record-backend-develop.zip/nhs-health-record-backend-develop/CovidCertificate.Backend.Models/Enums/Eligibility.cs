﻿namespace CovidCertificate.Backend.Models.Enums
{
    public enum Eligibility { Ineligible = 0, Eligible = 1 }
}
