﻿using CovidCertificate.Backend.Interfaces;
using Newtonsoft.Json;
using System;

namespace CovidCertificate.Backend.Models.DataModels
{
    [Collection("Holding-Test-Data")]
    public class HoldingTestResult : UserHashedDocument, IGenericResult
    {
        public HoldingTestResult(string name, DateTime dateOfBirth, string emailAddress, string phoneNumber, string nhsNumber, DateTime dateTimeOfTest, string result, string validityType)
            : base(name, dateOfBirth, phoneNumber, emailAddress, nhsNumber)
        {
            this.DateTimeOfTest = dateTimeOfTest;
            this.Result = result;
            this.ValidityType = validityType;
        }

        public HoldingTestResult(TestResult testResult) : base(testResult.Id.ToString(), testResult.PartitionKey, testResult.PhoneHash, testResult.EmailHash, testResult.NhsNumberHash)
        {

        }

        public DateTime DateTimeOfTest { get; set; }
        public string Result { get; set; }
        public string ValidityType { get; set; }

        //Implement interface fields without having to rename existing models
        
    }
}
