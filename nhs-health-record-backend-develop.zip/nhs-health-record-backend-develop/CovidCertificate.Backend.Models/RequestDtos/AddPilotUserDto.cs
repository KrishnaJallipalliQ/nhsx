﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Interfaces;
using CovidCertificate.Backend.Models.Validators;
using FluentValidation;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Models.RequestDtos
{
    public class AddPilotUserDto 
    {
        [JsonConstructor]
        public AddPilotUserDto(string name, DateTime dateOfBirth) 
        {
            this.DateOfBirth = dateOfBirth;
            this.Name = name;
        }
        public string Name { get; set; }
        public DateTime DateOfBirth { get; set; }
        public PilotUser ToPilotUser() => new PilotUser(this);
        public virtual async Task ValidateObjectAndThrowOnFailuresAsync()
        {
            await new AddPilotUserDtoValidator().ValidateAndThrowAsync(this);
        }
    }
}
