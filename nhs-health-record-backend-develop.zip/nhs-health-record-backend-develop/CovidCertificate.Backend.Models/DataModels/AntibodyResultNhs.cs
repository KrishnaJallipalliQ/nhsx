﻿using CovidCertificate.Backend.Interfaces;
using Newtonsoft.Json;
using System;
using System.Text;

namespace CovidCertificate.Backend.Models.DataModels
{
    public class AntibodyResultNhs : IGenericResult
    {
        public AntibodyResultNhs(AntibodyResult dto) : this(dto.DateTimeOfTest, dto.TestResult, dto.ValidityType, dto.TestKit) { }

        [JsonConstructor]
        public AntibodyResultNhs(DateTime dateTimeOfTest, string result, string validityType, string testKit)
        {
            this.DateTimeOfTest = dateTimeOfTest;
            this.Result = result;
            this.ValidityType = validityType;
            this.TestKit = testKit;
        }

        public DateTime DateTimeOfTest { get; }
        public string ValidityType { get; }
        public string Result { get; }
        public string TestKit { get; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Result:").Append(this.Result ?? "").AppendLine();
            sb.Append("TestKit:").Append(this.TestKit ?? "").AppendLine();
            sb.Append("ValidityType:").Append(this.ValidityType ?? "").AppendLine();
            sb.Append("DateTimeOfTest").Append(this.DateTimeOfTest).AppendLine();
            return sb.ToString();
        }
    }
}
