﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace CovidCertificate.Backend.Models.Interfaces
{
    public interface IUserHashedDocument : IMongoDocument
    {
        [BsonRepresentation(BsonType.String)]
        public string PhoneHash { get; }

        [BsonRepresentation(BsonType.String)]
        public string EmailHash { get; }

        [BsonRepresentation(BsonType.String)]
        public string NhsNumberHash { get; }

        [BsonRepresentation(BsonType.String)]
        public string PartitionKey { get; }
    }
}
