﻿using CovidCertificate.Backend.Models.DataModels;
using FluentValidation;

namespace CovidCertificate.Backend.Models.Validators
{
    public class EligibilityConfigurationValidator : AbstractValidator<EligibilityConfiguration>
    {
        public EligibilityConfigurationValidator()
        {
            RuleForEach(x => x.Rules).SetValidator(new EligibilityRulesValidator());
        }
    }
}
