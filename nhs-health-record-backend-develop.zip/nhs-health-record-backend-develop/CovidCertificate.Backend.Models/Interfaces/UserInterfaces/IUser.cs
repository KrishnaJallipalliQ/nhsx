﻿namespace CovidCertificate.Backend.Models.Interfaces
{
    public interface IUser : IUserInformation, IUserContactInformation 
    { }
}
