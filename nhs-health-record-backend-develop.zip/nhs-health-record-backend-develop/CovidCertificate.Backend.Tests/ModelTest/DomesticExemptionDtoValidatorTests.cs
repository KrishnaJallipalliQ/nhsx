﻿using System;
using System.Linq;
using System.Threading.Tasks;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Models.Validators;
using Xunit;

namespace CovidCertificate.Backend.Tests.ModelTest
{
    public class DomesticExemptionDtoValidatorTests
    {
        private readonly string validReason = "reason";
        private readonly string invalidReason = null;
        private readonly string invalidReasonErrorMessage = "'Reason' must not be empty.";
        private readonly string validNhsNumber = "1234567890";
        private readonly string invalidNhsNumber = "badNhsNumber";
        private readonly string invalidNhsNumberErrorMessage = "'Nhs Number' is not in the correct format.";
        private readonly DateTime validDateOfBirth = DateTime.Now.AddYears(-20);
        private readonly DateTime invalidDateOfBirth = new DateTime();
        private readonly string invalidDateOfBirthErrorMessage = "'Date Of Birth' must not be empty.";

        [Fact]
        public async Task DomesticExemptionDto_IsValid()
        {
            //Assign
            var domesticExemptionDtoValidator = new DomesticExemptionDtoValidator();
            var domesticExemption = new DomesticExemptionDto(validNhsNumber, validDateOfBirth, validReason);

            //Act
            var validatorResult = await domesticExemptionDtoValidator.ValidateAsync(domesticExemption);
            var dtoExtensionValidatorResult = await domesticExemption.ValidateObjectAsync();

            //Assert
            Assert.True(validatorResult.IsValid);
            Assert.True(dtoExtensionValidatorResult.IsValid);
        }

        [Fact]
        public async Task DomesticExemptionDto_NhsNumber_IsNotValid()
        {
            //Assign
            var domesticExemptionDtoValidator = new DomesticExemptionDtoValidator();
            var domesticExemption = new DomesticExemptionDto(invalidNhsNumber, validDateOfBirth, validReason);

            //Act
            var validatorResult = await domesticExemptionDtoValidator.ValidateAsync(domesticExemption);
            var dtoExtensionValidatorResult = await domesticExemption.ValidateObjectAsync();

            //Assert
            Assert.Equal(invalidNhsNumberErrorMessage, validatorResult.Errors.FirstOrDefault().ErrorMessage);
            Assert.Equal(invalidNhsNumberErrorMessage, dtoExtensionValidatorResult.Errors.FirstOrDefault().ErrorMessage);
            Assert.False(validatorResult.IsValid);
            Assert.False(dtoExtensionValidatorResult.IsValid);
        }

        [Fact]
        public async Task DomesticExemptionDto_DateOfBirth_IsNotValid()
        {
            //Assign
            var domesticExemptionDtoValidator = new DomesticExemptionDtoValidator();
            var domesticExemption = new DomesticExemptionDto(validNhsNumber, invalidDateOfBirth, validReason);

            //Act
            var validatorResult = await domesticExemptionDtoValidator.ValidateAsync(domesticExemption);
            var dtoExtensionValidatorResult = await domesticExemption.ValidateObjectAsync();

            //Assert
            Assert.Equal(invalidDateOfBirthErrorMessage, validatorResult.Errors.FirstOrDefault().ErrorMessage);
            Assert.Equal(invalidDateOfBirthErrorMessage, dtoExtensionValidatorResult.Errors.FirstOrDefault().ErrorMessage);
            Assert.False(validatorResult.IsValid);
            Assert.False(dtoExtensionValidatorResult.IsValid);
        }
    }
}
