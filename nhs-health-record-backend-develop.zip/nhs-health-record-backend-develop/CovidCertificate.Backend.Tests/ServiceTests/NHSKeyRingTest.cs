﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Services;
using CovidCertificate.Backend.Services.KeyServices;
using CovidCertificate.Backend.Tests.TestHelpers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class NhsKeyRingTest
    {
        private readonly Mock<ILogger<NhsKeyRing>> mockLogger;
        private readonly Mock<ILogger<NhsIdJwtValidator>> mockLoggerValidator;
        private readonly Mock<IPublicKeyService> mockPublicKeyService;
        private readonly Dictionary<string, string> inMemorySettings;
        private readonly IConfiguration configuration;

        public NhsKeyRingTest()
        {

            mockLogger = new Mock<ILogger<NhsKeyRing>>();
            mockLoggerValidator = new Mock<ILogger<NhsIdJwtValidator>>();
            mockPublicKeyService = new Mock<IPublicKeyService>();
            inMemorySettings = NHSKeyRingTestHelper.InMemorySettings;
            configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();
        }

        [Fact]
        public async Task NhsKeyRing_CanCorrectlySignAndVerifyDataAsync_ResultTrue()
        {
            // Arrange
            var nhsKeyRing = new NhsKeyRing(configuration, mockLogger.Object);
            var payload = new Dictionary<string, object>()
            {
                {"sub", configuration["ClientId"]},
                {"aud", configuration["TokenUrl"]},
                {"iss", configuration["ClientId"]},
                {"exp", new DateTimeOffset(DateTime.Now.AddHours(Convert.ToDouble(configuration["TokenLifetime"]))).ToUnixTimeSeconds()},
                {"jti", Guid.NewGuid().ToString()}
            };

            // Act
            var token = nhsKeyRing.SignData(payload);
            var nhsIdJwtValidator = NHSKeyRingTestHelper.GetNhsIdJwtValidator(NHSKeyRingTestHelper.GetValidPublicJwk(), configuration, mockLoggerValidator, mockPublicKeyService);
            var result = await nhsIdJwtValidator.IsValidToken(token, NhsIdJwtValidatorTestHelper.AuthSchema);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public async Task NhsKeyRing_WillFailIfIncorrectlySigned_ResultFalse()
        {
            // Arrange
            var nhsKeyRing = new NhsKeyRing(configuration, mockLogger.Object);
            var payload = new Dictionary<string, object>()
            {
                {"sub", configuration["ClientId"]},
                {"aud", configuration["TokenUrl"]},
                {"iss", configuration["ClientId"]},
                {"exp", new DateTimeOffset(DateTime.Now.AddHours(Convert.ToDouble(configuration["TokenLifetime"]))).ToUnixTimeSeconds()},
                {"jti", Guid.NewGuid().ToString()}
            };

            // Act
            var token = nhsKeyRing.SignData(payload);
            var nhsIdJwtValidator = NHSKeyRingTestHelper.GetNhsIdJwtValidator(NHSKeyRingTestHelper.GetInvalidPublicJwk(), configuration, mockLoggerValidator, mockPublicKeyService);
            var result = await nhsIdJwtValidator.IsValidToken(token, NhsIdJwtValidatorTestHelper.AuthSchema);

            // Assert
            Assert.False(result);
        }
    }
}
