using CovidCertificate.Backend.Configuration.Bases.BaseFunctions;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.ResponseDtos;
using CovidCertificate.Backend.Utils.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using SendGrid.Helpers.Errors.Model;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Auth
{
    public class RefreshToken : BaseFunction
    {
        public RefreshToken(INhsLoginService nhsLoginService, ILogger<RefreshToken> logger) : base(logger) => _nhsLoginService = nhsLoginService;

        private readonly INhsLoginService _nhsLoginService;

        [FunctionName("RefreshToken")]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "post", Route = "Token/Refresh")] HttpRequest request)
        {
            try
            {
                logger.LogInformation("RefreshToken was invoked");

                if (!request.Headers.TryGetValue("refreshToken", out var refreshTokenHeader))
                {
                    throw new ArgumentNullException("No refresh token was specified.");
                }
                var nhsLoginToken = await _nhsLoginService.GetAccessTokenAsync(refreshTokenHeader);
                logger.LogTraceAndDebug($"nhsLoginToken : {nhsLoginToken?.ToString()}");

                // Since we do not acquire a new refresh token from NHS login. We return the same refresh token in the response.
                var nhsLoginTokenResponse = new NhsLoginTokenResponse(nhsLoginToken.AccessToken, refreshTokenHeader, nhsLoginToken.ExpiresIn, nhsLoginToken.IdToken);
                logger.LogTraceAndDebug($"nhsLoginTokenResponse:{nhsLoginTokenResponse?.ToString()}");

                logger.LogInformation("RefreshToken has finished");

                return new OkObjectResult(nhsLoginTokenResponse);
            }
            catch (Exception e) when (e is BadRequestException || e is ArgumentNullException)
            {
                logger.LogWarning(e, e.Message);
                return new BadRequestObjectResult("There seems to be a problem: bad request");
            }
            catch (UnauthorizedException e)
            {
                logger.LogWarning(e, e.Message);
                return new UnauthorizedObjectResult("There seems to be a problem: unauthorized");
            }
            catch (HttpRequestException e)
            {
                logger.LogCritical(e, e.Message);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
            catch (Exception e)
            {
                logger.LogError(e, e.Message);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}
