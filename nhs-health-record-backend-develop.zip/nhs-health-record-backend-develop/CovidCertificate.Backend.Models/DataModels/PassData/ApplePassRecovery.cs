﻿using CovidCertificate.Backend.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.DataModels
{
    public class ApplePassRecovery
    {
        public string DateOfFirstPositiveTestResult { get; set; }
        public string CertificateType { get; set; }
        public string DiseaseTargeted { get; set; }
        public string CountryOfTest { get; set; }
        public string CertificateIssuer { get; set; }
        public string CertificateValidFrom { get; set; }
        public string CertificateValidUntil { get; set; }
        public string Uvci { get; set; }
        public ApplePassRecovery(TestResultNhs testResultNhs)
        {
            DateOfFirstPositiveTestResult = testResultNhs.DateTimeOfTest.ToString("dd MMMM yyyy");
            CertificateType = testResultNhs.ValidityType;
            DiseaseTargeted = testResultNhs.DiseaseTargeted.Item2;
            CountryOfTest = testResultNhs.CountryOfAuthority;
            CertificateIssuer = testResultNhs.Authority;
            CertificateValidFrom = DateTime.UtcNow.ToString("dd MMMM yyyy");
        }
    }
}
