using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using System;
using System.Collections.Generic;
using CovidCertificate.Backend.Utils.Extensions;
using System.Net;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Services.Mappers;
using Hl7.Fhir.Serialization;
using Hl7.Fhir.Model;
using static Hl7.Fhir.Model.Bundle;
using SendGrid.Helpers.Errors.Model;
using CovidCertificate.Backend.Models.Exceptions;
using CovidCertificate.Backend.Utils;
using Microsoft.Extensions.Configuration;
using System.Linq;

namespace CovidCertificate.Backend.Services
{
    public class VRService : IVRService
    {
        private readonly VaccinationMapper vacMapper;
        private readonly ILogger<VRService> logger;
        private readonly IRedisCacheService redisCacheService;
        private readonly IVRApi _vrApi;
        private readonly IPilotFilterService pilotFilterService;
        private readonly IConfiguration configuration;

        public VRService(VaccinationMapper mapper, ILogger<VRService> _logger, IRedisCacheService _redisCacheService,
            IVRApi vrApi, IPilotFilterService pilotFilterService, IConfiguration configuration)
        {
            logger = _logger;
            redisCacheService = _redisCacheService;
            _vrApi = vrApi;
            vacMapper = mapper;
            this.pilotFilterService = pilotFilterService;
            this.configuration = configuration;
        }

        private async Task<string> GetFHIRVaccines(string idToken, CovidPassportUser covidUser)
        {
            var idTokenHash = idToken.GetHashString();
            logger.LogTraceAndDebug($"token hash is: {idTokenHash}");
            var key = $"GetVaccines:{idTokenHash}";
            (var cachedResponse,var IsExist) =await redisCacheService.GetKeyValueAsync<string>(key);
            if (!IsExist)
            {
                var response = await _vrApi.GetFHIRVaccines(idToken);
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    var result = await response.Content.ReadAsStringAsync();
                    await redisCacheService.AddKeyAsync(key, result, RedisLifeSpanLevel.Medium);
                    return result;
                }

                if (response.StatusCode == HttpStatusCode.Unauthorized)
                    throw new UnauthorizedException("Status code Unauthorized when calling Vaccine Registry:" + response.ReasonPhrase);
                if (response.StatusCode == HttpStatusCode.BadRequest)
                    throw new BadRequestException("Status code Bad Request when calling Vaccine Registry:" + response.ReasonPhrase);

                throw new ArgumentException("Error with calling Vaccine Registry");
            }

            return cachedResponse;
        }

        public async Task<List<Vaccine>> GetVaccines(string idToken, CovidPassportUser covidUser)
        {
            var vaccines = new List<Vaccine>();
            if (Environment.GetEnvironmentVariable("ViewOnlyPilotUsersData") == "true" && !(await pilotFilterService.IsPilotUser(covidUser.ToPilotUser())))
            {
                return vaccines;
            }

            var fjp = new FhirJsonParser();
            Bundle immunizationBundle = fjp.Parse<Bundle>(await GetFHIRVaccines(idToken, covidUser));
            
            foreach (EntryComponent entry in immunizationBundle.Entry)
            {
                var immunization = entry.Resource as Immunization;
                if (immunization is Immunization)
                {
                    if (immunization.Status != Immunization.ImmunizationStatusCodes.Completed) continue;
                    logger.LogTraceAndDebug(
                        $"Immunization being mapped. Date: {immunization.Occurrence}." +
                        $" Vaccine: {immunization.VaccineCode}. Manufacturer: {immunization.Manufacturer}");
                    try { 
                        var vaccine = await vacMapper.MapFhirToVaccine(immunization);
                        logger.LogTraceAndDebug($"Vaccine mapped. Date: {vaccine.VaccinationDate}");
                        // filter duplicate vaccines based on dose number, product (SNOMED code) and DateTimeOfTest
                        var query = vaccines.Where(x => x.DoseNumber == vaccine.DoseNumber
                                                        && x.SnomedCode == vaccine.SnomedCode
                                                        && x.VaccinationDate == vaccine.VaccinationDate);
                        if (query.Any())
                        {
                            var existingVaccineRecord = query.First();
                            if (existingVaccineRecord.DateEntered < vaccine.DateEntered)
                            {
                                vaccines.Remove(existingVaccineRecord);
                                vaccines.Add(vaccine);
                            }
                        }
                        else
                        {
                            vaccines.Add(vaccine);
                        }
                    }
                    catch (VaccineMappingException e)
                    {
                        logger.LogError(e, e.Message);
                    }
                }
            }
            if (configuration.GetValue<bool>("FilterFirstAndLastVaccines")){
                if (vaccines.Count > 2)
                {
                    logger.LogTraceAndDebug("Filtering for first and last vaccines");
                    List<Vaccine> sortedList = vaccines.OrderBy(v => v.VaccinationDate).ToList();
                    return new List<Vaccine> { sortedList.First(), sortedList.Last() };
                }
            }
            return vaccines;
        }
    }
}
