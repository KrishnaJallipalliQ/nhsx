﻿using CovidCertificate.Backend.Models.RequestDtos;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.Validators
{
    public class EmailPdfRequestDtoValidator : AbstractValidator<EmailPdfRequestDto>
    {
        public EmailPdfRequestDtoValidator()
        {
            RuleFor(x => x.PdfData).NotEmpty();
            RuleFor(x => x.Email).EmailAddress();
            RuleFor(x => x.Name).NotEmpty();
            RuleFor(x => x.LanguageCode).NotEmpty();
        }
    }
}
