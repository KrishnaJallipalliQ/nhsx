﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Models.DataModels;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Omnibasis.GoogleWallet;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Models.Settings;
using System.Text;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;
using System.IO;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.OpenSsl;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Security;
using System.Linq;
using CovidCertificate.Backend.Utils;

namespace CovidCertificate.Backend.Services
{
    public class GooglePassJwt : IGooglePassJwt
    {

        private readonly ILogger<GooglePassJwt> _logger;
        private readonly PassSettings settings;
        private readonly IGeneratePassData generatePassData;
        private readonly string privateKey;
        public GooglePassJwt(ILogger<GooglePassJwt> logger, IGeneratePassData passData, IConfiguration configuration, PassSettings passSettings)
        {
            _logger = logger;

            generatePassData = passData;

            settings = passSettings;
            this.privateKey = configuration["GooglePrivateKey"];
        }

        public async Task<string> GenerateJwt(CovidPassportUser user, QRType qrType, string idToken = "")
        {
            _logger.LogInformation("GenerateJwt was invoked");
            var data = await generatePassData.GetPassDataAsync(user, idToken, qrType);

            var qrCode = data.qr;
            var cert = data.cert;
            if (qrCode == null || cert == null)
            {
                throw new InvalidDataException("Invalid pass type");
            }
            var covidCardObject = prepareCommonFields(user);

            switch (qrType)
            {
                case QRType.Domestic:
                    prepareDomesticFields(covidCardObject, cert, qrCode);
                    break;
                case QRType.International:
                    prepareInternationalFields(covidCardObject, cert, qrCode);
                    break;
                case QRType.Recovery:
                    prepareRecoveryFields(covidCardObject, cert, qrCode);
                    break;
                default:
                    _logger.LogWarning("Unknown QR Type");
                    break;
            }

            var createPayload = new Payload
            {
                covidCardObjects = new List<CovidCardObject> { covidCardObject }
            };
            var privateKeyNew = privateKey.Replace("\\n", "\n");
            using RSA rsa = RSA.Create();
            rsa.ImportPkcs8PrivateKey(Convert.FromBase64String(privateKeyNew), out _);
            var signingCredentials = new SigningCredentials(new RsaSecurityKey(rsa), SecurityAlgorithms.RsaSha256)
            {
                CryptoProviderFactory = new CryptoProviderFactory { CacheSignatureProviders = false }
            };
            var jwtHeader = new JwtHeader(
                signingCredentials: signingCredentials);
            var jwtPayload = new JwtPayload
            {
                { "iss",settings.Iss},
                { "aud",settings.Audience},
                { "iat", DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString()},
                {"typ", settings.JwtType },
                {"origins", $"[{settings.PassOrigins}]" },
                {"payload",createPayload },
            };
            var jwt = new JwtSecurityToken(jwtHeader, jwtPayload);
            var handler = new JwtSecurityTokenHandler();
            var tokenString = handler.WriteToken(jwt);
            return tokenString;
        }

        private CovidCardObject prepareCommonFields(CovidPassportUser user)
        {
            var covidCardObject = new CovidCardObject();

            StringBuilder sb = new StringBuilder();
            sb.Append(settings.IssuerId).Append('.').Append(settings.UniqueId);
            covidCardObject.id = sb.ToString();
            covidCardObject.issuerId = settings.IssuerId.ToString();
            covidCardObject.barcode = new Barcode { type = "qrCode" };
            covidCardObject.barcode.alternateText = "Barcode";
            covidCardObject.cardColorHex = settings.BackgroundColour;
            covidCardObject.logo = new Logo { sourceUri = new SourceUri { uri = "https://www.gstatic.com/images/icons/material/system_gm/2x/healing_black_48dp.png", description = "NHS App" } };
            covidCardObject.patientDetails = new PatientDetails { patientName = user.Name };
            covidCardObject.title = settings.PassName;

            return covidCardObject;
        }

        private CovidCardObject prepareDomesticFields(CovidCardObject pass, Certificate cert, QRcodeResponse code)
        {
            pass.barcode.value = cert.QrCodeTokens[0];
            pass.expiration = code.ValidityEndDate;
            _logger.LogInformation("Domestic pass generated");
            return pass;
        }

        private CovidCardObject prepareInternationalFields(CovidCardObject pass, Certificate cert, QRcodeResponse code)
        {
            //TODO International Fields go here
            return pass;
        }

        private CovidCardObject prepareRecoveryFields(CovidCardObject pass, Certificate cert, QRcodeResponse code)
        {
            //TODO Recovery Fields go here
            return pass;
        }
    }
}

