﻿using CovidCertificate.Backend.International.Services;
using CovidCertificate.Backend.Models.DataModels;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using PeterO.Cbor;
using System;
using System.Linq;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.International.Tests.Helpers;
using Xunit;

namespace CovidCertificate.Backend.International.Tests
{
    public class CondensorServiceTest
    {
        private readonly CondensorService condensorService;
        private readonly Mock<ILogger<CondensorService>> mockLogger;
        private readonly Mock<IConfiguration> mockConfig;
        private readonly Mock<IGetTimeZones> mockGetTimeZones;

        public CondensorServiceTest()
        {
            mockLogger = new Mock<ILogger<CondensorService>>();
            mockConfig = new Mock<IConfiguration>();
            mockConfig.SetupGet<string>(m => m["ValidityEndDate"]).Returns("2021-06-20");
            mockConfig.SetupGet<string>(m => m["VaccinationAuthority"]).Returns("NHS Digital");
            mockConfig.SetupGet<string>(m => m["TimeZoneWindows"]).Returns("GMT Standard Time");
            mockConfig.SetupGet<string>(m => m["TimeZoneLinux"]).Returns("Europe/London");
            mockGetTimeZones = new Mock<IGetTimeZones>();
            mockGetTimeZones.Setup(x => x.GetTimeZoneInfo()).Returns(TimeZoneInfo.Utc);
            condensorService = new CondensorService(mockLogger.Object, mockConfig.Object, mockGetTimeZones.Object);
        }
        [Fact]
        public void CondenseCBORValid()
        {
            var vaccinations = TestHelpers.SetUpVaccines();
            var user = TestHelpers.SetUpUser();
            var result = condensorService.CondenseCBOR<Vaccine>(user, DateTimeOffset.UtcNow.ToUnixTimeSeconds(), vaccinations, string.Empty, DateTime.UtcNow.AddDays(30), 0);
            Assert.NotNull(result);
            Assert.IsType<CBORObject>(result);
        }
        [Fact]
        public void CondenseCBORTValid()
        {
            var vaccinations = TestHelpers.SetUpVaccines();
            var user = TestHelpers.SetUpUser();
            var result = condensorService.CondenseCBOR<Vaccine>(user, DateTimeOffset.UtcNow.ToUnixTimeSeconds(), vaccinations, string.Empty, DateTime.UtcNow.AddDays(30), 0);
            Assert.NotNull(result);
            Assert.IsType<CBORObject>(result);
        }

        [Fact]
        public void CondenseCBORTRecoveryModelValid()
        {
            var testResults = TestHelpers.SetUpRecoveryTestResults();
            var user = TestHelpers.SetUpUser();
            var result = condensorService.CondenseCBOR<TestResultNhs>(user, DateTimeOffset.UtcNow.ToUnixTimeSeconds(), testResults, string.Empty, DateTime.UtcNow.AddDays(30), 0);
            Assert.NotNull(result);
            Assert.IsType<CBORObject>(result);
        }

        [Fact]
        public void CondenseCBORInvalid()
        {
            var vaccinations = TestHelpers.SetUpVaccines();
            var user = new CovidPassportUser(null, default, null, null, null);
            Assert.Throws<ArgumentException>(() => condensorService.CondenseCBOR<Vaccine>(user, DateTimeOffset.UtcNow.ToUnixTimeSeconds(), vaccinations, string.Empty, DateTime.UtcNow.AddDays(30), 0));
        }

        [Theory]
        [InlineData("Firstname Middlename Middlename", "Lastname", "Firstname Middlename Middlename", "Lastname", "FIRSTNAME<MIDDLENAME<MIDDLENAME", "LASTNAME")]
        [InlineData("Firstname Middlename", "L'astname", "Firstname Middlename", "L'astname", "FIRSTNAME<MIDDLENAME", "L<ASTNAME")]
        [InlineData("Firstname Middlename", "L-astname", "Firstname Middlename", "L-astname", "FIRSTNAME<MIDDLENAME", "L<ASTNAME")]
        [InlineData("Mike O'Leary", "Smith-Johnson", "Mike O'Leary", "Smith-Johnson", "MIKE<O<LEARY", "SMITH<JOHNSON")]
        [InlineData("Firstname Middle-name Another-MiddleName", "L-astname SecondLastName", "Firstname Middle-name Another-MiddleName", "L-astname SecondLastName", "FIRSTNAME<MIDDLE<NAME<ANOTHER<MIDDLENAME", "L<ASTNAME<SECONDLASTNAME")]
        // Other inlinedata can be tested if NHS login allows non english alphabetical characters, still to be confirmed
        [InlineData("Jiřina-Maria Alena", "d'Červenková Panklová", "Jiřina-Maria Alena", "d'Červenková Panklová", "JIRINA<MARIA<ALENA", "D<CERVENKOVA<PANKLOVA")]
        [InlineData("Gabriele", "Musterfrau-Gößinger", "Gabriele", "Musterfrau-Gößinger", "GABRIELE", "MUSTERFRAU<GOSINGER")]
        [InlineData("Elith Nåd", "Møy", "Elith Nåd", "Møy", "ELITH<NAD", "MOY")]

        public void ToNameCBOR_CheckNameParsedProperly(string givenName, string familyName, string expectedGN, string expectedFN, string expectedGNT, string expectedFNT)
        {
            //Arrange
            var user = new CovidPassportUser(givenName + " " + familyName, DateTime.UtcNow, "", "", null, familyName, givenName);
            char[] charsToRemove = { '"' };
            var vaccinations = TestHelpers.SetUpVaccines();

            //Act
            var cborObject = condensorService.CondenseCBOR<Vaccine>(user, DateTimeOffset.UtcNow.ToUnixTimeSeconds(), vaccinations, string.Empty, DateTime.UtcNow.AddDays(30),  0);
            var cborList = cborObject[-260][1]["nam"].Entries.ToList();

            var actualGN = cborList.Find(x => x.Key.ToString() == "\"gn\"").Value.ToString().Trim('"');
            var actualFN = cborList.Find(x => x.Key.ToString() == "\"fn\"").Value.ToString().Trim('"');
            var actualGNT = cborList.Find(x => x.Key.ToString() == "\"gnt\"").Value.ToString().Trim('"');
            var actualFNT = cborList.Find(x => x.Key.ToString() == "\"fnt\"").Value.ToString().Trim('"');
            
            //Assert
            Assert.Equal(expectedGN, actualGN);
            Assert.Equal(expectedFN, actualFN);
            Assert.Equal(expectedGNT, actualGNT);
            Assert.Equal(expectedFNT, actualFNT);
        }

        [Fact]
        public void CondenseTransliteration_ForeignCharacterUser()
        {
            var user = TestHelpers.SetUpForeignCharacterUser();
            var transliterationResults = CondensorService.GetTransliterationResults(user.FamilyName, user.GivenName);

            Assert.NotNull(transliterationResults);
            Assert.Contains("O-T", transliterationResults[0]);
            Assert.Contains("A-N-U", transliterationResults[1]);
        }

        [Fact]
        public void CondenseTransliteration_EnglishUser()
        {
            var user = TestHelpers.SetUpUser();
            var transliterationResults = CondensorService.GetTransliterationResults(user.FamilyName, user.GivenName);

            Assert.NotNull(transliterationResults);
            Assert.Contains("McTestPerson", transliterationResults[0]);
            Assert.Contains("Test", transliterationResults[1]);
        }

        [Fact]
        public void GetFromFamilyAndGivenNames_EnglishCharacters()
        {
            //Arrange
            var user = new CovidPassportUser("FirstName LastName", DateTime.UtcNow, "", "", null, string.Empty, string.Empty);
            var vaccinations = TestHelpers.SetUpVaccines();

            //Act
            var cborObject = condensorService.CondenseCBOR<Vaccine>(user, DateTimeOffset.UtcNow.ToUnixTimeSeconds(), vaccinations, string.Empty, DateTime.UtcNow.AddDays(30), 0);
            var cborList = cborObject[-260][1]["nam"].Entries.ToList();

            var actualFN = cborList.Find(x => x.Key.ToString() == "\"fn\"").Value.ToString().Trim('"');
            var actualGN = cborList.Find(x => x.Key.ToString() == "\"gn\"").Value.ToString().Trim('"');
            var actualFNT = cborList.Find(x => x.Key.ToString() == "\"fnt\"").Value.ToString().Trim('"');
            var actualGNT = cborList.Find(x => x.Key.ToString() == "\"gnt\"").Value.ToString().Trim('"');

            //Assert
            Assert.Equal("firstname", actualGN);
            Assert.Equal("lastname", actualFN);
            Assert.Equal("FIRSTNAME", actualGNT);
            Assert.Equal("LASTNAME", actualFNT);
        }

        [Fact]
        public void GetFromFamilyAndGivenNames_ForeignCharacters()
        {
            //Arrange 
            var user = new CovidPassportUser("Elith Nåd Møy", DateTime.UtcNow, "", "", null, string.Empty, string.Empty);
            var vaccinations = TestHelpers.SetUpVaccines();

            //Act
            var cborObject = condensorService.CondenseCBOR<Vaccine>(user, DateTimeOffset.UtcNow.ToUnixTimeSeconds(), vaccinations, string.Empty, DateTime.UtcNow.AddDays(30), 0);
            var cborList = cborObject[-260][1]["nam"].Entries.ToList();

            var actualFN = cborList.Find(x => x.Key.ToString() == "\"fn\"").Value.ToString().Trim('"');
            var actualGN = cborList.Find(x => x.Key.ToString() == "\"gn\"").Value.ToString().Trim('"');
            var actualFNT = cborList.Find(x => x.Key.ToString() == "\"fnt\"").Value.ToString().Trim('"');
            var actualGNT = cborList.Find(x => x.Key.ToString() == "\"gnt\"").Value.ToString().Trim('"');

            //Assert
            Assert.Equal("elith nåd", actualGN);
            Assert.Equal("møy", actualFN);
            Assert.Equal("ELITH<NAD", actualGNT);
            Assert.Equal("MOY", actualFNT);
        }
    }
}
