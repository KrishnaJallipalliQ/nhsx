﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Services.Certificates;
using CovidCertificate.Backend.Services.DomesticExemptions;
using Microsoft.Extensions.DependencyInjection;

namespace CovidCertificate.Backend.Extensions
{
    public static class DomesticExemptionExtensions
    {
        public static void AddDomesticExemptionServices(this IServiceCollection services)
        {
            services.AddScoped<IDomesticExemptionService, DomesticExemptionService>();
            services.AddScoped<IDomesticExemptionCertificateGenerator, DomesticExemptionCertificateGenerator>();
            services.AddSingleton<IDomesticExemptionCache, DomesticExemptionCache>();
            services.AddScoped<IDomesticExemptionParser, DomesticExemptionParser>();
        }
    }
}
