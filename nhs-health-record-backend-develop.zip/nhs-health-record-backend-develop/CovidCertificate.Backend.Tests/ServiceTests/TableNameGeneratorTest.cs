﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Services;
using System;
using Xunit;
namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class TableNameGeneratorTest
    {
        private const string DateFormat = "ddMMyyHH";
        private readonly ITableNameGenerator service;

        public TableNameGeneratorTest()
        {
            service = new TableNameGenerator();
        }

        [Fact]
        public void GetTableName_WithUtcNow_ShouldBeSuccesful()
        {
            //Arrange 
            var expected = $"FA{DateTime.UtcNow.ToString(DateFormat)}";
            //Act
            var result = service.GetTableName();

            //Assert
            Assert.NotNull(result);
            Assert.Equal(expected, result);
        }

        [Fact]
        public void GetTableName_WithGivenDate_ShouldBeSuccesful()
        {
            //Arrange 
            var input = DateTime.UtcNow.AddDays(-1);
            var expected = $"FA{input.ToString(DateFormat)}";

            //Act
            var result = service.GetTableName(input);

            //Assert
            Assert.NotNull(result);
            Assert.Equal(expected, result);
        }
    }
}
