﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.Interfaces;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Utils;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace CovidCertificate.Backend.Models.DataModels
{
    [Collection("Current-Pilot-Users")]
    public class PilotUser : MongoDocument
    {
        public PilotUser(AddPilotUserDto addPilotUserDto) 
        {
            UserHash = StringUtils.GetValueHash(addPilotUserDto.Name, addPilotUserDto.DateOfBirth);
        }
        public PilotUser(CovidPassportUser covidUser)
        {
            UserHash = StringUtils.GetValueHash(covidUser.Name, covidUser.DateOfBirth);
        }
        public PilotUser(UserHashedDocument hashedDoc) 
        {
        }
        public PilotUser(AddTestResultRequestDto addTestResultDto)
        {
            UserHash = StringUtils.GetValueHash(addTestResultDto.Name, addTestResultDto.DateOfBirth);
        }
        public string UserHash { get; set; }

        [JsonConstructor]
        private PilotUser(string id, [JsonProperty("UserHash")] string userHash) : base(id)
        {
            this.UserHash = userHash;
        }
    }
}
