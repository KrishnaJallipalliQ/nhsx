﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.RequestDtos
{
    public class AddInternationalVaccinePdfRequestDto
    {

        public string ExpiryTimestamp { get; set; }
        public IEnumerable<AddInternationalPdfVaccinationRequestDto> Vaccinations { get; set; }
        public string VaccinationUniqueCertificateIdentifer { get; set; }
    }
}
