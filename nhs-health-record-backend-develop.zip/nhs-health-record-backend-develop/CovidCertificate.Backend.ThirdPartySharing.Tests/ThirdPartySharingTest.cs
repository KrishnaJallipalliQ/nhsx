using System;
using System.Collections.Generic;
using System.IO;
using System.Linq.Expressions;
using System.Security.Claims;
using System.Security.Principal;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Web.Http;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Interfaces.RemoteAccessCodeService;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Models.Exceptions;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Models.ResponseDtos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Graph;
using Moq;
using Xunit;

namespace CovidCertificate.Backend.ThirdPartySharing.Tests
{
    public class GetRegRemoteCovidStatusFunction_Tests
    {
        private readonly Mock<ILogger<GetRegRemoteCovidStatusFunction>> loggerMock = new Mock<ILogger<GetRegRemoteCovidStatusFunction>>();
       
        private readonly Mock<IRemoteAccessCodeService> remoteAccessServiceMock = new Mock<IRemoteAccessCodeService>();

        private readonly Mock<ICovidCertificateCreator> certificateCreatorMock = new Mock<ICovidCertificateCreator>();

        private readonly Mock<IMongoRepository<ThirdParty>> repoMock = new Mock<IMongoRepository<ThirdParty>>();

        private string idToken;

        public GetRegRemoteCovidStatusFunction_Tests()
        {
            idToken = "dummytoken";
            var graphServiceClient = new Mock<IGraphServiceClient>();

            var result = new Mock<Microsoft.Graph.IGraphServiceApplicationsCollectionRequest>();
            graphServiceClient.Setup(c => c.Applications.Request().Filter(It.IsAny<string>())).Returns(result.Object);           
        }


        [Fact]
        public void Run_InternalServerError_ClaimsNull()
        {
            var uat = new GetRegRemoteCovidStatusFunction(remoteAccessServiceMock.Object, certificateCreatorMock.Object, repoMock.Object, loggerMock.Object);

            var httpRequest = new Mock<HttpRequest>();

            var result = Assert.ThrowsAsync<ArgumentNullException>(() => uat.Run(httpRequest.Object, ClaimsPrincipal.Current));

            Assert.NotNull(result);
            Assert.IsType<System.Threading.Tasks.Task<ArgumentNullException>>(result);
        }

        /// <summary>
        /// Send an authroised user and no payload to the service and make sure the errors are handled
        /// </summary>
        [Fact]
        public void Run_ReturnsError_WhenUserIsAuthorizedButNoClaims()
        {
            //Arrange
            var uat = new GetRegRemoteCovidStatusFunction(remoteAccessServiceMock.Object, certificateCreatorMock.Object, repoMock.Object, loggerMock.Object);

            var httpRequest = new Mock<HttpRequest>();
            var identity = new Mock<IIdentity>();

            identity.Setup(c => c.Name).Returns("Test User");

            var user = new Mock<ClaimsPrincipal>();
            user.Setup(c => c.Identity).Returns(identity.Object);

            httpRequest.Setup(c => c.HttpContext.User).Returns(user.Object);

            MongoReturnNonNullThirdParty("id", "name");

            //Act
            var result = uat.Run(httpRequest.Object, httpRequest.Object.HttpContext.User);

            //Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
        }

        /// <summary>
        /// Send an invalid payload to the service and make sure errors are handled
        /// </summary>
        [Fact]
        public void Run_Invalid_Request()
        {
            //Arrange
            var uat = new GetRegRemoteCovidStatusFunction(remoteAccessServiceMock.Object, certificateCreatorMock.Object, repoMock.Object, loggerMock.Object);

            var httpRequest = new Mock<HttpRequest>();
            var identity = new Mock<IIdentity>();

            httpRequest.Setup(c => c.Body).Returns(new MemoryStream(Encoding.UTF8.GetBytes("Test")));

            identity.Setup(c => c.Name).Returns("Test User");

            var user = new Mock<ClaimsPrincipal>();
            user.Setup(c => c.Identity).Returns(identity.Object);
            httpRequest.Setup(c => c.HttpContext.User).Returns(user.Object);
            MongoReturnNonNullThirdParty("id", "name");

            //Act
            var result = uat.Run(httpRequest.Object, httpRequest.Object.HttpContext.User);

            //Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
        }

        /// <summary>
        /// Json payload is serialised correctly and certificate is in date, check the returned value matches expected logic
        /// </summary>
        [Fact(Skip = "Disabled as long as no longer retrieving certificates by hash")]
        public void Run_ReturnsCertificate_WhenGivenValidInput()
        {
            //Arrange
            var expiry = DateTime.UtcNow.AddDays(1);
            FakeCertificate(expiry);
            FakeAccessCode(DateTime.UtcNow.AddMinutes(5));
            var httpRequest = FakeHttpRequest(FakeBody());
            var uat = new GetRegRemoteCovidStatusFunction(remoteAccessServiceMock.Object, certificateCreatorMock.Object, repoMock.Object, loggerMock.Object);
            MongoReturnNonNullThirdParty("id", "name");

            //Act
            OkObjectResult result = uat.Run(httpRequest, httpRequest.HttpContext.User).Result as OkObjectResult;

            //Assert
            Assert.NotNull(result);

            var cert = result.Value as RemoteCovidStatusResponseDto;

            Assert.NotNull(cert);
            Assert.Equal(expiry, cert.CertificationExpiry);
            Assert.Equal("Valid", cert.CertificationStatus);
        }

        /// <summary>
        /// Input is valid but the third party in the database
        /// </summary>
        [Fact]
        public void Run_ReturnBadRequest_WhenNoThirdPartyCorrespondToDetails()
        {
            //Arrange
            var expiry = DateTime.UtcNow.AddDays(1);
            FakeCertificate(expiry);
            FakeAccessCode(DateTime.UtcNow.AddMinutes(5));
            var httpRequest = FakeHttpRequest(FakeBody());
            var uat = new GetRegRemoteCovidStatusFunction(remoteAccessServiceMock.Object, certificateCreatorMock.Object, repoMock.Object, loggerMock.Object);
            MongoReturnNullThirdParty();

            //Act
            var result = uat.Run(httpRequest, httpRequest.HttpContext.User);

            //Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
        }

        /// <summary>
        /// Testing what happens in the event of an expired certificate being issued
        /// </summary>
        [Fact]
        public void Run_ReturnCertificateStatusNone_WhenCertificateHasExpired()
        {
            //Arrange
            var expiry = DateTime.UtcNow.AddDays(-1);
            FakeCertificate(expiry);
            FakeAccessCode(DateTime.UtcNow.AddMinutes(5));
            var uat = new GetRegRemoteCovidStatusFunction(remoteAccessServiceMock.Object, certificateCreatorMock.Object, repoMock.Object, loggerMock.Object);

            MongoReturnNonNullThirdParty("id", "name");

            var httpRequest = FakeHttpRequest(FakeBody());

            //Act
            OkObjectResult result = uat.Run(httpRequest, httpRequest.HttpContext.User).Result as OkObjectResult;

            //Assert
            Assert.NotNull(result);

            var cert = result.Value as RemoteCovidStatusResponseDto;

            Assert.NotNull(cert);
            Assert.Null(cert.CertificationExpiry);
            Assert.Equal("None", cert.CertificationStatus);
        }

        /// <summary>
        /// If the user is unauthroised or no record is recorded 
        /// </summary>
        [Fact]
        public void Run_ReturnCertificateStatusNone_WhenNoValidCertificate()
        {
            //Arrange
            FakeCertificate(null);
            FakeAccessCode(DateTime.UtcNow.AddMinutes(5));
            var uat = new GetRegRemoteCovidStatusFunction(remoteAccessServiceMock.Object, certificateCreatorMock.Object, repoMock.Object, loggerMock.Object);

            var httpRequest = FakeHttpRequest(FakeBody());

            MongoReturnNonNullThirdParty("id", "name");

            //Act
            OkObjectResult result = uat.Run(httpRequest, httpRequest.HttpContext.User).Result as OkObjectResult;

            //Assert
            Assert.NotNull(result);

            var cert = result.Value as RemoteCovidStatusResponseDto;

            Assert.NotNull(cert);
            Assert.Null(cert.CertificationExpiry);
            Assert.Equal("None", cert.CertificationStatus);
        }

        [Fact]
        public void Run_ReturnsBadRequest_WhenNullAccessCodeRetrieved()
        {
            //Arrange
            FakeCertificate(null);

            var uat = new GetRegRemoteCovidStatusFunction(remoteAccessServiceMock.Object,
                certificateCreatorMock.Object, repoMock.Object, loggerMock.Object);
            remoteAccessServiceMock.Setup(x => x.GetRegRemoteCode(It.IsAny<FetchRemoteCovidStatusDto>(), It.IsAny<GetAuthCodeRequestDto>())).ReturnsAsync((RemoteAccessCode)null);
            var httpRequest = FakeHttpRequest(FakeBody());
            MongoReturnNonNullThirdParty("id", "name");

            //Act
            var result = uat.Run(httpRequest, httpRequest.HttpContext.User);

            //Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
        }

        [Fact]
        public void Run_ReturnsBadRequest_WhenRetrievingRemoteCodeThrowsException()
        {
            //Arrange
            FakeCertificate(null);

            remoteAccessServiceMock.Setup(c =>
                    c.GetRegRemoteCode(It.IsAny<FetchRemoteCovidStatusDto>(), It.IsAny<GetAuthCodeRequestDto>())).Throws(new RemoteCodeStatusException("Error"));

            var uat = new GetRegRemoteCovidStatusFunction(remoteAccessServiceMock.Object, certificateCreatorMock.Object, repoMock.Object, loggerMock.Object);

            var httpRequest = FakeHttpRequest(FakeBody());

            //Act
            var result = uat.Run(httpRequest, httpRequest.HttpContext.User);

            //Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
        }

        #region Helper Functions

        private static string FakeBody()
        {
            var request = new FetchRemoteCovidStatusDto("Test User", new DateTime(2000, 01, 01), "123456789");

            return JsonSerializer.Serialize<FetchRemoteCovidStatusDto>(request);
        }

        /// <summary>
        /// Creates a Fake HTTP request
        /// </summary>
        /// <param name="claims"></param>
        /// <returns></returns>
        private static HttpRequest FakeHttpRequest(string body, bool claims = true)
        {
            var httpRequest = new Mock<HttpContext>();
            var identity = new Mock<IIdentity>();

            httpRequest.Setup(c=> c.Request.Body).Returns(new MemoryStream(Encoding.UTF8.GetBytes(body)));
            identity.Setup(c => c.Name).Returns("Test User");

            var user = new Mock<ClaimsPrincipal>();
            if (claims)
            {
                user.Setup(c => c.Identity).Returns(identity.Object);
                user.Setup(c => c.Claims).Returns(new List<Claim> { new Claim("objectidentifier", "test") });
            }

            httpRequest.Setup(c => c.Request.HttpContext).Returns(new DefaultHttpContext());
            httpRequest.Setup(c => c.Request.HttpContext.User).Returns(user.Object);
            httpRequest.Setup(c=> c.User).Returns(user.Object);

            return httpRequest.Object.Request;
        }

        /// <summary>
        /// Helper function to generate a Fake certificate with the supplied expiry
        /// </summary>
        /// <param name="expiry">When the certificate should expire, if null then a null certificate object returned</param>
        private void FakeCertificate(DateTime? expiry)
        {
            if (expiry != null)
            {
                certificateCreatorMock
                    .Setup(c => c.GetCertificateByHash(It.IsAny<RemoteAccessCode>(), It.IsAny<FetchRemoteCovidStatusDto>(), It.IsAny<string>()))
                    .Returns(Task.FromResult(new Certificate("Test User", new DateTime(2000, 01, 01), new DateTime(2000, 01, 01),
                        expiry.Value, CertificateType.Diagnostic, CertificateScenario.International)));
            }
            else
            {
                Certificate cert = null;

                certificateCreatorMock
                    .Setup(c => c.GetCertificateByHash(It.IsAny<RemoteAccessCode>(), It.IsAny<FetchRemoteCovidStatusDto>(), It.IsAny<string>()))
                    .Returns(Task.FromResult(cert));
            }
        }

        /// <summary>
        /// Sets up the fake access code
        /// </summary>
        /// <param name="expiry"> All Datetimes Should be UTC</param>
        private void FakeAccessCode(DateTime expiry)
        {
            var accessCode = new RemoteAccessCode("ABCDEFG", 0,expiry,"lkjjkljllkj", new CovidPassportUser(null, default, null, null));
            remoteAccessServiceMock.Setup(c => c.GetRegRemoteCode(It.IsAny<FetchRemoteCovidStatusDto>(), It.IsAny<GetAuthCodeRequestDto>())).Returns(Task.FromResult(accessCode));
        }

        private void MongoReturnNullThirdParty()
        {
            repoMock.Setup(x => x.FindOneAsync(It.IsAny<Expression<Func<ThirdParty, bool>>>())).ReturnsAsync((ThirdParty)null);
        }

        private void MongoReturnNonNullThirdParty(string thirdPartyId, string thirdPartyName)
        {
            var thirdParty = new ThirdParty(thirdPartyId, thirdPartyName);

            repoMock.Setup(x => x.FindOneAsync(It.IsAny<Expression<Func<ThirdParty, bool>>>())).ReturnsAsync(thirdParty);
        }

        #endregion region
    }
}