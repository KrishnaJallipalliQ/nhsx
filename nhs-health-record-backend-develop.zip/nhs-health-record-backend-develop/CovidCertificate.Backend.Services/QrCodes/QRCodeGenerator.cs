﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Models.DataModels;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services.QrCodes
{
    public class QRCodeGenerator : IQRCodeGenerator
    {
        private readonly ILogger<QRCodeGenerator> logger;
        private readonly IJwtGenerator jwtGenerator;

        public QRCodeGenerator(
            ILogger<QRCodeGenerator> logger, 
            IJwtGenerator jwtGenerator)
        {
            this.logger = logger;
            this.jwtGenerator = jwtGenerator;
        }

        public async Task<string> GenerateQRCodeForCertificate(Certificate certificate)
        {
            logger.LogInformation("GenerateQRCodeForCertificate was invoked");
            var qrToken = await jwtGenerator.Issue(certificate);

            if (qrToken.Token == null)
                throw new NullReferenceException("Token not retrieved");

            logger.LogInformation("GenerateQRCodeForCertificate has finished");

            return qrToken.Token;
        }
    }
}
