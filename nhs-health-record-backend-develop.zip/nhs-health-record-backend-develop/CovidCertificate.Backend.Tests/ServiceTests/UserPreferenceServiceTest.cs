﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.Exceptions;
using CovidCertificate.Backend.Models.ResponseDtos;
using CovidCertificate.Backend.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class UserPreferenceServiceTest
    {
        private UserPreferenceService service;
        private readonly Mock<IMongoRepository<UserPreferenceResponse>> mongoRepositoryMock = new Mock<IMongoRepository<UserPreferenceResponse>>();
        private readonly Mock<ILogger<UserPreferenceService>> loggerMock = new Mock<ILogger<UserPreferenceService>>();
        private readonly Mock<IConfiguration> configurationMock = new Mock<IConfiguration>();

        public UserPreferenceServiceTest()
        {
            service = new UserPreferenceService(mongoRepositoryMock.Object, configurationMock.Object, loggerMock.Object);

        }
        [Fact]
        public async Task testGetPreferenceData_NullID()
        {
            var result = await Assert.ThrowsAsync<ArgumentNullException>(() => service.getPreferences(null));
            Assert.IsType<ArgumentNullException>(result);
            Assert.Equal("User does not have an NHS ID", result.ParamName);
        }

        [Fact]
        public async Task testGetPreferenceData_NoUserData()
        {
            mongoRepositoryMock.Setup(m => m.FindOneAsync(x => x.NHSID == It.IsAny<string>())).ReturnsAsync((Expression<Func<UserPreferenceResponse, bool>> e) => null);

            var result = await Assert.ThrowsAsync<NoResultsException>(() => service.getPreferences("test"));
            Assert.IsType<NoResultsException>(result);
            Assert.Equal("No user preference data found", result.Message);
        }
        [Fact]
        public async Task testGetPreferenceData_AcceptedLatestTerms()
        {
            var testUserPreference = new UserPreferenceResponse("test", DateTime.UtcNow);
            mongoRepositoryMock.Setup(m => m.FindOneAsync(It.IsAny<Expression<Func<UserPreferenceResponse, bool>>>())).ReturnsAsync(testUserPreference);
            Environment.SetEnvironmentVariable("TCDate", "2018-08-18T07:22:16.0000000Z");
            UserPreferenceResponse result = await service.getPreferences("test");
            Assert.True(result.AcceptedLatestTC);
        }
        [Fact]
        public async Task testGetPreferenceData_NotAcceptedLatestTerms()
        {
            var testUserPreference = new UserPreferenceResponse("test", DateTime.Parse("2018-08-18T07:22:16.0000000Z"));
            mongoRepositoryMock.Setup(m => m.FindOneAsync(It.IsAny<Expression<Func<UserPreferenceResponse, bool>>>())).ReturnsAsync(testUserPreference);
            Environment.SetEnvironmentVariable("TCDate", DateTime.UtcNow.ToString());
            UserPreferenceResponse result = await service.getPreferences("test");
            Assert.False(result.AcceptedLatestTC);
        }
        [Fact]
        public async Task updateLanguageCode_IncorrectCodeLength()
        {
            var result = await Assert.ThrowsAsync<ArgumentException>(() => service.updateLanguageCodeAsync("test", "Incorrect"));
            Assert.IsType<ArgumentException>(result);
            Assert.Equal("Incorrect Language Format", result.Message);
        }
        [Fact]
        public async Task updateLanguageCode_IncorrectCode()
        {
            var result = await Assert.ThrowsAsync<ArgumentException>(() => service.updateLanguageCodeAsync("test", "xx"));
            Assert.IsType<ArgumentException>(result);
            Assert.Equal("Not a valid language code", result.Message);
        }
    }
}
