﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.BlobService;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Passbook.Generator;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class AssertedLoginIdentityServiceTests
    {
        private readonly Mock<IConfiguration> configurationMock = new Mock<IConfiguration>();
        private readonly Mock<IBlobService> blobStorageMock = new Mock<IBlobService>();
        private readonly Mock<ILogger<AssertedLoginIdentityService>> loggerMock = new Mock<ILogger<AssertedLoginIdentityService>>();
        private readonly string idToken = "dummytoken";

        [Fact]
        public async Task GenerateAssertedLoginIdentity_withValidPrivateKey_withValidToken_IsSuccessful()
        {
            //Arrange
            var inMemorySettings = new Dictionary<string, string> {
                {"NHSLoginKey", "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDDPafEDelOWBm8\n4efz2ouuP+CNKo3S5SuAK8gD1IupEhJhTK28yfG3k5ke4ZrTcWLa3xc20eMyCb0v\nhIr49RFD1j8FUQSqS7/bS8IrlufkMK781bsDT7iPw6BE9+FY9XgpBS5KK9K0FUFq\nSfwcTAfLxJE+Ryh4MbgbcN6fx1FOg6lrm57/8IL25zL0lLKsJEdUsUUrgeKC0gNq\n0787NKPtFCzpdb/7g//wYTIJnTTz1bJEO9Uh6x6mViLccuzz/446/Uv60gkyD+KU\nmALg2jYkYHly14EEFGrNFozc/MVId/UXJQaY0Wiz0vluoEJjV8E1zacRdUMAUA58\nOOpo64BrAgMBAAECggEATDbSOZ8wluufSHNrJ28FncTDtHeLG2toWsU8c/pRdnNe\nh2r2Wz79w6qzWDG7TZTygPwbRMQUC2Fv34++7EZGMhP9T+b7ijq9ry5YoslqxlIW\nzQ3lzfod0skL1EBrUF2qRWEHW97VhoTRn1s4Nheb53hZNlVyv9CwzM13qimVXK8r\n9z9HzJDMw95HKJfEFyyRS6EavgW3MOgxpW6+GutNVMUEzNuKiHNj/6JdFWHP58LN\nNke+ED7EuiTdevahMs/oYecCpgmm0rZZxj3K561EjYEhjCKb64sELLav1xEFJVx+\nQb6HGRubWuy1IU7OuMiLNHgadGrvZvL3B5166FX2MQKBgQDrpcMHWs6xgqdQsmV5\nGJPJBjXzlm95SbUUSCkaXdMpE6Qz6w4dfaOe1HV1NbZcjKfMHXHfl3acrVBVAbGD\nl0QAkWfKqWcwExS8Suje42Hfrhn8esc8MGdCtPaD++j+i3aM92AMi52UoRaNg0jy\n+O6hfDdGaMaioqsQ69i7r0R7qQKBgQDUGn1kLrKNDU+N0FHSMDjM6rOSg6Axa3j9\nXlzBxHCtbqcp4KGzCvNv/6sgpYWgvYeRn+PIaTb3lOuXKO+zYIEK5cKRzvpOBmcq\nmtKFylWaNZNWs2+4wJgnzocT2+UsWhp6KeiILfonzbCF6pnndfIVwhmYcNTGCC8f\nVzFQ8JSH8wKBgQCxEigQ+L1kSccsLkFt03gJkG8uERbGzwoQqYCpXWN09Fto3/IF\nWwl+Kivw3WGg/diA2odc+lWYuespVVJsjVf+DUUu1kjBqTTloGyIP9il2g+Q1zmr\nErwlNhIfb0XPMEDvAFveUXMh4kIuKD7CxSeblNl8QPMx9oYQ+wgrUDJnsQKBgDmu\nppE7PeWsTAlWMRpHcPsRjRp4X3VxM+s74V/062vPHvj9lRwbC09XKZPsT+YCBT9u\nS0Uyj/dO8a8fO+j9grqS95Itxta3WRE2H7Cw8QzKKzK2A9krz3Vr7kJRWAbyziaR\nBSMb1d9DShFxVr+izN5r9ggGD2d3zFDqpofLlalPAoGASjS2jruVYvHUxvdUI2kp\nK0zybAHAamlMA136Z1PvWbkTuJC18t+o6ZWNgbMbIcqHMhCZDKZgut/wCyhmzM6f\nfVgNjWuxzUWqb44bWlj3/OE/oZj+yptrOFMe5/futoxkq7aV/1z2d9qm3Ul/fX1Z\nXhGcIW0Dsq4P3qALYt7X6CM=\n-----END PRIVATE KEY-----"},
            };

            IConfiguration configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();

            var jwtToken = new JwtSecurityToken("eyJzdWIiOiIxYTczY2NkNy04OWU2LTQ3MGItYWNkYS1hOTFmY2YxZjMyOTciLCJhdWQiOiJoZWFsdGhyZWNvcmRzIiwia2lkIjoiZjYwZWI0NmZmOGFiZjBiZjllOTE3ZWVlNjA4NmM1ZmE0YTE2MmE1ZCIsImlzcyI6Imh0dHBzOi8vYXV0aC5hb3Muc2lnbmluLm5ocy51ayIsInR5cCI6IkpXVCIsImV4cCI6MTYyODE1NzAyMCwiaWF0IjoxNjI4MTUzNDIwLCJhbGciOiJSUzUxMiIsImp0aSI6IjUxYWJiYzgyLTc4NzItNDZmNi04YzMxLTAwNWJjOGM1OTFhMCJ9.eyJzdWIiOiIxYTczY2NkNy04OWU2LTQ3MGItYWNkYS1hOTFmY2YxZjMyOTciLCJiaXJ0aGRhdGUiOiIyMDA0LTAzLTAzIiwibmhzX251bWJlciI6Ijk0NDI4NDkyMDQiLCJpc3MiOiJodHRwczovL2F1dGguYW9zLnNpZ25pbi5uaHMudWsiLCJ2dG0iOiJodHRwczovL2F1dGguYW9zLnNpZ25pbi5uaHMudWsvdHJ1c3RtYXJrL2F1dGguYW9zLnNpZ25pbi5uaHMudWsiLCJhdWQiOiJoZWFsdGhyZWNvcmRzIiwiaWRfc3RhdHVzIjoidmVyaWZpZWQiLCJ0b2tlbl91c2UiOiJpZCIsInN1cm5hbWUiOiJKQUNPQiIsImF1dGhfdGltZSI6MTYyODE1MzQxNywidm90IjoiUDUuQ3AuQ2QiLCJpZGVudGl0eV9wcm9vZmluZ19sZXZlbCI6IlA1IiwiZXhwIjoxNjI4MTU3MDIwLCJpYXQiOjE2MjgxNTM0MjAsImZhbWlseV9uYW1lIjoiSkFDT0IiLCJqdGkiOiI1MWFiYmM4Mi03ODcyLTQ2ZjYtOGMzMS0wMDViYzhjNTkxYTAifQ.WYWwu-sj2Y6sOJleNonFN_sWDeSPyvke7cTTqaowjCieDmgaWoGiqDZmt0o1hxIcDnjVXI60G24iTX7htuZlgWQDwr5pnimUcLbJKkE6t0kg-jMqJVWZHm1OAAyYZX3I6FfDChH5RXaM0g5mHFH_nvw7w391eKJOo1s62m0nucrSjE6xJAOJZvRn5V2KDDPb5-MjKhAmy7TvLPxZDIMtGsoCmzD5jkiCinHPa719NhkIwd6_SAgS1nCi01b0gxYxjHNWO0DNu_u7pXs4xsuCoShu5skV6FC5G_-vc25nSghV0No6CCur2dmj3mrq2HsxhFtt4GNOUfpj4mZ0dy48RA");
            
            //Act
            var assertedLoginIdentityService = new AssertedLoginIdentityService(configuration, loggerMock.Object);
            var result = new JwtSecurityToken(assertedLoginIdentityService.GenerateAssertedLoginIdentity(jwtToken));

            //Assert
            Assert.Equal("healthrecords", result.Claims.First(c => c.Type == "iss").Value);
        }
    }
}
