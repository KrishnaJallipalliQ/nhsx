﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using FluentValidation;
using Xunit;

namespace CovidCertificate.Backend.Tests.ValidatorTests
{
    public class EligibilityConditionValidatorTests
    {

        [Fact]
        public async Task ValidateObjectAndThrowOnFailuresAsync_EligibilityCondition_VaccineIdentifiers_AllNull()
        {
            //Arrange
            EligibilityConfiguration eligibilityConfiguration = new EligibilityConfiguration(new List<EligibilityRules>
            {
                new EligibilityRules("Vaccination-Test-Config", CertificateType.Vaccination, CertificateScenario.Domestic, new List<EligibilityCondition>()
                    {
                        new EligibilityCondition(null, null, null
                            , DataType.Vaccination, 6336, TimeFormat.Hours, 2016, 504, 2
                            , 0, null, Eligibility.Eligible, new List<EligibilityNotFollowedBy>())
                    },
                    4320,
                    TimeFormat.Hours)
            }, new EligibilityDomesticExemptions(48));

            //Act
            Func<Task> actInvalid = async () => await eligibilityConfiguration.ValidateObjectAndThrowOnFailuresAsync();

            //Assert
            var exInvalidDto = await Assert.ThrowsAsync<ValidationException>(actInvalid);
            Assert.Equal("NameOfProduct, SnomedCodes or VaccineCombinations must be specified but not more than one.", exInvalidDto.Message);

        }

        [Fact]
        public async Task ValidateObjectAndThrowOnFailuresAsync_EligibilityCondition_VaccineIdentifiers_AllNotNull()
        {
            //Arrange
            EligibilityConfiguration eligibilityConfiguration = new EligibilityConfiguration(new List<EligibilityRules>
            {
                new EligibilityRules("Vaccination-Test-Config", CertificateType.Vaccination, CertificateScenario.Domestic, new List<EligibilityCondition>()
                    {
                        new EligibilityCondition("Oxford", new List<string>(), new List<List<string>>()
                            , DataType.Vaccination, 6336, TimeFormat.Hours, 2016, 504, 2
                            , 0, null, Eligibility.Eligible, new List<EligibilityNotFollowedBy>())
                    },
                    4320,
                    TimeFormat.Hours)
            }, new EligibilityDomesticExemptions(48));

            //Act
            Func<Task> actInvalid = async () => await eligibilityConfiguration.ValidateObjectAndThrowOnFailuresAsync();

            //Assert
            var exInvalidDto = await Assert.ThrowsAsync<ValidationException>(actInvalid);
            Assert.Equal("NameOfProduct, SnomedCodes or VaccineCombinations must be specified but not more than one.", exInvalidDto.Message);
        }

        [Fact]
        public async Task ValidateObjectAndThrowOnFailuresAsync_EligibilityCondition_VaccineIdentifiers_TwoNotNull()
        {
            //Arrange
            EligibilityConfiguration eligibilityConfiguration = new EligibilityConfiguration(new List<EligibilityRules>
            {
                new EligibilityRules("Vaccination-Test-Config", CertificateType.Vaccination, CertificateScenario.Domestic, new List<EligibilityCondition>()
                    {
                        new EligibilityCondition(null, new List<string>(), new List<List<string>>()
                            , DataType.Vaccination, 6336, TimeFormat.Hours, 2016, 504, 2
                            , 0, null, Eligibility.Eligible, new List<EligibilityNotFollowedBy>())
                    },
                    4320,
                    TimeFormat.Hours)
            }, new EligibilityDomesticExemptions(48));

            //Act
            Func<Task> actInvalid = async () => await eligibilityConfiguration.ValidateObjectAndThrowOnFailuresAsync();

            //Assert
            var exInvalidDto = await Assert.ThrowsAsync<ValidationException>(actInvalid);
            Assert.Equal("NameOfProduct, SnomedCodes or VaccineCombinations must be specified but not more than one.", exInvalidDto.Message);
        }

        [Fact]
        public async Task ValidateObjectAndThrowOnFailuresAsync_EligibilityCondition_VaccineIdentifiers_OneNotNull()
        {
            //Arrange
            EligibilityConfiguration eligibilityConfiguration = new EligibilityConfiguration(new List<EligibilityRules>
            {
                new EligibilityRules("Vaccination-Test-Config", CertificateType.Vaccination, CertificateScenario.Domestic, new List<EligibilityCondition>()
                    {
                        new EligibilityCondition(null, null, new List<List<string>>()
                            , DataType.Vaccination, 6336, TimeFormat.Hours, 2016, 504, 2
                            , 0, null, Eligibility.Eligible, new List<EligibilityNotFollowedBy>())
                    },
                    4320,
                    TimeFormat.Hours)
            }, new EligibilityDomesticExemptions(48));

            //Act
            Func<Task> actValid = async () => await eligibilityConfiguration.ValidateObjectAndThrowOnFailuresAsync();

            //Assert
            var exValidDto = await Record.ExceptionAsync(actValid);
            Assert.Null(exValidDto);
        }
    }
}
