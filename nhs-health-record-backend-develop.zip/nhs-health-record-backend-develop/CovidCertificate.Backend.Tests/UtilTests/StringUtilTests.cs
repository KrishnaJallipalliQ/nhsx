﻿using CovidCertificate.Backend.Utils;
using System;
using System.IO;
using System.Text;
using Xunit;

namespace CovidCertificate.Backend.Tests.UtilTests
{
    public class StringUtilTests
    {
        [Fact]
        public void TestRandomStringLengthExpectSix()
        {
            var randomString = StringUtils.RandomString(6);
            Assert.Equal(6, randomString.Length);        
        }

        /// <summary>
        /// Hash in this test is the same as VR hashing
        /// </summary>
        [Fact]
        public void TestNHSNumberHash()
        {
            var result = StringUtils.GetValueHash("1010101010", new DateTime(2004, 10, 13));

            Assert.Equal("75332C46C89721FF139359256786A2AB5607C925F06AC40CE23EA369D2B8192B", result);
        }

        [Fact]
        public void TestHashExpectValidResult()
        {
            var testInput = "WEDSA_test@test.com";
            var testOutput = StringUtils.GetHashString(testInput);

            Assert.NotNull(testOutput);
            Assert.Equal("4A08E1B495F9305829F9E4CE3ACFC84353FE38567D8C4D10AF248B265FFC90A3", testOutput);
        }
        
        [Fact]
        public void TestStringToStreamExpectSuccess()
        {
            var testInputString = "I'm a test string";
            var fileStream = testInputString.GetStream();
            Assert.True(fileStream.CanRead);
            Assert.True(fileStream.CanWrite);
            Assert.Equal(0, fileStream.Position);

            var memStream = fileStream as MemoryStream;
            var streamArray = memStream.ToArray();
            var output = Encoding.UTF8.GetString(streamArray);

            Assert.Equal(testInputString, output);
        }

        [Theory]
        [InlineData("This string has exactly 60 characters, count it if you must", 30, "This string has exactly 60 cha")]
        [InlineData("This string has exactly 60 characters, count it if you must", 100, "This string has exactly 60 characters, count it if you must")]
        [InlineData("This string has exactly 60 characters, count it if you must", -1, "")]
        [InlineData(null, 100, null)]
        public void StringMaxLengthGivesNoMoreAndNoLessThanMaxAllowed(string input, int maxLength, string expected)
        {
            Assert.Equal(expected, input.MaxLength(maxLength));
        }
    }
}
