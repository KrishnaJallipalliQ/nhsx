using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Delegates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Settings;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Threading.Tasks;
using CovidCertificate.Backend.Services.KeyServices;
using CovidCertificate.Backend.Utils;
using Microsoft.Extensions.Configuration;

namespace CovidCertificate.Backend.Services
{
    public class NhsIdJwtValidator : IJwtValidator
    {
        private const string ValidationEnabledConfiguration = "JwtValidationEnabled";

        private readonly ValidationServiceResolver validationParamResolver;
        private readonly ILogger<NhsIdJwtValidator> logger;
        private readonly IPublicKeyService publicKeyService;
        private readonly IConfiguration configuration;

        public NhsIdJwtValidator(IConfiguration configuration, ValidationServiceResolver serviceResolver,
            ILogger<NhsIdJwtValidator> logger, IPublicKeyService publicKeyService)
        {
            this.validationParamResolver = serviceResolver;
            this.logger = logger;
            this.configuration = configuration;
            this.publicKeyService = publicKeyService;
        }

        /// <summary>
        /// Checks if a validation token is valid based off the current app settings
        /// </summary>
        /// <param name="token">The input JWT</param>
        /// <returns>If the token is valid</returns>
        public async Task<bool> IsValidToken(string token, string authSchema = "CovidCertificate")
        {
            if (configuration[ValidationEnabledConfiguration].FlagEqualsFalse())
            {
                logger.LogWarning("User token validation (id-token) is disabled.");
                
                return true;
            }

            logger.LogInformation("User token validation (id-token) is enabled.");
            var validationService = validationParamResolver(authSchema);
            var validationParameters = await validationService.GetValidationParameters();
            if (validationParameters == null)
            {
                return false;
            }

            var tokenHandler = new JwtSecurityTokenHandler();
            try
            {
                tokenHandler.ValidateToken(token, validationParameters, out var _);
                logger.LogInformation("User token validation (id-token) was successful.");

                return true;
            }
            catch (SecurityTokenInvalidSignatureException)
            {
                logger.LogWarning("User token validation fail, refreshing public key.");

                return await RefreshPublicKeyAndRetryValidation(token, validationParameters, tokenHandler);
            }
            catch (SecurityTokenException e)
            {
                logger.LogWarning(e, "Failed to validate token: " + token);
                //If the validate token throws an exception this means the token isn't valid

                return false;
            }
            catch (Exception e)
            {
                logger.LogCritical(e, e.Message);
                throw;
            }
        }

        private async Task<bool> RefreshPublicKeyAndRetryValidation(string token,
            TokenValidationParameters validationParameters, JwtSecurityTokenHandler tokenHandler)
        {
            try
            {
                var publicJwk = await publicKeyService.RefreshPublicKey();
                validationParameters.IssuerSigningKey = publicJwk;
                tokenHandler.ValidateToken(token, validationParameters, out var _);

                return true;
            }
            catch (SecurityTokenInvalidSignatureException e)
            {
                logger.LogWarning(e, "User token validation failed with fresh key. Token invalid");

                return false;
            }
        }

        public async Task<ClaimsPrincipal> GetClaims(string token, string authSchema = "CovidCertificate")
        {
            throw new NotImplementedException();
        }
    }
}