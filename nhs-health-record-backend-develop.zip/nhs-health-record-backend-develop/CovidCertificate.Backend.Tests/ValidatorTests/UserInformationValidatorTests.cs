﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Validators;
using CovidCertificate.Backend.Tests.TestHelpers;
using FluentValidation;
using Xunit;

namespace CovidCertificate.Backend.Tests.ValidatorTests
{
    public class UserInformationValidatorTests
    {
        private readonly UserInformationValidator uat;
        private const string ValidEmail = "name@domain.it";
        private const string ValidName = "Maria Tester Jorgensen";
        private readonly DateTime validDateOfBirth = DateTime.UtcNow.AddYears(-20);
        private const string ValidPhoneNumber = "+447000123456";

        public UserInformationValidatorTests()
        {
            uat = new UserInformationValidator();
        }

        [Fact]
        public async Task ValidateAndThrowOnAsync_ThrowException_NullName()
        {
            // Arrange
            CovidPassportUser user =
                new CovidPassportUser(null, validDateOfBirth, ValidEmail, ValidPhoneNumber);

            // Act
            Func<Task> act = async () => await uat.ValidateAndThrowAsync(user);

            // Assert
            var ex = await Assert.ThrowsAsync<ValidationException>(act);
            Assert.Equal("A name was not specified.", ex.Message);
        }

        [Fact]
        public async Task ValidateAndThrowOnAsync_ThrowException_EmptyName()
        {
            // Arrange
            CovidPassportUser user =
                new CovidPassportUser(string.Empty, validDateOfBirth, ValidEmail, ValidPhoneNumber);

            // Act
            Func<Task> act = async () => await uat.ValidateAndThrowAsync(user);

            // Assert
            var ex = await Assert.ThrowsAsync<ValidationException>(act);
            Assert.Equal("A name was not specified.", ex.Message);
        }

        [Fact]
        public async Task ValidateAndThrowOnAsync_ThrowException_LongName()
        {
            // Arrange
            var tooShortName = ArrangeTestHelper.CreateRandomString(256);
            CovidPassportUser user =
                new CovidPassportUser(tooShortName, validDateOfBirth, ValidEmail, ValidPhoneNumber);

            // Act
            Func<Task> act = async () => await uat.ValidateAndThrowAsync(user);

            // Assert
            var ex = await Assert.ThrowsAsync<ValidationException>(act);
            Assert.Equal("A name must not exceed the character limit of 255.", ex.Message);
        }

        [Fact]
        public async Task ValidateAndThrowOnAsync_ThrowException_ShortName()
        {
            // Arrange
            var tooShortName = ArrangeTestHelper.CreateRandomString(1);
            CovidPassportUser user =
                new CovidPassportUser(tooShortName, validDateOfBirth, ValidEmail, ValidPhoneNumber);

            // Act
            Func<Task> act = async () => await uat.ValidateAndThrowAsync(user);

            // Assert
            var ex = await Assert.ThrowsAsync<ValidationException>(act);
            Assert.Equal("A name must contain a minimum of 2 characters without a space in between.", ex.Message);
        }

        [Fact]
        public async Task ValidateAndThrowOnAsync_ThrowException_PastDateOfBirth()
        {
            // Arrange
            var tooEarlyDateOfBirth = new DateTime(1900, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddTicks(-1);
            CovidPassportUser user =
                new CovidPassportUser(ValidName, tooEarlyDateOfBirth, ValidEmail, ValidPhoneNumber);

            // Act
            Func<Task> act = async () => await uat.ValidateAndThrowAsync(user);

            // Assert
            var ex = await Assert.ThrowsAsync<ValidationException>(act);
            Assert.Equal("Date of birth cannot be before the year 1900.", ex.Message);
        }

        [Fact]
        public async Task ValidateAndThrowOnAsync_ThrowException_FutureDateOfBirth()
        {
            // Arrange
            var dateOfBirthInFturue = DateTime.UtcNow.AddHours(15);
            CovidPassportUser user =
                new CovidPassportUser(ValidName, dateOfBirthInFturue, ValidEmail, ValidPhoneNumber);

            // Act
            Func<Task> act = async () => await uat.ValidateAndThrowAsync(user);

            // Assert
            var ex = await Assert.ThrowsAsync<ValidationException>(act);
            Assert.Equal("Date of birth cannot be in the future.", ex.Message);
        }
    }
}
