﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.Enums
{
    public enum CertificateScenario
    {
        International,
        Domestic
    }
}
