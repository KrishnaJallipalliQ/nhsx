﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using Hl7.Fhir.Model;
using Hl7.Fhir.Serialization;
using Microsoft.Extensions.Configuration;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using CovidCertificate.Backend.Models.Enums;

namespace CovidCertificate.Backend.Tests.TestHelpers
{
    public static class VaccinationMapperHelper
    {
        private const string json = @"{""39375411000001104"":{
                ""DISEASE"":[""840539006"",""COVID-19""],
                ""MANUFACTURER"":[""ORG-100031184"",""Moderna Biotech Spain S.L""],
	            ""PRODUCT"":[""EU/1/20/1507"",""COVID-19 Vaccine Moderna"",""COVID-19 Vaccine Moderna""],
	            ""VACCINE"":[""1119349007"",""SARS Cov-2 mRNA Vaccine""],
                ""TOTALSERIESOFDOSES"": ""2"" }
                ,""39115711000001107"":{
                ""DISEASE"":[""840539006"",""COVID-19""],
                ""MANUFACTURER"":[""ORG-100030215"",""Biontech Manufacturing GmbH""],
	            ""PRODUCT"":[""EU/1/20/1528"",""Comirnaty"",""Pfizer/BioNTech COVID-19 vaccine""],
	            ""VACCINE"":[""1119349007"",""SARS Cov-2 mRNA Vaccine""],
                ""TOTALSERIESOFDOSES"": ""2"" }
                }";


        static VaccinationMapperHelper()
        {
        }

        public static Mock<IVaccineMapping> CreateMockVaccineMapping()
        {
            var map = JsonConvert.DeserializeObject<Dictionary<string, VaccineMap>>(json);
            Mock<IVaccineMapping> mockMapping = new Mock<IVaccineMapping>();
            mockMapping.Setup(m => m.GetMappings()).ReturnsAsync(map);
            return mockMapping;
        }

        public static IConfiguration CreateMockConfig()
        {
            var inMemorySettings = new Dictionary<string, string>
            {
                { "TotalSeriesOfDoses","2"}
            };
            return new ConfigurationBuilder().AddInMemoryCollection(inMemorySettings).Build();
        }

        public static Immunization CreateImmunization(int days, int doseNumber)
        {
            string currentPath = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.Parent.FullName;
            string loc = Path.Combine(currentPath, "CovidCertificate.Backend.Tests", "TestHelpers", "vaccinemock.json");

            StreamReader r = new StreamReader(loc);
            var vaccinejson = r.ReadToEnd();
            if (!days.Equals(0))
                vaccinejson.Replace("2013-01-10", DateTime.Parse("2013-01-10", CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal).AddDays(days).ToString("yyyy-MM-dd"));
            if (!doseNumber.Equals(0))
            {
                vaccinejson = vaccinejson.Replace(@"""doseNumberPositiveInt"": 2", @"""doseNumberPositiveInt"": " + doseNumber);
                Console.WriteLine(vaccinejson);
            }
            var fjp = new FhirJsonParser();


            return fjp.Parse<Immunization>(vaccinejson);
        }

        public static Certificate SetUpVaccineCertificateModel(CertificateType certificateType, CertificateScenario certificateScenario)
        {
            return new Certificate("", DateTime.UtcNow.AddYears(-20), DateTime.UtcNow.AddDays(180), DateTime.UtcNow.AddDays(300), certificateType, certificateScenario, new List<IGenericResult>() { Setup_Minus25Days_Vaccine(), Setup_Minus1Day_Vaccine() });
        }

        public static Vaccine Setup_Minus25Days_Vaccine()
        {
            var vaccine = new Vaccine();
            vaccine.DoseNumber = 1;
            vaccine.VaccinationDate = DateTime.UtcNow.AddDays(-25);
            vaccine.VaccineManufacturer = Tuple.Create<string, string>("MANUFACTURER", "Oxford");
            vaccine.DiseaseTargeted = Tuple.Create<string, string>("Oxford", "DISEASE");
            vaccine.VaccineType = Tuple.Create<string, string>("Oxford", "TYPE");
            vaccine.Product = Tuple.Create<string, string>("Oxford", "PRODUCT");
            vaccine.VaccineBatchNumber = "BATCH";
            vaccine.CountryOfVaccination = "UK";
            vaccine.Authority = "NHS";
            vaccine.DisplayName = "Oxford";
            return vaccine;
        }

        public static Vaccine Setup_Minus1Day_Vaccine()
        {
            var vaccine = new Vaccine();
            vaccine.DoseNumber = 1;
            vaccine.VaccinationDate = DateTime.UtcNow.AddDays(-1);
            vaccine.VaccineManufacturer = Tuple.Create<string, string>("MANUFACTURER", "Oxford");
            vaccine.DiseaseTargeted = Tuple.Create<string, string>("Oxford", "DISEASE");
            vaccine.VaccineType = Tuple.Create<string, string>("Oxford", "TYPE");
            vaccine.Product = Tuple.Create<string, string>("Oxford", "PRODUCT");
            vaccine.VaccineBatchNumber = "BATCH";
            vaccine.CountryOfVaccination = "UK";
            vaccine.Authority = "NHS";
            vaccine.DisplayName = "Oxford";
            return vaccine;
        }
    }
}
