﻿using System;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Interfaces;

namespace CovidCertificate.Backend.Models.ResponseDtos
{
    public class TestResultResponse
    {
        public TestResultResponse(TestResult dto, IGetTimeZones timeZones)
            => new TestResultResponse(dto.DateTimeOfTest, dto.Result, dto.ValidityType, timeZones);

        public TestResultResponse(TestResultNhs result, IGetTimeZones timeZones)
            => new TestResultResponse(result.DateTimeOfTest, result.Result, result.ValidityType, timeZones);

        public TestResultResponse(DateTime dateTimeOfTest, string result, string testType, IGetTimeZones timeZones)
        {
            var timeZoneInfo = timeZones.GetTimeZoneInfo();
            this.DateTimeOfTest = TimeZoneInfo.ConvertTime(dateTimeOfTest, timeZoneInfo);
            this.Result = result;
            this.TestType = testType;
        }

        public DateTime DateTimeOfTest { get; }
        public string Result { get; }
        public string TestType { get; }
    }
}
