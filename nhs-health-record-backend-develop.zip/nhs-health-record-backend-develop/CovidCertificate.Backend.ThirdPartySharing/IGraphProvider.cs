﻿using System;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.ThirdPartySharing
{
    public interface IGraphProvider
    {
         
         Task<string> GetDisplayNameByApplicationId(string applicationId);
    }
}
