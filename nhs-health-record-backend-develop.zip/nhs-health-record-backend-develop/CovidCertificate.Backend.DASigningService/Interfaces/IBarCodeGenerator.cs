﻿using System.Threading.Tasks;
using CovidCertificate.Backend.DASigningService.Models;
using CovidCertificate.Backend.DASigningService.Responses;
using Hl7.Fhir.Model;

namespace CovidCertificate.Backend.DASigningService.Interfaces
{
    public interface IBarcodeGenerator
    {
        Task<BarcodeResults> BarcodesFromFhirBundle(Bundle bundle, RegionConfig regionConfig);        
    }
}
