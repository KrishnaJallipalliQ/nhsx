using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using System.Linq;
using System.Net.Http;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Utils;
using Microsoft.IdentityModel.Tokens;

namespace CovidCertificate.Backend.Services.KeyServices
{
    public class PublicKeyService : IPublicKeyService
    {
        private readonly ILogger<PublicKeyService> logger;
        private readonly IHttpClientFactory httpClientFactory;
        private JsonWebKey publicJWK;
        private string jwksUrl;
        private static readonly AsyncLock mutex = new AsyncLock();

        public PublicKeyService(ILogger<PublicKeyService> logger, IHttpClientFactory httpClientFactory,
            NhsLoginSettings nhsLoginSettings)
        {
            this.logger = logger;
            this.httpClientFactory = httpClientFactory;
            jwksUrl = nhsLoginSettings.PublicKeyUrl;
        }

        public async Task<JsonWebKey> GetPublicKey()
        {
            if (publicJWK == default)
            {
                using (await mutex.LockAsync())
                {
                    if (publicJWK == default)
                    {
                        publicJWK = await GetJwkPublicKeyFromNhs();
                    }
                }
            }

            return publicJWK;
        }

        public async Task<JsonWebKey> RefreshPublicKey()
        {
            using (await mutex.LockAsync())
            {
                publicJWK = await GetJwkPublicKeyFromNhs();
            }

            return publicJWK;
        }

        private async Task<JsonWebKey> GetJwkPublicKeyFromNhs()
        {
            logger.LogInformation($"Sending request to {jwksUrl} to get public key for id-token validation");
            var response = await httpClientFactory.CreateClient().GetAsync(jwksUrl);
            var responseString = await response.Content.ReadAsStringAsync();

            var jwks = new JsonWebKeySet(responseString);

            return jwks.Keys.First();
        }
    }
}