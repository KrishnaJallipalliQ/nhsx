﻿using CovidCertificate.Backend.DASigningService.ErrorHandling;
using CovidCertificate.Backend.DASigningService.Interfaces;
using CovidCertificate.Backend.DASigningService.Requests;
using CovidCertificate.Backend.DASigningService.Services;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.DASigningService.Tests.ServiceTests
{
    public class LogServiceTests
    {
        private readonly Mock<ILogger<RegionConfigService>> logger = new Mock<ILogger<RegionConfigService>>();
        private readonly Mock<IMongoRepository<Region2DBarcodeResult>> mongoRepository = new Mock<IMongoRepository<Region2DBarcodeResult>>();
        private IConfiguration configuration;
        private ILogService logService;
        private IConfigurationBuilder builder;
        private readonly string uvci;
        private readonly string apiName;
        private string regionMappings;
        private IRegionConfigService regionConfigService;
        public LogServiceTests()
        {
            uvci = "testUvci#1";
            apiName = "Create2DVaccinationBarcode";
            regionMappings = @"{
                        ""RegionMappings"": [
                {
                            ""RegionCode"": ""Gibraltar"",
                    ""Issuer"": ""Gibraltar"",
                    ""MemberState"": ""GI"",
                    ""CountryCode"": ""GI""
                },
                {
                            ""RegionCode"": ""Jersey"",
                    ""Issuer"": ""Health and Community Services"",
                    ""MemberState"": ""JE"",
                    ""CountryCode"": ""GB""
                },
                {
                            ""RegionCode"": ""Guernsey"",
                    ""Issuer"": ""Guernsey"",
                    ""MemberState"": ""GG"",
                    ""CountryCode"": ""GG""
                }
                                            ],
                }";
            builder = new ConfigurationBuilder();
            builder.AddJsonStream(new MemoryStream(Encoding.UTF8.GetBytes(regionMappings)));
            configuration = builder.Build();
            regionConfigService = new RegionConfigService(configuration, logger.Object);
            logService = new LogService(mongoRepository.Object);
        }

        [Fact]
        public async Task LogResult_WithValidInputsAndHttpOkStatus_LoggerInformationCalledOnce()
        {
            //Assign
            var errorHandler = new ErrorHandler();
            var regionSubscriptionNameHeader = "Region-Jersey-1";
            var regionConfig =
                regionConfigService.GetRegionConfig(regionSubscriptionNameHeader, errorHandler);
            Region2DBarcodeResult document = null;
            mongoRepository.Setup(r => r.InsertOneAsync(It.IsAny<Region2DBarcodeResult>())).Callback<Region2DBarcodeResult>((obj) => document = obj);

            //Act
            await logService.LogResult(logger.Object, uvci, apiName, HttpStatusCode.OK, regionConfig);

            //Assert
            logger.Verify(x => x.Log(
                            LogLevel.Information,
                            It.IsAny<EventId>(),
                            It.Is<It.IsAnyType>((v, t) => true),
                            It.IsAny<Exception>(),
                            It.IsAny<Func<It.IsAnyType, Exception, string>>()), Times.Once);
        }

        [Fact]
        public async Task LogResult_WithValidInputsAndHttpBadRequestStatus_LoggerWarningCalledOnce()
        {
            //Assign
            var errorHandler = new ErrorHandler();
            var regionSubscriptionNameHeader = "Region-Jersey-1";

            var regionConfig =
                regionConfigService.GetRegionConfig(regionSubscriptionNameHeader, errorHandler);
            Region2DBarcodeResult document = null;
            mongoRepository.Setup(r => r.InsertOneAsync(It.IsAny<Region2DBarcodeResult>())).Callback<Region2DBarcodeResult>((obj) => document = obj);

            //Act
            await logService.LogResult(logger.Object, uvci, apiName, HttpStatusCode.BadRequest, regionConfig);

            //Assert
            logger.Verify(x => x.Log(
                            LogLevel.Warning,
                            It.IsAny<EventId>(),
                            It.Is<It.IsAnyType>((v, t) => true),
                            It.IsAny<Exception>(),
                            It.IsAny<Func<It.IsAnyType, Exception, string>>()), Times.Once);
        }

        [Fact]
        public async Task LogResult_WithValidInputsAndHttpNoContentStatus_LoggerErrorCalledOnce()
        {
            //Assign
            var errorHandler = new ErrorHandler();
            var regionSubscriptionNameHeader = "Region-Jersey-1";

            var regionConfig =
                regionConfigService.GetRegionConfig(regionSubscriptionNameHeader, errorHandler);
            Region2DBarcodeResult document = null;
            mongoRepository.Setup(r => r.InsertOneAsync(It.IsAny<Region2DBarcodeResult>())).Callback<Region2DBarcodeResult>((obj) => document = obj);

            //Act
            await logService.LogResult(logger.Object, uvci, apiName, HttpStatusCode.NoContent, regionConfig);

            //Assert
            logger.Verify(x => x.Log(
                            LogLevel.Error,
                            It.IsAny<EventId>(),
                            It.Is<It.IsAnyType>((v, t) => true),
                            It.IsAny<Exception>(),
                            It.IsAny<Func<It.IsAnyType, Exception, string>>()), Times.Once);
        }
    }
}
