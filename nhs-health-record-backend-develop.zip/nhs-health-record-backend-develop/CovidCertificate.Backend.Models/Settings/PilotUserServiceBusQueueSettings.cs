﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace CovidCertificate.Backend.Models.Settings
{
    public class PilotUserServiceBusQueueSettings
    {
        [Required(AllowEmptyStrings = false)]
        public string QueueName { get; set; }
    }
}
