﻿using CovidCertificate.Backend.NhsApiIntegration.Responses;
using System.IdentityModel.Tokens.Jwt;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.NhsApiIntegration.Interfaces
{
    public interface INhsTestResultsHistoryApiAccessTokenService
    {
        Task<string> GetAccessTokenAsync(string identityToken);

        Task<TokenResponse> RefreshAccessTokenInRedisAsync();

        Task<TokenResponse> GetUserRestrictedTokenAsync(string identityToken);
    }
}
