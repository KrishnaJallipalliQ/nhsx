﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Tests.TestHelpers
{
    /// <summary>
    /// A static class containing essential methods for arranging data used for unit tests.
    /// </summary>
    public static class ArrangeTestHelper
    {
        private static readonly Random random;

        static ArrangeTestHelper() => random = new Random();


        /// <summary>
        /// Loops through each object and parses its properties and corresponding values into a KeyValuePair&lt;string, object&gt;
        /// </summary>
        /// <param name="objects"></param>
        /// <returns>An <see cref="IEnumerable{T}"/> of type <see cref="KeyValuePair{string, object}"/> representing the parsed objects.</returns>
        public static IEnumerable<KeyValuePair<string, object>> ObjectsToKeyValuePair<T>(IEnumerable<T> objects)
        {
            foreach (var obj in objects)
                foreach (var property in obj.GetType().GetProperties())
                    yield return new KeyValuePair<string, object>(property.Name, property.GetValue(obj));
        }

        /// <summary>
        /// Creates a random <see cref="DateTime"/> between two specefied DateTimes.
        /// </summary>
        /// <param name="startDate">The <see cref="DateTime"/> of the earliest <see cref="DateTime"/> that can be created.</param>
        /// <param name="endDate">The <see cref="DateTime"/> of the latest <see cref="DateTime"/> that can be created.</param>
        /// <returns>A random <see cref="DateTime"/> in a granularity of <see cref="TimeSpan.Days"/>.</returns> 
        /// Note: If a higher percentage of uniqueness is required the granularity can be lowered in the <see cref="TimeSpan"/>'s constructor call.
        public static DateTime CreateRandomDateTimeBetweenDates(DateTime startDate, DateTime endDate)
        {
            var timeSpanToGenerateBetween = endDate - startDate;
            var newRandomTimeSpan = new TimeSpan(random.Next(0, (int)timeSpanToGenerateBetween.TotalDays), 0, 0, 0);
            return startDate + newRandomTimeSpan;
        }

        /// <summary>
        /// Creates a concatenated random <see cref="string"/> of the desired length using the randomness of the <see cref="Guid"/> generation algorithm.
        /// </summary>
        /// <param name="stringLength">Length of <see cref="string"/> to return.</param>
        /// <returns>A random <see cref="string"/> of <paramref name="stringLength"/> characters.</returns>
        public static string CreateRandomString(int stringLength)
        {
            if (stringLength < 0)
                throw new ArgumentOutOfRangeException($"The {nameof(stringLength)}:{stringLength} cannot be smaller than zero.");

            var sb = new StringBuilder();
            int numberOfGuidsToConcat = ((stringLength - 1) / 32) + 1; // Subtracting 1 before division and adding after, ensures the StringBuilder length will be >= 'stringLength'
            for (int i = 1; i <= numberOfGuidsToConcat; i++)
                sb.Append(Guid.NewGuid().ToString("N")); // Using 'N' to specify we want 32 digits strings with no separations

            return sb.ToString(0, stringLength);
        }

        /// <summary>
        /// Creates a concatenated random number <see cref="string"/> of the desired length using the randomness of the <see cref="Random"/> generation algorithm.
        /// </summary>
        /// <param name="numberLength">Length of <see cref="string"/> to return.</param>
        /// <returns>A random <see cref="string"/> of <paramref name="numberLength"/> number characters.</returns>
        public static string CreateRandomNumberString(int numberLength)
        {
            if (numberLength < 0)
                throw new ArgumentOutOfRangeException($"The {nameof(numberLength)}:{numberLength} cannot be smaller than zero.");

            var sb = new StringBuilder(); 
            for (int i = 0; i < numberLength; i++)
                sb.Append(random.Next(0, 9));

            return sb.ToString();
        }

        /// <summary>
        /// Creates a concatenated random email <see cref="string"/> of the desired length using the randomness of the <see cref="CreateRandomString"/> generation algorithm.
        /// </summary>
        /// <param name="usernameLength"></param>
        /// <param name="domainNameLength"></param>
        /// <param name="domainLength"></param>
        /// <returns>A random <see cref="string"/> of <paramref name="usernameLength"/>, <paramref name="domainNameLength"/> and <paramref name="domainLength"/> characters.</returns>
        public static string CreateRandomEmailString(int usernameLength, int domainNameLength, int domainLength)
        {
            if (usernameLength < 0 || domainNameLength < 0 || domainLength < 0)
                throw new ArgumentOutOfRangeException($"A email part cannot be smaller than zero. The provided args: " +
                    $"{nameof(usernameLength)}:{usernameLength}, {nameof(domainNameLength)}:{domainNameLength}, {nameof(domainLength)}:{domainLength}.");

            var sb = new StringBuilder();
            sb.Append(CreateRandomString(usernameLength));
            sb.Append("@");
            sb.Append(CreateRandomString(domainNameLength));
            sb.Append(".");
            sb.Append(CreateRandomString(domainLength));

            return sb.ToString();
        }
    }
}
