﻿using CovidCertificate.Backend.Interfaces.BlobService;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Services.Mappers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class VaccineMappingCacheTest
    {
        private readonly VaccineMappingCache vaccineMappingCache;
        private readonly Mock<ILogger<VaccineMappingCache>> mockLogger;
        private readonly Mock<IConfiguration> mockConfiguration;
        private readonly Mock<IBlobService> mockBlobService;

        public VaccineMappingCacheTest()
        {
            mockLogger = new Mock<ILogger<VaccineMappingCache>>();
            mockBlobService = new Mock<IBlobService>();
            mockBlobService
                .Setup(x => x.GetObjectFromBlob<Dictionary<string, VaccineMap>>(
                    "vaccine-results-configuration", "vaccine-results-mapping.json"))
                .ReturnsAsync(() => new Dictionary<string, VaccineMap>());

            mockConfiguration = new Mock<IConfiguration>();
            mockConfiguration.SetupGet(m => m["VaccineMapperCacheTime"]).Returns("1");

            vaccineMappingCache = new VaccineMappingCache(mockConfiguration.Object, mockLogger.Object, mockBlobService.Object);
        }

        [Fact]
        public async Task GetMappings_MappingsCacheValid_ReturnCachedMappings()
        {
            //Arrange
            var mappings = await vaccineMappingCache.GetMappings();

            //Act
            var cachedMappings = await vaccineMappingCache.GetMappings();

            //Assert
            mockBlobService.Verify(blobService => blobService.GetObjectFromBlob<Dictionary<string, VaccineMap>>(
                It.IsAny<string>(), It.IsAny<string>()), Times.Once());

            Assert.Same(mappings, cachedMappings);
        }

        [Fact]
        public async Task GetMappings_OldMappingsCache_GetMappingsFromBlobStorage()
        {
            //Arrange
            mockConfiguration.SetupGet(m => m["VaccineMapperCacheTime"]).Returns("-1");
            var mappings = await vaccineMappingCache.GetMappings();

            //Act
            var mappingsAfterCacheExpired = await vaccineMappingCache.GetMappings();

            //Assert
            mockBlobService.Verify(blobService => blobService.GetObjectFromBlob<Dictionary<string, VaccineMap>>(
                It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(2));

            Assert.NotSame(mappings, mappingsAfterCacheExpired);
        }


        [Fact]
        public async Task GetMappings_NoMappingsInCache_GetMappingsFromBlobStorage()
        {
            //Act
            var result = await vaccineMappingCache.GetMappings();

            //Assert
            mockBlobService.Verify(blobService => blobService.GetObjectFromBlob<Dictionary<string, VaccineMap>>(
                It.IsAny<string>(), It.IsAny<string>()));

            Assert.NotNull(result);
            Assert.IsType<Dictionary<string, VaccineMap>>(result);
        }

        [Fact]
        public async Task GetMappings_InvalidVaccineMapperCacheTime_ReturnCachedMappings()
        {
            //Arrange
            mockConfiguration.SetupGet(m => m["VaccineMapperCacheTime"]).Returns("Test");

            //Act
            var mappings = await vaccineMappingCache.GetMappings();

            var cachedMappings = await vaccineMappingCache.GetMappings();

            //Assert
            mockBlobService.Verify(blobService => blobService.GetObjectFromBlob<Dictionary<string, VaccineMap>>(
                It.IsAny<string>(), It.IsAny<string>()), Times.Once());

            Assert.NotNull(mappings);
            Assert.Same(mappings, cachedMappings);
        }

        [Fact]
        public async Task GetMappings_ExceptionThrown_ReturnEmptyMappings()
        {
            //Arrange
            mockBlobService
                .Setup(x => x.GetObjectFromBlob<Dictionary<string, VaccineMap>>(
                    "vaccine-results-configuration", "vaccine-results-mapping.json"))
                .Throws(new Exception());

            //Act
            var mappings = await vaccineMappingCache.GetMappings();

            //Assert
            Assert.NotNull(mappings);
        }
    }
}
