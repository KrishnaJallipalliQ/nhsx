﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.ResponseDtos;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Utils;
using CovidCertificate.Backend.Utils.Extensions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services.DomesticExemptions
{
    public class DomesticExemptionCache : IDomesticExemptionCache
    {
        private readonly IServiceScopeFactory serviceScopeFactory;
        private readonly ILogger<DomesticExemptionCache> logger;
        private readonly IRedisCacheService redisCacheService;
        private readonly IConfiguration configuration;
        private readonly DomesticExemptionSettings settings;

        private static readonly AsyncLock mutex = new AsyncLock();
        private Dictionary<string, DomesticExemption> exemptions = null;
        private DateTime inMemoryCacheExpiry = DateTime.MinValue;
        private int inMemoryCacheTimeToLiveInSeconds = -1;
        private const string cacheKeyExemptions = "DomesticExemptions:AllExemptions";

        private bool exemptionsAvailableFromMemory => DateTime.UtcNow < inMemoryCacheExpiry && exemptions != null;

        public DomesticExemptionCache(ILogger<DomesticExemptionCache> logger, IServiceScopeFactory serviceScopeFactory, IRedisCacheService redisCacheService, IConfiguration configuration, DomesticExemptionSettings settings)
        {
            this.logger = logger;
            this.serviceScopeFactory = serviceScopeFactory;
            this.redisCacheService = redisCacheService;
            this.configuration = configuration;
            this.settings = settings;
        }

        public async Task<IDictionary<string, DomesticExemption>> GetDomesticExemptions()
        {
            logger.LogInformation("GetDomesticExemptions was invoked");
            if (exemptionsAvailableFromMemory)
            {
                logger.LogTraceAndDebug("Found exemption in memory");
                logger.LogInformation("GetDomesticExemptions has finished");
                return exemptions;
            }

            using (await mutex.LockAsync())
            {
                if (exemptionsAvailableFromMemory)
                {
                    logger.LogTraceAndDebug("Found exemption in memory");
                    logger.LogInformation("GetDomesticExemptions has finished");
                    return exemptions;
                }

                (var exemptionsFromCache, bool exemptionsExistInCache) = await redisCacheService.GetKeyValueAsync<IEnumerable<DomesticExemption>>(cacheKeyExemptions);

                if (exemptionsExistInCache)
                {
                    UpdateInMemoryCache(exemptionsFromCache);

                    logger.LogTraceAndDebug("Found exemption in cache");
                    logger.LogInformation("GetDomesticExemptions has finished");
                    return exemptions;
                }

                var exemptionsFromDb = await GetDomesticExemptionsFromDb();
                UpdateInMemoryCache(exemptionsFromDb);
                await UpdateRedisCacheAsync(exemptionsFromDb);
                
                logger.LogTraceAndDebug("Found exemption in database");
                logger.LogInformation("GetDomesticExemptions has finished");
                return exemptionsFromDb.ToDictionary(x => x.NhsDobHash);
            }
        }

        private void UpdateInMemoryCache(IEnumerable<DomesticExemption> exemptions)
        {
            logger.LogInformation("UpdateInMemoryCache was invoked");
            this.exemptions = exemptions.ToDictionary(x => x.NhsDobHash);
            inMemoryCacheTimeToLiveInSeconds = settings.InMemoryTimeToLiveSeconds;
            inMemoryCacheExpiry = DateTime.UtcNow.AddSeconds(inMemoryCacheTimeToLiveInSeconds);
            logger.LogInformation("UpdateInMemoryCache has finished");
        }

        private async Task UpdateRedisCacheAsync(IEnumerable<DomesticExemption> exemptions)
        {
            logger.LogInformation("UpdateRedisCacheAsync was invoked");
            await redisCacheService.AddKeyAsync(cacheKeyExemptions, exemptions, RedisLifeSpanLevel.Long);
            logger.LogInformation("UpdateRedisCacheAsync has finished");
        }

        private async Task<IEnumerable<DomesticExemption>> GetDomesticExemptionsFromDb()
        {
            logger.LogInformation("GetDomesticExemptionsFromDb was invoked");

            using (var scope = serviceScopeFactory.CreateScope())
            {
                var mongoRepository = scope.ServiceProvider.GetService<IMongoRepository<DomesticExemption>>();
                var domesticExemptions = await mongoRepository.FindAllAsync(x => true);   
                
                var sortedDomesticExemptions = domesticExemptions
                    .Where(x => x.NhsDobHash != null)
                    .Where(x => x.Reason != null)
                    .GroupBy(x => x.NhsDobHash)
                    .Select(x => x.First());

                logger.LogInformation("GetDomesticExemptionsFromDb has finished");
                return sortedDomesticExemptions;
            }
        }
    }
}
