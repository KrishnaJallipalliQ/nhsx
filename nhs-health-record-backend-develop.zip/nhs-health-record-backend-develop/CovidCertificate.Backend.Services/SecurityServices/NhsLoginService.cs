﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Services.KeyServices;
using CovidCertificate.Backend.Utils;
using CovidCertificate.Backend.Utils.Extensions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Polly;
using SendGrid.Helpers.Errors.Model;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services.SecurityServices
{
    public class NhsLoginService : INhsLoginService
    {
        private readonly int _retryCount;
        private readonly int _retryDelay; 
        private static readonly HttpClient _httpClient = new HttpClient();
        private static readonly string _authorizationCodeGrantType;
        private static readonly string _refreshTokenGrantType;
        private readonly NhsKeyRing _nhsKeyRing;
        private readonly NhsLoginSettings _nhsLoginSettings;
        private readonly ILogger<NhsLoginService> _logger;
        private readonly IRedisCacheService _redisCacheService;
        private readonly IConfiguration _configuration;

        static NhsLoginService()
        {
            _httpClient.DefaultRequestHeaders.Add("cache-control", "no-cache");
            _authorizationCodeGrantType = "authorization_code";
            _refreshTokenGrantType = "refresh_token";
        }

        public NhsLoginService(NhsKeyRing keyRing, NhsLoginSettings nhsLoginSettings, ILogger<NhsLoginService> logger, IRedisCacheService redisCacheService, IConfiguration configuration)
        {
            _nhsKeyRing = keyRing;
            _nhsLoginSettings = nhsLoginSettings;
            _logger = logger;
            _redisCacheService = redisCacheService;
            _configuration = configuration;
            _retryCount = _configuration.GetValue<int>("NhsLoginRetryCount");
            _retryDelay = _configuration.GetValue<int>("NhsLoginRetryDelaySeconds");
        }

        public async Task<NhsLoginToken> GetAccessTokenAsync(string refreshToken)
        {
            _logger.LogInformation("(async)GetAccesTokenAync was invoked");

            if (string.IsNullOrWhiteSpace(refreshToken))
                throw new ArgumentNullException("The refresh token was empty.");

            var nhsLoginToken = await SendRequestAndReturnNhsLoginToken(refreshToken);

            _logger.LogInformation("(async)GetAccesTokenAync has finished ");

            return nhsLoginToken;
        }

        public async Task<NhsLoginToken> GetAccessTokenAsync(string authorisationCode, string redirectUri)
        {
            _logger.LogInformation("GetAccessTokenAsync was invoked");

            if (string.IsNullOrWhiteSpace(authorisationCode))
                throw new ArgumentNullException("The authorisation code was empty.");
            if (string.IsNullOrWhiteSpace(redirectUri))
                throw new ArgumentNullException("The redirect uri was empty.");

            var nhsLoginToken = await SendRequestAndReturnNhsLoginToken(authorisationCode, redirectUri);

            _logger.LogInformation("GetAccessTokenAsync has finished");

            return nhsLoginToken;
        }

        public async Task<NhsUserInfo> GetUserInfo(string accessToken)
        {
            _logger.LogTraceAndDebug("GetUserInfo was invoked");
            if (string.IsNullOrWhiteSpace(accessToken))
            {
                throw new ArgumentNullException(accessToken, "The access token was empty.");
            }

            var accessTokenHash = accessToken.GetHashString();
            string key = $"GetUserInfo:{accessTokenHash}";

            (var cachedResponse, bool exists) = await _redisCacheService.GetKeyValueAsync<string>(key);

            if (!exists)
            {
                _logger.LogTraceAndDebug($"Calling Userinfo Api ");
                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                var response = await _httpClient.GetAsync(_nhsLoginSettings.UserInfoEndpoint);
                if (!response.IsSuccessStatusCode)
                {
                    await NhsLoginUserInfoResponseErrorHandler(response);
                }
                var content = await response.Content.ReadAsStringAsync();
                await _redisCacheService.AddKeyAsync(key, content, RedisLifeSpanLevel.Short);

                return JsonConvert.DeserializeObject<NhsUserInfo>(content);
            }
            return JsonConvert.DeserializeObject<NhsUserInfo>(cachedResponse);
        }



        private HttpRequestMessage CreateRefreshTokenRequest(string refreshToken)
        {
            _logger.LogTraceAndDebug("CreateRefreshTokenRequest was invoked");

            var dict = SetupCommonRequestParameters();
            dict.Add("grant_type", _refreshTokenGrantType);
            dict.Add("refresh_token", refreshToken);

            _logger.LogTraceAndDebug("CreateRefreshTokenRequest has finished");

            return new HttpRequestMessage(HttpMethod.Post, _nhsLoginSettings.TokenUri) { Content = new FormUrlEncodedContent(dict) };
        }

        private HttpRequestMessage CreateAuthorisationRequest(string authorisationCode, string redirectUri)
        {
            _logger.LogInformation("CreateAuthorisationRequest was invoked");

            var dict = SetupCommonRequestParameters();
            dict.Add("grant_type", _authorizationCodeGrantType);
            dict.Add("redirect_uri", redirectUri);
            dict.Add("code", authorisationCode);

            _logger.LogInformation("CreateAuthorisationRequest has finished");

            return new HttpRequestMessage(HttpMethod.Post, _nhsLoginSettings.TokenUri) { Content = new FormUrlEncodedContent(dict) };
        }

        private Dictionary<string, string> SetupCommonRequestParameters()
        {
            _logger.LogInformation("SetupCommonRequestParameters was invoked");

            var payload = new Dictionary<string, object>()
            {
                {"sub", _nhsLoginSettings.ClientId},
                {"aud", _nhsLoginSettings.TokenUri},
                {"iss", _nhsLoginSettings.ClientId},
                {"exp", DateTimeOffset.UtcNow.AddHours(_nhsLoginSettings.TokenLifeTime).ToUnixTimeSeconds()},
                {"jti", Guid.NewGuid()}
            };

            _logger.LogInformation("SetupCommonRequestParameters has finished");

            return new Dictionary<string, string>()
            {
                {"client_id", _nhsLoginSettings.ClientId},
                {"client_assertion_type", _nhsLoginSettings.ClientAssertionType},
                {"client_assertion", _nhsKeyRing.SignData(payload)}
            };
        }

        private async Task<NhsLoginToken> SendRequestAndReturnNhsLoginToken(string code, string redirectUri = "")
        {
            _logger.LogInformation("SendRequestAndReturnNhsLoginToken was invoked");

            var retryPolicy = Policy.Handle<Exception>()
                .WaitAndRetryAsync(_retryCount, iretryAttempt => TimeSpan.FromSeconds(Math.Pow(_retryDelay, iretryAttempt)));

            var response = new HttpResponseMessage();

            await retryPolicy.ExecuteAsync(async () =>
            {
                var request = new HttpRequestMessage();
                if (String.IsNullOrEmpty(redirectUri)) {
                    request = CreateRefreshTokenRequest(code);
                } else
                {
                    request = CreateAuthorisationRequest(code, redirectUri);
                }
                response = await _httpClient.SendAsync(request);
                _logger.LogInformation($"Authorization code starting with {code.MaxLength(8)} gave response code {((int)response.StatusCode)}");
                if (!response.IsSuccessStatusCode)
                {
                    await NhsLoginTokenResponseErrorHandler(response);
                }
            });

            _logger.LogInformation("SendRequestAndReturnNhsLoginToken has finished");

            return await GetNhsLoginTokenFromResponse(response);
        }

        private async Task<NhsLoginToken> GetNhsLoginTokenFromResponse(HttpResponseMessage response)
        {
            _logger.LogInformation("GetNhsLoginTokenFromResponse was invoked");

            var responseString = await response.Content.ReadAsStringAsync();
            _logger.LogTraceAndDebug($"responseString is {responseString}");

            return JsonConvert.DeserializeObject<NhsLoginToken>(responseString) ??
                throw new FormatException($"No properties was populated or the JSON constructor was inaccessible. Response content: {responseString}");
        }

        // The error scenarios is based on the documentation of NHS Login /Token error responses - "Interface Specification - Federation" found on NHS Login's GitHub:
        // https://github.com/nhsconnect/nhslogin
        private async Task NhsLoginTokenResponseErrorHandler(HttpResponseMessage response)
        {
            var responseStr = await response.Content.ReadAsStringAsync();
            NhsErrorResponse error;
            try
            {
                error = JsonConvert.DeserializeObject<NhsErrorResponse>(responseStr) ??
                    throw new FormatException($"No properties was populated or the JSON constructor was inaccessible. Response content: {responseStr}");
            }
            catch (Exception e)
            {
                // We throw a new exception here, to isolate issues casued by the response not matching the rules of the Authorization Framework OAuth 2.0 [RFC6749] documentation. (This is known to happen in some cases for invalid_client and unsupported_grant_type) 
                throw new UnauthorizedException($"Unauthorized request to NHS Login /Token. StatusCode: {response.StatusCode}. Response Value: {responseStr}.", e);
            }

            switch ((response.StatusCode, error.ErrorType))
            {
                case (HttpStatusCode.BadRequest, "invalid_request"):
                    throw new BadRequestException("The request is missing a required parameter, includes an unsupported parameter value (other than grant type), repeats a parameter, includes multiple credentials, utilizes more than one mechanism for authenticating the client, or is otherwise malformed.");
                case (HttpStatusCode.BadRequest, "invalid_client"):
                    throw new HttpRequestException("Client authentication failed (e.g., unknown client, no client authentication included, or unsupported authentication method).");
                case (HttpStatusCode.BadRequest, "invalid_grant"):
                    throw new UnauthorizedException("The provided authorization grant (e.g., authorization code, resource owner credentials) or refresh token is invalid, expired, revoked, does not match the redirection URI used in the authorization request, or was issued to another client.");
                case (HttpStatusCode.BadRequest, "unauthorized_client"):
                    throw new HttpRequestException("The authenticated client is not authorized to use this authorization grant type.");
                case (HttpStatusCode.BadRequest, "unsupported_grant_type"):
                    throw new HttpRequestException("The authorization grant type is not supported by the Platform.");
                case (HttpStatusCode.BadRequest, "invalid_scope"):
                    throw new BadRequestException("The requested scope is invalid, unknown, malformed, or exceeds the scope granted by the resource owner");
                default:
                    if (response.StatusCode is HttpStatusCode.InternalServerError)
                        throw new Exception($"An InternalServerError occurred on the side of NHS login: {error.ErrorType}.");
                    else
                        throw new Exception($"An unexpected error occurred for the NHS login request with StatusCode: {response.StatusCode} and error: {error.ErrorType}.");
            }
        }


        // The error scenarios is based on the documentation of NHS Login /UserInfo error responses - "Interface Specification - Federation" found on NHS Login's GitHub:
        // https://github.com/nhsconnect/nhslogin
        private async Task NhsLoginUserInfoResponseErrorHandler(HttpResponseMessage response)
        {
            var responseStr = await response.Content.ReadAsStringAsync();
            NhsErrorResponse error;
            try
            {
                error = JsonConvert.DeserializeObject<NhsErrorResponse>(responseStr) ??
                    throw new FormatException($"No properties was populated or the JSON constructor was inaccessible. Response content: {responseStr}");
            }
            catch (Exception e)
            {
                // We throw a new exception here, to isolate issues casued by the response not matching the rules of the Authorization Framework OAuth 2.0 [RFC6749] documentation.
                throw new UnauthorizedException($"Unauthorized request to NHS Login /UserInfo. StatusCode: {response.StatusCode}. Response Value: {responseStr}. WWW-Authenticate header: {response.Headers.WwwAuthenticate}.", e);
            }

            switch ((response.StatusCode, error.ErrorType))
            {
                case (HttpStatusCode.BadRequest, "invalid_request"):
                    throw new BadRequestException("The request is missing a required parameter, includes an unsupported parameter or parameter value, repeats the same parameter, uses more than one method for including an access token, or is otherwise malformed.");
                case (HttpStatusCode.Unauthorized, "invalid_token"):
                    throw new UnauthorizedException("The access token provided is expired, revoked, malformed, or invalid for other reasons.");
                case (HttpStatusCode.Forbidden, "insufficient_scope"):
                    throw new ForbiddenException("The request requires higher privileges than provided by the access token.");
                default:
                    if (response.StatusCode is HttpStatusCode.InternalServerError)
                        throw new Exception($"An InternalServerError occurred on the side of NHS login: {error.ErrorType}.");
                    else
                        throw new Exception($"An unexpected error occurred for the NHS login request with StatusCode: {response.StatusCode}. Error: {error.ErrorType}. WWW-Authenticate header: {response.Headers.WwwAuthenticate}.");
            }
        }

        private class NhsErrorResponse
        {
            [JsonProperty("error"), JsonRequired]
            public string ErrorType { get; private set; }
            [JsonProperty("error_description")] // Note: this field is currently on NHS Login's backlog, and for that reason not supported, until NHS Login adds the support. It should be used to do a proper mapping of errors.
            public string ErrorMessage { get; private set; }
            [JsonProperty("error_uri")] // Note: this field is currently on NHS Login's backlog, and for that reason not supported, until NHS Login adds the support. It should be used to do a proper mapping of errors.
            public string ErrorUri { get; private set; }
        }
    }
}