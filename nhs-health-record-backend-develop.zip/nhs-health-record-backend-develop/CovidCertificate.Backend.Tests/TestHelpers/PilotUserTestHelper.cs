﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.RequestDtos;
using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Tests.TestHelpers
{
    class PilotUserTestHelper
    {
        private static Random random;


        static PilotUserTestHelper()
        {
            random = new Random();
        }


        #region AddPilotUserDto Methods

        /// <summary>
        /// Creates the specified number of <see cref="AddPilotUserDto"/> objects using the parameters <paramref name="user"/> and <paramref name="numberOfDtosToCreate"/>.
        /// </summary>
        /// <param name="user">The <see cref="CovidTestUser"/> the created <see cref="AddPilotUserDto"/> objects should belong to.</param>
        /// <param name="numberOfDtosToCreate">The number of <see cref="AddPilotUserDto"/> objects to be created.</param>
        /// <param name="testType">The <see cref="AddPilotUserDto.TestType"/> that <see cref="AddPilotUserDto"/> objects will be created with.</param>
        /// <returns>An <see cref="IEnumerable{T}"/> of type <see cref="AddPilotUserDto"/> consisting of <paramref name="numberOfDtosToCreate"/> objects belonging to the specified <paramref name="user"/>.</returns>
        public static IEnumerable<AddPilotUserDto> CreateAddPilotUserDto(CovidPassportUser user, int numberOfDtosToCreate)
        {
            for (int i = 0; i < numberOfDtosToCreate; i++)
                yield return CreateAddPilotUserDto(user);
        }

        /// <summary>
        /// Creates an <see cref="AddPilotUserDto"/> using the specified <paramref name="user"/>.
        /// </summary>
        /// <param name="user">The <see cref="CovidTestUser"/> the created <see cref="AddPilotUserDto"/> object should belong to.</param>
        /// <param name="testType">The <see cref="AddPilotUserDto.TestType"/> that <see cref="AddPilotUserDto"/> objects will be created with.</param>
        /// <returns>A new <see cref="AddPilotUserDto"/> belonging to the specified <paramref name="user"/>.</returns>
        public static AddPilotUserDto CreateAddPilotUserDto(CovidPassportUser user)
        {
            return new AddPilotUserDto(user.Name, user.DateOfBirth);
        }

        /// <summary>
        /// Gets the required <see cref="AddPilotUserDto"/> properties that will throw a <see cref="JsonSerializationException"/> during deserialization if not specified.
        /// </summary>
        /// <returns>An <see cref="IEnumerable{T}"/> of type <see cref="string"/> of the required JSON fields for deserialization of <see cref="AddPilotUserDto"/>.</returns>
        public static IEnumerable<string> GetRequiredAddPilotUserDtoProperties()
        {
            yield return nameof(AddPilotUserDto.Name);
        }

        public static PilotUser CreatePilotUser(CovidPassportUser user)
        {
            var addPilotUserDro = CreateAddPilotUserDto(user);
            return new PilotUser(addPilotUserDro);
        }

        public static IEnumerable<PilotUser> CreatePilotUser(CovidPassportUser user, int numberOfResultsToCreate)
        {
            for (int i = 0; i < numberOfResultsToCreate; i++)
                yield return CreatePilotUser(user);
        }

        public static IEnumerable<string> GetRequiredPilotUserProperties()
        {
            return new List<string>();
            // Note: Property 'Id' is currently not a required property as it is not set to be nullable. If this changes, the property should be added here. 
        }
        #endregion
    }
}
