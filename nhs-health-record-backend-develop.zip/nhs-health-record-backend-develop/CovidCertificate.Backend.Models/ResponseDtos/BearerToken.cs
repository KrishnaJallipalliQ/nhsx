﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.ResponseDtos
{
    public class BearerToken
    {
        public string Token_Type { get; set; }
        public int Expires_In { get; set; }
        public int Ext_Expires_In { get; set; }
        public string Access_Token { get; set; }
    }

}
