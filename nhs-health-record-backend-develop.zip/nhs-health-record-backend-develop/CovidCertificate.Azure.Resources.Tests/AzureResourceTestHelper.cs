﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace CovidCertificate.Azure.Resources.Tests
{
    public static class AzureResourceTestHelper
    {
        public static string GetJsonFromAzureResourcesProject(string file)
        {
            var binPath = Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory);
            var filePath = Path.Combine(binPath, "../../../../CovidCertificate.Azure.Resources/", file);
            using StreamReader r = new StreamReader(filePath);
            return r.ReadToEnd();
        }
    }
}
