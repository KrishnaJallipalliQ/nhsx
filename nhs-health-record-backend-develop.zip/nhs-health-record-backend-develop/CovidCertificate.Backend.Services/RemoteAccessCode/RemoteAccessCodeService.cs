﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.RemoteAccessCodeService;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Exceptions;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Utils;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services.RemoteAccessCode
{
    public class RemoteAccessCodeService : IRemoteAccessCodeService
    {
        private readonly ILogger<RemoteAccessCodeService> logger;
        private readonly IMongoRepository<Models.DataModels.RemoteAccessCode> mongoRepository;

        public RemoteAccessCodeService(
                                        ILogger<RemoteAccessCodeService> logger,
                                        IMongoRepository<Models.DataModels.RemoteAccessCode> mongoRepository)
        {
            this.logger = logger;
            this.mongoRepository = mongoRepository;
        }


        public async Task<Models.DataModels.RemoteAccessCode> CreateCode(GenerateRemoteCodeRequestDto req, CovidPassportUser covidUser)
        {

            logger.LogInformation("CreateCode was invoked");

            var accessCode = StringUtils.RandomString(9);
            
            var accessIdHash = CreateAccessHash(covidUser.Name, covidUser.DateOfBirth);
            Models.DataModels.RemoteAccessCode remoteAccessCode = new Models.DataModels.RemoteAccessCode(accessCode, req.UseCount, req.ExpirationDateTime, accessIdHash, covidUser);

             //Check how many records have been created in the last 24 hours
            var remoteCodes = await mongoRepository.FindAllAsync(x => x.AccessHash == accessIdHash && x.CreatedDateTime > DateTime.UtcNow.AddDays(-1));
            if (remoteCodes.ToList().Count >= 10)
                throw new TooManyRequestsException("Max daily codes already reached");

            //Insert record if checks pass                
            await mongoRepository.InsertOneAsync(remoteAccessCode);

            logger.LogInformation("CreateCode has finished");

            return remoteAccessCode;
        }

        //Currently returns the userHash, potentially change name of function 
        public async Task<Models.DataModels.RemoteAccessCode> GetRemoteCode(FetchRemoteCovidStatusDto validationDto)
        {
            logger.LogInformation("GetRemoteCovidStatus was invoked");

            var accessIdHash = CreateAccessHash(validationDto.Name, validationDto.DateOfBirth);

            var remoteCode = await mongoRepository.FindOneAsync(x => string.Equals(x.AccessCode, validationDto.RemoteAccessCode, StringComparison.OrdinalIgnoreCase) &&
                                                                x.AccessHash == accessIdHash);

            if (remoteCode is null)
                throw new RemoteAccessCodeNotFoundException("No remote code matches the provided details");

            if (remoteCode.ExpiryDateTime < DateTime.UtcNow)
                throw new RemoteAccessCodeNotFoundException("Remote Code has expired");

            if (remoteCode.CodeStatus == CodeStatusType.Registered)
                throw new RemoteAccessCodeNotFoundException("Remote Code is not available for unregistered use");

            if (remoteCode.CodeStatus == CodeStatusType.Revoked)
                throw new RemoteAccessCodeNotFoundException("Remote Code has been revoked");

            if (remoteCode.CodeStatus == CodeStatusType.Unused)
            {
                remoteCode.CodeStatus = CodeStatusType.Unregistered;
                await mongoRepository.ReplaceOneAsync(remoteCode);
            }

            logger.LogInformation("GetRemoteCode has finished");
            return remoteCode;
        }

        public async Task<Models.DataModels.RemoteAccessCode> GetRegRemoteCode(FetchRemoteCovidStatusDto requestDto, GetAuthCodeRequestDto thirdPartyDto)
        {
            //Create Hash for database lookup 
            var accessIdHash = CreateAccessHash(requestDto.Name, requestDto.DateOfBirth); 

            //Find remote code with AccessCode and Access Hash Filter
            var remoteCode = await mongoRepository.FindOneAsync( x => string.Equals(x.AccessCode, requestDto.RemoteAccessCode, StringComparison.OrdinalIgnoreCase) &&
                                                                      x.AccessHash == accessIdHash);

            Models.DataModels.RemoteAccessCode result = default;

            if (remoteCode != null)
                //Extracting out the logic that checks the returned code for better readability
                result = await CheckAndInsertAuthCode(remoteCode, requestDto, thirdPartyDto);
            else
                throw new RemoteAccessCodeNotFoundException($"No remote code found: code {requestDto.RemoteAccessCode} does not exist for this user");

            return result;
        }

        private string CreateAccessHash(String name, DateTime dateTime)
        {
            logger.LogInformation("CreateAccessHash was invoked");

            string tempString = (name.ToLower().Trim() + "_" + dateTime).GetShortHash();

            logger.LogInformation("CreateAccessHash has finished");

            return tempString;
        }

        private async Task<Models.DataModels.RemoteAccessCode> CheckAndInsertAuthCode(Models.DataModels.RemoteAccessCode remoteCode,
                                                                                      FetchRemoteCovidStatusDto requestDto,
                                                                                      GetAuthCodeRequestDto thirdPartyDto)
        {            
            var status = remoteCode.CodeStatus;

            if (remoteCode.ExpiryDateTime < DateTime.UtcNow)
                throw new InvalidRemoteCodeException("This code has expired"); //Return an error 

            if (status == CodeStatusType.Revoked)
                throw new RemoteCodeStatusException("Code had been Revoked"); //return 404 and failure message 
                //throw new exception you create (look at Too Many Requests Exception) as example and then throw bad object result in auth function 

            if (status == CodeStatusType.Unregistered)
                throw new RemoteCodeStatusException("Code is Unregistered"); //return 404 and failure message

            if (status == CodeStatusType.Registered)
            {
                //TODO: Does it only make sense to check the ThirdPartyID 
                if (remoteCode.ThirdPartyName == thirdPartyDto.ThirdPartyName && remoteCode.ThirdPartyID == thirdPartyDto.ThirdPartyID)
                    return remoteCode;
                else
                    throw new RemoteCodeStatusException("The ThirdPartyName or ThirdPartyID is incorrect"); //return 404 and failure message
            }

            if (status == CodeStatusType.Unused)
            {
                remoteCode.CodeStatus = CodeStatusType.Registered;
                remoteCode.ThirdPartyName = thirdPartyDto.ThirdPartyName;
                remoteCode.ThirdPartyID = thirdPartyDto.ThirdPartyID;

                //Store this new remote code in the DB
                //TODO: Refactor to use the new Mongo Repository Implementation 
                await mongoRepository.ReplaceOneAsync(remoteCode);
            }

            return remoteCode;
        }

        public async Task RevokeRemoteCode(CovidPassportUser covidUser, RevokeRemoteCheckCodeDto revokeRemoteCheckCodeDto)
        {
            logger.LogInformation("RevokeRemoteCode was invoked");
            // Generates the userHash so that the document in the DB can be found
            var userHash = "";
            if (string.IsNullOrEmpty(covidUser.EmailAddress))
            {
                userHash = StringUtils.GetValueHash(covidUser.PhoneNumber, covidUser.Name, covidUser.DateOfBirth);
            }
            else
            {
                userHash = StringUtils.GetValueHash(covidUser.EmailAddress, covidUser.Name, covidUser.DateOfBirth);
            }

            //Finds the code to be revoked
            var remoteCode = await mongoRepository.FindOneAsync(x => string.Equals(x.AccessCode, revokeRemoteCheckCodeDto.RemoteCheckCode, StringComparison.OrdinalIgnoreCase)
                                                                     && (x.PhoneHash == userHash || x.EmailHash == userHash));

            //Sets CodeStatus to revoked
            if (remoteCode == null)
            {
                throw new RemoteAccessCodeNotFoundException("The remote access code could not be found");
            }
            else
            {
                remoteCode.CodeStatus = CodeStatusType.Revoked;
            }

            //Replaces the document with a new one where the difference is that it has been revoked
            await mongoRepository.ReplaceOneAsync(remoteCode);
            logger.LogInformation("RevokeRemoteCode has finished");
        }

        public async Task<IEnumerable<Models.DataModels.RemoteAccessCode>> GetActiveRemoteCheckCodes(CovidPassportUser covidUser) 
        {
            logger.LogInformation("GetActiveRemoteCheckCodes was invoked");

            Expression<Func<Models.DataModels.RemoteAccessCode, bool>> expression;

            if (string.IsNullOrEmpty(covidUser.EmailAddress))
                expression = x => x.PhoneHash == StringUtils.GetValueHash(covidUser.PhoneNumber, covidUser.Name, covidUser.DateOfBirth) && x.ExpiryDateTime >= DateTime.UtcNow && x.CodeStatus != CodeStatusType.Revoked;
            else
                expression = x => x.EmailHash == StringUtils.GetValueHash(covidUser.EmailAddress, covidUser.Name, covidUser.DateOfBirth) && x.ExpiryDateTime >= DateTime.UtcNow && x.CodeStatus != CodeStatusType.Revoked;

            var finfAllAsyncResult = await mongoRepository.FindAllAsync(expression);

            logger.LogInformation("GetActiveRemoteCheckCodes has finished");
            return finfAllAsyncResult;
        }                       
    }
}
