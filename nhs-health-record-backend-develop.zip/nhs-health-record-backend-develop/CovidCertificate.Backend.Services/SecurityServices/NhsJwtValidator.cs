﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Delegates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Settings;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services
{
    public class NhsJwtValidator : IJwtValidator
    {
        private readonly ValidationServiceResolver validationParamResolver;
        private readonly INhsLoginService nhsLoginService;
        private readonly ILogger<NhsJwtValidator> logger;
        private readonly NhsLoginSettings nhsLoginSettings;
        private IList<string> AcceptedIdentityProofingLevel { get; set; }

        public NhsJwtValidator(ValidationServiceResolver serviceResolver, INhsLoginService nhsLoginService, NhsLoginSettings nhsLoginSettings,
            ILogger<NhsJwtValidator> logger)
        {
            this.validationParamResolver = serviceResolver;
            this.nhsLoginService = nhsLoginService;
            this.nhsLoginSettings = nhsLoginSettings;
            this.logger = logger;
            AcceptedIdentityProofingLevel = GetAllowedIdentityProofing(nhsLoginSettings.AcceptedIdentityProofingLevel);
        }

        protected IList<string> GetAllowedIdentityProofing(string allowedValues)
        {
            var lstEndPoints = new List<string>();
            if (!string.IsNullOrEmpty(allowedValues))
            {
                var endpoints = allowedValues.Split(';');
                lstEndPoints.AddRange(endpoints);
            }
            return lstEndPoints;
        }
        /// <summary>
        /// Checks if a validation token is valid based off the current app settings
        /// </summary>
        /// <param name="token">The input JWT</param>
        /// <returns>If the token is valid</returns>
        public async Task<bool> IsValidToken(string token, string authSchema = "CovidCertificate")
        {
            var validationService = validationParamResolver(authSchema);
            var validationParameters = await validationService.GetValidationParameters();
            var tokenHandler = new JwtSecurityTokenHandler();
            try
            {
                var _ = tokenHandler.ValidateToken(token, validationParameters, out var _);
                return true;
            }
            catch (SecurityTokenException e)
            {
                logger.LogCritical(e, "Failed to validate token: " + token);
                //If the validate token throws an exception this means the token isn't valid
                return false;
            }
            catch (Exception e)
            {
                logger.LogCritical(e, e.Message);
                throw;
            }
        }

        /// <summary>
        /// Fetches the claims for a token if it's valid
        /// </summary>
        /// <param name="token">the jwt token</param>
        /// <returns>The tokens claims</returns>
        public async Task<ClaimsPrincipal> GetClaims(string token, string authSchema = "CovidCertificate")
        {
            logger.LogInformation("GetClaims was invoked");

            var validationService = validationParamResolver(authSchema);
            var validationParameters = await validationService.GetValidationParameters();
            var tokenHandler = new JwtSecurityTokenHandler();
            //var _ = tokenHandler.ValidateToken(token, validationParameters, out var _);

            try
            {
                NhsUserInfo userInfo = await nhsLoginService.GetUserInfo(token);
                logger.LogInformation("GetClaims has finished");

                if (!AcceptedIdentityProofingLevel.Contains(userInfo.IdentityProofingLevel)) return default;
                return new ClaimsPrincipal(userInfo.GetClaims());
            }
            catch (SecurityTokenException e)
            {
                logger.LogError(e, "Failed to validate token: " + token);
                //If the validate token throws an exception this means the token isn't valid
                return default;
            }
            catch (AggregateException e)
            {
                logger.LogError(e, "Error during token validation: " + token);
                //If the validate token throws an exception this means the token isn't valid
                return default;
            }
            catch (Exception e)
            {
                logger.LogError(e, $"Unexpected error during token validation: {e.Message}");
                throw;
            }
        }
    }
}