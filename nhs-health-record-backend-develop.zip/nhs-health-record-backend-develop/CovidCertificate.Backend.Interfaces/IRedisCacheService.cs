﻿using CovidCertificate.Backend.Models.Settings;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IRedisCacheService
    {
        /// <summary>
        /// Add the key in redis cache.Expiration type can be short,medium,long.
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <param name="expirationType"></param>
        /// <returns></returns>
        Task<bool> AddKeyAsync(string key, object value, RedisLifeSpanLevel redisLifeSpanLevel);
        Task<(T, bool)> GetKeyValueAsync<T>(string key);
    }
}