﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Interfaces.UserInterfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.International.Interfaces
{
    public interface IEncoderService
    {
        Task<string> EncodeFlowAsync<T>(IUserCBORInformation user, long certifiateGenerationTime, IEnumerable<T> results, string uniqueCertificateIdentifier, DateTime? validityEndDate, int resultIndex, string barcodeIssuerCountry = null);
    }
}
