﻿using Microsoft.Extensions.Logging;
using Moq;
using CovidCertificate.Backend.International.Tests.Helpers;

namespace CovidCertificate.Backend.International.Tests
{
    public class CBORFlowTest
    {
        private readonly CBORFlow cbor;
        private readonly Mock<ILogger<CBORFlow>> mockLogger;
       public CBORFlowTest()
        {
            mockLogger = new Mock<ILogger<CBORFlow>>();
            var KeyRing = TestHelpers.SetupKeyRing();
            cbor = new CBORFlow(mockLogger.Object, KeyRing);
        }
    }
}
