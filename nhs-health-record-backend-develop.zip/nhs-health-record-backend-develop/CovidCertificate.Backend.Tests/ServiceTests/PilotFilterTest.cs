﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Services.PilotFilter;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class PilotFilterTest
    {
        private PilotFilterService PilotFilterServiceSIT;

        private readonly Mock<IMongoRepository<PilotUser>> mongoMock;
        private readonly Mock<IConfiguration> configurationMock;
        private readonly Mock<ILogger<PilotFilterService>> loggerMock;

        private TestResult mockTestResult;
        private AddPilotUserDto mockAddPilotUserDto;

        public PilotFilterTest()
        {
            mongoMock = new Mock<IMongoRepository<PilotUser>>();
            configurationMock = new Mock<IConfiguration>();
            loggerMock = new Mock<ILogger<PilotFilterService>>();

            PilotFilterServiceSIT = new PilotFilterService(loggerMock.Object, mongoMock.Object);

            //Create a Mock test result
            mockTestResult = new TestResult("Test User", DateTime.UtcNow.AddYears(-20), "testuser@netcompany.com", "+447759700847", "0000000000", DateTime.UtcNow.AddDays(-7), "Negative", "QRTPCR","PCR","TEST");
            mockAddPilotUserDto = new AddPilotUserDto("Test User", DateTime.UtcNow.AddYears(-20));
        }

        public async Task IsPilotUser_Success()
        {
            //Arrange
            PilotFilterServiceSIT = new PilotFilterService(loggerMock.Object, mongoMock.Object);
            var pilotUser = mockAddPilotUserDto.ToPilotUser();
            mongoMock.Setup(m => m.FindOneAsync(It.IsAny<Expression<Func<PilotUser, bool>>>())).ReturnsAsync(pilotUser);

            //Act
            bool act = await PilotFilterServiceSIT.IsPilotUser(pilotUser);

            //Assert
            Assert.True(act);
        }

        public async Task IsPilotUser_Unregistered()
        {
            //Arrange
            PilotFilterServiceSIT = new PilotFilterService(loggerMock.Object, mongoMock.Object);
            var pilotUser = mockAddPilotUserDto.ToPilotUser();

            //Act
            bool act = await PilotFilterServiceSIT.IsPilotUser(pilotUser);

            //Assert
            Assert.False(act);
        }
    }
}
