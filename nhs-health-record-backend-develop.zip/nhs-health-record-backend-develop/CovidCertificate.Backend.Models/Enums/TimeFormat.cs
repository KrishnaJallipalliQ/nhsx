﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.Enums
{
    public enum TimeFormat
    {
        Hours,
        Days,
        Weeks,
        Months
    }
}
