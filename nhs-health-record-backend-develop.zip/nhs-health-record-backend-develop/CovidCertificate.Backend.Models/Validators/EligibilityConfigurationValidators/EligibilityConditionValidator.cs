﻿using CovidCertificate.Backend.Models.DataModels;
using FluentValidation;

namespace CovidCertificate.Backend.Models.Validators
{
    public class EligibilityConditionValidator : AbstractValidator<EligibilityCondition>
    {
        public EligibilityConditionValidator()
        {
            RuleFor(x => TernaryXor(x.NameOfProduct != null,x.SnomedCodes != null, x.VaccineCombinations != null)).Equal(true).OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.NameOfProduct)}, {nameof(x.SnomedCodes)} or {nameof(x.VaccineCombinations)} must be specified but not more than one.");
            });

            RuleFor(x => x.ProductType).NotNull().OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.ProductType)} was not specified.");
            });

            RuleFor(x => x.EligibilityPeriodHours).NotNull().OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.EligibilityPeriodHours)} was not specified");
            });
            RuleFor(x => x.EligibilityPeriodHours).GreaterThan(0).OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.EligibilityPeriodHours)} cannot be less than or equal to 0");
            });

            RuleFor(x => x.FormatValidity).NotNull().OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.FormatValidity)} was not specified.");
            });

            RuleFor(x => x.MaximumHoursBetweenResults == null || x.MaximumHoursBetweenResults > 0).Equal(true).OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.MaximumHoursBetweenResults)} cannot be less than or equal to 0. Set to null if a value does not need to be assigned.");
            });

            RuleFor(x => x.MinimumHoursBetweenResults == null || x.MinimumHoursBetweenResults > 0).Equal(true).OnFailure(x =>
            {
                throw new ValidationException($"nameof{nameof(x.MinimumHoursBetweenResults)} cannot be less than or equal to 0. Set to null if a value does not need to be assigned.");
            });

            RuleFor(x => x.MinCount).NotNull().OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.MinCount)} was not specified");
            });
            RuleFor(x => x.MinCount).GreaterThan(0).OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.MinCount)} cannot be less than or equal to 0");
            });

            RuleFor(x => x.ResultValidAfterHoursFromLastResult).NotNull().OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.ResultValidAfterHoursFromLastResult)} was not specified");
            });
            RuleFor(x => x.ResultValidAfterHoursFromLastResult).GreaterThanOrEqualTo(0).OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.ResultValidAfterHoursFromLastResult)} cannot be less than 0");
            });

            RuleForEach(x => x.NotFollowedBy).SetValidator(new EligibilityNotFollowedByValidator());

            RuleFor(x => x.MakesEligibleOrIneligible).NotNull().OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.MakesEligibleOrIneligible)} was not specified");
            });
            RuleFor(x => IsValueBoolean((int)x.MakesEligibleOrIneligible)).Equal(true).OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.MakesEligibleOrIneligible)} must be true or false");
            });
        }
        private bool IsValueBoolean(int? input)
        {
            return (input == 0 || input == 1);
        }

        /*Xor for three variables,
         this outputs true when only one of the inputs are true
         it will output false when more than one value is true*/
        private bool TernaryXor(bool a, bool b, bool c)
        {
            return (!a && (b ^ c)) || (a && !(b || c));
        }
    }
}
