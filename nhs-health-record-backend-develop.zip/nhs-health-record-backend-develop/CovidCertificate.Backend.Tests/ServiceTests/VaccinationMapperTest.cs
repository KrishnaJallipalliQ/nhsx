﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Exceptions;
using CovidCertificate.Backend.Services.Mappers;
using CovidCertificate.Backend.Tests.TestHelpers;
using Hl7.Fhir.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Linq;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class VaccinationMapperTest
    {
        private readonly VaccinationMapper _vaccinationMapper;
        private readonly Mock<IVaccineMapping> _mockVaccineMapping;
        private readonly Mock<IConfiguration> _mockConfiguration;
        private readonly Mock<ILogger<VaccinationMapper>> _mockLogger;
        private readonly Mock<IFhirLookupApi> _mockFhirLookup;
        private Immunization _immunization;

        public VaccinationMapperTest()
        {
            _mockVaccineMapping = new Mock<IVaccineMapping>();
            _mockConfiguration = new Mock<IConfiguration>();
            _mockFhirLookup = new Mock<IFhirLookupApi>();
            _mockLogger = new Mock<ILogger<VaccinationMapper>>();
            _mockVaccineMapping = VaccinationMapperHelper.CreateMockVaccineMapping();
            _mockConfiguration.SetupGet<string>(m => m["CountryOfVaccination"]).Returns("GB");
            _mockConfiguration.SetupGet<string>(m => m["DiseaseTargeted"]).Returns("COVID-19");
            _mockConfiguration.SetupGet<string>(m => m["VaccinationAuthority"]).Returns("NHS");
            _mockConfiguration.SetupGet<string>(m => m["TotalSeriesOfDoses"]).Returns("2");

            _vaccinationMapper = new VaccinationMapper(_mockVaccineMapping.Object, _mockConfiguration.Object, _mockFhirLookup.Object, _mockLogger.Object);
        }

        [Fact]
        public async void MapRawValue_ReturnCorrectResult_WhenGivenValidInput()
        {
            //Assign
            var manufacturerCodeExpected = "ORG-100031184";

            //Act
            var result = await _vaccinationMapper.MapRawValue("39375411000001104");

            //Assert
            Assert.NotNull(result);
            Assert.IsType<VaccineMap>(result);
            Assert.Equal(manufacturerCodeExpected, result.Manufacturer[0]);
        }

        [Fact]
        public async void MapRawValue_ReturnCorrectResult_WhenGivenValidInputForSecondSnomed()
        {
            //Assign
            var manufacturerCodeExpected = "ORG-100030215";

            //Act
            var result = await _vaccinationMapper.MapRawValue("39115711000001107");

            //Assert
            Assert.NotNull(result);
            Assert.IsType<VaccineMap>(result);
            Assert.Equal(manufacturerCodeExpected, result.Manufacturer[0]);
        }

        [Fact]
        public async void MapRawValue_ThrowException_WhenGivenNull()
        {
            //Act & Assert
            VaccineMappingException ex = await Assert.ThrowsAsync<VaccineMappingException>(() => _vaccinationMapper.MapRawValue(null));
            Assert.Equal("No SNOMED code for vaccine record", ex.Message);
        }

        [Fact]
        public async void MapRawValue_ThrowException_WhenInputNotInMapping()
        {
            //Arrange
            var input = "test";

            //Act & Assert
            VaccineMappingException ex = await Assert.ThrowsAsync<VaccineMappingException>(() => _vaccinationMapper.MapRawValue(input));
            Assert.Equal("Vaccine SNOMED code is not mapped", ex.Message);
        }

        [Fact]
        public async void MapFhirToVaccineAsync_MapCorrect_DoseNumber_Match()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);

            //Act
            Vaccine result = await _vaccinationMapper.MapFhirToVaccine(_immunization);

            //Assert
            Assert.Equal(_immunization.ProtocolApplied.FirstOrDefault().DoseNumber.ToString(), result.DoseNumber.ToString());
        }

        [Fact]
        public async void MapFhirToVaccineAsync_MapCorrect_VaccinationDate_Match()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);

            //Act
            Vaccine result = await _vaccinationMapper.MapFhirToVaccine(_immunization);

            //Assert
            Assert.Equal(DateTime.Parse(_immunization.Occurrence.ToString()), result.VaccinationDate);
        }

        [Fact]
        public async void MapFhirToVaccineAsync_MapCorrect_VaccineManufacturer_Match()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);
            var vaccineManufacturerCodeExpected = "ORG-100031184";
            var vaccineManufacturerDisplayNameExpected = "Moderna Biotech Spain S.L";

            //Act
            Vaccine result = await _vaccinationMapper.MapFhirToVaccine(_immunization);

            //Assert
            Assert.Equal(vaccineManufacturerCodeExpected, result.VaccineManufacturer.Item1);
            Assert.Equal(vaccineManufacturerDisplayNameExpected, result.VaccineManufacturer.Item2);
        }

        [Fact]
        public async void MapFhirToVaccineAsync_MapCorrect_VaccineType_Match()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);
            var vaccineTypeCodeExpected = "1119349007";
            var vaccineTypeDisplayNameExpected = "SARS Cov-2 mRNA Vaccine";

            //Act
            Vaccine result = await _vaccinationMapper.MapFhirToVaccine(_immunization);

            //Assert
            Assert.Equal(vaccineTypeCodeExpected, result.VaccineType.Item1);
            Assert.Equal(vaccineTypeDisplayNameExpected, result.VaccineType.Item2);

        }

        [Fact]
        public async void MapFhirToVaccineAsync_MapCorrect_VaccineBatch_Match()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);

            //Act
            Vaccine result = await _vaccinationMapper.MapFhirToVaccine(_immunization);

            //Assert
            Assert.Equal(_immunization.LotNumber, result.VaccineBatchNumber);
        }

        [Fact]
        public async void MapFhirToVaccineAsync_MapCorrect_Product_Match()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);
            var vaccineProductCodeExpected = "EU/1/20/1507";
            var vaccineProductDisplayNameExpected = "COVID-19 Vaccine Moderna";

            //Act
            Vaccine result = await _vaccinationMapper.MapFhirToVaccine(_immunization);

            //Assert
            Assert.Equal(vaccineProductCodeExpected, result.Product.Item1);
            Assert.Equal(vaccineProductDisplayNameExpected, result.Product.Item2);
            Assert.Equal(vaccineProductDisplayNameExpected, result.DisplayName);
        }

        [Fact]
        public async void MapFhirToVaccineAsync_MapCorrect_DiseaseTargeted_Match()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);
            var vaccineDiseaseTargetedCodeExpected = "840539006";
            var vaccineDiseaseTargetedDisplayNameExpected = "COVID-19";

            //Act
            Vaccine result = await _vaccinationMapper.MapFhirToVaccine(_immunization);

            //Assert
            Assert.Equal(vaccineDiseaseTargetedCodeExpected, result.DiseaseTargeted.Item1);
            Assert.Equal(vaccineDiseaseTargetedDisplayNameExpected, result.DiseaseTargeted.Item2);
        }

        [Fact]
        public async void MapFhirToVaccineAsync_MapCorrect_CountryOfVaccination_Match()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);
            var countryOfVaccinationExpected = "GB";

            //Act
            Vaccine result = await _vaccinationMapper.MapFhirToVaccine(_immunization);

            //Assert
            Assert.Equal(countryOfVaccinationExpected, result.CountryOfVaccination);
        }

        [Fact]
        public async void MapFhirToVaccineAsync_MapCorrect_Authority_Match()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);
            var authorityExpected = "NHS";

            //Act
            Vaccine result = await _vaccinationMapper.MapFhirToVaccine(_immunization);

            //Assert
            Assert.Equal(authorityExpected, result.Authority);
        }

        [Fact]
        public async void MapFhirToVaccineAsync_MapCorrect_DateTimeOfTest_Match()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);
            var vaccineDateTimeOfTestExpected = "2013-01-10 00:00:00";

            //Act
            Vaccine result = await _vaccinationMapper.MapFhirToVaccine(_immunization);

            //Assert
            Assert.Equal(vaccineDateTimeOfTestExpected, result.DateTimeOfTest.Date.ToString("yyyy-MM-dd HH:mm:ss"));
        }

        [Fact]
        public async void MapFhirToVaccineAsync_MapCorrect_ValidityType_Match()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);
            var validityTypeExpected = "Moderna Biotech Spain S.L";

            //Act
            Vaccine result = await _vaccinationMapper.MapFhirToVaccine(_immunization);

            //Assert
            Assert.Equal(validityTypeExpected, result.ValidityType);
        }

        [Fact]
        public async void MapFhirToVaccineAsync_MapCorrect_TotalSeriesOfDoses_Match()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);
            var totalSeriesofDosesExpected = "2";

            //Act
            Vaccine result = await _vaccinationMapper.MapFhirToVaccine(_immunization);

            //Assert
            Assert.Equal(totalSeriesofDosesExpected, result.TotalSeriesOfDoses.ToString());
        }

        [Fact]
        public async void MapFhirToVaccineAsync_MapCorrect_DisplayName_Match()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);
            var displayNameExpected = "COVID-19 Vaccine Moderna";

            //Act
            Vaccine result = await _vaccinationMapper.MapFhirToVaccine(_immunization);

            //Assert
            Assert.Equal(displayNameExpected, result.DisplayName);
        }

        [Fact]
        public async void MapFhirToVaccineAsync_MapCorrect_SnomedCode_Match()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);
            var snomedCodeExpected = "39375411000001104";

            //Act
            Vaccine result = await _vaccinationMapper.MapFhirToVaccine(_immunization);

            //Assert
            Assert.Equal(snomedCodeExpected, result.SnomedCode);
        }

        [Fact]
        public async void MapFhirToVaccineAsync_MapCorrect_DateEntered_Match()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);
            var dateEnteredExpected = "2013-01-11";

            //Act
            Vaccine result = await _vaccinationMapper.MapFhirToVaccine(_immunization);

            //Assert
            Assert.Equal(dateEnteredExpected, result.DateEntered.ToString("yyyy-MM-dd"));
        }

        [Fact]
        public async void MapFhirToVaccineAsync_ReturnDefaultMinDate_RecordedMissing_Match()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);
            _immunization.Recorded = null;
            var dateEnteredExpected = "0001-01-01";

            //Act
            Vaccine result = await _vaccinationMapper.MapFhirToVaccine(_immunization);

            //Assert
            Assert.Equal(dateEnteredExpected, result.DateEntered.ToString("yyyy-MM-dd"));
        }

        [Fact]
        public async void MapFhirToVaccineAsync_ThrowsVaccineMappingException_OccurenceMissing()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);
            _immunization.Occurrence = null;

            //Act & Assert
            await Assert.ThrowsAsync<VaccineMappingException>(async() => await _vaccinationMapper.MapFhirToVaccine(_immunization));
        }

        [Fact]
        public async void MapFhirToVaccineAsync_ReturnNameOfSite_WhenODSMatches()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);
            var nameOfSite = "Some hospital";
            _mockFhirLookup.Setup(m => m.ConvertOdsCodeToName("RRR999")).ReturnsAsync(nameOfSite);

            //Act
            var result = await _vaccinationMapper.MapFhirToVaccine(_immunization);

            //Assert
            Assert.Equal(nameOfSite, result.Site);
        }

        [Fact]
        public async void MapFhirToVaccineAsync_NoNameOfSite_WhenODSDoNotMatch()
        {
            //Arrange
            _immunization = VaccinationMapperHelper.CreateImmunization(0, 0);
            var nameOfSite = "Some hospital";
            _mockFhirLookup.Setup(m => m.ConvertOdsCodeToName("NonMatchingODScode")).ReturnsAsync(nameOfSite);

            //Act
            var result = await _vaccinationMapper.MapFhirToVaccine(_immunization);

            //Assert
            Assert.Null(result.Site);
        }
    }
}
