﻿using CovidCertificate.Backend.Utils;
using System;

namespace CovidCertificate.Backend.Models.DataModels
{
    [Collection("TwoFactorAuth")]
    public class TwoFactorAuth : MongoDocument
    {
        public TwoFactorAuth(string authCode, string destination) : base()
        {
            AuthCode = authCode;
            Destination = destination;
            SendDate = DateTime.UtcNow;
        }

        public string AuthCode { get; set; }

        public string Destination { get; set; }

        public DateTime SendDate { get; set; }

        public string GetTableKey() => (AuthCode + "_" + Destination).GetShortHash();
    }
}
