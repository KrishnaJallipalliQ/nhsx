﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Tests.TestHelpers;
using Newtonsoft.Json;
using Xunit;

namespace CovidCertificate.Backend.Tests.ModelTest
{
    public class AntibodyResultTests
    {
        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public void AntibodyResult_InstantiateAntibodyResult(CovidPassportUser user)
        {
            // Arrange
            var antibodyRequestDto = AntibodyTestHelper.CreateAntibodyRequestDto(user);

            // Act
            var antibodyResult = new AntibodyResult(antibodyRequestDto);

            // Assert
            Assert.NotNull(antibodyResult);
        }

        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public void AntibodyResult_InstantiateAntibodyResultFromJson(CovidPassportUser user)
        {
            // Arrange
            var expectedAntibodyResult = AntibodyTestHelper.CreateAntibodyResult(user);
            var jsonAntibodyResult = JsonConvert.SerializeObject(expectedAntibodyResult);

            // Act
            var actualAntibodyResult = JsonConvert.DeserializeObject<AntibodyResult>(jsonAntibodyResult);

            // Assert
            Assert.NotNull(actualAntibodyResult);
            Assert.Equal(expectedAntibodyResult, actualAntibodyResult);
        }

        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public void AntibodyResult_IsPositive(CovidPassportUser user)
        {
            // Arrange
            var positiveAntibodyResult = AntibodyTestHelper.CreateAntibodyResult(user, AntibodyResultTestType.Positive);
            var negativeAntibodyResult = AntibodyTestHelper.CreateAntibodyResult(user, AntibodyResultTestType.Negative);
            var voidAntibodyResult = AntibodyTestHelper.CreateAntibodyResult(user, AntibodyResultTestType.Void);

            // Act & Assert
            Assert.True(positiveAntibodyResult.IsPositive());
            Assert.False(negativeAntibodyResult.IsPositive());
            Assert.False(voidAntibodyResult.IsPositive());
        }

        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public void AntibodyResult_IsNotPositive(CovidPassportUser user)
        {
            // Arrange
            var positiveAntibodyResult = AntibodyTestHelper.CreateAntibodyResult(user, AntibodyResultTestType.Positive);
            var negativeAntibodyResult = AntibodyTestHelper.CreateAntibodyResult(user, AntibodyResultTestType.Negative);
            var voidAntibodyResult = AntibodyTestHelper.CreateAntibodyResult(user, AntibodyResultTestType.Void);

            // Act & Assert
            Assert.False(positiveAntibodyResult.IsNotPositive());
            Assert.True(negativeAntibodyResult.IsNotPositive());
            Assert.True(voidAntibodyResult.IsNotPositive());
        }

        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public void AntibodyResult_IsNegative(CovidPassportUser user)
        {
            // Arrange
            var positiveAntibodyResult = AntibodyTestHelper.CreateAntibodyResult(user, AntibodyResultTestType.Positive);
            var negativeAntibodyResult = AntibodyTestHelper.CreateAntibodyResult(user, AntibodyResultTestType.Negative);
            var voidAntibodyResult = AntibodyTestHelper.CreateAntibodyResult(user, AntibodyResultTestType.Void);

            // Act & Assert
            Assert.False(positiveAntibodyResult.IsNegative());
            Assert.True(negativeAntibodyResult.IsNegative());
            Assert.False(voidAntibodyResult.IsNegative());
        }

        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public void AntibodyResult_Equals_ShouldReturnTrue(CovidPassportUser user)
        {
            // Arrange
            var antibodyResultOriginal = AntibodyTestHelper.CreateAntibodyResult(user);
            var antibodyResultOriginalJson = JsonConvert.SerializeObject(antibodyResultOriginal);
            var antibodyResultOne = JsonConvert.DeserializeObject<AntibodyResult>(antibodyResultOriginalJson);
            var antibodyResultTwo = JsonConvert.DeserializeObject<AntibodyResult>(antibodyResultOriginalJson);
            var antibodyResultThree = JsonConvert.DeserializeObject<AntibodyResult>(antibodyResultOriginalJson);

            // Act & Assert
            Assert.True(antibodyResultOne.Equals(antibodyResultOne)); // reflexive 
            Assert.True(antibodyResultOne.Equals(antibodyResultTwo)); // symmetric
            Assert.True(antibodyResultTwo.Equals(antibodyResultOne)); // symmetric 
            Assert.True(antibodyResultTwo.Equals(antibodyResultThree)); // symmetric
            Assert.True(antibodyResultOne.Equals(antibodyResultThree)); // symmetric & transitive
        }

        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public void AntibodyResult_Equals_ShouldReturnFalse(CovidPassportUser user)
        {
            // Arrange
            var antibodyResultOne = AntibodyTestHelper.CreateAntibodyResult(user);
            var antibodyResultTwo = AntibodyTestHelper.CreateAntibodyResult(user);
            var obj = new object();

            // Act & Assert
            Assert.False(antibodyResultOne.Equals(antibodyResultTwo));
            Assert.False(antibodyResultOne.Equals(obj));
        }

        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public void AntibodyResult_GetHashCode(CovidPassportUser user)
        {
            // Arrange
            var antibodyResultOne = AntibodyTestHelper.CreateAntibodyResult(user);
            var antibodyResultTwo = AntibodyTestHelper.CreateAntibodyResult(user);

            // Act
            var antibodyResultOneHashCodeOne = antibodyResultOne.GetHashCode();
            var antibodyResultOneHashCodeTwo = antibodyResultOne.GetHashCode();
            var antibodyResultTwoHashCode = antibodyResultTwo.GetHashCode();

            // Assert
            Assert.Equal(antibodyResultOneHashCodeOne, antibodyResultOneHashCodeTwo);
            Assert.NotEqual(antibodyResultOneHashCodeOne, antibodyResultTwoHashCode);
        }
    }
}
