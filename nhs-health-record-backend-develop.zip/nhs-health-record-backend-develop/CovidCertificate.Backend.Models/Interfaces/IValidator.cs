﻿using System.Threading.Tasks;

namespace CovidCertificate.Backend.Models.Interfaces
{
    public interface IValidator
    {
        /// <summary>
        /// Validates the object based on its specefied <see cref="FluentValidation.AbstractValidator{T}"/> rules.
        /// </summary>
        /// <returns></returns>
        Task ValidateObjectAndThrowOnFailuresAsync();
    }
}
