﻿namespace CovidCertificate.Backend.Models.Settings
{
    public enum RedisLifeSpanLevel
    {
        Short,
        Medium,
        Long        
    }
}
