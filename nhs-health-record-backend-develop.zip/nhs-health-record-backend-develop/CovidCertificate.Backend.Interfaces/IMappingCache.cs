﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Settings;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IMappingCache
    {
        public Task<Dictionary<string, Dictionary<string, string>>> GetMappings();
    }
}
