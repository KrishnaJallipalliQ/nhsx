﻿using CovidCertificate.Backend.Models.DataModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IVRService
    {
        Task<List<Vaccine>> GetVaccines(string idToken, CovidPassportUser covidUser);
    }
}
