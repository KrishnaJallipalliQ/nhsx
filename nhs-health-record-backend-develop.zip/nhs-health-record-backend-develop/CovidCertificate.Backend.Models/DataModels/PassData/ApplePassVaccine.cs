﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.DataModels
{
    public class ApplePassVaccine
    {
        public string VaccinationDate { get; set; }
        public string Product { get; set; }
        public string Manufacturer { get; set; }
        public string VaccineType { get; set; }
        public string BatchNumber { get; set; }
        public string DiseaseTargeted { get; set; }
        public string CountryOfVaccination { get; set; }
        public string Authority { get; set; }
        public string AdministeringCentre { get; set; }
        public string Uvci { get; set; }
        public ApplePassVaccine(Vaccine vaccine)
        {
            VaccinationDate = vaccine.VaccinationDate.ToString("dd MMMM yyyy");
            Product = vaccine.Product.Item2;
            Manufacturer = vaccine.VaccineManufacturer.Item2;
            VaccineType = vaccine.VaccineType.Item2;
            BatchNumber = vaccine.VaccineBatchNumber;
            DiseaseTargeted = vaccine.DiseaseTargeted.Item2;
            CountryOfVaccination = vaccine.CountryOfVaccination;
            Authority = vaccine.Authority;
            AdministeringCentre = vaccine.Site;

        }
    }
}
