﻿using Azure.Storage.Blobs;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Utils.Extensions;
using HandlebarsDotNet;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Runtime.Caching;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using CovidCertificate.Backend.Models.RequestDtos.InternationalScenarios;

using CovidCertificate.Backend.Utils;
using CovidCertificate.Backend.Interfaces.BlobService;

namespace CovidCertificate.Backend.Services.PdfGeneration
{
    public class HtmlGeneratorService : IHtmlGeneratorService
    {
        private readonly IConfiguration configuration;
        private readonly IQrImageGenerator qrImageGenerator;
        private readonly ILogger<HtmlGeneratorService> logger;
        private readonly IBlobService blobService;
        private readonly TimeZoneInfo timeZoneInfo;
        private MemoryCache templateCache = MemoryCache.Default;

        public HtmlGeneratorService(
            IConfiguration configuration,
            IQrImageGenerator qrImageGenerator,
            ILogger<HtmlGeneratorService> logger,
            IGetTimeZones timeZones,
            IBlobService blobService)
        {
            this.configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            this.qrImageGenerator = qrImageGenerator ?? throw new ArgumentNullException(nameof(qrImageGenerator));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.blobService = blobService ?? throw new ArgumentNullException(nameof(blobService));
            timeZoneInfo = timeZones.GetTimeZoneInfo();
        }

        public async Task<string> GenerateHtml(GetHtmlRequestDto dto, string templateFolder)
        {
            logger.LogInformation("GenerateHtml was invoked");

            var templateFetchingTask = GetHtmlTemplate(templateFolder, dto.TemplateName);
            var qrCodeImage = qrImageGenerator.GenerateQrCodeString(dto.QrCodeToken);
            logger.LogTraceAndDebug($"qrCodeImage is {qrCodeImage}");
            var template = await templateFetchingTask;
            logger.LogTraceAndDebug($"template is {template}");

            var data = new
            {
                qrCode = qrCodeImage,
                expiryDate = StringUtils.GetFormattedDateTime(dto.Expiry),
                name = dto.Name,
                certificateType = CertificateTypeToString(dto.CertificateType),
                uniqueCertificateIdentifier = dto.UniqueCertificateIdentifier
            };

            if (template == null)
                throw new NullReferenceException("Couldn't get template");

            var result = template(data);
            logger.LogTraceAndDebug($"result is {result}");

            logger.LogInformation("GenerateHtml has finished");
            return result;
        }

        public async Task<string> GenerateInternationalHtml(CovidPassportUser covidUser, 
                                                            string encodedVaccineString, 
                                                            Certificate vaccinationCertificate,
                                                            string encodedRecveryString,
                                                            Certificate recoveryCertificate, 
                                                            string templateFolder, 
                                                            string templateName)
        {
            logger.LogInformation("GenerateInternationalHtml was invoked");

            CheckIfVariablesAreNull(covidUser, templateFolder);

            var templateFetchingTask = GetHtmlTemplate(templateFolder, templateName);
            var template = await templateFetchingTask;
            logger.LogTraceAndDebug($"template is {template}");

            var data = new AddInternationalDynamicPdfRequestDto(LoadVaccineDto(encodedVaccineString, vaccinationCertificate),
                                                                LoadRecoveryDto(encodedRecveryString, recoveryCertificate),
                                                                covidUser.Name,
                                                                covidUser.DateOfBirth.ToString("d MMMM yyyy"),
                                                                covidUser.EmailAddress,
                                                                templateName);

            if (template == null)
                throw new NullReferenceException("Couldn't get template");

            var result = template(data);
            logger.LogTraceAndDebug($"result is {result}");

            logger.LogInformation("GenerateHtml has finished");
            return result;
        }
        public async Task<string> getApplePassHtml(dynamic model, PassData type, string langCode = "en")
        {
            var templateFetchingTask = GetHtmlTemplate("pass-views", langCode + "-" + type.ToString());
            var template = await templateFetchingTask;
            var result = template(model);
            return result;
        }

        private void CheckIfVariablesAreNull(CovidPassportUser covidUser,
                                              string templateFolder)
        {
            if (covidUser == null)
            {
                throw new ArgumentNullException(nameof(covidUser));
            }

            if (templateFolder == null)
            {
                throw new ArgumentNullException(nameof(templateFolder));
            }
        }

        /// <summary>
        /// Fetches the email template from blob storage and then caches it in memory
        /// </summary>
        /// <param name="templateName"></param>
        /// <returns></returns>
        private async Task<HandlebarsTemplate<object, object>> GetHtmlTemplate(string templateFolder, string templateName)
        {
            logger.LogInformation("GetEmailTemplate was invoked");

            var cacheKey = $"email-template:{templateName}";

            if (templateCache.Contains(cacheKey))
            {
                logger.LogInformation("GetEmailTemplate has finished");
                return (HandlebarsTemplate<object, object>) templateCache.Get(cacheKey);
            }

            string returnText = await blobService.GetStringFromBlob(templateFolder, templateName);

            var compiledTemplate = Handlebars.Compile(returnText);

            if (!templateCache.Contains(cacheKey))
            {
                templateCache.Add(cacheKey, compiledTemplate, DateTimeOffset.UtcNow.AddHours(1));
            }

            logger.LogInformation("GetEmailTemplate has finished");

            return compiledTemplate;
        }

        private string CertificateTypeToString(CertificateType type)
        {
            return type switch
            {
                CertificateType.Vaccination => "Vaccinated",
                CertificateType.Immunity => "Antibody tested",
                CertificateType.Diagnostic => "Negative tested",
                CertificateType.Exemption => "Exempt",
                CertificateType.None => "Basis of issuance",
                _ => "Basis of issuance",
            };
        }

        private AddInternationalRecoveryPdfRequestDto LoadRecoveryDto(string encodedRecoveryString, Certificate recoveryCertificate)
        {

            if (recoveryCertificate == null)
                return null;
            var qrCodeImage = qrImageGenerator.GenerateQrCodeString(encodedRecoveryString);
            return new AddInternationalRecoveryPdfRequestDto
            {
                RecoveryTest = LoadRecovery(recoveryCertificate.GetLatestDiagnosticResultFromEligibleResults().ToList(), recoveryCertificate, qrCodeImage),
                RecoveryUniqueCertificateIdentifer = recoveryCertificate.UniqueCertificateIdentifier
            };
        }

        private IEnumerable<AddInternationalPdfRecoveryTestsRequestDto> LoadRecovery(List<TestResultNhs> testResultNhs, Certificate certificate, string qrCodeImage)
        {
            var pdfDtoList = new List<AddInternationalPdfRecoveryTestsRequestDto>();

            foreach (var recovery in testResultNhs)
            {
                pdfDtoList.Add(new AddInternationalPdfRecoveryTestsRequestDto
                {
                    QRCodeToken = qrCodeImage,
                    DiseaseTargeted = StringUtils.UseDashForEmptyOrBlankValues(recovery.DiseaseTargeted.Item2),
                    DateOfFirstPositiveTestResult = StringUtils.UseDashForEmptyOrBlankValues(StringUtils.UtcTimeZoneConverter(recovery.DateTimeOfTest, timeZoneInfo)),
                    CountryOfTest = StringUtils.UseDashForEmptyOrBlankValues(recovery.CountryOfAuthority),
                    CertificateIssuer = configuration["VaccinationAuthority"],
                    CertificateType = StringUtils.UseDashForEmptyOrBlankValues(recovery.ValidityType),
                    CertificateValidFrom = StringUtils.UseDashForEmptyOrBlankValues(StringUtils.UtcTimeZoneConverter(DateTime.UtcNow, timeZoneInfo)),
                    CertificateValidUntil = StringUtils.UseDashForEmptyOrBlankValues(StringUtils.UtcTimeZoneConverter(certificate.validityEndDate, timeZoneInfo))
                });
            }
            return pdfDtoList;

        }

        private AddInternationalVaccinePdfRequestDto LoadVaccineDto(string encodedVaccineString, Certificate vaccinationCertificate)
        { 
            if(vaccinationCertificate == null)
                return null;

            return new AddInternationalVaccinePdfRequestDto
            {
                Vaccinations = LoadVaccines(vaccinationCertificate),
                VaccinationUniqueCertificateIdentifer = vaccinationCertificate.UniqueCertificateIdentifier
            };
        }
       
        private IEnumerable<AddInternationalPdfVaccinationRequestDto> LoadVaccines(Certificate vaccinationCertificate)
        {
            var pdfDtoList = new List<AddInternationalPdfVaccinationRequestDto>();
            var vaccinesToShow = vaccinationCertificate.GetAllVaccinationsFromEligibleResults().TakeLast(2).ToList();
            for (int i = 0 ; i <= vaccinesToShow.Count() - 1 ; i++)
            {
                pdfDtoList.Add(new AddInternationalPdfVaccinationRequestDto(vaccinesToShow[i].DoseNumber,
                                                                            StringUtils.UseDashForEmptyOrBlankValues(StringUtils.UtcTimeZoneConverter(vaccinesToShow[i].VaccinationDate, timeZoneInfo)),
                                                                            StringUtils.UseDashForEmptyOrBlankValues(vaccinesToShow[i].VaccineManufacturer.Item2),
                                                                            StringUtils.UseDashForEmptyOrBlankValues(vaccinesToShow[i].Product.Item2),
                                                                            StringUtils.UseDashForEmptyOrBlankValues(vaccinesToShow[i].DiseaseTargeted.Item2),
                                                                            StringUtils.UseDashForEmptyOrBlankValues(vaccinesToShow[i].VaccineType.Item2),
                                                                            StringUtils.UseDashForEmptyOrBlankValues(vaccinesToShow[i].VaccineBatchNumber),
                                                                            StringUtils.UseDashForEmptyOrBlankValues(vaccinesToShow[i].CountryOfVaccination),
                                                                            configuration["VaccinationAuthority"],
                                                                            StringUtils.UseDashForEmptyOrBlankValues(vaccinesToShow[i].Site),
                                                                            vaccinesToShow[i].DisplayName == null ? StringUtils.UseDashForEmptyOrBlankValues(vaccinesToShow[i].Product.Item2) : StringUtils.UseDashForEmptyOrBlankValues(vaccinesToShow[i].DisplayName),
                                                                            vaccinesToShow[i].TotalSeriesOfDoses,
                                                                            StringUtils.UtcTimeZoneConverter(vaccinationCertificate.validityEndDate, timeZoneInfo),
                                                                            qrImageGenerator.GenerateQrCodeString(vaccinationCertificate.QrCodeTokens[i])));
            }            
            return pdfDtoList.OrderBy(x => x.VaccinationDate);
        }
    }
}