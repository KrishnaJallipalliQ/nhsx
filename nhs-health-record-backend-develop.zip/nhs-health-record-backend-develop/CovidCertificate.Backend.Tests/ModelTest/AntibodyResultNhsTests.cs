﻿using System;
using CovidCertificate.Backend.Models.DataModels;
using Xunit;

namespace CovidCertificate.Backend.Tests.ModelTest
{
    public class AntibodyResultNhsTests
    {

        private readonly string positive = "Positive";
        private readonly string negative = "Negative";
        private readonly string voidResult = "Void";
        private readonly string testKitPCR = "PCR";
        private readonly string validityTypeTest = "test";

        [Fact]
        public void AntibodyResult_IsPositive()
        {
            // Arrange
            var positiveAntibodyResult = new AntibodyResultNhs(DateTime.Today, positive, validityTypeTest, testKitPCR);
            var negativeAntibodyResult = new AntibodyResultNhs(DateTime.Today, negative, validityTypeTest, testKitPCR);
            var voidAntibodyResult = new AntibodyResultNhs(DateTime.Today, voidResult, validityTypeTest, testKitPCR);

            // Act & Assert
            Assert.True(positiveAntibodyResult.Result.Equals(positive));
            Assert.False(negativeAntibodyResult.Result.Equals(positive));
            Assert.False(voidAntibodyResult.Result.Equals(positive));
        }

        [Fact]
        public void AntibodyResult_IsNegative()
        {
            // Arrange
            var positiveAntibodyResult = new AntibodyResultNhs(DateTime.Today, positive, validityTypeTest, testKitPCR);
            var negativeAntibodyResult = new AntibodyResultNhs(DateTime.Today, negative, validityTypeTest, testKitPCR);
            var voidAntibodyResult = new AntibodyResultNhs(DateTime.Today, voidResult, validityTypeTest, testKitPCR);

            // Act & Assert
            Assert.False(positiveAntibodyResult.Result.Equals(negative));
            Assert.True(negativeAntibodyResult.Result.Equals(negative));
            Assert.False(voidAntibodyResult.Result.Equals(negative));
        }

        [Fact]
        public void AntibodyResult_Equals_ShouldReturnFalse()
        {
            // Arrange
            var testResultOne = new AntibodyResultNhs(DateTime.Today, positive, validityTypeTest, testKitPCR);
            var testResultTwo = new AntibodyResultNhs(DateTime.Today, positive, validityTypeTest, testKitPCR);
            var obj = new object();

            // Act & Assert
            Assert.False(testResultOne.Equals(testResultTwo));
            Assert.False(testResultOne.Equals(obj));
        }

        [Fact]
        public void AntibodyResult_GetHashCode()
        {
            // Arrange
            var testResultOne = new AntibodyResultNhs(DateTime.Today, positive, validityTypeTest, testKitPCR);
            var testResultTwo = new AntibodyResultNhs(DateTime.Today, positive, validityTypeTest, testKitPCR);

            // Act
            var testResultOneHashCodeOne = testResultOne.GetHashCode();
            var testResultOneHashCodeTwo = testResultOne.GetHashCode();
            var testResultTwoHashCode = testResultTwo.GetHashCode();

            // Assert
            Assert.Equal(testResultOneHashCodeOne, testResultOneHashCodeTwo);
            Assert.NotEqual(testResultOneHashCodeOne, testResultTwoHashCode);
        }

        [Fact]
        public void AntibodyResultToAntibodyResultNhs_MappedCorrectly()
        {
            //Arrange
            var testKit = "testKitTest";
            var validityType = "validityTypeTest";
            var result = "resultTest";
            var test = "test";
            var antibodyResult = new AntibodyResult(test, DateTime.Today, test, test, test, DateTime.Today, result, validityType, testKit);

            //Act
            var antibodyResultNhs = new AntibodyResultNhs(antibodyResult);

            //Assert
            Assert.Equal(DateTime.Today, antibodyResultNhs.DateTimeOfTest);
            Assert.Equal(result, antibodyResultNhs.Result);
            Assert.Equal(validityType, antibodyResultNhs.ValidityType);
            Assert.Equal(testKit, antibodyResultNhs.TestKit);
        }
    }
}
