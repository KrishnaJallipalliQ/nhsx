﻿using CovidCertificate.Backend.Models.Interfaces;
using CovidCertificate.Backend.Models.Validators;
using FluentValidation;
using System;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Models.RequestDtos
{
    public class FetchRemoteCovidStatusDto : IUserInformation
    {
        public FetchRemoteCovidStatusDto(string name, DateTime dateOfBirth, string remoteAccessCode, string nhsNumber = null)
        {
            this.Name = name;
            this.DateOfBirth = dateOfBirth;
            this.RemoteAccessCode = remoteAccessCode;
            this.NhsNumber = nhsNumber;
        }

        public string Name { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string NhsNumber { get; }
        public string RemoteAccessCode { get; set; }


        public async Task ValidateObjectAndThrowOnFailuresAsync() 
        {
            await new UserInformationValidator().ValidateAndThrowAsync(this);
            await new FetchRemoteCovidStatusDtoValidator().ValidateAndThrowAsync(this);
        } 


        private class FetchRemoteCovidStatusDtoValidator : AbstractValidator<FetchRemoteCovidStatusDto>
        {
            public FetchRemoteCovidStatusDtoValidator()
            {
                #region RemoteAccessCode Rules
                RuleFor(x => x.RemoteAccessCode).Length(9).Matches("^[a-zA-Z0-9]*$").OnFailure(x =>
                {
                    throw new ValidationException("Remote Access Code ");
                });
                #endregion 
            }
        }
    }
}