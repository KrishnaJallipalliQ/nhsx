﻿namespace CovidCertificate.Backend.Models.RequestDtos
{
    public class GetAuthCodeRequestDto
    {
        public string ThirdPartyName { get; set; }
        public string ThirdPartyID { get; set; }
    }
}
