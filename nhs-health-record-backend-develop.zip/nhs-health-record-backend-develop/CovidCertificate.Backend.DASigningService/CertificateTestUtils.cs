﻿using Org.BouncyCastle.Asn1.X509;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Generators;
using Org.BouncyCastle.Crypto.Prng;
using Org.BouncyCastle.Math;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.X509;
using System;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

namespace CovidCertificate.Backend.DASigningService
{
    public class CertificateTestUtils
    {
        public string GenerateCertificateHeaderValue()
        {
            X509Certificate2 cert = GenerateCertificate("NorthernIreland");
            return System.Convert.ToBase64String(cert.RawData);
        }

        public string ReadFromCertificateStore()
        {
            string certThumbprint = "E1B281A63A5D3A31185669F3DA63154807B63640";
            using (X509Store certStore = new X509Store(StoreName.My, StoreLocation.CurrentUser))
            {
                certStore.Open(OpenFlags.ReadOnly);

                X509Certificate2Collection certCollection = certStore.Certificates.Find(
                            X509FindType.FindByThumbprint,
                            certThumbprint,
                            false);
                X509Certificate2 cert = certCollection.OfType<X509Certificate2>().FirstOrDefault();
                if (cert == null)
                {
                    return "Did not find certificate with matching thumbprint";
                }
                return "Found certificate: " + cert.Thumbprint;
            }
        }

        private X509Certificate2 GenerateCertificate(string certName)
        {
            var keypairgen = new RsaKeyPairGenerator();
            keypairgen.Init(new KeyGenerationParameters(new SecureRandom(new CryptoApiRandomGenerator()), 1024));

            var keypair = keypairgen.GenerateKeyPair();

            var gen = new X509V3CertificateGenerator();

            var CN = new X509Name("CN=" + certName);
            var SN = BigInteger.ProbablePrime(120, new Random());

            gen.SetSerialNumber(SN);
            gen.SetSubjectDN(CN);
            gen.SetIssuerDN(CN);
            gen.SetNotAfter(DateTime.MaxValue);
            gen.SetNotBefore(DateTime.Now.Subtract(new TimeSpan(7, 0, 0, 0)));
            gen.SetSignatureAlgorithm("MD5WithRSA");
            gen.SetPublicKey(keypair.Public);

            var newCert = gen.Generate(keypair.Private);

            return new X509Certificate2(DotNetUtilities.ToX509Certificate((Org.BouncyCastle.X509.X509Certificate)newCert));
        }
    }
}
