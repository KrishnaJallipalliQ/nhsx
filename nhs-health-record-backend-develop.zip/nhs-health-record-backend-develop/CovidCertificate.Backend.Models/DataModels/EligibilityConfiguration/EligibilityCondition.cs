﻿using CovidCertificate.Backend.Models.Enums;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace CovidCertificate.Backend.Models.DataModels
{
    public class EligibilityCondition
    {
        public string NameOfProduct { get; private set; }
        public IEnumerable<string> SnomedCodes { get; private set; }
        public List<List<string>> VaccineCombinations { get; private set; }
        public DataType ProductType { get; private set; }
        public int EligibilityPeriodHours { get; private set; }
        public TimeFormat FormatValidity { get; private set; }
        public int? MaximumHoursBetweenResults { get; private set; }
        public int? MinimumHoursBetweenResults { get; private set; }
        public int MinCount { get; private set; }
        public int ResultValidAfterHoursFromLastResult { get; private set; }
        public ResultStatus? Result { get; private set; }
        public Eligibility MakesEligibleOrIneligible { get; private set; }        
        public IEnumerable<EligibilityNotFollowedBy> NotFollowedBy { get; private set; }


        [JsonConstructor]
        public EligibilityCondition(string nameOfProduct, IEnumerable<string> snomedCodes, List<List<string>> vaccineCombinations, DataType productType, int eligibilityPeriodHours, TimeFormat formatValidity, int? maximumHoursBetweenResults, int? minimumHoursBetweenResults, int minCount, int resultValidAfterHoursFromLastResult, ResultStatus? result, Eligibility makesEligibleOrIneligible,  IEnumerable<EligibilityNotFollowedBy> notFollowedBy) {
            NameOfProduct = nameOfProduct;
            SnomedCodes = snomedCodes;
            VaccineCombinations = vaccineCombinations;
            ProductType = productType;
            EligibilityPeriodHours = eligibilityPeriodHours;
            FormatValidity = formatValidity;
            MaximumHoursBetweenResults = maximumHoursBetweenResults;
            MinimumHoursBetweenResults = minimumHoursBetweenResults;
            MinCount = minCount;
            ResultValidAfterHoursFromLastResult = resultValidAfterHoursFromLastResult;
            Result = result;
            MakesEligibleOrIneligible = makesEligibleOrIneligible;
            NotFollowedBy = notFollowedBy;
        }
    }
}