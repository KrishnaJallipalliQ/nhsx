﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Models.RequestDtos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IHtmlGeneratorService
    {
        Task<string> GenerateHtml(GetHtmlRequestDto dto, string templateFolder);

        Task<string> GenerateInternationalHtml(CovidPassportUser covidUser, 
                                               string encodedVaccineString, 
                                               Certificate vaccinationCertificate, 
                                               string encodedRecoveryString, 
                                               Certificate recoveryCertificate, 
                                               string templateFolder, 
                                               string templateName);
        Task<string> getApplePassHtml(dynamic model, PassData type, string langCode = "en");
    }
}
