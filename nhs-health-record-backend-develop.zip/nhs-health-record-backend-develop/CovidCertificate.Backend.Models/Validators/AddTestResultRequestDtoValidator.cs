﻿using CovidCertificate.Backend.Models.RequestDtos;
using FluentValidation;
using System;
using System.Text.RegularExpressions;

namespace CovidCertificate.Backend.Models.Validators
{
    public class AddTestResultRequestDtoValidator : AbstractValidator<AddTestResultRequestDto>
    {
        public AddTestResultRequestDtoValidator()
        {
            RuleFor(x => x.Name).NotEmpty();

            var phoneRegex = new Regex(ValidatorConsts.PhoneRegex);
            When(x => !string.IsNullOrEmpty(x.PhoneNumber), () =>
            {
                RuleFor(x => x.PhoneNumber).Matches(phoneRegex);
            });

            When(x => !string.IsNullOrEmpty(x.EmailAddress), () =>
            {
                RuleFor(x => x.EmailAddress).EmailAddress();
            });

            When(x => string.IsNullOrEmpty(x.PhoneNumber), () =>
            {
                RuleFor(x => x.EmailAddress).NotEmpty();
            });

            When(x => string.IsNullOrEmpty(x.EmailAddress), () =>
            {
                RuleFor(x => x.PhoneNumber).NotEmpty();
            });

            RuleFor(x => x.Result).NotEmpty();
            RuleFor(x => x.TestKit).NotNull();
            RuleFor(x => x.DateTimeOfTest).LessThan(DateTime.UtcNow);
            RuleFor(x => x.DateOfBirth).NotEqual(default(DateTime));
        }

    }
}
