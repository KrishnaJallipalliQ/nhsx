﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CovidCertificate.Backend.Models.DataModels;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IVaccineMapping
    {
        public Task<Dictionary<string, VaccineMap>> GetMappings();
    }
}
