﻿using CovidCertificate.Backend.Services.KeyServices;
using PeterO.Cbor;
using System;
using System.Security.Cryptography;
using Microsoft.Extensions.Logging;
using CovidCertificate.Backend.International.Interfaces;
using System.Threading.Tasks;
using System.Text;
using CovidCertificate.Backend.International.Models;

namespace CovidCertificate.Backend.International
{
    public class CBORFlow : ICBORFlow
    {
        private readonly ILogger<CBORFlow> logger;
        private readonly IKeyRing keyRing;
        // Please refer to https://tools.ietf.org/html/rfc8152#section-4.4
        // externalData is added for unprotected field 
        // contextString is for RFC standard, do not change!
        private static byte[] externalData = new byte[0];
        private static string contextString = "Signature1";

        public CBORFlow(ILogger<CBORFlow> logger, IKeyRing keyRing)
        {
            this.logger = logger;
            this.keyRing = keyRing;
        }

        public byte[] JsonToCbor(string jsonString)
        {
            //Convert from jsonString to CBORObject then to bytes
            CBORObject cborFormatedJson = CBORObject.FromJSONString(jsonString);
            byte[] cborDataFormatBytes = cborFormatedJson.EncodeToBytes();

            return cborDataFormatBytes;
        }

        public string CborToJson(byte[] cborDataFormatBytes)
        {
            // Convert from bytes to CBORObject then to jsonString
            CBORObject cborObjectFromBytes = CBORObject.DecodeFromBytes(cborDataFormatBytes);
            string jsonString = cborObjectFromBytes.ToJSONString();
            return jsonString;
        }

        public async Task<byte[]> AddMetaDataToCbor(byte[] originalCborBytes, string keyId)
        {
            CBORObject cwtObject = CBORObject.NewArray();

            // Add algorithm and KeyId to protected
            CBORObject protectedObject = CBORObject.NewMap();
            // Please refer to https://tools.ietf.org/html/rfc8152
            // Key values such has 1 and 4 in CBOR maps are specifically set in reference to RFC 8152
            // Please do not change key value integers for CBOR maps and arrays

            protectedObject.Add(1, Algorithms.SHA256withECDSA);

            // Convert keyId from human readable string to Base64 string
            // Then convert that base64 string to a base64 byte array
            byte[] keyIdBytes = Encoding.UTF8.GetBytes(keyId);
            string keyIdBase64String = Convert.ToBase64String(keyIdBytes);
            keyIdBytes = Convert.FromBase64String(keyIdBase64String);

            protectedObject.Add(4, keyIdBytes);
            byte[] protectedBytes = protectedObject.EncodeToBytes();
            cwtObject.Insert(0, protectedBytes);

            // Add unprotected header
            CBORObject unprotectedObject = CBORObject.NewMap();
            cwtObject.Insert(1, unprotectedObject);

            // Add Message/Payload
            cwtObject.Insert(2, originalCborBytes);

            // *** Make seperate object just for creating signature ***
            CBORObject obj = CBORObject.NewArray();
            obj.Add(contextString);
            obj.Add(protectedBytes);
            obj.Add(externalData);
            if (originalCborBytes != null)
            {
                obj.Add(originalCborBytes);
            }
            else
            {
                obj.Add(null);
            }
            var objBytes = obj.EncodeToBytes();

            // Sign that obj just created to get signedCborBytes
            var signedCborBytes = await keyRing.SignData(keyId, objBytes);

            // Add Signature
            cwtObject.Insert(3, signedCborBytes);

            // Tag entire cwtObject with 18, as stated in 4.2 of RFC 8152
            cwtObject = CBORObject.FromObjectAndTag(cwtObject, 18);

            // Convert altered cbor back to bytes
            byte[] alteredCborBytes = cwtObject.EncodeToBytes();


            return alteredCborBytes;
        }
    }
}