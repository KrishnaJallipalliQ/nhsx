﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Validators;
using CsvHelper.Configuration.Attributes;
using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Models.RequestDtos
{
    public class DomesticExemptionDto
    {
        [Index(0)] 
        public string NhsNumber { get; set; }
        [Index(1)] 
        public DateTime DateOfBirth { get; set; }
        [Index(2)] 
        [Optional]
        public string Reason { get; set; }

        public static DomesticExemptionDtoValidator Validator = new DomesticExemptionDtoValidator();

        [JsonConstructor]
        public DomesticExemptionDto(string nhsNumber, DateTime dateOfBirth, string reason)
        {
            NhsNumber = nhsNumber;
            Reason = reason;
            DateOfBirth = dateOfBirth;
        }

        public DomesticExemption ToDomesticExemption() => new DomesticExemption(this);

        public virtual async Task<ValidationResult> ValidateObjectAsync()
        {
            return await Validator.ValidateAsync(this);
        }

        public string ToString()
        {
            return NhsNumber + "," + DateOfBirth + "," + Reason;
        }
    }
}
