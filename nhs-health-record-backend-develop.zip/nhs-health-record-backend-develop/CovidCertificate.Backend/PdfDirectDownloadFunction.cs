using CovidCertificate.Backend.Configuration.Bases.BaseFunctions;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Interfaces.Delegates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Utils.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using CovidCertificate.Backend.Models.Helpers;

namespace CovidCertificate.Backend
{
    public class PdfDirectDownloadFunction : BaseSecureFunction
    {
        private readonly ICovidCertificateCreator covidCertificateCreator;
        private readonly IHtmlGeneratorService htmlGeneratorService;
        private readonly IPdfGeneratorService pdfGeneratorService;
        private readonly HtmlGeneratorSettings generatorSettings;
        private readonly TimeZoneInfo timeZoneInfo;

        public PdfDirectDownloadFunction(ICovidCertificateCreator covidCertificateCreator,
                                         IHtmlGeneratorService htmlGeneratorService,
                                         IPdfGeneratorService pdfGeneratorService,
                                         JwtValidatorResolver jwtValidator, IConfiguration configuration,
                                         HtmlGeneratorSettings generatorSettings, IGetTimeZones timeZones,
                                         ILogger<PdfDirectDownloadFunction> logger) : base(jwtValidator, configuration, logger)
        {
            this.covidCertificateCreator = covidCertificateCreator;
            this.htmlGeneratorService = htmlGeneratorService;
            this.pdfGeneratorService = pdfGeneratorService;
            this.generatorSettings = generatorSettings;
            timeZoneInfo = timeZones.GetTimeZoneInfo();
        }

        [FunctionName("PdfDirectDownloadFunction")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "PdfDirectDownload")] HttpRequest req)
        {
            try
            {
                logger.LogInformation("PdfDirectDownloadFunction was invoked");

                var authorisationResult = await base.AuthoriseEndpoint(req);
                logger.LogTraceAndDebug($"authorisationResult: IsValid is {authorisationResult?.IsValid}, Response is {authorisationResult?.Response}, TokenClaims is {authorisationResult?.TokenClaims}");

                if (base.responseInvalid(authorisationResult))
                {
                    logger.LogInformation("PdfDirectDownloadFunction has finished");
                    return authorisationResult.Response;
                }

                var covidUser = new CovidPassportUser(authorisationResult.TokenClaims);
                logger.LogTraceAndDebug($"covidUser:{covidUser?.ToString()}");
                logger.LogInformation($"covidUser: {covidUser?.ToNhsNumberAndDobHashKey()}");

                var templateName = req.GetTemplateHeader();
                logger.LogTraceAndDebug($"language is {templateName}");

                var certificate = await covidCertificateCreator.GetDomesticCertificate(covidUser, base.GetIdToken(req));

                if (certificate == default)
                {
                    logger.LogInformation("certificate == default");
                    logger.LogInformation("PdfDirectDownloadFunction has finished");
                    return new NoContentResult();
                }
                logger.LogTraceAndDebug($"certificate:{certificate?.ToString()}");
                var utc = TimeFormatConvert.ToUniversal(certificate.validityEndDate);
                var dto = new AddPdfCertificateRequestDto
                {
                    Name = covidUser.Name,
                    DateOfBirth = covidUser.DateOfBirth,
                    Email = covidUser.EmailAddress,
                    TemplateName = templateName,
                    Expiry = TimeZoneInfo.ConvertTimeFromUtc(utc, timeZoneInfo),
                    QrCodeToken = certificate.QrCodeTokens[0],
                    CertificateType = certificate.CertificateType,
                    UniqueCertificateIdentifier = certificate.UniqueCertificateIdentifier
                };

                var emailHtml = await htmlGeneratorService.GenerateHtml(dto.GetHtmlDto(), generatorSettings.TemplateFolder);
                if (emailHtml == default)
                {
                    logger.LogCritical("Could not fetch email html");
                    throw new Exception("Email couldn't be fetched");
                }
                logger.LogTraceAndDebug($"emailHtml is {emailHtml}");
                var emailPdfRequest = new PdfGenerationRequestDto
                {
                    Email = covidUser.EmailAddress,
                    Name = covidUser.Name,
                    EmailContent = emailHtml
                };

                var pdfContent = await pdfGeneratorService.GeneratePdfDocumentStream(emailPdfRequest);

                if (!pdfContent.CanRead)
                {
                    logger.LogCritical("Could not read pdf stream");
                    logger.LogInformation("PdfDirectDownloadFunction has finished");
                    return new StatusCodeResult(500);
                }
                logger.LogTraceAndDebug($"pdfContent is {pdfContent}");

                logger.LogInformation("PdfDirectDownloadFunction has finished");
                return new FileStreamResult(pdfContent, "application/pdf");
            }
            catch (Exception e)
            {
                logger.LogCritical(e, e.Message);
                throw;
            }
        }
    }
}
