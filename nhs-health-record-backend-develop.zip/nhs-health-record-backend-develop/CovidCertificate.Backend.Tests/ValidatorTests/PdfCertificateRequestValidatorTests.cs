﻿using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Models.Validators;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Tests.ValidatorTests
{
    public class PdfCertificateRequestValidatorTests
    {
        private PdfCertificateRequest validPCR = new PdfCertificateRequest()
        {
            Email = "test@test.com",
            TemplateName = "en",
            Expiry = DateTime.Now.AddDays(5),
            QrCodeToken = "abcdef.0123456789ABCDEF.ABCDEFGHIJKLMNOP",
            CertificateType = CertificateType.Vaccination
        };
        [Fact]
        public async Task ValidateAsync_ValidPdfCertificateRequest_ReturnsTrue()
        {
            //Arrange 
            var validator = new PdfCertificateRequestValidator();
            var pcr = validPCR;
            //Act
            var result = await validator.ValidateAsync(pcr);
            //Assert
            Assert.True(result.IsValid);
            Assert.Equal(0, result.Errors.Count);
        }
        [Fact]
        public async Task ValidateAsync_IncorrectEmails_ReturnsFalse()
        {
            //Arrange 
            var validator = new PdfCertificateRequestValidator();
            var pcr = validPCR;
            pcr.Email = "test";
            //Act
            var result = await validator.ValidateAsync(pcr);
            //Assert
            Assert.False(result.IsValid);
            Assert.Equal(1, result.Errors.Count);
        }
        [Fact]
        public async Task ValidateAsync_EmptyLangCode_ReturnsFalse()
        {
            //Arrange 
            var validator = new PdfCertificateRequestValidator();
            var pcr = validPCR;
            pcr.TemplateName = string.Empty;
            //Act
            var result = await validator.ValidateAsync(pcr);
            //Assert
            Assert.False(result.IsValid);
            Assert.Equal(1, result.Errors.Count);
        }
        [Fact]
        public async Task ValidateAsync_PastExpiry_ReturnsFalse()
        {
            //Arrange 
            var validator = new PdfCertificateRequestValidator();
            var pcr = validPCR;
            pcr.Expiry = DateTime.Now.AddDays(-1);
            //Act
            var result = await validator.ValidateAsync(pcr);
            //Assert
            Assert.False(result.IsValid);
            Assert.Equal(1, result.Errors.Count);
        }
        [Fact]
        public async Task ValidateAsync_IncorrectQR_ReturnsFalse()
        {
            //Arrange 
            var validator = new PdfCertificateRequestValidator();
            var pcr = validPCR;
            pcr.QrCodeToken = "test";
            //Act
            var result = await validator.ValidateAsync(pcr);
            //Assert
            Assert.False(result.IsValid);
            Assert.Equal(1, result.Errors.Count);
        }
    }
}
