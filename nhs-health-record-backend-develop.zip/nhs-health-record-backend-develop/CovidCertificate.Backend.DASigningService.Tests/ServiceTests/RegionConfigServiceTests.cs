﻿using Microsoft.Extensions.Logging;
using Moq;
using System.Text;
using Microsoft.Extensions.Configuration;
using CovidCertificate.Backend.DASigningService.Services;
using Xunit;
using CovidCertificate.Backend.DASigningService.Requests;
using CovidCertificate.Backend.DASigningService.Interfaces;
using CovidCertificate.Backend.DASigningService.ErrorHandling;
using System.IO;

namespace CovidCertificate.Backend.DASigningService.Tests.ServiceTests
{
    public class RegionConfigServiceTests
    {
        private Mock<ILogger<RegionConfigService>> logger = new Mock<ILogger<RegionConfigService>>();
        private IConfiguration configuration;
        private IRegionConfigService regionConfigService;
        private IConfigurationBuilder builder;
        private string regionMappings;
        private string rawRequestBodyCorrect;
        private string rawRequestBodyIncorrect;

        public RegionConfigServiceTests()
        {
            this.regionMappings = @"{
                        ""RegionMappings"": [
                {
                            ""RegionCode"": ""Gibraltar"",
                    ""Issuer"": ""Gibraltar"",
                    ""MemberState"": ""GI"",
                    ""CountryCode"": ""GI""
                },
                {
                            ""RegionCode"": ""Jersey"",
                    ""Issuer"": ""Health and Community Services"",
                    ""MemberState"": ""JE"",
                    ""CountryCode"": ""GB""
                },
                {
                            ""RegionCode"": ""Guernsey"",
                    ""Issuer"": ""Guernsey"",
                    ""MemberState"": ""GG"",
                    ""CountryCode"": ""GG""
                }
                                            ],
                }";
            rawRequestBodyCorrect = "{\r\n  \"resourceType\": \"Bundle\",\r\n  \"type\": \"collection\",   \r\n  \"entry\": [\r\n    {\r\n      \"resource\": {\r\n      \"resourceType\": \"Patient\",    \r\n      \"name\": [\r\n        {                        \r\n        \"family\": \"Jackson\",\r\n        \"given\": [\r\n          \"Jane\"\r\n        ]            \r\n        }\r\n      ],        \r\n      \"birthDate\": \"1952-05-31\"    \r\n      }\r\n    },       \r\n    {\r\n      \"resource\": {\r\n        \"resourceType\": \"Immunization\",       \r\n        \"id\": \"87cf548c-2a23-4b18-b0b7-8704a44fc25f\",    \r\n        \"status\": \"completed\",\r\n        \"vaccineCode\": {\r\n          \"coding\": [\r\n            {\r\n              \"code\": \"39115611000001103\",\r\n            }\r\n          ]\r\n        },\r\n        \"occurrenceDateTime\": \"2020-12-05T23:20:04.000Z\",\r\n        \"lotNumber\": \"OBQUJKGQDBCLVDEFWUUQ\",\r\n        \"protocolApplied\": [ { \"doseNumberPositiveInt\": 1 } ]\r\n      }\r\n    },\r\n    {\r\n      \"resource\": {\r\n        \"resourceType\": \"Immunization\",       \r\n        \"id\": \"55275435-9b4d-47c5-81df-b25f6d612768\",    \r\n        \"status\": \"completed\",\r\n        \"vaccineCode\": {\r\n          \"coding\": [\r\n            {\r\n              \"code\": \"39115611000001103\",\r\n            }\r\n          ]\r\n        },\r\n        \"occurrenceDateTime\": \"2021-02-08T14:33:04.000Z\",\r\n        \"lotNumber\": \"OBQUJKGQDBCLVDEFWUUQ\",\r\n        \"protocolApplied\": [ { \"doseNumberPositiveInt\": 2 } ]\r\n      }\r\n    }    \r\n  ]\r\n}\r\n";
            rawRequestBodyIncorrect = "{\r\n  \"resourceType\": \"Bundle\",\r\n  \"type\": \"collection\", \"resource\": {\r\n      \"resourceType\": \"Patient\",    \r\n      \"name\": [\r\n        {                        \r\n        \"family\": \"Jackson\",\r\n        \"given\": [\r\n          \"Jane\"\r\n        ]            \r\n        }\r\n      ],        \r\n      \"birthDate\": \"1952-05-31\"    \r\n      }\r\n    },       \r\n    {\r\n      \"resource\": {\r\n        \"resourceType\": \"Immunization\",       \r\n        \"id\": \"87cf548c-2a23-4b18-b0b7-8704a44fc25f\",    \r\n        \"status\": \"completed\",\r\n        \"vaccineCode\": {\r\n          \"coding\": [\r\n            {\r\n              \"code\": \"39115611000001103\",\r\n            }\r\n          ]\r\n        },\r\n        \"occurrenceDateTime\": \"2020-12-05T23:20:04.000Z\",\r\n        \"lotNumber\": \"OBQUJKGQDBCLVDEFWUUQ\",\r\n        \"protocolApplied\": [ { \"doseNumberPositiveInt\": 1 } ]\r\n      }\r\n    },\r\n    {\r\n      \"resource\": {\r\n        \"resourceType\": \"Immunization\",       \r\n        \"id\": \"55275435-9b4d-47c5-81df-b25f6d612768\",    \r\n        \"status\": \"completed\",\r\n        \"vaccineCode\": {\r\n          \"coding\": [\r\n            {\r\n              \"code\": \"39115611000001103\",\r\n            }\r\n          ]\r\n        },\r\n        \"occurrenceDateTime\": \"2021-02-08T14:33:04.000Z\",\r\n        \"lotNumber\": \"OBQUJKGQDBCLVDEFWUUQ\",\r\n        \"protocolApplied\": [ { \"doseNumberPositiveInt\": 2 } ]\r\n      }\r\n    }    \r\n  ]\r\n}\r\n";
            builder = new ConfigurationBuilder();
            builder.AddJsonStream(new MemoryStream(Encoding.UTF8.GetBytes(regionMappings)));
            configuration = this.builder.Build();
            regionConfigService = new RegionConfigService(configuration, logger.Object);

        }

        [Fact]
        public void GetRegionConfig_CorrectRegionCode_ReturnsRegionConfig()
        {
            //Arrange
            var errorHandler = new ErrorHandler();
            var regionSubscriptionNameHeader = "Region-Jersey-1";

            //Act
            var regionConfig =
                regionConfigService.GetRegionConfig(regionSubscriptionNameHeader, errorHandler);

            //Assert
            Assert.NotNull(regionConfig);
            Assert.Empty(errorHandler.Errors);
        }

        [Fact]
        public void GetRegionConfig_IncorrectRegionCodeCorrectRequestBody_ReturnsNull()
        {
            //Arrange
            var errorHandler = new ErrorHandler();
            var regionSubscriptionNameHeader = "Incorrect-Region";
      
            var regionCode = regionSubscriptionNameHeader.Split("-")[1];

            //Act
            var regionConfig =
                regionConfigService.GetRegionConfig(regionSubscriptionNameHeader, errorHandler);

            //Assert
            Assert.Null(regionConfig);
            Assert.Equal(ErrorCode.UNEXPECTED_SYSTEM_ERROR.GetHashCode().ToString(), errorHandler.Errors[0].Code.ToString());
            Assert.Equal("Unrecognized region code in 'Region-Subscription-Name' header: " +
                            regionCode, errorHandler.Errors[0].Message.ToString());
        }

        [Fact]
        public void GetRegionConfig_CorrectRegionCodeIncorrectRequestBody_ReturnsRegionConfig()
        {
            //Arrange
            var errorHandler = new ErrorHandler();
            var regionSubscriptionNameHeader = "Region-Jersey-1";

            //Act
            var regionConfig =
                regionConfigService.GetRegionConfig(regionSubscriptionNameHeader, errorHandler);

            //Assert
            Assert.NotNull(regionConfig);
            Assert.Empty(errorHandler.Errors);
        }

        [Fact]
        public void GetRegionConfig_ExceptionThrown_ReturnsNull()
        {
            //Arrange
            var errorHandler = new ErrorHandler();

            //Act
            var regionConfig =
                regionConfigService.GetRegionConfig(null, errorHandler);

            //Assert
            Assert.Null(regionConfig);
            Assert.Equal(ErrorCode.UNEXPECTED_SYSTEM_ERROR.GetHashCode().ToString(), errorHandler.Errors[0].Code.ToString());
            Assert.Equal("Unexpected error retrieving calling region", errorHandler.Errors[0].Message.ToString());
        }
    }
}
