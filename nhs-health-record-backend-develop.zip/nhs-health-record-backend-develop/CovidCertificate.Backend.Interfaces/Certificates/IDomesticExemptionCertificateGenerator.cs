﻿using CovidCertificate.Backend.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces.Certificates
{
    public interface IDomesticExemptionCertificateGenerator
    {
        public Task<Certificate> GenerateCertificate(CovidPassportUser user);
    }
}
