﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.Exceptions
{
    public class TwoFactorAuthException : Exception
    {
        public TwoFactorAuthException(string message) : base(message)
        {
        }
    }
}
