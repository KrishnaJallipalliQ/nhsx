﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.Exceptions
{
    public class RemoteAccessCodeNotFoundException : Exception
    {
        public RemoteAccessCodeNotFoundException(string message) : base(message)
        {
        }
    }
}
