﻿using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IFhirLookupApi
    {
        /// <summary>
        /// Calls the FHIR ODS Lookup API, retrieves data for a specific ODS name
        /// and returns the name of the site
        /// </summary>
        /// <param name="odsCode"></param>
        /// <returns></returns>
        public Task<string> ConvertOdsCodeToName(string odsCode);
    }
}
