﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Utils.Extensions;
using Microsoft.Extensions.Logging;
using SelectPdf;
using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services
{
    public class PdfGeneratorService : IPdfGeneratorService
    {
        private readonly HtmlGeneratorSettings generatorSettings;
        private readonly IHtmlGeneratorService htmlGeneratorService;
        private readonly ILogger<PdfGeneratorService> logger;

        public PdfGeneratorService(HtmlGeneratorSettings generatorSettings,
            IHtmlGeneratorService htmlGeneratorService,
            ILogger<PdfGeneratorService> logger)
        {
            this.generatorSettings = generatorSettings;
            this.htmlGeneratorService = htmlGeneratorService;
            this.logger = logger;
        }

        public async Task<string> GeneratePdfDocument(PdfGenerationRequestDto dto)
        {
            var pdf = ExtractPdfDocument(dto);

            return ConvertToBase64(pdf);
        }

        private PdfDocument ExtractPdfDocument(PdfGenerationRequestDto dto)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            PdfDocument pdf;
            try
            {
                var converter = new HtmlToPdf();
                pdf = converter.ConvertHtmlString(dto.EmailContent);
            }
            catch (Exception e)
            {

                var exceptionType = e.GetType().Name;
                logger.LogCritical(e, $"Couldn't create PDF file: {exceptionType}");
                throw;
            }

            return pdf;
        }

        public async Task<Stream> GeneratePdfDocumentStream(PdfGenerationRequestDto dto)
        {
            logger.LogInformation("GeneratePdfDocumentStream was invoked");

            var pdf = ExtractPdfDocument(dto);

            logger.LogTraceAndDebug($"pdf is {pdf}");
            
            await using var stream = new MemoryStream();
            pdf.Save(stream);

            logger.LogInformation("GeneratePdfDocumentStream has finished");

            return stream;
        }

        /// <summary>
        /// Saves the pdf to a stream and then we convert the bytes to base 64
        /// </summary>
        /// <param name="pdfDocument"></param>
        /// <returns></returns>
        private string ConvertToBase64(PdfDocument pdfDocument)
        {
            using var stream = new MemoryStream();
            pdfDocument.Save(stream);
            var bytes = stream.ToArray();
            return Convert.ToBase64String(bytes);
        }
    }
}
