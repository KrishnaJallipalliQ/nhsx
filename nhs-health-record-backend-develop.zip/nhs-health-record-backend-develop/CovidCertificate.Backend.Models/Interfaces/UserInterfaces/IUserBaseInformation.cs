﻿using System;

namespace CovidCertificate.Backend.Models.Interfaces
{
    public interface IUserBaseInformation : IValidator
    {
        string Name { get; }
        DateTime DateOfBirth { get; }
    }
}
