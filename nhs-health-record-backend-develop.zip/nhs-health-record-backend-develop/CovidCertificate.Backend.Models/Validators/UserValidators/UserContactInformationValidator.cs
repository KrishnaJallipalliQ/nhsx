﻿using CovidCertificate.Backend.Models.Interfaces;
using FluentValidation;
using System.Text.RegularExpressions;

namespace CovidCertificate.Backend.Models.Validators
{
    public class UserContactInformationValidator : AbstractValidator<IUserContactInformation>
    {
        public UserContactInformationValidator()
        {
            #region EmailAddress Rules
            When(x => !string.IsNullOrEmpty(x.EmailAddress), () =>
            {
                RuleFor(x => x.EmailAddress).EmailAddress().OnFailure(x =>
                {
                    throw new ValidationException("Invalid email format.");
                });

                RuleFor(x => x.EmailAddress).MinimumLength(6).OnFailure(x =>
                {
                    throw new ValidationException("Minimum characters in email address is 6");
                });

                RuleFor(x => x.EmailAddress).MaximumLength(254).OnFailure(x =>
                {
                    throw new ValidationException("Maximum characters in email address is 254");
                });


                RuleFor(x => GetEmailUserName(x.EmailAddress)).MaximumLength(64).OnFailure(x =>
                {
                    throw new ValidationException("Maximum characters before “@”: 64");

                });


                RuleFor(x => GetEmailUserName(x.EmailAddress)).MaximumLength(64).OnFailure(x =>
                {
                    throw new ValidationException("Maximum characters before “@”: 64");

                });
            });

            #endregion

            #region PhoneNumber Rules
            When(x => !string.IsNullOrEmpty(x.PhoneNumber), () =>
            {
                RuleFor(x => x.PhoneNumber).Matches(new Regex(ValidatorConsts.PhoneRegex)).OnFailure(x =>
                {
                    throw new ValidationException("Invalid phone number format.");
                });
            });

            #endregion

            #region No Contact Rules
            When(x => string.IsNullOrEmpty(x.EmailAddress) && string.IsNullOrEmpty(x.PhoneNumber), () =>
            {
                RuleFor(x => x).Null().OnFailure(x =>
                {
                    throw new ValidationException("Either a phone number or email address must be specified.");
                });
            });
            #endregion
        }

        private string GetEmailUserName(string emailAddress) => emailAddress?.Split("@")[0];
    }
}
