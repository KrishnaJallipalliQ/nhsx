﻿using CovidCertificate.Backend.DASigningService.ErrorHandling;
using CovidCertificate.Backend.DASigningService.Tests.ValidatorTests.TestHelpers;
using CovidCertificate.Backend.DASigningService.Validators;
using CovidCertificate.Backend.Utils;
using Xunit;

namespace CovidCertificate.Backend.DASigningService.Tests.ValidatorTests
{
    public class Create2DVaccinationBarcodeRequestValidatorTest
    {
        private static readonly Create2DVaccinationBarcodeRequestValidator barcodeValidator = new Create2DVaccinationBarcodeRequestValidator();

        [Fact]
        public void Validate_ValidRequest_ReturnNoErrors()
        {
            // Arrange
            var mockBarcodeRequest = Create2DVaccinationBarcodeRequestValidatorTestHelper.CreateValidMock2DBarcodeRequest();

            // Act
            var barcodeValidationResult = barcodeValidator.Validate(mockBarcodeRequest);

            //Assert
            Assert.Empty(barcodeValidationResult.Errors);
        }

        [Fact]
        public void Validate_InvalidType_ReturnUnsupportedTypeError()
        {
            // Arrange
            var mockBarcodeRequest = Create2DVaccinationBarcodeRequestValidatorTestHelper.CreateValidMock2DBarcodeRequest();
            mockBarcodeRequest.Type = "invalid test type";

            // Act
            var barcodeValidationResult = barcodeValidator.Validate(mockBarcodeRequest);

            //Assert
            Assert.Equal(ErrorCode.UNSUPPORTED_TYPE.ToString(StringUtils.NumberFormattedEnumFormat),
                                                                      barcodeValidationResult.Errors[0].ErrorCode.ToString());
            Assert.Equal("Unsupported type.", barcodeValidationResult.Errors[0].ErrorMessage);
        }

        [Fact]
        public void Validate_WhenTypeIsNull_ReturnNoError()
        {
            // Arrange
            var mockBarcodeRequest = Create2DVaccinationBarcodeRequestValidatorTestHelper.CreateValidMock2DBarcodeRequest();
            mockBarcodeRequest.Type = null;

            // Act
            var barcodeValidationResult = barcodeValidator.Validate(mockBarcodeRequest);

            //Assert
            Assert.Empty(barcodeValidationResult.Errors);
        }

        [Fact]
        public void Validate_WhenBodyIsEmpty_ReturnFHIRInvalidError()
        {
            // Arrange
            var mockBarcodeRequest = Create2DVaccinationBarcodeRequestValidatorTestHelper.CreateValidMock2DBarcodeRequest();
            mockBarcodeRequest.Body = string.Empty;

            // Act
            var barcodeValidationResult = barcodeValidator.Validate(mockBarcodeRequest);

            //Assert
            Assert.Equal(ErrorCode.FHIR_INVALID.ToString(StringUtils.NumberFormattedEnumFormat),
                                                                      barcodeValidationResult.Errors[0].ErrorCode.ToString());
            Assert.Equal("Request should not be empty.", barcodeValidationResult.Errors[0].ErrorMessage);
        }

        [Fact]
        public void Validate_WhenHeaderIsEmpty_ReturnUnexpectedSystemError()
        {
            // Arrange
            var mockBarcodeRequest = Create2DVaccinationBarcodeRequestValidatorTestHelper.CreateValidMock2DBarcodeRequest();
            mockBarcodeRequest.RegionSubscriptionNameHeader = string.Empty;

            // Act
            var barcodeValidationResult = barcodeValidator.Validate(mockBarcodeRequest);

            //Assert
            Assert.Equal(ErrorCode.UNEXPECTED_SYSTEM_ERROR.ToString(StringUtils.NumberFormattedEnumFormat),
                                                                      barcodeValidationResult.Errors[0].ErrorCode.ToString());
            Assert.Equal($"Missing header '{DevolvedAdministrationBarcodeGeneratorFunction.RegionSubscriptionNameHeader}'",
                                                                      barcodeValidationResult.Errors[0].ErrorMessage);
        }
    }
}
