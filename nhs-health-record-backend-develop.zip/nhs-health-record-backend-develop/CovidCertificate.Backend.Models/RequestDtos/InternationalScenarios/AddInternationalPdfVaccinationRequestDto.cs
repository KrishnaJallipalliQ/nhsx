﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.RequestDtos
{
    public class AddInternationalPdfVaccinationRequestDto
    {
        public int VaccinationDoseNumber { get; set; }
        public string VaccinationDate { get; set; }
        public string VaccineManufacturer { get; set; }
        public string VaccineProduct { get; set; }
        public string DiseaseTargeted { get; set; }
        public string VaccineType { get; set; }
        public string VaccineBatchNumber { get; set; }
        public string CountryOfVaccination { get; set; }
        public string Authority { get; set; }
        public string Site { get; set; }
        public string DisplayName { get; set; }
        public string ExpiryDate { get; set; }
        public string QRCodeToken { get; set; }
        public int VaccinationTotalSeriesOfDoses { get; set; }

        public AddInternationalPdfVaccinationRequestDto(int vaccinationDoseNumber, string vaccinationDate, string vaccineManufacturer, string vaccineProduct, string diseaseTargeted, string vaccineType, string vaccineBatchNumber, string countryOfVaccination, string authority, string site, string displayName, int vaccinationTotalSeriesOfDoses, string expiryDate, string qrCodeToken)
        {
            VaccinationDoseNumber = vaccinationDoseNumber;
            VaccinationDate = vaccinationDate;
            VaccineManufacturer = vaccineManufacturer;
            VaccineProduct = vaccineProduct;
            DiseaseTargeted = diseaseTargeted;
            VaccineType = vaccineType;
            VaccineBatchNumber = vaccineBatchNumber;
            CountryOfVaccination = countryOfVaccination;
            Authority = authority;
            Site = site;
            DisplayName = displayName;
            VaccinationTotalSeriesOfDoses = vaccinationTotalSeriesOfDoses;
            ExpiryDate = expiryDate;
            QRCodeToken = qrCodeToken;
        }
    }
}
