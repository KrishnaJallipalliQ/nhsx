﻿namespace CovidCertificate.Backend.Models.DataModels
{
    public class TestType
    {
        public string Name { get; set; }
        public int TimeSpanHours { get; set; }
        public int MinCount { get; set; }
        public int DurabilityDays { get; set; }
        public int ExpiryHours { get; set; }
    }
}
