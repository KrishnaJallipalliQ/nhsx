﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Utils.Extensions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services.PdfGeneration
{
    public class PdfHtmlGeneratorService : IPdfGeneratorService
    {
        private readonly IConfiguration configuration;
        private readonly ILogger<PdfHtmlGeneratorService> logger;
        private static readonly HttpClient _httpClient = new HttpClient();

        public PdfHtmlGeneratorService(IConfiguration configuration,
            ILogger<PdfHtmlGeneratorService> logger)
        {
            this.configuration = configuration;
            this.logger = logger;
        }

        public async Task<string> GeneratePdfDocument(PdfGenerationRequestDto dto)
        {
            var url = configuration["PdfGenerationEndpoint"];
            var pdfResponse = await _httpClient.PostAsync(url, new StringContent(dto.EmailContent));
            if(!pdfResponse.IsSuccessStatusCode)
            {
                logger.LogError("Could not pdf generation");
                return default;
            }

            var pdfText = await pdfResponse.Content.ReadAsStringAsync();
            return pdfText;
        }

        public async Task<Stream> GeneratePdfDocumentStream(PdfGenerationRequestDto dto)
        {
            logger.LogInformation("GeneratePdfDocumentStream was invoked");

            var url = configuration["PdfGenerationEndpoint"];
            logger.LogTraceAndDebug($"url is {url}");

            var pdfResponse = await _httpClient.PostAsync(url, new StringContent(dto.EmailContent));
            if (!pdfResponse.IsSuccessStatusCode)
            {
                logger.LogError("Could not pdf generation");
                logger.LogInformation("GeneratePdfDocumentStream has finished");
                return default;
            }
            logger.LogTraceAndDebug($"pdfResponse: StatusCode is {pdfResponse?.StatusCode}, Headers is {pdfResponse?.Headers}, Content is {pdfResponse?.Content}, ReasonPhrase is {pdfResponse?.ReasonPhrase}");
            logger.LogInformation("GeneratePdfDocumentStream has finished");
            return await pdfResponse.Content.ReadAsStreamAsync();
        }
    }
}
