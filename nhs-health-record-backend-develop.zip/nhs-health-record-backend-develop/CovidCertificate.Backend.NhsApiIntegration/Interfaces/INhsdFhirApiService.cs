﻿using System.Threading.Tasks;
using Hl7.Fhir.Model;

namespace CovidCertificate.Backend.NhsApiIntegration.Interfaces
{
    public interface INhsdFhirApiService
    {
        Task<Bundle> GetAntibodyTestResults(string identityToken);

        Task<Bundle> GetDiagnosticTestResults(string identityToken);
    }
}
