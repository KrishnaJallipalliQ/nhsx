﻿using System;
using System.Runtime.Caching;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.Settings;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services
{
    public class NhsTokenValidationFetcher : IJwtValidationParameterFetcher
    {
        private readonly NhsLoginSettings nhsLoginSettings;
        private readonly ILogger<NhsTokenValidationFetcher> logger;
        private OpenIdConnectConfiguration openIdConnectConfiguration;
        private readonly MemoryCache memoryCache = MemoryCache.Default;
        private const string cacheKey = "WellKnownUrl";

        public NhsTokenValidationFetcher(NhsLoginSettings nhsLoginSettings, ILogger<NhsTokenValidationFetcher> logger)
        {
            this.nhsLoginSettings = nhsLoginSettings;
            this.logger = logger;
        }

        /// <summary>
        /// Gets the validation parameters for the token validation
        /// </summary>
        /// <returns></returns>
        public async Task<TokenValidationParameters> GetValidationParameters()
        {
            var openId = await OpenIdConfig();
            return new TokenValidationParameters
            {
                ValidIssuer = nhsLoginSettings.Issuer,
                ValidAudience = nhsLoginSettings.Audience,
                IssuerSigningKeys = openId.SigningKeys,
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidateIssuerSigningKey = true,
                ValidateLifetime = true,
                //RequireSignedTokens = true
            };
        }

        /// <summary>
        /// Fetches the RSA keys for the web token
        /// </summary>
        /// <returns>The configuation wrapper</returns>
        private async Task<OpenIdConnectConfiguration> OpenIdConfig()
        {
            if (memoryCache.Contains(cacheKey))
            {
                return memoryCache.Get(cacheKey) as OpenIdConnectConfiguration;
            }

            logger.LogInformation("Getting WellKnownUrl");
            var configurationManager =
                new ConfigurationManager<OpenIdConnectConfiguration>(nhsLoginSettings.WellKnownUrl,
                    new OpenIdConnectConfigurationRetriever());
            var result = await configurationManager.GetConfigurationAsync();

            if (!memoryCache.Contains(cacheKey))
                memoryCache.Add(cacheKey, result, DateTimeOffset.UtcNow.AddHours(1));
            return result;
        }
    }
}