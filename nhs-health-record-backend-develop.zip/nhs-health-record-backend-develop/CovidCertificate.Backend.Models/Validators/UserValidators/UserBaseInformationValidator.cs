﻿using CovidCertificate.Backend.Models.Interfaces;
using FluentValidation;
using System;
using System.Linq;

namespace CovidCertificate.Backend.Models.Validators.UserValidators
{
    public class UserBaseInformationValidator : AbstractValidator<IUserBaseInformation>
    {
        public UserBaseInformationValidator()
        {
            #region Name Rules

            RuleFor(x => x.Name).NotEmpty().OnFailure(x =>
            {
                throw new ValidationException("A name was not specified.");
            });

            RuleFor(x => x.Name.Count(c => !char.IsWhiteSpace(c))).GreaterThanOrEqualTo(2).OnFailure(x =>
            {
                throw new ValidationException("A name must contain a minimum of 2 characters without a space in between.");
            });

            RuleFor(x => x.Name.Length).LessThanOrEqualTo(255).OnFailure(x =>
            {
                throw new ValidationException("A name must not exceed the character limit of 255.");
            });

            #endregion

            #region DateOfBirth Rules

            RuleFor(x => x.DateOfBirth).GreaterThanOrEqualTo(new DateTime(1900, 1, 1, 0, 0, 0, DateTimeKind.Utc)).OnFailure(x =>
            {
                throw new ValidationException("Date of birth cannot be before the year 1900.");
            });

            RuleFor(x => x.DateOfBirth).LessThanOrEqualTo(DateTime.UtcNow).OnFailure(x =>
            {
                throw new ValidationException("Date of birth cannot be in the future.");
            });

            #endregion
        }
    }
}
