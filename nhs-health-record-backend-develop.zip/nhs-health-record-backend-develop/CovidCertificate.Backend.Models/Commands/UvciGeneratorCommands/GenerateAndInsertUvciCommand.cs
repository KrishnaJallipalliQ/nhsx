﻿using System;
using CovidCertificate.Backend.Models.Enums;

namespace CovidCertificate.Backend.Models.Commands.UvciGeneratorCommands
{
    public abstract class GenerateAndInsertUvciCommand
    {
        public string Issuer { get; }

        public string Country { get;  }
        public string UserHash { get; }
        public CertificateType CertificateType { get; }
        public CertificateScenario CertificateScenario { get; }
        public DateTime DateOfCertificateExpiration { get; }

        public GenerateAndInsertUvciCommand(
            string issuer,
            string country,
            string userHash,
            CertificateType certificateType,
            CertificateScenario certificateScenario,
            DateTime dateOfCertificateExpiration)
        {
            Issuer = issuer;
            Country = country;
            UserHash = userHash;
            CertificateType = certificateType;
            CertificateScenario = certificateScenario;
            DateOfCertificateExpiration = dateOfCertificateExpiration;
        }
    }
}
