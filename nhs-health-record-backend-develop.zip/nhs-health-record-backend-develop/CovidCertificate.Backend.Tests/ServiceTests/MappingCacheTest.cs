﻿using CovidCertificate.Backend.Interfaces.BlobService;
using CovidCertificate.Backend.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class MappingCacheTest
    {
        private readonly MappingCache mappingCache;
        private readonly Mock<ILogger<MappingCache>> mockLogger;
        private readonly Mock<IConfiguration> mockConfiguration;
        private readonly Mock<IBlobService> mockBlobService;


        public MappingCacheTest()
        {
            mockLogger = new Mock<ILogger<MappingCache>>();
            mockBlobService = new Mock<IBlobService>();
            mockConfiguration = new Mock<IConfiguration>();
            mockConfiguration.SetupGet<string>(m => m["TestMapperCacheTime"]).Returns("1");

            var serviceScopeFactory = MockSetup_ReturnMappings();

            mappingCache = new MappingCache(mockConfiguration.Object, mockLogger.Object, mockBlobService.Object);
        }

        [Fact]
        public async Task GetMappings_MappingsCacheValid_ReturnCachedMappings()
        {
            //Arrange
            var mappings = await mappingCache.GetMappings();

            //Act
            var cachedMappings = await mappingCache.GetMappings(); 

            //Assert
            Assert.Same(mappings, cachedMappings);
        }

        [Fact]
        public async Task GetMappings_MappingsCacheValid_DontAskBlobServiceForMappings()
        {
            //Arrange
            var mappings = await mappingCache.GetMappings();

            //Act
            var cachedMappings = await mappingCache.GetMappings(); //Cache still valid so shouldn't ask blobService for mappings again

            //Assert
            mockBlobService.Verify(blobService => blobService.GetObjectFromBlob<Dictionary<string, Dictionary<string, string>>>(
                It.IsAny<string>(), It.IsAny<string>()), Times.Once());
        }

        [Fact]
        public async Task GetMappings_OldMappingsCache_GetMappingsFromBlobStorage()
        {
            //Arrange
            // this will force the cache to be old
            mockConfiguration.SetupGet<string>(m => m["TestMapperCacheTime"]).Returns("-1");
            var mappings = await mappingCache.GetMappings();
            
            //Act
            var mappingsAfterCacheExpired = await mappingCache.GetMappings();

            //Assert
            mockBlobService.Verify(blobService => blobService.GetObjectFromBlob<Dictionary<string, Dictionary<string, string>>>(
                It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(2));

            Assert.NotSame(mappings, mappingsAfterCacheExpired);
        }


        [Fact]
        public async Task GetMappings_NoMappingsInCache_GetMappingsFromBlobStorage()
        {
            //Act
            var result = await mappingCache.GetMappings();

            //Assert
            mockBlobService.Verify(blobService => blobService.GetObjectFromBlob<Dictionary<string, Dictionary<string, string>>>(
                It.IsAny<string>(), It.IsAny<string>()));

            Assert.NotNull(result);
            Assert.IsType<Dictionary<string, Dictionary<string, string>>>(result);
        }

        private Mock<IServiceScopeFactory> MockSetup_ReturnMappings()
        {
            var serviceProvider = new Mock<IServiceProvider>();

            var serviceScope = new Mock<IServiceScope>();
            serviceScope.Setup(x => x.ServiceProvider).Returns(serviceProvider.Object);

            var serviceScopeFactory = new Mock<IServiceScopeFactory>();
            serviceScopeFactory
                .Setup(x => x.CreateScope())
                .Returns(serviceScope.Object);

            serviceProvider
                .Setup(x => x.GetService(typeof(IBlobService)))
                .Returns(mockBlobService.Object);

            mockBlobService
                .Setup(x => x.GetObjectFromBlob<Dictionary<string, Dictionary<string, string>>>(
                    "test-results-configuration", "test-results-mapping.json"))
                .ReturnsAsync(() => new Dictionary<string, Dictionary<string, string>>());

            return serviceScopeFactory;
        }
    }
}