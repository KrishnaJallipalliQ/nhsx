﻿using System.Threading.Tasks;

namespace CovidCertificate.Backend.International.Interfaces
{
    public interface ICBORFlow
    {
        byte[] JsonToCbor(string jsonString);
        string CborToJson(byte[] cborDataFormatBytes);
        Task<byte[]> AddMetaDataToCbor(byte[] originalCborBytes, string keyId);
    }
}
