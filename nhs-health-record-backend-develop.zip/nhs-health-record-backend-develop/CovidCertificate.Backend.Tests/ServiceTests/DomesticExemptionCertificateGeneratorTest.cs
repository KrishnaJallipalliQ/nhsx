﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Services.Certificates;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using Xunit;
using CovidCertificate.Backend.Models.Enums;
using System.Threading.Tasks;
using CovidCertificate.Backend.Models.Commands.UvciGeneratorCommands;
using Microsoft.Extensions.Configuration;
using CovidCertificate.Backend.Services;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class DomesticExemptionCertificateGeneratorTest
    {
        private readonly DomesticExemptionCertificateGenerator service;
        private readonly Mock<IQRCodeGenerator> QRCodeGeneratorMock = new Mock<IQRCodeGenerator>(MockBehavior.Strict);
        private readonly Mock<ILogger<DomesticExemptionCertificateGenerator>> loggerMock = new Mock<ILogger<DomesticExemptionCertificateGenerator>>();
        private readonly Mock<IBlobFilesInMemoryCache<EligibilityConfiguration>> mockEligibilityService = new Mock<IBlobFilesInMemoryCache<EligibilityConfiguration>>();
        private readonly Mock<IConfiguration> mockConfig = new Mock<IConfiguration>();
        private readonly Mock<IUvciGenerator> mockUvciGenerator = new Mock<IUvciGenerator>();
        private string idToken;

        public DomesticExemptionCertificateGeneratorTest()
        {
            idToken = "dummytoken";
            mockConfig.SetupGet<string>(m => m["GetTestResultsFlag"]).Returns("true");
            mockConfig.SetupGet<string>(m => m["GetAntibodyResultsFlag"]).Returns("true");
            service = new DomesticExemptionCertificateGenerator(
                loggerMock.Object,
                QRCodeGeneratorMock.Object,
                mockEligibilityService.Object,
                mockUvciGenerator.Object,
                CreateConfiguration()
                );
        }

        [Fact]
        public async Task CanGenerateCertificate()
        {
            // Arrange
            var certificateExpiresInHours = 48;
            var certificateGenerationEligibleForDays = 10000;

            mockEligibilityService.Setup(m => m.GetFile()).ReturnsAsync(
                new EligibilityConfiguration(It.IsAny<IEnumerable<EligibilityRules>>(), new EligibilityDomesticExemptions(certificateExpiresInHours))
                );

            CovidPassportUser user = new CovidPassportUser("Test McTestPerson", DateTime.UtcNow.AddYears(-20), "test@test.com", "0123456789", "0000000000");

            QRCodeGeneratorMock.Setup(m => m.GenerateQRCodeForCertificate(It.IsAny<Certificate>())).ReturnsAsync((string)null);
            mockUvciGenerator.Setup(x => x.TryGenerateAndInsertUvci(It.IsAny<GenerateAndInsertUvciCommand>()))
                .ReturnsAsync("test:uvci");

            // Act
            var certificate = await service.GenerateCertificate(user);

            // Assert
            Assert.Equal(CertificateType.Exemption, certificate.CertificateType);
            Assert.Equal(DateTime.UtcNow.AddDays(certificateGenerationEligibleForDays).Date, certificate.eligibilityEndDate.Date);
            Assert.Equal(DateTime.UtcNow.AddHours(certificateExpiresInHours).Date, certificate.validityEndDate.Date);
        }

        private IConfigurationRoot CreateConfiguration()
        {
            var inMemoryConfiguration = new Dictionary<string, string> {
                {"CountryOfIssuer", "GB"},
                {"UVCIPrefix", "URN"},
                {"UVCIVersion", "verion"}
            };

            return new ConfigurationBuilder()
                .AddInMemoryCollection(inMemoryConfiguration)
                .Build();
        }

    }
}
