﻿using CovidCertificate.Backend.Interfaces.BlobService;
using CovidCertificate.Backend.Utils;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services
{
    public class BlobFilesInMemoryCache<T> : IBlobFilesInMemoryCache<T> where T : class, new()
    {
        private readonly string blobContainer;
        private readonly string blobName;
        private readonly ILogger<BlobFilesInMemoryCache<T>> logger;
        private readonly IConfiguration configuration;
        private readonly AsyncLock blobMutex = new AsyncLock();
        private T blob;
        private DateTime cacheExpiry;
        private bool cacheValid => cacheExpiry > DateTime.UtcNow && blob != null;
        private readonly IBlobService blobService;

        public BlobFilesInMemoryCache(ILogger<BlobFilesInMemoryCache<T>> logger, IConfiguration configuration, IBlobService blobService)
        {
            this.logger = logger;
            this.configuration = configuration;
            this.blobService = blobService;

            blobContainer = configuration[$"BlobContainerName{typeof(T).ToString().Split('.').Last()}"];
            blobName = configuration[$"BlobFileName{typeof(T).ToString().Split('.').Last()}"];
        }
        public async Task<T> GetFile()
        {
            logger.LogInformation($"{nameof(BlobFilesInMemoryCache<T>)} was invoked.");

            if (cacheValid)
            {
                logger.LogInformation($"{nameof(BlobFilesInMemoryCache<T>)} cache is valid, returning {typeof(T)}.");

                return blob;
            }

            using(await blobMutex.LockAsync())
            {
                if (cacheValid)
                {
                    logger.LogInformation($"{nameof(BlobFilesInMemoryCache<T>)} cache is valid, returning {typeof(T)} (mutex).");

                    return blob;
                }
                logger.LogInformation("In-memory blob not found or invalid. Attempting to fetch mappings from blob storage.");

                blob = await blobService.GetObjectFromBlob<T>(blobContainer, blobName);
                cacheExpiry = DateTime.UtcNow.AddSeconds(configuration.GetValue<int?>("BlobFilesInMemoryCacheExpiryTime") ?? 600);

                return blob;
            }            
        }
    }
}
