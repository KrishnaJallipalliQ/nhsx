﻿using System;

namespace CovidCertificate.Backend.Models.ResponseDtos
{
    public class RemoteCovidStatusResponseDto
    {
        public string CertificationStatus { get; set; }
        public DateTime? CertificationExpiry { get; set; }
    }
}
