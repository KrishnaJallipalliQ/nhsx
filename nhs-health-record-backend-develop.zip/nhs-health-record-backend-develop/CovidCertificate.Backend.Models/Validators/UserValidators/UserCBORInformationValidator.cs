﻿using CovidCertificate.Backend.Models.Interfaces.UserInterfaces;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.Validators.UserValidators
{
    public class UserCBORInformationValidator : AbstractValidator<IUserCBORInformation>
    {
        public UserCBORInformationValidator()
        {
            #region FamilyName Rules

            RuleFor(x => x.FamilyName).NotEmpty().OnFailure(x =>
            {
                throw new ValidationException("A familyName was not specified.");
            });


            RuleFor(x => x.FamilyName.Length).LessThanOrEqualTo(255).OnFailure(x =>
            {
                throw new ValidationException("A familyName must not exceed the character limit of 255.");
            });

            #endregion
            #region GivenName Rules

            RuleFor(x => x.GivenName).NotEmpty().OnFailure(x =>
            {
                throw new ValidationException("A givenName was not specified.");
            });

            RuleFor(x => x.GivenName.Length).LessThanOrEqualTo(255).OnFailure(x =>
            {
                throw new ValidationException("A givenName must not exceed the character limit of 255.");
            });

            #endregion
        }
    }
}
