﻿using CovidCertificate.Backend.Models.DataModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IAntibodyResultsService
    {
        public Task<IEnumerable<AntibodyResultNhs>> GetAntibodyResults(string idToken);
    }
}
