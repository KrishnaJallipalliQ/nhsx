﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Tests.TestHelpers;
using FluentValidation;
using System;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Tests.ValidatorTests
{
    public class AntibodyRequestDtoValidatorTests
    {
        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public async Task ValidateObjectAndThrowOnFailuresAsync_ValidAntibodyRequestDto_ShouldNotThrow(CovidPassportUser user)
        {
            // Arrange
            var antibodyRequestDto = AntibodyTestHelper.CreateAntibodyRequestDto(user);

            // Act
            Func<Task> act = async () => await antibodyRequestDto.ValidateObjectAndThrowOnFailuresAsync();

            // Assert
            var ex = await Record.ExceptionAsync(act);
            Assert.Null(ex);
        }
      

        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public async Task ValidateObjectAndThrowOnFailuresAsync_FutureDateTimeOfTest(CovidPassportUser user)
        {
            // Arrange
            var validAntibodyRequestDto = AntibodyTestHelper.CreateAntibodyRequestDto(user);
            validAntibodyRequestDto.DateTimeOfTest = DateTime.UtcNow;

            var invalidAntibodyRequestDto = AntibodyTestHelper.CreateAntibodyRequestDto(user);
            invalidAntibodyRequestDto.DateTimeOfTest = DateTime.UtcNow.AddHours(1);

            // Act
            Func<Task> actValid = async () => await validAntibodyRequestDto.ValidateObjectAndThrowOnFailuresAsync();
            Func<Task> actInvalid = async () => await invalidAntibodyRequestDto.ValidateObjectAndThrowOnFailuresAsync();

            // Assert
            var exValidDto = await Record.ExceptionAsync(actValid);
            Assert.Null(exValidDto);

            var exInvalidDto = await Assert.ThrowsAsync<ValidationException>(actInvalid);
            Assert.Equal("The date of the test cannot be in the future.", exInvalidDto.Message);
        }

        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public async Task ValidateObjectAndThrowOnFailuresAsync_PastDateTimeOfTest(CovidPassportUser user)
        {
            // Arrange
            var validAntibodyRequestDto = AntibodyTestHelper.CreateAntibodyRequestDto(user);
            validAntibodyRequestDto.DateTimeOfTest = new DateTime(2020, 1, 1, 0, 0, 0, DateTimeKind.Utc);

            var invalidAntibodyRequestDto = AntibodyTestHelper.CreateAntibodyRequestDto(user);
            invalidAntibodyRequestDto.DateTimeOfTest = new DateTime(2020, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddTicks(-1);

            // Act
            Func<Task> actValid = async () => await validAntibodyRequestDto.ValidateObjectAndThrowOnFailuresAsync();
            Func<Task> actInvalid = async () => await invalidAntibodyRequestDto.ValidateObjectAndThrowOnFailuresAsync();

            // Assert
            var exValidDto = await Record.ExceptionAsync(actValid);
            Assert.Null(exValidDto);

            var exInvalidDto = await Assert.ThrowsAsync<ValidationException>(actInvalid);
            Assert.Equal("The date of the test cannot be before the year 2020.", exInvalidDto.Message);
        }

        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public async Task ValidateObjectAndThrowOnFailuresAsync_TestTypeEmptyAndNull(CovidPassportUser user)
        {
            // Arrange
            var antibodyRequestDtoEmptyTestType = AntibodyTestHelper.CreateAntibodyRequestDto(user);
            antibodyRequestDtoEmptyTestType.TestType = string.Empty;

            var antibodyRequestDtoNullTestType = AntibodyTestHelper.CreateAntibodyRequestDto(user);
            antibodyRequestDtoNullTestType.TestType = null;

            // Act
            Func<Task> actEmptyTestType = async () => await antibodyRequestDtoEmptyTestType.ValidateObjectAndThrowOnFailuresAsync();
            Func<Task> actNullTestType = async () => await antibodyRequestDtoNullTestType.ValidateObjectAndThrowOnFailuresAsync();

            // Assert
            var exEmptyTestType = await Assert.ThrowsAsync<ValidationException>(actEmptyTestType);
            Assert.Equal("The test type must be specified.", exEmptyTestType.Message);

            var exNullTestType = await Assert.ThrowsAsync<ValidationException>(actNullTestType);
            Assert.Equal("The test type must be specified.", exNullTestType.Message);
        }

        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public async Task ValidateObjectAndThrowOnFailuresAsync_InvalidTestResult(CovidPassportUser user)
        {
            // Arrange
            var antibodyRequestDto = AntibodyTestHelper.CreateAntibodyRequestDto(user);
            antibodyRequestDto.TestResult = "INVALID";

            // Act
            Func<Task> act = async () => await antibodyRequestDto.ValidateObjectAndThrowOnFailuresAsync();

            // Assert
            var ex = await Assert.ThrowsAsync<ValidationException>(act);
            Assert.Equal("Invalid test type, must be : positive,negative,void", ex.Message);
        }    
    }
}
