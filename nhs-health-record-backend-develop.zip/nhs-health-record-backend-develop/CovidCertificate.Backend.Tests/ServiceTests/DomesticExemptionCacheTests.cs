﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.RequestDtos;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using Xunit;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using CovidCertificate.Backend.Services;
using CovidCertificate.Backend.Services.DomesticExemptions;
using Microsoft.Extensions.DependencyInjection;
using CovidCertificate.Backend.Models.Settings;
using System.Linq;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class DomesticExemptionCacheTests
    {
        private DomesticExemptionCache domesticExemptionCache;
        private readonly Mock<ILogger<DomesticExemptionCache>> mockLogger = new Mock<ILogger<DomesticExemptionCache>>();
        private readonly Mock<IConfiguration> mockConfig = new Mock<IConfiguration>();
        private readonly Mock<IServiceScopeFactory> mockServiceScopeFactory = new Mock<IServiceScopeFactory>();
        private readonly Mock<IRedisCacheService> mockRedisCacheService = new Mock<IRedisCacheService>();
        private readonly Mock<ILogger<MongoRepository<DomesticExemption>>> mockMongoLogger = new Mock<ILogger<MongoRepository<DomesticExemption>>>();
        private readonly Mock<IMongoRepository<DomesticExemption>> mockMongoRepo = new Mock<IMongoRepository<DomesticExemption>>();
        private readonly string cacheKeyExemptions = "DomesticExemptions:AllExemptions";
        private readonly DomesticExemptionSettings settings = new DomesticExemptionSettings();


        public DomesticExemptionCacheTests()
        {
            mockConfig.SetupGet(m => m["VaccineMapperCacheTime"]).Returns("10");
            settings.InMemoryTimeToLiveSeconds = 10;

            domesticExemptionCache = new DomesticExemptionCache(
                mockLogger.Object,
                mockServiceScopeFactory.Object,
                mockRedisCacheService.Object,
                mockConfig.Object,
                settings
                );
        }

        [Fact]
        public async Task DomesticExemptionCache_FromMemory()
        {
            //Arrange
            var exemptions = new List<DomesticExemption>
            {
                new DomesticExemptionDto("1234567890", DateTime.Now, "test").ToDomesticExemption()
            };

            mockRedisCacheService.Setup(x => x.AddKeyAsync(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<RedisLifeSpanLevel>())).Verifiable();
            mockRedisCacheService.Setup(x => x.GetKeyValueAsync<IEnumerable<DomesticExemption>>(It.IsAny<string>())).ReturnsAsync((exemptions, true)).Verifiable();

            //Act
            await mockRedisCacheService.Object.AddKeyAsync(cacheKeyExemptions, exemptions, RedisLifeSpanLevel.Short);
            var redisCacheExemptions = await domesticExemptionCache.GetDomesticExemptions();

            mockRedisCacheService.Setup(x => x.GetKeyValueAsync<IEnumerable<DomesticExemption>>(It.IsAny<string>())).ReturnsAsync((null, true)).Verifiable();
            var memoryExemptions = await domesticExemptionCache.GetDomesticExemptions();

            //Assert
            Assert.Equal(exemptions.ToDictionary(x => x.NhsDobHash), memoryExemptions);
        }

        [Fact]
        public async Task DomesticExemptionCache_FromRedis()
        {
            //Arrange
            var exemptions = new List<DomesticExemption>
            {
                new DomesticExemptionDto("1234567890", DateTime.Now, "test").ToDomesticExemption()
            };

            mockRedisCacheService.Setup(x => x.AddKeyAsync(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<RedisLifeSpanLevel>())).Verifiable();
            mockRedisCacheService.Setup(x => x.GetKeyValueAsync<IEnumerable<DomesticExemption>>(It.IsAny<string>())).ReturnsAsync((exemptions, true)).Verifiable();

            //Act
            await mockRedisCacheService.Object.AddKeyAsync(cacheKeyExemptions, exemptions, RedisLifeSpanLevel.Short);

            var redisCacheExemptions = await domesticExemptionCache.GetDomesticExemptions();

            //Assert
            mockRedisCacheService.Verify(x => x.GetKeyValueAsync<IEnumerable<DomesticExemption>>(It.IsAny<string>()), Times.Once);
            Assert.Equal(exemptions.ToDictionary(x => x.NhsDobHash), redisCacheExemptions);
        }

        [Fact]
        public async Task DomesticExemptionCache_FromDatabase()
        {
            //Arrange
            var exemptions = new List<DomesticExemption>
            {
                new DomesticExemptionDto("1234567890", DateTime.Now, "test").ToDomesticExemption()
            };

            mockMongoRepo.Setup(m => m.FindAllAsync(It.IsAny<Expression<Func<DomesticExemption, bool>>>())).ReturnsAsync(exemptions);

            var serviceProvider = new Mock<IServiceProvider>();
            serviceProvider
                .Setup(x => x.GetService(typeof(IMongoRepository<DomesticExemption>)))
                .Returns(mockMongoRepo.Object);

            var serviceScope = new Mock<IServiceScope>();
            serviceScope.Setup(x => x.ServiceProvider).Returns(serviceProvider.Object);

            mockServiceScopeFactory
                .Setup(x => x.CreateScope())
                .Returns(serviceScope.Object);

            domesticExemptionCache = new DomesticExemptionCache(
                mockLogger.Object,
                mockServiceScopeFactory.Object,
                mockRedisCacheService.Object,
                mockConfig.Object,
                settings
                );

            //Act
            var databaseExemptions = await domesticExemptionCache.GetDomesticExemptions();

            //Assert
            mockMongoRepo.Verify(x => x.FindAllAsync(It.IsAny<Expression<Func<DomesticExemption, bool>>>()), Times.Once);
            Assert.Equal(exemptions.ToDictionary(x => x.NhsDobHash), databaseExemptions);
        }
    }
}
