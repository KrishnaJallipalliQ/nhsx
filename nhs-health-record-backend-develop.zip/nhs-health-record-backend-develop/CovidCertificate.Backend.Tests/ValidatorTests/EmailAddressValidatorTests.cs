﻿using CovidCertificate.Backend.Models.Validators;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Tests.ValidatorTests
{
    public class EmailAddressValidatorTests
    {
        private readonly EmailAddressValidator validator;
        public EmailAddressValidatorTests()
        {
            validator = new EmailAddressValidator();
        }

        [Theory]
        [InlineData("test@test.com")]
        [InlineData("test@test.co.uk")]
        [InlineData("t.est@test.co.uk")]
        [InlineData("te+st@test.co.uk")]
        public async Task ValidateAsync_ValidateValidEmailAddress_ReturnsTrue(string email)
        {
            // Arrange

            // Act
            var result = await validator.ValidateAsync(email);

            // Assert
            Assert.True(result.IsValid);
            Assert.Equal(0, result.Errors.Count);
        }

        [Theory]
        [InlineData("")]
        [InlineData("t")]
        [InlineData("@t.com")]
        [InlineData("te st@test.co.uk")]
        public async Task ValidateAsync_ValidateInValidEmailAddress_ReturnsFalse(string email)
        {
            // Arrange

            // Act
            var result = await validator.ValidateAsync(email);

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count > 0);
        }
    }
}
