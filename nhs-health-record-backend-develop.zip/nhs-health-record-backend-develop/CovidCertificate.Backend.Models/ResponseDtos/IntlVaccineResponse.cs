﻿using CovidCertificate.Backend.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.ResponseDtos
{
    public class IntlVaccineResponse: Vaccine
    {
        public string QRCode;

        public IntlVaccineResponse(Vaccine v, string qr):base(v)
        {

            QRCode = qr;

        }
    }
}
