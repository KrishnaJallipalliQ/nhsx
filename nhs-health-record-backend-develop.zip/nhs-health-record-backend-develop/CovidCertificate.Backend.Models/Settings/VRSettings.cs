﻿
namespace CovidCertificate.Backend.Models.Settings
{
    public class VRSettings
    {
        public string RegistryUrl { get; set; }
        public string TokenUrl { get; set; }
        public string SubscriptionKey { get; set; }
        public string ClientID { get; set; }
        public string ClientSecretKey { get; set; }
        public string Scope { get; set; }
    }
}
