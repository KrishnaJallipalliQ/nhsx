using CovidCertificate.Backend.DASigningService.ErrorHandling;
using CovidCertificate.Backend.DASigningService.Tests.ValidatorTests.TestHelpers;
using CovidCertificate.Backend.DASigningService.Validators;
using CovidCertificate.Backend.Utils;
using Hl7.Fhir.Model;
using System;
using Xunit;

namespace CovidCertificate.Backend.DASigningService.Tests
{
    public class FhirPatientValidatorTests
    {
        private static readonly FhirPatientValidator fhirPatientValidator = new FhirPatientValidator();

        [Fact]
        public void Validate_WhenPatientNameIsEmpty_ReturnError()
        {
            // Arrange
            var mockPatient = FhirPatientValidatorTestHelper.CreateValidMockPatient();
            mockPatient.Name.RemoveAt(0);

            // Act
            var patientValidationResult = fhirPatientValidator.Validate(mockPatient);

            //Assert
            Assert.Equal(ErrorCode.FHIR_PATIENT_NAME_MISSING.ToString(StringUtils.NumberFormattedEnumFormat),
                                                                      patientValidationResult.Errors[0].ErrorCode.ToString());
            Assert.Equal("Patient name missing.", patientValidationResult.Errors[0].ErrorMessage);
        }

        [Fact]
        public void Validate_PatientGivenNameMissing_ReturnError()
        {
            // Arrange
            var mockPatient = FhirPatientValidatorTestHelper.CreateValidMockPatient();
            mockPatient.Name[0].Given = new HumanName().Given;

            // Act
            var patientValidationResult = fhirPatientValidator.Validate(mockPatient);

            //Assert
            Assert.Equal(ErrorCode.FHIR_PATIENT_GIVEN_NAME_MISSING.ToString(StringUtils.NumberFormattedEnumFormat),
                                                                        patientValidationResult.Errors[0].ErrorCode.ToString());
            Assert.Equal("Patient.Name[0].Given missing.", patientValidationResult.Errors[0].ErrorMessage);
        }

        [Fact]
        public void Validate_PatientFamilyNameMissing_ReturnError()
        {
            // Arrange
            var mockPatient = FhirPatientValidatorTestHelper.CreateValidMockPatient();
            mockPatient.Name[0].Family = new HumanName().Family;

            // Act
            var patientValidationResult = fhirPatientValidator.Validate(mockPatient);

            //Assert
            Assert.Equal(ErrorCode.FHIR_PATIENT_FAMILY_NAME_MISSING.ToString(StringUtils.NumberFormattedEnumFormat),
                                                                        patientValidationResult.Errors[0].ErrorCode.ToString());
            Assert.Equal("Patient.Name[0].Family missing.", patientValidationResult.Errors[0].ErrorMessage);
        }

        [Fact]
        public void Validate_PatientBirthDateMissing_ReturnError()
        {
            // Arrange
            var mockPatient = FhirPatientValidatorTestHelper.CreateValidMockPatient();
            mockPatient.BirthDate = "";

            // Act
            var patientValidationResult = fhirPatientValidator.Validate(mockPatient);

            //Assert
            Assert.Equal(ErrorCode.FHIR_PATIENT_BIRTHDATE_MISSING.ToString(StringUtils.NumberFormattedEnumFormat),
                                                                        patientValidationResult.Errors[0].ErrorCode.ToString());
            Assert.Equal("Patient.BirthDate missing.", patientValidationResult.Errors[0].ErrorMessage);
        }

        [Fact]
        public void Validate_PatientMissing_ReturnError()
        {
            // Arrange
            Patient mockPatient = null;

            // Act
            var patientValidationResult = fhirPatientValidator.Validate(mockPatient);

            //Assert
            Assert.Equal(ErrorCode.FHIR_PATIENT_MISSING.ToString(StringUtils.NumberFormattedEnumFormat),
                                                                        patientValidationResult.Errors[0].ErrorCode.ToString());
            Assert.Equal("Patient missing.", patientValidationResult.Errors[0].ErrorMessage);

        }
    }
}
