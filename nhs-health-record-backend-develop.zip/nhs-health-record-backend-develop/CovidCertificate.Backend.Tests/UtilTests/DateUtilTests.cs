﻿using CovidCertificate.Backend.Utils.Extensions;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace CovidCertificate.Backend.Tests.UtilTests
{
    public class DateUtilTests
    {
        [Fact]
        public void Get_Database_Name_For_10_12_2020_Expect_Success()
        {
            var date = new DateTime(2020, 12, 10);
            var dbName = date.GetDatabaseName();

            Assert.Equal("2020_50", dbName);
        }

        [Fact]
        public void Get_Database_Name_For_01_01_2020_Expect_Success()
        {
            var date = new DateTime(2020, 1, 1);
            var dbName = date.GetDatabaseName();

            Assert.Equal("2020_1", dbName);
        }

    }
}
