using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.NhsApiIntegration.Interfaces;
using Hl7.Fhir.Model;
using Hl7.Fhir.Serialization;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.Protected;
using nhs.vaccination.registry.externalApiIntegration.Services;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Xunit;
using System.Linq;
using Task = System.Threading.Tasks.Task;
using Microsoft.Extensions.Configuration;
using CovidCertificate.Backend.Models;
using System.IdentityModel.Tokens.Jwt;
using Polly.Timeout;

namespace CovidCertificate.Backend.NhsApiIntegration.Tests
{
    public class NhsdFhirApiServiceTests
    {
        private readonly string identityToken = "eyJzdWIiOiI0Y2JkZThkZC00NjA2LTRiNjUtYThhYy0wM2JiZjMwMTNkNWIiLCJhdWQiOiJoZWFsdGhyZWNvcmRzIiwia2lkIjoiZjYwZWI0NmZmOGFiZjBiZjllOTE3ZWVlNjA4NmM1ZmE0YTE2MmE1ZCIsImlzcyI6Imh0dHBzOi8vYXV0aC5hb3Muc2lnbmluLm5ocy51ayIsInR5cCI6IkpXVCIsImV4cCI6MTYyMTMzMzIyOSwiaWF0IjoxNjIxMzI5NjI5LCJhbGciOiJSUzUxMiIsImp0aSI6ImNjODNjYTYxLWM0MDQtNDY0OC05NDljLTZkYjNkOTVhOTNhOCJ9.eyJzdWIiOiI0Y2JkZThkZC00NjA2LTRiNjUtYThhYy0wM2JiZjMwMTNkNWIiLCJiaXJ0aGRhdGUiOiIxOTE4LTA2LTI4IiwibmhzX251bWJlciI6Ijk2NTg0Nzc4NjAiLCJpc3MiOiJodHRwczovL2F1dGguYW9zLnNpZ25pbi5uaHMudWsiLCJ2dG0iOiJodHRwczovL2F1dGguYW9zLnNpZ25pbi5uaHMudWsvdHJ1c3RtYXJrL2F1dGguYW9zLnNpZ25pbi5uaHMudWsiLCJhdWQiOiJoZWFsdGhyZWNvcmRzIiwiaWRfc3RhdHVzIjoidmVyaWZpZWQiLCJ0b2tlbl91c2UiOiJpZCIsInN1cm5hbWUiOiJHQU5URVMiLCJhdXRoX3RpbWUiOjE2MjEzMjk2MjYsInZvdCI6IlA5LkNwLkNkIiwiaWRlbnRpdHlfcHJvb2ZpbmdfbGV2ZWwiOiJQOSIsImV4cCI6MTYyMTMzMzIyOSwiaWF0IjoxNjIxMzI5NjI5LCJmYW1pbHlfbmFtZSI6IkdBTlRFUyIsImp0aSI6ImNjODNjYTYxLWM0MDQtNDY0OC05NDljLTZkYjNkOTVhOTNhOCJ9.rTwK5-m1RLciOYKaDj2StAPF1C5IuBaTQV9BARNxXTKisraGXrbKs1jAyfY3iZOofmfbCMjC3vfFCE1hxrM9ZrZHhN--ZEkzx8xASF12JbLQ5Qpidq_GFnYQhIM49BxrmW4y7ojp2VEuMbrDjinJ8NcnIOtIrgknMevmRp-PkJgUkbVVe3jKmn6w-zboW9nYm0v0xi2-D--HFtRIld-0yJf_bISY_sxuVDivSiQ6A9bda7QCiN9SAOPi_rCt-1s9yZ9ShXPZ1LTpz6mXDHUQTtQZlZo_ZXqQRI4E9DMEBxFkC86U5vqZszB6EyurexDcpp3NHdc32hEjO1YPEm6VWw";
        Mock<HttpMessageHandler> nhsdApiHandlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
        Mock<ILogger<NhsdFhirApiService>> loggerMock = new Mock<ILogger<NhsdFhirApiService>>();

        private void MockSetup(StringContent stringContent, HttpStatusCode statusCode, out IConfiguration configuration, out HttpClient httpClient)
        {
            var inMemoryConfiguration = new Dictionary<string, string> {
                { "NhsBaseUrl", "test-3" },
                { "UseDiagnosticHistoryMock", "false" },
                { "UseAccessTokenUserRestrictedMode", "true" },
                { "NhsDiagnosticApiRetryCount", "1" },
                { "NhsDiagnosticApiRetrySleepDurationInMilliseconds", "500" },
                { "NhsDiagnosticApiTimeoutInMilliseconds", "90" }
            };
            configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemoryConfiguration)
                .Build();
            nhsdApiHandlerMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = statusCode,
                    Content = stringContent,
                })
                .Verifiable();
            httpClient = new HttpClient(nhsdApiHandlerMock.Object)
            {
                BaseAddress = new Uri("http://test.com/"),
            };
        }

        private void MockExceptionSetup(out IConfiguration configuration, out HttpClient httpClient, Exception exception)
        {
            var inMemoryConfiguration = new Dictionary<string, string> {
                { "NhsBaseUrl", "test-3" },
                { "UseDiagnosticHistoryMock", "false" },
                { "UseAccessTokenUserRestrictedMode", "true" },
                { "NhsDiagnosticApiRetryCount", "1" },
                { "NhsDiagnosticApiRetrySleepDurationInMilliseconds", "500" },
                { "NhsDiagnosticApiTimeoutInMilliseconds", "90" }
            };
            configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemoryConfiguration)
                .Build();

            nhsdApiHandlerMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ThrowsAsync(exception)
                .Verifiable();
            httpClient = new HttpClient(nhsdApiHandlerMock.Object)
            {
                BaseAddress = new Uri("http://test.com/"),
            };
        }

        [Fact]
        public async Task SuccessResponseFromClient_EmptyBundle()
        {
            // Arrange
            var bundle = new Bundle()
            {
                Total = 0,
                Type = Bundle.BundleType.Searchset
            };

            var loggerMock = new Mock<ILogger<NhsdFhirApiService>>();

            var stringContent = new StringContent(FHIRSerializer.Serialize(bundle));
            MockSetup(stringContent, HttpStatusCode.OK, out IConfiguration configuration, out HttpClient httpClient);

            var settings = CreateSettings();

            var accessTokenServiceMock = new Mock<INhsTestResultsHistoryApiAccessTokenService>();
            accessTokenServiceMock.Setup(x => x.GetAccessTokenAsync(It.IsAny<string>())).ReturnsAsync("token");

            var nhsdFhirApiService = new NhsdFhirApiService(loggerMock.Object, httpClient, settings, accessTokenServiceMock.Object);

            // Act
            var antibodyTestResults = await nhsdFhirApiService.GetAntibodyTestResults(identityToken);

            // Assert
            accessTokenServiceMock.Verify(x => x.GetAccessTokenAsync(It.IsAny<string>()), Times.Once);
            Assert.True(bundle.Matches(antibodyTestResults));
        }


        [Fact]
        public async Task SuccessResponseFromClient_AntibodyResultsInBundle()
        {
            // Arrange
            var bundle = new Bundle()
            {
                Entry = new List<Bundle.EntryComponent>() { new Bundle.EntryComponent() { Resource = new Observation() } },
                Total = 1,
                Type = Bundle.BundleType.Searchset
            };

            var loggerMock = new Mock<ILogger<NhsdFhirApiService>>();

            var stringContent = new StringContent(FHIRSerializer.Serialize(bundle));
            MockSetup(stringContent, HttpStatusCode.OK, out IConfiguration configuration, out HttpClient httpClient);

            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(new FhirJsonSerializer().SerializeToString(bundle)),
                })
                .Verifiable();

            var settings = CreateSettings();

            var accessTokenServiceMock = new Mock<INhsTestResultsHistoryApiAccessTokenService>();
            accessTokenServiceMock.Setup(x => x.GetAccessTokenAsync(It.IsAny<string>())).ReturnsAsync("token");

            var nhsdFhirApiService = new NhsdFhirApiService(loggerMock.Object, httpClient, settings, accessTokenServiceMock.Object);

            // Act
            var antibodyTestResults = await nhsdFhirApiService.GetAntibodyTestResults(identityToken);

            // Assert
            accessTokenServiceMock.Verify(x => x.GetAccessTokenAsync(It.IsAny<string>()), Times.Once);
            Assert.True(bundle.Matches(antibodyTestResults));
        }

        [Fact]
        public async Task SuccessResponseFromClient_AntibodyResultsInBundle_WithSensitiveData()
        {
            // Arrange
            var nhsId = "1234567890";

            var bundle = new Bundle()
            {
                Entry = new List<Bundle.EntryComponent>() {
                    new Bundle.EntryComponent(){
                        Resource = new Observation(){
                            Subject = new ResourceReference()
                            {
                                Identifier = new Identifier(){
                                    Value = nhsId,
                                },
                            },
                        }
                    }
                    },
                Total = 1,
                Type = Bundle.BundleType.Searchset
            };

            var stringContent = new StringContent(FHIRSerializer.Serialize(bundle));
            MockSetup(stringContent, HttpStatusCode.OK, out IConfiguration configuration, out HttpClient httpClient);

            var loggerMock = new Mock<ILogger<NhsdFhirApiService>>();

            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(new FhirJsonSerializer().SerializeToString(bundle)),
                })
                .Verifiable();

            var settings = CreateSettings();

            var accessTokenServiceMock = new Mock<INhsTestResultsHistoryApiAccessTokenService>();
            accessTokenServiceMock.Setup(x => x.GetAccessTokenAsync(It.IsAny<string>())).ReturnsAsync("token");

            var nhsdFhirApiService = new NhsdFhirApiService(loggerMock.Object, httpClient, settings, accessTokenServiceMock.Object);

            // Act
            var antibodyTestResults = await nhsdFhirApiService.GetAntibodyTestResults(identityToken);

            // Assert
            var resource = (Observation) antibodyTestResults.Entry.First().Resource;
            Assert.NotEqual(nhsId, resource.Subject.Identifier.Value);
        }

        [Fact]
        public void UnauthorisedResponseFromClient_ShouldThrowException()
        {
            // Arrange
            var loggerMock = new Mock<ILogger<NhsdFhirApiService>>();

            var stringContent = new StringContent("error");
            MockSetup(stringContent, HttpStatusCode.Unauthorized, out IConfiguration configuration, out HttpClient httpClient);
            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);

            handlerMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.Unauthorized,
                    Content = new StringContent("Unauthorized"),
                })
                .Verifiable();

            var settings = CreateSettings();

            var accessTokenServiceMock = new Mock<INhsTestResultsHistoryApiAccessTokenService>();
            accessTokenServiceMock.Setup(x => x.GetAccessTokenAsync(It.IsAny<string>())).ReturnsAsync("token");


            var nhsdFhirApiService = new NhsdFhirApiService(loggerMock.Object, httpClient, settings, accessTokenServiceMock.Object);

            // Act
            var antibodyTestResults = Assert.ThrowsAsync<Exception>(() => nhsdFhirApiService.GetAntibodyTestResults(identityToken));

            // Assert
            accessTokenServiceMock.Verify(x => x.GetAccessTokenAsync(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task ErrorResponseFromClientWithTimeoutPolicy()
        {
            // Arrange
            var bundle = new Bundle()
            {
                Type = Bundle.BundleType.Searchset,
                Total = 0
            };
            var stringContent = new StringContent(FHIRSerializer.Serialize(bundle));
            MockExceptionSetup(out IConfiguration configuration, out HttpClient httpClient, new TimeoutRejectedException("Timeout"));
            //MockSetup(stringContent, HttpStatusCode.InternalServerError, out IConfiguration configuration, out HttpClient httpClient);
            var token = CreateToken("nhsd_number", "test");

            httpClient = new HttpClient(nhsdApiHandlerMock.Object)
            {
                BaseAddress = new Uri("http://test.com/"),
            };

            var accessTokenServiceMock = new Mock<INhsTestResultsHistoryApiAccessTokenService>();
            accessTokenServiceMock.Setup(x => x.GetAccessTokenAsync(It.IsAny<string>())).ReturnsAsync("token");

            var settings = CreateSettings();
            var nhsdFhirApiService = new NhsdFhirApiService(loggerMock.Object, httpClient, settings, accessTokenServiceMock.Object);

            // Act
            var exception =
                await Assert.ThrowsAsync<TimeoutRejectedException>(() => nhsdFhirApiService.GetDiagnosticTestResults(token));

            // Assert
            accessTokenServiceMock.Verify(x => x.GetAccessTokenAsync(It.IsAny<string>()), Times.Once);
            nhsdApiHandlerMock.Protected().Verify("SendAsync", Times.Exactly(settings.NhsDiagnosticApiRetryCount + 1), ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>());
        }

        [Fact]
        public async Task ErrorResponseFromClientWithTimeoutPolicyAntibody()
        {
            // Arrange
            var bundle = new Bundle()
            {
                Type = Bundle.BundleType.Searchset,
                Total = 0
            };
            var stringContent = new StringContent(FHIRSerializer.Serialize(bundle));
            MockExceptionSetup(out IConfiguration configuration, out HttpClient httpClient, new TimeoutRejectedException("Timeout"));
            //MockSetup(stringContent, HttpStatusCode.InternalServerError, out IConfiguration configuration, out HttpClient httpClient);
            var token = CreateToken("nhsd_number", "test");

            var accessTokenServiceMock = new Mock<INhsTestResultsHistoryApiAccessTokenService>();
            accessTokenServiceMock.Setup(x => x.GetAccessTokenAsync(It.IsAny<string>())).ReturnsAsync("token");

            var settings = CreateSettings();
            var nhsdFhirApiService = new NhsdFhirApiService(loggerMock.Object, httpClient, settings, accessTokenServiceMock.Object);

            // Act
            var exception =
                await Assert.ThrowsAsync<TimeoutRejectedException>(() => nhsdFhirApiService.GetAntibodyTestResults(token));

            // Assert
            accessTokenServiceMock.Verify(x => x.GetAccessTokenAsync(It.IsAny<string>()), Times.Once);
            nhsdApiHandlerMock.Protected().Verify("SendAsync", Times.Exactly(settings.NhsDiagnosticApiRetryCount + 1), ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>());
        }

        [Fact]
        public async Task SuccessResponseFromClientWithTimeoutPolicyAntibody()
        {
            // Arrange
            var bundle = new Bundle()
            {
                Type = Bundle.BundleType.Searchset,
                Total = 0
            };
            var stringContent = new StringContent(FHIRSerializer.Serialize(bundle));
            MockSetup(stringContent, HttpStatusCode.InternalServerError, out IConfiguration configuration, out HttpClient httpClient);
            var token = CreateToken("nhsd_number", "test");
            nhsdApiHandlerMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .Returns(async () =>
                {
                    return new HttpResponseMessage()
                    {
                        StatusCode = HttpStatusCode.OK,
                        Content = stringContent,
                    };
                })
                .Verifiable();
            httpClient = new HttpClient(nhsdApiHandlerMock.Object)
            {
                BaseAddress = new Uri("http://test.com/"),
            };

            var accessTokenServiceMock = new Mock<INhsTestResultsHistoryApiAccessTokenService>();
            accessTokenServiceMock.Setup(x => x.GetAccessTokenAsync(It.IsAny<string>())).ReturnsAsync("token");
            var settings = CreateSettings();
            var nhsdFhirApiService = new NhsdFhirApiService(loggerMock.Object, httpClient, settings, accessTokenServiceMock.Object);

            // Act
            var result = await nhsdFhirApiService.GetAntibodyTestResults(token);

            // Assert
            Assert.IsType<Bundle>(result);
            accessTokenServiceMock.Verify(x => x.GetAccessTokenAsync(It.IsAny<string>()), Times.Once);
            nhsdApiHandlerMock.Protected().Verify("SendAsync", Times.Once(), ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>());
        }

        [Fact]
        public async Task SuccessResponseFromClientWithTimeoutPolicy()
        {
            // Arrange
            var bundle = new Bundle()
            {
                Type = Bundle.BundleType.Searchset,
                Total = 0
            };
            var stringContent = new StringContent(FHIRSerializer.Serialize(bundle));
            MockSetup(stringContent, HttpStatusCode.InternalServerError, out IConfiguration configuration, out HttpClient httpClient);

            var token = CreateToken("nhsd_number", "test");
            nhsdApiHandlerMock
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .Returns(async () =>
                {
                    return new HttpResponseMessage()
                    {
                        StatusCode = HttpStatusCode.OK,
                        Content = stringContent,
                    };
                })
                .Verifiable();
            httpClient = new HttpClient(nhsdApiHandlerMock.Object)
            {
                BaseAddress = new Uri("http://test.com/"),
            };

            var accessTokenServiceMock = new Mock<INhsTestResultsHistoryApiAccessTokenService>();
            accessTokenServiceMock.Setup(x => x.GetAccessTokenAsync(It.IsAny<string>())).ReturnsAsync("token");
            var settings = CreateSettings();
            var nhsdFhirApiService = new NhsdFhirApiService(loggerMock.Object, httpClient, settings, accessTokenServiceMock.Object);

            // Act
            var result = await nhsdFhirApiService.GetDiagnosticTestResults(token);

            // Assert
            Assert.IsType<Bundle>(result);
            accessTokenServiceMock.Verify(x => x.GetAccessTokenAsync(It.IsAny<string>()), Times.Once);
            nhsdApiHandlerMock.Protected().Verify("SendAsync", Times.Exactly(1), ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>());
        }

        [Fact]
        public async Task InternalServerErrorResponseFromClientWithRetryPolicy()
        {
            // Arrange
            var stringContent = new StringContent("error");
            MockSetup(stringContent, HttpStatusCode.InternalServerError, out IConfiguration configuration, out HttpClient httpClient);
            var token = CreateToken("nhsd_number", "test");
            var settings = new NhsTestResultsHistoryApiSettings
            {
                NhsDiagnosticApiRetryCount = 1, 
                NhsDiagnosticApiTimeoutInMilliseconds = 3000, 
                NhsDiagnosticApiRetrySleepDurationInMilliseconds = 2000,
                DisableP9 = false,
                DisableP5 = false,
                AllowAllOtherThanP5AndP9 = true
            };
            var accessTokenServiceMock = new Mock<INhsTestResultsHistoryApiAccessTokenService>();

            accessTokenServiceMock.Setup(x => x.GetAccessTokenAsync(It.IsAny<string>())).ReturnsAsync("token");

            //Act
            var nhsdFhirApiService = new NhsdFhirApiService(loggerMock.Object, httpClient, settings, accessTokenServiceMock.Object);
            
            // Assert
            var exception =
                await Assert.ThrowsAsync<Exception>(() => nhsdFhirApiService.GetDiagnosticTestResults(token));

            accessTokenServiceMock.Verify(x => x.GetAccessTokenAsync(It.IsAny<string>()), Times.Once);
            nhsdApiHandlerMock.Protected().Verify("SendAsync", Times.Exactly(2), ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>());
        }

        private string CreateToken(string field, string value)
        {
            var jwt = new JwtSecurityToken(new JwtHeader(), new JwtPayload { { field, value } });
            return new JwtSecurityTokenHandler().WriteToken(jwt);
        }

        private NhsTestResultsHistoryApiSettings CreateSettings()
        {
            return new NhsTestResultsHistoryApiSettings
            {
                NhsDiagnosticApiRetryCount = 3, 
                NhsDiagnosticApiTimeoutInMilliseconds = 300, 
                NhsDiagnosticApiRetrySleepDurationInMilliseconds = 10, 
                DisableP9 = false,
                DisableP5 = false,
                AllowAllOtherThanP5AndP9 = true
            };
        }

    }
}
