﻿using CovidCertificate.Backend.Auth;
using CovidCertificate.Backend.Auth.Tests.TestHelpers;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.ResponseDtos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Tests.AzureFunctionsTests
{
    public class TokenTests
    {
        private readonly Token _refreshTokenFunction;
        private readonly Mock<ILogger<Token>> _loggerMock;
        private readonly NhsLoginToken _nhsLoginToken;
        private readonly Mock<INhsLoginService> _nhsLoginServiceMock;

        public TokenTests()
        {
            var nhsLoginTokenAsJson = $"{{\"access_token\": \"eyJzdWIiOiIwZWM1YzMwZS1kVrL3Ry9uZS\", \"refresh_token\": \"6e2a4324-22d2-420f-85d7-0fd8739ea20a\", \"expires_in\": \"300\"}}";
            _nhsLoginToken = JsonConvert.DeserializeObject<NhsLoginToken>(nhsLoginTokenAsJson);

            var nhsLoginServiceMock = new Mock<INhsLoginService>();
            nhsLoginServiceMock.Setup(x => x.GetAccessTokenAsync(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(_nhsLoginToken);

            this._loggerMock = new Mock<ILogger<Token>>();
            this._nhsLoginServiceMock = nhsLoginServiceMock;
            this._refreshTokenFunction = new Token(_nhsLoginServiceMock.Object, _loggerMock.Object);
        }

        [Fact]
        public async Task Run_NoAuthorizationCode()
        {
            // Arrange
            var redirectUriStr = "http://localhost/";
            var requestMock = new Mock<HttpRequest>();
            var queryCollection = new QueryCollection(new Dictionary<string, StringValues>() { { "redirectUri", redirectUriStr } });
            requestMock.Setup(x => x.Query).Returns(queryCollection);

            var expectedErrorMessage = "No authorization code was specified.";
            var expectedException = new ArgumentNullException(expectedErrorMessage);
            var expectedResponseValue = "There seems to be a problem: bad request";

            // Act
            var actualResponse = await _refreshTokenFunction.Run(requestMock.Object) as BadRequestObjectResult;

            // Assert
            requestMock.Verify(mock => mock.Query, Times.Once());
            VerifyLog(LogLevel.Warning, expectedException);

            Assert.NotNull(actualResponse);
            Assert.Equal(expectedResponseValue, actualResponse.Value);
        }

        [Fact]
        public async Task Run_NoRedirectUri()
        {
            // Arrange
            var authorizationCodeStr = "5f7a3fe7-36e5-4004-a302-aa7d2cf2988a";
            var requestMock = new Mock<HttpRequest>();
            var queryCollection = new QueryCollection(new Dictionary<string, StringValues>() { { "code", authorizationCodeStr } });
            requestMock.Setup(x => x.Query).Returns(queryCollection);

            var expectedErrorMessage = "No redirect uri was specified.";
            var expectedException = new ArgumentNullException(expectedErrorMessage);
            var expectedResponseValue = "There seems to be a problem: bad request";

            // Act
            var actualResponse = await _refreshTokenFunction.Run(requestMock.Object) as BadRequestObjectResult;

            // Assert
            requestMock.Verify(mock => mock.Query, Times.Exactly(2));
            VerifyLog(LogLevel.Warning, expectedException);

            Assert.NotNull(actualResponse);
            Assert.Equal(expectedResponseValue, actualResponse.Value);
        }

        [Fact]
        public async Task Run_ValidRequest()
        {
            // Arrange
            var authorizationCodeStr = "5f7a3fe7-36e5-4004-a302-aa7d2cf2988a";
            var redirectUriStr = "http://localhost/";
            var requestMock = new Mock<HttpRequest>();
            var queryCollection = new QueryCollection(new Dictionary<string, StringValues>() { { "code", authorizationCodeStr }, { "redirectUri", redirectUriStr } });
            requestMock.Setup(x => x.Query).Returns(queryCollection);

            // Act
            var actualResponse = await _refreshTokenFunction.Run(requestMock.Object) as OkObjectResult;
            var actualNhsLoginTokenResponse = actualResponse.Value as NhsLoginTokenResponse;

            // Assert
            requestMock.Verify(mock => mock.Query, Times.Exactly(2));
            _nhsLoginServiceMock.Verify(x => x.GetAccessTokenAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Once());

            Assert.NotNull(actualResponse);
            Assert.NotNull(actualNhsLoginTokenResponse);
            Assert.NotNull(actualNhsLoginTokenResponse.AccessToken);
            Assert.NotNull(actualNhsLoginTokenResponse.RefreshToken);
            Assert.NotNull(actualNhsLoginTokenResponse.ExpiresIn);
        }

        [Theory]
        [MemberData(nameof(DataInjector.GetObjectResultExceptionScenarios), MemberType = typeof(DataInjector))]
        public async Task Run_ExceptionScenarios_ShouldReturnObjectResult<T>(Exception exception, LogLevel logLevel, T expectedResponse) where T : ObjectResult
        {
            // Arrange
            var requestMock = new Mock<HttpRequest>();
            var queryCollection = new QueryCollection(new Dictionary<string, StringValues>() { { "code", string.Empty }, { "redirectUri", string.Empty } });
            requestMock.Setup(x => x.Query).Returns(queryCollection);
            _nhsLoginServiceMock.Setup(x => x.GetAccessTokenAsync(It.IsAny<string>(), It.IsAny<string>())).ThrowsAsync(exception);

            // Act
            var actualResponse = await _refreshTokenFunction.Run(requestMock.Object) as T;

            // Assert
            requestMock.Verify(mock => mock.Query, Times.Exactly(2));
            VerifyLog(logLevel, exception);
            _nhsLoginServiceMock.Verify(x => x.GetAccessTokenAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Once());

            Assert.NotNull(actualResponse);
            Assert.Equal(expectedResponse.Value, actualResponse.Value);
        }

        [Theory]
        [MemberData(nameof(DataInjector.GetStatusCodeResultExceptionScenarios), MemberType = typeof(DataInjector))]
        public async Task Run_ExceptionScenarios_ShouldReturnStatusCodeResult(Exception exception, LogLevel logLevel, int expectedResponseStatusCode)
        {
            // Arrange
            var requestMock = new Mock<HttpRequest>();
            var queryCollection = new QueryCollection(new Dictionary<string, StringValues>() { { "code", string.Empty }, { "redirectUri", string.Empty } });
            requestMock.Setup(x => x.Query).Returns(queryCollection);
            _nhsLoginServiceMock.Setup(x => x.GetAccessTokenAsync(It.IsAny<string>(), It.IsAny<string>())).ThrowsAsync(exception);

            // Act
            var actualResponse = await _refreshTokenFunction.Run(requestMock.Object) as StatusCodeResult;

            // Assert
            requestMock.Verify(mock => mock.Query, Times.Exactly(2));
            VerifyLog(logLevel, exception);
            _nhsLoginServiceMock.Verify(x => x.GetAccessTokenAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Once());

            Assert.NotNull(actualResponse);
            Assert.Equal(expectedResponseStatusCode, actualResponse.StatusCode);
        }


        private void VerifyLog<T>(LogLevel logLevel, T exception) where T : Exception =>
            _loggerMock.Verify(x => x.Log(
                logLevel,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((obj, type) => string.Equals(exception.Message, obj.ToString(), StringComparison.InvariantCultureIgnoreCase)),
                It.IsAny<T>(),
                (Func<It.IsAnyType, Exception, string>)It.IsAny<object>()),
                Times.Once());
    }
}
