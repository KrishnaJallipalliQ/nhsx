﻿using CovidCertificate.Backend.Models.DataModels;
using FluentValidation;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Models.RequestDtos
{
    public class AntibodyRequestDto : UserRequestDto
    {
        [JsonConstructor]
        public AntibodyRequestDto(string name, DateTime dateOfBirth, string emailAddress, string phoneNumber, DateTime dateTimeOfTest, string testType, string testResult, string testKit) 
            : base(name, dateOfBirth, emailAddress, phoneNumber)
        {
            this.DateTimeOfTest = dateTimeOfTest;
            this.TestType = testType;
            this.TestResult = testResult;
            this.TestKit = testKit;
        }

        [JsonRequired]
        public DateTime DateTimeOfTest { get; set; }
        [JsonRequired]
        public string TestType { get; set; }
        [JsonRequired]
        public string TestResult { get; set; }
        [JsonRequired]
        public string TestKit { get; set; }


        public AntibodyResult ToAntibodyResult() => new AntibodyResult(this);

        public override async Task ValidateObjectAndThrowOnFailuresAsync() 
        {
            await base.ValidateObjectAndThrowOnFailuresAsync(); 
            await new AntibodyRequestDtoValidator().ValidateAndThrowAsync(this);
        }


        private class AntibodyRequestDtoValidator : AbstractValidator<AntibodyRequestDto>
        {
            public AntibodyRequestDtoValidator()
            {
                #region DateTimeOfTest Rules
                RuleFor(x => x.DateTimeOfTest).GreaterThanOrEqualTo(new DateTime(2020, 1, 1, 0, 0, 0, DateTimeKind.Utc)).OnFailure(x =>
                {
                    throw new ValidationException("The date of the test cannot be before the year 2020.");
                });

                RuleFor(x => x.DateTimeOfTest).LessThanOrEqualTo(DateTime.UtcNow).OnFailure(x =>
                {
                    throw new ValidationException("The date of the test cannot be in the future.");
                });
                #endregion

                #region TestType Rules
                RuleFor(x => x.TestType).NotEmpty().OnFailure(x =>
                {
                    throw new ValidationException("The test type must be specified.");
                });
                #endregion

                #region TestResult Rules
                List<string> resultTypes = new List<string>() { "positive", "negative", "void" };
                RuleFor(x => x.TestResult).Must(x => resultTypes.Any(resultType => resultType.Equals(x.ToLower()))).OnFailure(x =>
                {
                    throw new ValidationException("Invalid test type, must be : " + string.Join(",", resultTypes));
                });
                #endregion
            }
        }
    }
}
