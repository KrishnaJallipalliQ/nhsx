﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Services.Certificates;
using CovidCertificate.Backend.Tests.TestHelpers;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;
using Microsoft.Extensions.Configuration;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class ConfigurationValidityCalculatorTest
    {
        private readonly Mock<ILogger<ConfigurationValidityCalculator>> logger;
        private readonly Mock<IUvciGenerator> uvciGenerator;
        private readonly IConfigurationValidityCalculator configurationValidityCalculator;

        private CovidPassportUser fakeUserUsingEmailAdresss;
        private readonly IConfiguration configurationSettings;
        private readonly EligibilityConfiguration eligibilityConfigurationHelper = EligibilityConfigurationHelper.CreatedConfiguration();

        private static int pcrValidFor = 48;
        private static int validAfter = 100;
        private static int vaccMaxTimeBetweenHours = 2016;
        private static int antiBodyExpiry = 720;
        private static List<string> snomedCodes = new List<string> { "39115010003567843", "39174920494040485930" };

        public ConfigurationValidityCalculatorTest()
        {
            var inMemorySettings = new Dictionary<string, string> {
                {"P5CertificateExpiryInHours", "72"},
            };
            configurationSettings = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();
            this.logger = new Mock<ILogger<ConfigurationValidityCalculator>>();
            this.configurationValidityCalculator = new ConfigurationValidityCalculator(logger.Object, configurationSettings);
            fakeUserUsingEmailAdresss = CovidTestUserTestHelper.CreateUserUsingEmailAddress();
            this.uvciGenerator = new Mock<IUvciGenerator>();
        }
        [Fact]
        public void ConfigurationValidityCalculator_NoTests_ReturnsNull()
        {
            //Arrange 
            var allTestResults = new List<IGenericResult>();

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss);

            //Assert 
            Assert.Empty(result);
        }

        [Fact]
        public void ConfigurationValidityCalculator_NegativeFollowedByPositiveTest_ReturnsNoCertificate()
        {
            //Arrange 
            var allTestResults = new List<IGenericResult>
            {
                TestResultTestHelper.CreateTestResultUsingRandomUser(DateTime.UtcNow.AddHours(-1), "Positive", "PCR","kit"),
                TestResultTestHelper.CreateTestResultUsingRandomUser(DateTime.UtcNow.AddHours(-3), "Negative", "PCR","kit"),
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss);

            //Assert 
            Assert.Empty(result);
        }

        [Fact]
        public void ConfigurationValidityCalculator_PositiveFollowedByNegativeTest_ReturnsCertificate()
        {
            //Arrange 
            var firstTestTime = DateTime.UtcNow.AddHours(-1);
            var allTestResults = new List<IGenericResult>
            {
                TestResultTestHelper.CreateTestResultUsingRandomUser(DateTime.UtcNow.AddHours(-3), "Positive", "PCR","kit"),
                TestResultTestHelper.CreateTestResultUsingRandomUser(firstTestTime, "Negative", "PCR","kit"),
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(firstTestTime.AddHours(pcrValidFor), result.eligibilityEndDate);
        }


        [Fact]
        public void ConfigurationValidityCalculator_ResultValidForHoursCorrect_ReturnsCertificate()
        {
            //Arrange 
            var firstTestTime = DateTime.UtcNow.AddHours(-24);
            var allTestResults = new List<IGenericResult>
            {
                TestResultTestHelper.CreateTestResultUsingRandomUser(firstTestTime, "Negative", "PCR","kit")
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(firstTestTime.AddHours(pcrValidFor), result.eligibilityEndDate);
        }

        [Fact]
        public void ConfigurationValidityCalculator_ResultPastValidForHours_ReturnsNoCertificate()
        {
            //Arrange 
            var firstTestTime = DateTime.UtcNow.AddHours(-pcrValidFor - 1);
            var allTestResults = new List<IGenericResult>
            {
                TestResultTestHelper.CreateTestResultUsingRandomUser(firstTestTime, "Negative", "PCR","kit")
            };
            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss);

            //Assert 
            Assert.Empty(result);
        }

        [Fact]
        public void ConfigurationValidityCalculator_OneVaccination_ReturnsNoCertificate()
        {
            var allTestResults = new List<IGenericResult>
            {
                new Vaccine(DateTime.UtcNow.AddDays(-24), "Oxford" ),
            };
            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss);

            //Assert 
            Assert.Empty(result);
        }

        [Fact]
        public void ConfigurationValidityCalculator_TwoVaccinationsTimeBetweenDateTooLargeVaccination_ReturnsNoCertificate()
        {
            //Arrange 
            var allTestResults = new List<IGenericResult>
            {
                new Vaccine(DateTime.UtcNow.AddDays(-24), "Oxford" ),
                new Vaccine(DateTime.UtcNow.AddDays(-120), "Oxford" )
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss);

            //Assert 
            Assert.Empty(result);
        }

        [Fact]
        public void ConfigurationValidityCalculator_TwoVaccinationsTimeBetweenDateCorrectVaccination_ReturnsCertificate()
        {
            //Arrange 
            var firstTestTime = DateTime.UtcNow.AddDays(-24);
            var allTestResults = new List<IGenericResult>
            {
                //Within 84 hour time difference 
                new Vaccine(firstTestTime, "Oxford" ),
                new Vaccine(DateTime.UtcNow.AddHours(- vaccMaxTimeBetweenHours + 1), "Oxford" )
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(firstTestTime.AddHours(6336), result.eligibilityEndDate);
        }

        [Fact]
        public void ConfigurationValidityCalculator_ThreeVaccinationsTimeBetweenDateCorrectVaccination_ReturnsCertificate()
        {
            //Arrange 
            var firstTestTime = DateTime.UtcNow.AddDays(-1);
            var allTestResults = new List<IGenericResult>
            {
                //Within 84 hour time difference 
                new Vaccine(firstTestTime, "Oxford" ),
                new Vaccine(DateTime.UtcNow.AddHours(- vaccMaxTimeBetweenHours + 1), "Oxford" ),
                new Vaccine(DateTime.UtcNow.AddHours(- vaccMaxTimeBetweenHours + 2), "Oxford" )
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(firstTestTime.AddHours(6336), result.eligibilityEndDate);
        }

        [Fact]
        public void ConfigurationValidityCalculator_TwoVaccinationsMinimumTimeBetweenDateTooSmall_ReturnsNoCertificate()
        {
            //Arrange 
            var allTestResults = new List<IGenericResult>
            {
                new Vaccine(DateTime.UtcNow.AddDays(-21), "Oxford" ),
                new Vaccine(DateTime.UtcNow.AddDays(-14), "Oxford" )
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss);

            //Assert 
            Assert.Empty(result);
        }

        [Fact]
        public void ConfigurationValidityCalculator_TwoVaccinationsMinimumTimeBetweenDateCorrect_ReturnsCertificate()
        {
            //Arrange 
            var firstTestTime = DateTime.UtcNow.AddDays(-24);
            var allTestResults = new List<IGenericResult>
            {
                //Within 84 hour time difference 
                new Vaccine(firstTestTime, "Oxford" ),
                new Vaccine(DateTime.UtcNow.AddHours(-1), "Oxford" )
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(CertificateType.Vaccination, result.CertificateType);
        }

        [Fact]
        public void ConfigurationValiditityCalculator_ValidSnomedCode_ReturnsCertificate()
        {
            //Arrange 
            var allTestResults = new List<IGenericResult>
            {
                new Vaccine(1, DateTime.UtcNow.AddDays(-21),  new Tuple<string, string>(string.Empty, string.Empty), new Tuple<string, string>(string.Empty, string.Empty), new Tuple<string, string>(string.Empty, string.Empty), null, "1", "GB", "NHS Digital", 2, "Site", "DisplayName", snomedCodes.First(), DateTime.UtcNow.AddDays(-21)),
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(CertificateType.Immunity, result.CertificateType);
        }

        [Fact]
        public void ConfigurationValiditityCalculator_InvalidSnomedCode_ReturnsNoCertificate()
        {          
            //Arrange 
            var allTestResults = new List<IGenericResult>
            {
                new Vaccine(1, DateTime.UtcNow.AddDays(-21), new Tuple<string, string>(string.Empty, string.Empty), new Tuple<string, string>(string.Empty, string.Empty), new Tuple<string, string>(string.Empty, string.Empty), null, "1", "GB", "NHS Digital", 2, "Site", "DisplayName", "wrongSnomedCode", DateTime.UtcNow.AddDays(-21)),
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss);

            //Assert 
            Assert.Empty(result);
        }

        [Fact]
        public void ConfigurationValidityCalculator_ValidAntibody_ReturnsCertificate()
        {
            //Arrange
            var firstTestTime = DateTime.UtcNow.AddDays(-24);
            var allTestResults = new List<IGenericResult>
            {
                //Within 84 hour time difference 
                new AntibodyResultNhs(firstTestTime, "Positive", "AntibodyTestName", "test kit")
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(firstTestTime.AddHours(antiBodyExpiry), result.validityEndDate);
        }

        [Fact]
        public void ConfigurationValidityCalculator_AntibodyNegative_ReturnsNoCertificate()
        {
            //Arrange
            var firstTestTime = DateTime.UtcNow.AddDays(-24);
            var antiBodyRequestDtoTestOne = new AntibodyRequestDto("", DateTime.UtcNow.AddYears(-20), "", "", firstTestTime, "AntibodyTestName", "Negative", "test kit");
            var allTestResults = new List<IGenericResult>
            {
                //Within 84 hour time difference 
                new AntibodyResult(antiBodyRequestDtoTestOne)
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss);

            //Assert 
            Assert.Empty(result);
        }

        [Fact]
        public void ConfigurationValidityCalculator_AntibodyPositiveAndPositiveDiagnostic_ReturnsNoCertificate()
        {
            //Arrange
            var firstTestTime = DateTime.UtcNow.AddDays(-24);
            var antiBodyRequestDtoTestOne = new AntibodyRequestDto("", DateTime.UtcNow.AddYears(-20), "", "", firstTestTime, "AntibodyTestName", "Negative", "test kit");
            var allTestResults = new List<IGenericResult>
            {
                //Within 84 hour time difference 
                new AntibodyResult(antiBodyRequestDtoTestOne),
                TestResultTestHelper.CreateTestResultUsingRandomUser(DateTime.UtcNow.AddHours(-36), "Positive", "PCR","kit")
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss);

            //Assert 
            Assert.Empty(result);
        }

        [Fact]
        public void ConfigurationValidityCalculator_AntibodyPositiveWithNegative_ReturnsCertificate()
        {
            //Arrange
            var firstTestTime = DateTime.UtcNow.AddHours(-3);
            var allTestResults = new List<IGenericResult>
            {
                //Within 84 hour time difference 
                new AntibodyResultNhs(firstTestTime, "Positive", "AntibodyTestName", "test kit"),
                new AntibodyResultNhs(firstTestTime.AddHours(-3), "Negative", "AntibodyTestName", "test kit")
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(firstTestTime.AddHours(antiBodyExpiry), result.validityEndDate);
        }

        [Fact]
        public void ConfigurationValidityCalculator_AntibodyPositiveThenVoid_DoesNotReturnCertificate()
        {
            //Arrange
            var firstTestTime = DateTime.UtcNow.AddHours(-3);
            var antiBodyRequestDtoTestOne = new AntibodyRequestDto("", DateTime.UtcNow.AddYears(-20), "", "", firstTestTime, "AntibodyTestName", "Void", "test kit");
            var antiBodyRequestDtoTestTwo = new AntibodyRequestDto("", DateTime.UtcNow.AddYears(-20), "", "", firstTestTime.AddHours(-3), "AntibodyTestName", "Positive", "test kit");
            var allTestResults = new List<IGenericResult>
            {
                //Within 84 hour time difference 
                new AntibodyResult(antiBodyRequestDtoTestOne),
                new AntibodyResult(antiBodyRequestDtoTestTwo)
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss);

            //Assert 
            Assert.Empty(result);
        }

        [Fact]
        public void HybridConfigurationValidityCalculator_ValidResults_ReturnsCertificate()
        {
            //Arrange
            var mostRecentDateTime = DateTime.UtcNow.AddHours(-5);
            var allTestResults = new List<IGenericResult>
            {
                new AntibodyResultNhs(mostRecentDateTime, "Positive", "ELISA", "test kit"),
                new AntibodyResultNhs(mostRecentDateTime.AddHours(-5), "Positive", "ELISA", "test kit"),
                TestResultTestHelper.CreateTestResultUsingRandomUser(DateTime.UtcNow.AddHours(-36), "Negative", "DiagnosticTest","kit")
            };
            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(CertificateType.Immunity, result.CertificateType);
            Assert.Equal(mostRecentDateTime.AddHours(240), result.eligibilityEndDate);
        }

        [Fact]
        public void WhenNegativeTest_In_36Hours_Then_ReturnsCertificate_P5()
        {
            //Arrange
            fakeUserUsingEmailAdresss.IdentityProofingLevel = "P5";
            var allTestResults = new List<IGenericResult>
            {
                TestResultTestHelper.CreateTestResultUsingRandomUser(DateTime.UtcNow.AddHours(-36), "Negative", "PCR","kit")
            };
            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules,
                                                                                                  fakeUserUsingEmailAdresss).First();
            //Assert 
            Assert.Equal(CertificateType.Diagnostic, result.CertificateType);
            Assert.Equal(DateTime.UtcNow.AddHours(48 - 36).ToString("dd/MM/yy hh:mm"), result.validityEndDate.ToString("dd/MM/yy hh:mm"));
        }

        [Fact]
        public void WhenPositiveTestFollowedByNegativeTest_In_10Days_Then_Valid_Certificate_P5()
        {
            //Arrange
            fakeUserUsingEmailAdresss.IdentityProofingLevel = "P5";
            var allTestResults = new List<IGenericResult>
            {
                TestResultTestHelper.CreateTestResultUsingRandomUser(DateTime.UtcNow.AddDays(-10), "Positive", "PCR","kit"),
                TestResultTestHelper.CreateTestResultUsingRandomUser(DateTime.UtcNow.AddHours(-36), "Negative", "PCR","kit")
            };
            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules,
                                                                                                   fakeUserUsingEmailAdresss).First();
            //Assert 
            Assert.Equal(DateTime.UtcNow.AddHours(48 - 36).ToString("dd/MM/yy hh:mm"), result.validityEndDate.ToString("dd/MM/yy hh:mm"));
        }

        [Fact]
        public void WhenPositiveTest_In_10Days_Then_No_Certificate_P5()
        {
            //Arrange
            fakeUserUsingEmailAdresss.IdentityProofingLevel = "P5";
            var allTestResults = new List<IGenericResult>
            {
                TestResultTestHelper.CreateTestResultUsingRandomUser(DateTime.UtcNow.AddDays(-10), "Positive", "PCR","kit")
            };
            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules,
                                                                                                   fakeUserUsingEmailAdresss);
            //Assert 
            Assert.Empty(result);
        }

        [Fact]
        public void WhenPositiveTest_In_12Days_Then_No_Certificate_P5()
        {
            //Arrange
            fakeUserUsingEmailAdresss.IdentityProofingLevel = "P5";
            var allTestResults = new List<IGenericResult>
            {
                TestResultTestHelper.CreateTestResultUsingRandomUser(DateTime.UtcNow.AddDays(-12), "Positive", "PCR","kit")
            };
            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules,
                                                                                                    fakeUserUsingEmailAdresss);
            //Assert 
            Assert.Empty(result);
        }

        [Fact]
        public void HybridConfigurationValidityCalculator_InvalidTestLast_DoesNotReturnCertificate()
        {
            //Arrange
            var mostRecentDateTime = DateTime.UtcNow.AddHours(-5);
            var antiBodyRequestDtoTestOne = new AntibodyRequestDto("", DateTime.UtcNow.AddYears(-20), "", "", mostRecentDateTime.AddHours(-5), "ELISA", "Positive", "test kit");
            var antiBodyRequestDtoTestTwo = new AntibodyRequestDto("", DateTime.UtcNow.AddYears(-20), "", "", mostRecentDateTime.AddHours(-10), "ELISA", "Positive", "test kit");

            var allTestResults = new List<IGenericResult>
            {
                new AntibodyResult(antiBodyRequestDtoTestOne),
                new AntibodyResult(antiBodyRequestDtoTestTwo),
                TestResultTestHelper.CreateTestResultUsingRandomUser(mostRecentDateTime, "Positive", "OtherDiTest","kit")

            };
            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss);

            //Assert 
            Assert.Empty(result);
        }

        [Fact]
        public void HybridConfigurationValidityCalculator_InvalidTestNotLast_ReturnsCertificate()
        {
            //Arrange
            var mostRecentDateTime = DateTime.UtcNow.AddHours(-5);
            var allTestResults = new List<IGenericResult>
            {
                new AntibodyResultNhs(mostRecentDateTime, "Positive", "ELISA", "test kit"),
                new AntibodyResultNhs(mostRecentDateTime.AddHours(-10), "Positive", "ELISA", "test kit"),
                TestResultTestHelper.CreateTestResultUsingRandomUser(mostRecentDateTime.AddHours(-20), "Negative", "DiagnosticTest","kit"),
                TestResultTestHelper.CreateTestResultUsingRandomUser(mostRecentDateTime.AddHours(-15), "Positive", "OtherDiTest","kit")
            };
            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(CertificateType.Immunity, result.CertificateType);
            Assert.Equal(mostRecentDateTime.AddHours(240), result.eligibilityEndDate);
        }


        [Fact]
        public void HybridConfigurationValidityCalculator_AllConditionsMet_DoesNotReturnCertificate()
        {
            //Arrange
            var antiBodyRequestDtoTestOne = new AntibodyRequestDto("", DateTime.UtcNow.AddYears(-20), "", "", DateTime.UtcNow.AddHours(-5), "ELISA", "Positive", "test kit");
            var antiBodyRequestDtoTestTwo = new AntibodyRequestDto("", DateTime.UtcNow.AddYears(-20), "", "", DateTime.UtcNow.AddHours(-10), "ELISA", "Positive", "test kit");
            var allTestResults = new List<IGenericResult>
            {
                new AntibodyResult(antiBodyRequestDtoTestOne),
                new AntibodyResult(antiBodyRequestDtoTestTwo),
                new Vaccine(DateTime.UtcNow.AddHours(-24), "Moderna" ),
                new Vaccine(DateTime.UtcNow.AddHours(-48), "Moderna" ),
                TestResultTestHelper.CreateTestResultUsingRandomUser(DateTime.UtcNow.AddHours(-36), "Positive", "DiTest","kit")
            };
            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss);

            //Assert 
            Assert.Empty(result);
        }
        [Fact]
        public void HybridConfigurationValidityCalculator_OnlyEligibilityConditionMet_ReturnsCertificate()
        {
            //Arrange
            var mostRecentDateTime = DateTime.UtcNow.AddHours(-5);

            var allTestResults = new List<IGenericResult>
            {
                new AntibodyResultNhs(mostRecentDateTime, "Positive", "ELISA", "test kit"),
                new AntibodyResultNhs(mostRecentDateTime.AddHours(-10), "Positive", "ELISA", "test kit"),
                new Vaccine(DateTime.UtcNow.AddHours(-24), "Moderna" ),
                new Vaccine(DateTime.UtcNow.AddHours(-50), "Other vacc" ),
                TestResultTestHelper.CreateTestResultUsingRandomUser(DateTime.UtcNow.AddHours(-36), "Positive", "DiTest","kit"),
                TestResultTestHelper.CreateTestResultUsingRandomUser(DateTime.UtcNow.AddHours(-24), "Negative", "DiTest","kit"),
                TestResultTestHelper.CreateTestResultUsingRandomUser(DateTime.UtcNow.AddHours(-36), "Negative", "DiagnosticTest","kit"),
            };
            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(CertificateType.Immunity, result.CertificateType);
            Assert.Equal(mostRecentDateTime.AddHours(240), result.eligibilityEndDate);
        }
        [Fact]
        public void HybridConfiguration_MultipleConditionsSatisfied_ReturnsLongestExpiry()
        {
            //Arrange
            var mostRecentDateTime = DateTime.UtcNow.AddHours(-5);

            var allTestResults = new List<IGenericResult>
            {
                new AntibodyResultNhs(mostRecentDateTime.AddHours(-5), "Positive", "ELISA", "test kit"),
                new AntibodyResultNhs(mostRecentDateTime.AddHours(-10), "Positive", "ELISA", "test kit"),
                TestResultTestHelper.CreateTestResultUsingRandomUser(mostRecentDateTime, "Negative", "DiagnosticTest","kit")
            };
            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(CertificateType.Immunity, result.CertificateType);
            Assert.Equal(mostRecentDateTime.AddHours(240), result.eligibilityEndDate);
        }
        [Fact]
        public void HybridConfiguration_MultipleConditionsSatisfiedDifferentOrder_ReturnsLongestExpiry()
        {
            //Arrange
            var mostRecentDateTime = DateTime.UtcNow.AddHours(-5);

            var allTestResults = new List<IGenericResult>
            {
                TestResultTestHelper.CreateTestResultUsingRandomUser(mostRecentDateTime, "Negative", "DiagnosticTest","kit"),
                new AntibodyResultNhs(mostRecentDateTime.AddHours(-5), "Positive", "ELISA", "test kit"),
                new AntibodyResultNhs(mostRecentDateTime.AddHours(-10), "Positive", "ELISA", "test kit")
            };
            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(CertificateType.Immunity, result.CertificateType);
            Assert.Equal(mostRecentDateTime.AddHours(240), result.eligibilityEndDate);
        }

        [Fact]
        public void NewVaccineConfiguration_OneVaccine_DoesNotReturnCertificate()
        {
            //Arrange
            var mostRecentDateTime = DateTime.UtcNow.AddHours(-12);
            var allTestResults = new List<IGenericResult>
            {
                new Vaccine(mostRecentDateTime, "NewVaccine" )
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss);

            //Assert 
            Assert.Empty(result);
        }

        [Fact]
        public void NewVaccineConfiguration_TwoVaccinesTooFarInPast_DoesNotReturnCertificate()
        {
            //Arrange
            var mostRecentDateTime = DateTime.UtcNow.AddHours(-120);
            var allTestResults = new List<IGenericResult>
            {
                new Vaccine(mostRecentDateTime, "NewVaccine" ),
                new Vaccine(DateTime.UtcNow.AddHours(-2000), "NewVaccine" )
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss);

            //Assert 
            Assert.Empty(result);
        }
        [Fact]
        public void NewVaccineConfiguration_FirstVaccineTooSoon_DoesNotReturnCertificate()
        {
            //Arrange
            var mostRecentDateTime = DateTime.UtcNow.AddHours(-1);
            var allTestResults = new List<IGenericResult>
            {
                new Vaccine(mostRecentDateTime, "NewVaccine" ),
                new Vaccine(DateTime.UtcNow.AddHours(-150), "NewVaccine")
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss);

            //Assert 
            Assert.Empty(result);
        }
        [Fact]
        public void NewVaccineConfiguration_VaccinesTooFarApart_DoesNotReturnCertificate()
        {
            //Arrange
            var mostRecentDateTime = DateTime.UtcNow.AddHours(-101);
            var allTestResults = new List<IGenericResult>
            {
                new Vaccine(mostRecentDateTime, "NewVaccine" ),
                new Vaccine(DateTime.UtcNow.AddHours(-450), "NewVaccine")
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss);

            //Assert 
            Assert.Empty(result);
        }
        [Fact]
        public void NewVaccineConfiguration_ValidCombo_ReturnsCertificate()
        {
            //Arrange
            var mostRecentDateTime = DateTime.UtcNow.AddHours(-101);
            var allTestResults = new List<IGenericResult>
            {
                new Vaccine(mostRecentDateTime, "NewVaccine" ),
                new Vaccine(DateTime.UtcNow.AddHours(-250), "NewVaccine")
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            //Assert 
            Assert.Equal(CertificateType.Vaccination, result.CertificateType);
            Assert.Equal(mostRecentDateTime.AddHours(500 + validAfter), result.eligibilityEndDate);
        }

        [Fact]
        public void When2ValidVaccines_ValidCombo_ReturnsCertificate_For_P5_User()
        {
            //Arrange
            fakeUserUsingEmailAdresss.IdentityProofingLevel = "P5";
            var mostRecentDateTime = DateTime.UtcNow.AddHours(-101);
            var allTestResults = new List<IGenericResult>
            {
                new Vaccine(mostRecentDateTime, "NewVaccine" ),
                new Vaccine(DateTime.UtcNow.AddHours(-250), "NewVaccine")
            };
            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules,
                                                                                                fakeUserUsingEmailAdresss).First();
            //Assert 
            Assert.Equal(CertificateType.Vaccination, result.CertificateType);
            Assert.Equal(DateTime.UtcNow.AddHours(72).ToString("dd/MM/yy hh:mm"), result.validityEndDate.ToString("dd/MM/yy hh:mm"));
        }
        [Fact]
        public void NewVaccineConfiguration_SecondValidComboWithExtendedTime_ReturnsCertificate()
        {
            //Arrange
            var mostRecentDateTime = DateTime.UtcNow.AddHours(-499);
            var allTestResults = new List<IGenericResult>
            {
                new Vaccine(mostRecentDateTime, "NewVaccine" ),
                new Vaccine(DateTime.UtcNow.AddHours(-550), "NewVaccine")
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(CertificateType.Vaccination, result.CertificateType);
            Assert.Equal(mostRecentDateTime.AddHours(500 + validAfter), result.eligibilityEndDate);
        }


        [Fact]
        public void ConfigurationValidityCalculator_ResultValidForHoursCorrect_ReturnsCertificate_ForP5User()
        {
            fakeUserUsingEmailAdresss.IdentityProofingLevel = "P5";
            //Arrange 
            var firstTestTime = DateTime.UtcNow.AddHours(-24);
            var allTestResults = new List<IGenericResult>
            {
                TestResultTestHelper.CreateTestResultUsingRandomUser(firstTestTime, "Negative", "PCR","kit")
            };
            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules,
                                                                                                   fakeUserUsingEmailAdresss).First();
            //Assert 
            Assert.Equal(firstTestTime.AddHours(pcrValidFor), result.eligibilityEndDate);
        }

        [Fact]
        public void VaccinationCombinations_TwoVaccines_ValidVaccines_TimeValid_ReturnsCertificate()
        {
            //Arrange
            var firstTestTime = DateTime.UtcNow.AddDays(-24);
            var allTestResults = new List<IGenericResult>
            {
                new Vaccine(firstTestTime, "Oxford" ),
                new Vaccine(DateTime.UtcNow.AddHours(- vaccMaxTimeBetweenHours + 1), "Glasgow")
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(firstTestTime.AddHours(6336), result.eligibilityEndDate);
        }

        [Fact]
        public void VaccinationCombinations_TwoVaccines_ValidVaccines_ReturnsCertificate()
        {
            //Arrange
            var allTestResults = new List<IGenericResult>
            {
                new Vaccine(DateTime.UtcNow.AddDays(-24), "Oxford" ),
                new Vaccine(DateTime.UtcNow.AddHours(- vaccMaxTimeBetweenHours + 1), "Glasgow")
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(CertificateType.Vaccination, result.CertificateType);
        }

        [Fact]
        public void VaccinationCombinations_FourDuplicatedVaccines_ValidVaccines_ReturnsCertificate()
        {
            //Arrange
            var allTestResults = new List<IGenericResult>
            {
                new Vaccine(DateTime.UtcNow.AddDays(-24), "Oxford" ),
                new Vaccine(DateTime.UtcNow.AddHours(- vaccMaxTimeBetweenHours + 1), "Glasgow"),
                new Vaccine(DateTime.UtcNow.AddDays(-24), "Oxford" ),
                new Vaccine(DateTime.UtcNow.AddHours(- vaccMaxTimeBetweenHours + 1), "Glasgow")
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(CertificateType.Vaccination, result.CertificateType);
        }

        [Fact]
        public void VaccinationCombinations_TwoVaccines_InvalidCombination_ValidVaccines_ReturnsNoCertificate()
        {
            //Arrange
            var allTestResults = new List<IGenericResult>
            {
                new Vaccine(DateTime.UtcNow.AddDays(-24), "Glasgow" ),
                new Vaccine(DateTime.UtcNow.AddHours(- vaccMaxTimeBetweenHours + 1), "Oxford")
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Null(result);
        }

        [Fact]
        public void VaccinationCombinations_TwoVaccines_InvalidVaccines_ReturnsNoCertificate()
        {
            //Arrange
            var allTestResults = new List<IGenericResult>
            {
                new Vaccine(DateTime.UtcNow.AddDays(-24), "NewVac" ),
                new Vaccine(DateTime.UtcNow.AddHours(- vaccMaxTimeBetweenHours + 1), "OldVac")
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Null(result);
        }

        [Fact]
        public void VaccinationCombinations_TwoVaccines_OneInvalidManufacturer_ReturnsNoCertificate()
        {
            //Arrange
            var firstTestTime = DateTime.UtcNow.AddDays(-24);
            var allTestResults = new List<IGenericResult>
            {
                new Vaccine(firstTestTime, "Oxford" ),
                new Vaccine(DateTime.UtcNow.AddHours(- vaccMaxTimeBetweenHours + 1), "London")
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Null(result);
        }

        [Fact]
        public void ConfigurationValidityCalculator_ThreeVaccinations_AllValidVaccines_ReturnsCertificate()
        {
            //Arrange 
            var firstTestTime = DateTime.UtcNow.AddDays(-1);
            var allTestResults = new List<IGenericResult>
            {
                //Within 84 hour time difference 
                new Vaccine(firstTestTime, "Manchester" ),
                new Vaccine(DateTime.UtcNow.AddHours(- vaccMaxTimeBetweenHours + 1), "Cambridge" ),
                new Vaccine(DateTime.UtcNow.AddHours(- vaccMaxTimeBetweenHours + 2), "Glasgow" )
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(CertificateType.Vaccination, result.CertificateType);
        }

        [Fact]
        public void ConfigurationValidityCalculator_ThreeVaccinations_TwoValidVaccines_MiddleVacValid_ReturnsCertificate()
        {
            //Arrange 
            var firstTestTime = DateTime.UtcNow.AddDays(-1);
            var allTestResults = new List<IGenericResult>
            {
                //Within 84 hour time difference 
                new Vaccine(firstTestTime, "Manchester" ),
                new Vaccine(DateTime.UtcNow.AddHours(- vaccMaxTimeBetweenHours + 1), "Cambridge" ),
                new Vaccine(DateTime.UtcNow.AddHours(- vaccMaxTimeBetweenHours + 2), "NewVac" )
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Equal(CertificateType.Vaccination, result.CertificateType);
        }

        [Fact]
        public void ConfigurationValidityCalculator_ThreeVaccinations_OneValidVaccines_ReturnsNoCertificate()
        {
            //Arrange 
            var firstTestTime = DateTime.UtcNow.AddDays(-1);
            var allTestResults = new List<IGenericResult>
            {
                //Within 84 hour time difference 
                new Vaccine(firstTestTime, "Oxford" ),
                new Vaccine(DateTime.UtcNow.AddHours(- vaccMaxTimeBetweenHours + 1), "NewVac" ),
                new Vaccine(DateTime.UtcNow.AddHours(- vaccMaxTimeBetweenHours + 2), "OldVac" )
            };

            //Act
            var result = configurationValidityCalculator.GenerateCertificatesUsingRules(allTestResults, eligibilityConfigurationHelper.Rules, fakeUserUsingEmailAdresss).FirstOrDefault();

            //Assert 
            Assert.Null(result);
        }
    }
}