﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Utils;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace CovidCertificate.Backend.Services.DomesticExemptions
{
    public class DomesticExemptionService : IDomesticExemptionService
    {
        private readonly ILogger<DomesticExemptionService> logger;
        private readonly IMongoRepository<DomesticExemption> mongoRepository;
        private readonly IDomesticExemptionCache domesticExemptionCache;

        public DomesticExemptionService(
            ILogger<DomesticExemptionService> logger,
            IMongoRepository<DomesticExemption> mongoRepository,
            IDomesticExemptionCache domesticExemptionCache
            )
        {
            this.logger = logger;
            this.mongoRepository = mongoRepository;
            this.domesticExemptionCache = domesticExemptionCache;
        }

        public async Task<bool> SaveDomesticExemption(DomesticExemption domesticExemption)
        {
            logger.LogInformation($"{nameof(SaveDomesticExemption)} was invoked.");
            if (string.IsNullOrEmpty(domesticExemption.NhsDobHash) || string.IsNullOrEmpty(domesticExemption.Reason))
                return false;

            logger.LogInformation($"Checking if record for user: {domesticExemption.NhsDobHash} already exists.");
            var existingRecord = await mongoRepository.FindOneAsync(x => x.NhsDobHash == domesticExemption.NhsDobHash);
            if(existingRecord == null)
            {
                logger.LogInformation("Record not found, creating new one.");
                await mongoRepository.InsertOneAsync(domesticExemption);
                logger.LogInformation($"{nameof(SaveDomesticExemption)} has finished.");
                return true;
            }
            logger.LogInformation("Record found, replacing old one.");
            domesticExemption.Id = existingRecord.Id;
            await mongoRepository.ReplaceOneAsync(domesticExemption, d => d.NhsDobHash == domesticExemption.NhsDobHash);

            logger.LogInformation($"{nameof(SaveDomesticExemption)} has finished.");
            return true;
        }

        public async Task<bool> IsUserExempt(string nhsNumber, DateTime dateOfBirth)
        {
            logger.LogInformation($"{nameof(IsUserExempt)} was invoked.");
            var result = await GetDomesticExemption(nhsNumber, dateOfBirth);

            logger.LogInformation($"{nameof(IsUserExempt)} has finished.");
            return result != null;
        }

        public async Task<DomesticExemption> GetDomesticExemption(string nhsNumber, DateTime dateOfBirth)
        {
            logger.LogInformation($"{nameof(GetDomesticExemption)} was invoked");

            if (String.IsNullOrEmpty(nhsNumber) || dateOfBirth == default)
            {
                return null;
            }

            var userHash = HashUtils.GenerateHash(nhsNumber, dateOfBirth);

            var exemptions = await domesticExemptionCache.GetDomesticExemptions();

            logger.LogInformation($"{nameof(GetDomesticExemption)} has finished");

            if (exemptions.ContainsKey(userHash))
            {
                return exemptions[userHash];
            }

            return null;
        }

        public async Task<bool> RemoveDomesticExemption(DomesticExemption domesticExemption)
        {
            logger.LogInformation($"{nameof(RemoveDomesticExemption)} was invoked");
            var result = await mongoRepository.DeleteOneAsync(x => x.NhsDobHash == domesticExemption.NhsDobHash);

            logger.LogInformation($"{nameof(RemoveDomesticExemption)} has finished");
            return result != default;
        }
    }
}
