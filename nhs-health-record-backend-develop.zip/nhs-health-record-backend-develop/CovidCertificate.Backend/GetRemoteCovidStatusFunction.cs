using CovidCertificate.Backend.Configuration.Bases.BaseFunctions;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Interfaces.RemoteAccessCodeService;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Exceptions;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Models.ResponseDtos;
using CovidCertificate.Backend.Models.Validators;
using CovidCertificate.Backend.Utils.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace CovidCertificate.Backend
{
    public class GetRemoteCovidStatusFunction : BaseFunction
    {
        private readonly ICovidCertificateCreator covidCertificateCreator;
        private readonly IRemoteAccessCodeService remoteAccess;

        public GetRemoteCovidStatusFunction(IRemoteAccessCodeService remoteAccess, 
                                            ICovidCertificateCreator covidCertificateCreator, 
                                            ILogger<GetRemoteCovidStatusFunction> logger) 
                                            : base(logger)
        {
            this.remoteAccess = remoteAccess;
            this.covidCertificateCreator = covidCertificateCreator;
        }

        [FunctionName("GetRemoteCovidStatus")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "GetRemoteCovidStatus")] HttpRequest req)
        {

            logger.LogInformation("GetRemoteCovidStatus was invoked");

            var returnResult = await base.ValidatePost<FetchRemoteCovidStatusDto, FetchRemoteCovidStatusDtoValidator>(req);
            logger.LogTraceAndDebug($"RemoteCovidStatus result: {returnResult}");

            if (returnResult.GetType() != typeof(OkObjectResult))
            {
                logger.LogInformation($"Invalid RemoteCovidStatus result");
                logger.LogInformation("GetRemoteCovidStatus has finished");
                return returnResult;
            }
            var resultObject = (OkObjectResult)returnResult;
            var dto = (FetchRemoteCovidStatusDto)resultObject.Value;
            logger.LogTraceAndDebug($"RemoteCovidStatusDto: {dto}");
            try
            {
                var remoteCode = await remoteAccess.GetRemoteCode(dto);

                var certificate = await covidCertificateCreator.GetCertificateByHash(remoteCode,dto);
                logger.LogTraceAndDebug($"Certificate: {certificate}");
                var certficationStatus = "";
                DateTime? certificationExpiry = DateTime.UtcNow;

                if (certificate == null)
                {
                    certficationStatus = "None";
                    certificationExpiry = null;
                }
                else if (certificate.validityEndDate > DateTime.UtcNow)
                {
                    certficationStatus = "Valid";
                    certificationExpiry = certificate.validityEndDate;
                }

                var response = new RemoteCovidStatusResponseDto()
                {
                    CertificationStatus = certficationStatus,
                    CertificationExpiry = certificationExpiry
                };
                logger.LogTraceAndDebug($"Remote status response {response}");

                logger.LogInformation("GetRemoteCovidStatus has finished");
                return new OkObjectResult(response);
            }
            catch (ArgumentException e)
            {
                logger.LogError(e, e.Message);
                return new BadRequestObjectResult("Remote access code does not exist or is not associated with the entered person-details ");
            }
            catch (RemoteAccessCodeNotFoundException e)
            {
                logger.LogError(e, e.Message);
                return new StatusCodeResult(StatusCodes.Status404NotFound);
            }
            catch (Exception e)
            {
                logger.LogError(e, e.Message);
                throw;
            }
        }
       
    }
}
