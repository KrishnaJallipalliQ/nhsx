﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Models.RequestDtos;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace CovidCertificate.Backend.Tests.TestHelpers
{
    public class EligibilityConfigurationHelper
    {
        private static int lftExpiry = 36;
        private static int pcrExpiry = 36;
        private static int oxVaccExpiry = 4320;
        private static int vaccMaxTimeBetweenHours = 2016;
        private static int vaccMinTimeBetweenHours = 504;
        private static int antiBodyExpiry = 720;
        private static int hybridExpiry = 120;

        private static int pcrValidFor = 48;

        private static int validAfter = 100;

        private static List<string> snomedCodes = new List<string> { "39115010003567843", "39174920494040485930" };

        public static EligibilityConfiguration CreatedConfiguration()
        {

        EligibilityConfiguration configuration = new EligibilityConfiguration(new List<EligibilityRules>
            {
                new EligibilityRules("DiagLTF", CertificateType.Diagnostic, CertificateScenario.Domestic, new List<EligibilityCondition>(){
                        new EligibilityCondition("LFT", new List<string>(), new List<List<string>>(),DataType.Diagnostic, 48, TimeFormat.Hours, null, null, 2, 0, ResultStatus.Negative, Eligibility.Eligible, new List<EligibilityNotFollowedBy>())
                    },
                    lftExpiry,
                    TimeFormat.Hours
                ),
                new EligibilityRules("Diag-PCR", CertificateType.Diagnostic, CertificateScenario.Domestic, new List<EligibilityCondition>(){
                        new EligibilityCondition("PCR", new List<string>(), new List<List<string>>(),DataType.Diagnostic, pcrValidFor, TimeFormat.Hours, null, null, 1, 0, ResultStatus.Negative, Eligibility.Eligible,
                            new List<EligibilityNotFollowedBy>{new EligibilityNotFollowedBy(DataType.Diagnostic, "PCR", new List<EligibilityResult>{new EligibilityResult(ResultStatus.Positive)}) })
                    },
                    pcrExpiry,
                    TimeFormat.Hours
                ),
                new EligibilityRules("Antibody", CertificateType.Immunity, CertificateScenario.Domestic, new List<EligibilityCondition>(){
                        new EligibilityCondition("AntibodyTestName", new List<string>(), new List<List<string>>(),DataType.Immunity, 720, TimeFormat.Hours, null, null, 1, 0, ResultStatus.Positive, Eligibility.Eligible,
                            new List<EligibilityNotFollowedBy>{new EligibilityNotFollowedBy(DataType.Immunity, "AntibodyTestName", new List<EligibilityResult>{
                                new EligibilityResult(ResultStatus.Negative),
                                new EligibilityResult(ResultStatus.Void)
                            })}),
                        new EligibilityCondition("PCR", new List<string>(),new List<List<string>>(), DataType.Diagnostic, 240, TimeFormat.Hours, null, null, 1, 0, ResultStatus.Positive, Eligibility.Ineligible, new List<EligibilityNotFollowedBy>())
                    },
                    antiBodyExpiry,
                    TimeFormat.Hours
                ),
                new EligibilityRules("Vacc-Oxford", CertificateType.Vaccination, CertificateScenario.Domestic, new List<EligibilityCondition>(){
                        new EligibilityCondition("Oxford", new List<string>(),new List<List<string>>(), DataType.Vaccination, 6336, TimeFormat.Hours, vaccMaxTimeBetweenHours, vaccMinTimeBetweenHours, 2, 0, null, Eligibility.Eligible, new List<EligibilityNotFollowedBy>())
                    },
                    oxVaccExpiry,
                    TimeFormat.Hours
                ),
                new EligibilityRules("Vacc-Oxford", CertificateType.Immunity, CertificateScenario.International, new List<EligibilityCondition>(){
                        new EligibilityCondition("Oxford", snomedCodes, new List<List<string>>(),DataType.Vaccination, 1000, TimeFormat.Hours, vaccMaxTimeBetweenHours, vaccMinTimeBetweenHours, 1, 0, null, Eligibility.Eligible, new List<EligibilityNotFollowedBy>())
                    },
                    180,
                    TimeFormat.Hours
                ),
                new EligibilityRules("Hybrid", CertificateType.Immunity, CertificateScenario.Domestic, new List<EligibilityCondition>()
                    {
                    new EligibilityCondition("ELISA", new List<string>(),new List<List<string>>(), DataType.Immunity, 240, TimeFormat.Hours, 72, null, 2, 0, ResultStatus.Positive, Eligibility.Eligible,
                        new List<EligibilityNotFollowedBy>{new EligibilityNotFollowedBy(DataType.Diagnostic, "OtherDiTest", new List<EligibilityResult>{ new EligibilityResult(ResultStatus.Positive)}) }),
                    new EligibilityCondition("DiagnosticTest", new List<string>(),new List<List<string>>(), DataType.Diagnostic, 240, TimeFormat.Hours, null, null, 1, 0, ResultStatus.Negative, Eligibility.Eligible, new List<EligibilityNotFollowedBy>()),
                    new EligibilityCondition("Moderna", new List<string>(),new List<List<string>>(), DataType.Vaccination, 6336, TimeFormat.Hours, vaccMaxTimeBetweenHours, null, 2, 0, null, Eligibility.Ineligible, new List<EligibilityNotFollowedBy>()),
                    new EligibilityCondition("DiTest", new List<string>(),new List<List<string>>(), DataType.Diagnostic, 240, TimeFormat.Hours, null, null, 1, 0, ResultStatus.Positive, Eligibility.Ineligible,
                        new List<EligibilityNotFollowedBy>{new EligibilityNotFollowedBy(DataType.Diagnostic, "DiTest", new List<EligibilityResult>{ new EligibilityResult(ResultStatus.Negative)}) })

                    },
                    hybridExpiry,
                    TimeFormat.Hours),
                new EligibilityRules("NewVaccine", CertificateType.Vaccination, CertificateScenario.Domestic, new List<EligibilityCondition>()
                {
                    new EligibilityCondition("NewVaccine", new List<string>(),new List<List<string>>(), DataType.Vaccination, 500, TimeFormat.Hours, 250, null, 2, validAfter, null, Eligibility.Eligible, new List<EligibilityNotFollowedBy>())
                },
                    hybridExpiry,
                    TimeFormat.Hours),
                new EligibilityRules("Vaccination-Combinations", CertificateType.Vaccination, CertificateScenario.Domestic, new List<EligibilityCondition>()
                {
                    new EligibilityCondition(null, null, new List<List<string>>()
                    {
                        new List<string>{"Oxford", "Glasgow" },
                        new List<string>{"Manchester", "Cambridge" }
                    }, DataType.Vaccination, 6336, TimeFormat.Hours, vaccMaxTimeBetweenHours, vaccMinTimeBetweenHours, 2, 0, null, Eligibility.Eligible, new List<EligibilityNotFollowedBy>())
                },
                    oxVaccExpiry,
                    TimeFormat.Hours)
            },
            new EligibilityDomesticExemptions(48)
        );
            return configuration;
        }
    }
}
