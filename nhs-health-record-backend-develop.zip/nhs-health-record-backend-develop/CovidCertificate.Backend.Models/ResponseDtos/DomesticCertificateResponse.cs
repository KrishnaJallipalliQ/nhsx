﻿using CovidCertificate.Backend.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.ResponseDtos
{
	public class DomesticCertificateResponse
	{
		public Certificate Certificate { get; }
		public bool CertificateEverExisted { get; }

		public DomesticCertificateResponse(Certificate certificate, bool certificateEverExisted)
		{
			Certificate = certificate;
			CertificateEverExisted = certificateEverExisted;
		}
	}
}
