﻿using System.Threading;
using System.Threading.Tasks;
using CovidCertificate.Backend.Utils.Timing;
using Xunit;

namespace CovidCertificate.Backend.Tests.UtilTests
{
    public class TimeMeasurerTests
    {
        [Fact]
        public void TestStartAction()
        {
            //Act
            var res1 = TimeMeasurer.StartAction(() => Thread.Sleep(100));
            var res2 = TimeMeasurer.StartAction(() => Thread.Sleep(1));

            //Assert
            Assert.True(res1.Duration > res2.Duration);
        }

        [Fact]
        public async Task TestStartActionAsync()
        {
            //Act
            var res1 = await TimeMeasurer.StartActionAsync(async () => await Task.Delay(100));
            var res2 = await TimeMeasurer.StartActionAsync(async () => await Task.Yield());

            //Assert
            Assert.True(res1.Duration > res2.Duration);
        }

        [Fact]
        public void TestStartFunction()
        {
            //Act
            var res = TimeMeasurer.StartFunction(() => 42);

            //Assert
            Assert.Equal(42, res.Result);
        }

        [Fact]
        public async Task TestStartFunctionAsync()
        {
            //Act
            var res = await TimeMeasurer.StartFunctionAsync(() =>Task.FromResult(42));

            //Assert
            Assert.Equal(42, res.Result);
        }
    }
}
