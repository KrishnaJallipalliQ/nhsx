﻿using CovidCertificate.Backend.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IDomesticExemptionService
    {
        public Task<DomesticExemption> GetDomesticExemption(string nhsNumber, DateTime dateOfBirth);
        public Task<bool> IsUserExempt(string nhsNumber, DateTime dateOfBirth);
        public Task<bool> RemoveDomesticExemption(DomesticExemption domesticExemption);
        public Task<bool> SaveDomesticExemption(DomesticExemption domesticExemption);

    }
}
