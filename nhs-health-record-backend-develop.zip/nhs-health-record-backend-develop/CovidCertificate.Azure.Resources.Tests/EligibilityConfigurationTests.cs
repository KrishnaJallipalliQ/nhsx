using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.RequestDtos;
using Newtonsoft.Json;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Azure.Resources.Tests
{
    public class EligibilityConfigurationTests
    {
        private readonly EligibilityConfiguration configuration;

        public EligibilityConfigurationTests()
        {
            var configFileJson = AzureResourceTestHelper.GetJsonFromAzureResourcesProject("eligibility-configuration.json");

            configuration = JsonConvert.DeserializeObject<EligibilityConfiguration>(configFileJson);
        }

        [Fact]
        public void EligibilityConfigurationTests_ConfigurationNonNullWithConditions()
        {
            Assert.NotNull(configuration);
            Assert.NotEmpty(configuration.Rules);
        }

        [Fact]
        public async Task EligibilityConfigurationTests_RequestDtoValidatesWithoutErrors()
        {
            await configuration.ValidateObjectAndThrowOnFailuresAsync();
        }
    }
}
