﻿using CovidCertificate.Backend.Auth;
using CovidCertificate.Backend.Auth.Tests.TestHelpers;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.ResponseDtos;
using CovidCertificate.Backend.Models.Settings;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Auth.Tests
{
    public class ConfigurationTest
    {
        public ConfigurationTest()
        {
        }

        [Fact]
        public void ValidateNhsLoginSettingsTest()
        {
            NhsLoginSettings configuration = ConfigurationHelper.GetNhsLoginSettings();

            Assert.Equal("P9;P5", configuration.AcceptedIdentityProofingLevel);
            Assert.Equal("https://auth.aos.signin.nhs.uk", configuration.BaseUrl);
            Assert.Equal("https://auth.aos.signin.nhs.uk/token", configuration.TokenUri);
        }
    }
}
