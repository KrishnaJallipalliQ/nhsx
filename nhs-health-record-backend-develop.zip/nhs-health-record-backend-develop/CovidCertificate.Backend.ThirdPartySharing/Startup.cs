﻿using CovidCertificate.Backend;
using CovidCertificate.Backend.Configuration.Bases;
using CovidCertificate.Backend.Configuration.Extensions;
using CovidCertificate.Backend.Models.Settings;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using System.Diagnostics.CodeAnalysis;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Interfaces.RemoteAccessCodeService;
using CovidCertificate.Backend.Services;
using CovidCertificate.Backend.Services.Certificates;
using CovidCertificate.Backend.Services.KeyServices;
using CovidCertificate.Backend.Services.RemoteAccessCode;
using CovidCertificate.Backend.ThirdPartySharing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Graph;
using CovidCertificate.Backend.Services.PilotFilter;

[assembly: FunctionsStartup(typeof(Startup))]
namespace CovidCertificate.Backend
{
    [ExcludeFromCodeCoverage]
    public class Startup : StartupBase
    {
        public override void SetupFunctionSpecificSettings(IFunctionsHostBuilder builder)
        {
            builder.Services.AddHttpClient();
            builder.AddSetting<CertificateValiditySettings>(Configuration, "CertificateValidity");
            builder.AddSetting<MongoDbSettings>(Configuration, "MongoDbSettings");
            AddMongoDBClient(builder, Configuration);
        }

        public override void SetupDI(IFunctionsHostBuilder builder)
        {
            builder.Services.AddScoped<ICovidCertificateCreator, CovidCertificateCreator>();
            builder.Services.AddScoped<IRemoteAccessCodeService, RemoteAccessCodeService>();
            builder.Services.AddTransient<IAuthenticationProvider, GraphAuthenticationProvider>();
            builder.Services.AddTransient<IGraphServiceClient, GraphServiceClient>(x => new GraphServiceClient(
                                                                                    x.GetRequiredService<IAuthenticationProvider>()));
            builder.Services.AddTransient<IGraphProvider, MicrosoftGraphProvider>();
            builder.Services.AddScoped(typeof(IMongoRepository<>), typeof(MongoRepository<>));
            builder.Services.AddScoped<IConfigurationValidityCalculator, ConfigurationValidityCalculator>();
            builder.Services.AddScoped<IQRCodeGenerator, ECQRCodeGenerator>();
            builder.Services.AddScoped<IPilotFilterService, PilotFilterService>();
            builder.Services.AddSingleton<IKeyRing, KeyRing>();
        }
    }
}