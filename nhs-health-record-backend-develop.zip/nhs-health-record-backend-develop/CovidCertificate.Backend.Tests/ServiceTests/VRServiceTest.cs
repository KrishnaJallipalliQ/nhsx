﻿using CovidCertificate.Backend.Services;
using Moq;
using System;
using Xunit;
using Microsoft.Extensions.Logging;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Services.Mappers;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Models.DataModels;
using System.Collections.Generic;
using Hl7.Fhir.Model;
using Hl7.Fhir.Serialization;
using System.IO;
using Newtonsoft.Json;
using System.Globalization;
using CovidCertificate.Backend.Tests.TestHelpers;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class VRServiceTest
    {
        private readonly VaccinationMapper mapper;
        private readonly Mock<IVRApi> vrApi;
        private readonly Mock<IVaccineMapping> vaccineMapping = new Mock<IVaccineMapping>();
        private readonly Mock<ILogger<VaccinationMapper>> mapperLogger = new Mock<ILogger<VaccinationMapper>>();
        private readonly Mock<ILogger<VRService>> logger;
        private readonly Mock<IRedisCacheService> redisCache = new Mock<IRedisCacheService>();
        private readonly Mock<IPilotFilterService> mockPilotFilterService = new Mock<IPilotFilterService>();
        private readonly Mock<IFhirLookupApi> fhirLookUpMock = new Mock<IFhirLookupApi>();
        private readonly Mock<IConfiguration> configMock = new Mock<IConfiguration>();
        private string idToken;

        public VRServiceTest()
        {
            this.vrApi = new Mock<IVRApi>();
            this.logger = new Mock<ILogger<VRService>>();
            this.redisCache = new Mock<IRedisCacheService>();
            this.vaccineMapping = VaccinationMapperHelper.CreateMockVaccineMapping();
            var config = VaccinationMapperHelper.CreateMockConfig();
            mapper = new VaccinationMapper(vaccineMapping.Object, config, fhirLookUpMock.Object, mapperLogger.Object);
            idToken = "dummytoken";
        }

        [Fact]
        public void GetVaccines_ValidUser_ThrowsException()
        {
            var service = new VRService(mapper, logger.Object, redisCache.Object, vrApi.Object, mockPilotFilterService.Object, configMock.Object);
            Assert.ThrowsAsync<ArgumentNullException>(async () => await service.GetVaccines(idToken, It.IsAny<CovidPassportUser>()));
        }

        [Fact]
        public void GetVaccines_BadVRRequest_ThrowsException()
        {
            HttpResponseMessage failResponse = new HttpResponseMessage();
            failResponse.StatusCode = System.Net.HttpStatusCode.BadRequest;

            vrApi.Setup(x => x.GetFHIRVaccines(It.IsAny<string>())).ReturnsAsync(failResponse);
            var service = new VRService(mapper, logger.Object, redisCache.Object, vrApi.Object, mockPilotFilterService.Object, configMock.Object);
            Assert.ThrowsAsync<ArgumentException>(async () => await service.GetVaccines(idToken, It.IsAny<CovidPassportUser>()));
        }

        [Fact]
        public async void GetVaccines_GoodRequest_CallsCache()
        {
            HttpResponseMessage response = new HttpResponseMessage();
            response.StatusCode = System.Net.HttpStatusCode.OK;
            response.Content = new StringContent("content");
            vrApi.Setup(x => x.GetFHIRVaccines(It.IsAny<string>())).ReturnsAsync(response);

            redisCache.Setup(x => x.GetKeyValueAsync<string>(It.IsAny<string>())).ReturnsAsync((default, false));

            var service = new VRService(mapper, logger.Object, redisCache.Object, vrApi.Object, mockPilotFilterService.Object, configMock.Object);
            var vaccine = service.GetVaccines(idToken, new CovidPassportUser("", DateTime.UtcNow, "", "", ""));

            redisCache.Verify(x => x.AddKeyAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<RedisLifeSpanLevel>()), Times.Once());
        }

        [Fact]
        public async void GetVaccines_FilterOn_FiltersVaccines()
        {
            HttpResponseMessage response = new HttpResponseMessage();
            response.StatusCode = System.Net.HttpStatusCode.OK;
            response.Content = CreateBundle();
            vrApi.Setup(x => x.GetFHIRVaccines(It.IsAny<string>())).ReturnsAsync(response);


            redisCache.Setup(x => x.GetKeyValueAsync<string>(It.IsAny<string>())).ReturnsAsync((default, false));

            var inMemorySettings = new Dictionary<string, string>
            {
                { "FilterFirstAndLastVaccines","true"},
            };
            IConfiguration config = new ConfigurationBuilder().AddInMemoryCollection(inMemorySettings).Build();

            var service = new VRService(mapper, logger.Object, redisCache.Object, vrApi.Object, mockPilotFilterService.Object, config);
            var vaccine = service.GetVaccines(idToken, new CovidPassportUser("", DateTime.UtcNow, "", "", ""));

            redisCache.Verify(x => x.AddKeyAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<RedisLifeSpanLevel>()), Times.Once());

            Assert.Equal(2, vaccine.Result.Count);
        }

        public StringContent CreateBundle()
        {
            var immunization = VaccinationMapperHelper.CreateImmunization(0, 1);
            var immunization2 = VaccinationMapperHelper.CreateImmunization(40, 2);

            var bundle = new Bundle();
            bundle.AddResourceEntry(immunization, "urn:uuid:" + Guid.NewGuid().ToString());
            bundle.AddResourceEntry(immunization, "urn:uuid:" + Guid.NewGuid().ToString());
            bundle.AddResourceEntry(immunization2, "urn:uuid:" + Guid.NewGuid().ToString());

            return new StringContent(new FhirJsonSerializer().SerializeToString(bundle));
        }
    }
}