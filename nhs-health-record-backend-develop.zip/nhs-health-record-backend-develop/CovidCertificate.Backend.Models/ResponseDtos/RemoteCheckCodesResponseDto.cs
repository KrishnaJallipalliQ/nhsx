﻿using CovidCertificate.Backend.Models.DataModels;
using System;

namespace CovidCertificate.Backend.Models.ResponseDtos
{
    public class RemoteCheckCodesResponseDto
    {
        public RemoteCheckCodesResponseDto(RemoteAccessCode remoteAccessCode)
        {
            this.RemoteCheckCode = remoteAccessCode.AccessCode;
            this.ExprirationDateTime = remoteAccessCode.ExpiryDateTime;
            this.CreatedDateTime = remoteAccessCode.CreatedDateTime;
            this.CodeStatus = remoteAccessCode.CodeStatus.ToString();
            this.ThirdPartyName = remoteAccessCode.ThirdPartyName;
        }

        public string RemoteCheckCode { get; }
        public DateTime ExprirationDateTime { get; }
        public DateTime CreatedDateTime { get;}
        public string CodeStatus { get; }
        public string ThirdPartyName { get; }
    }
}
