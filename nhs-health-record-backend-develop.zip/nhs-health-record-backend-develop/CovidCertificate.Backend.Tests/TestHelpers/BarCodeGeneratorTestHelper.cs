﻿using Hl7.Fhir.Model;
using Hl7.Fhir.Serialization;

namespace CovidCertificate.Backend.Tests.TestHelpers
{
    public class BarCodeGeneratorTestHelper
    {
        private static FhirJsonParser parser = new FhirJsonParser();

        public static Bundle GetCorrectBundle()
        {
            var data = "{\r\n  \"resourceType\": \"Bundle\",\r\n  \"type\": \"collection\",  \r\n  \"entry\": [\r\n    {\r\n      \"resource\": {\r\n      \"resourceType\": \"Patient\",   \r\n      \"name\": [\r\n        {                       \r\n        \"family\": \"Jackson\",\r\n        \"given\": [\r\n          \"Jane\"\r\n        ]           \r\n        }\r\n      ],       \r\n      \"birthDate\": \"1952-05-31\"   \r\n      }\r\n    },      \r\n    {\r\n      \"resource\": {\r\n        \"resourceType\": \"Immunization\",      \r\n      \r\n        \"status\": \"completed\",\r\n        \"vaccineCode\": {\r\n          \"coding\": [\r\n            {\r\n              \"code\": \"39115611000001103\"\r\n            }\r\n          ]\r\n        },\r\n        \"occurrenceDateTime\": \"2020-12-05T23:20:04.000Z\",\r\n        \"lotNumber\": \"OBQUJKGQDBCLVDEFWUUQ\",\r\n        \"protocolApplied\": [ { \"doseNumberPositiveInt\": 1 } ]\r\n      }\r\n    }   \r\n  ]\r\n}\r\n ";
            return parser.Parse<Bundle>(data);
        }

        public static Bundle GetBundleWithoutPatient()
        {
            var data = " {\r\n  \"resourceType\": \"Bundle\",\r\n  \"type\": \"collection\",  \r\n  \"entry\": [    \r\n    {\r\n      \"resource\": {\r\n        \"resourceType\": \"Immunization\",      \r\n      \r\n        \"status\": \"completed\",\r\n        \"vaccineCode\": {\r\n          \"coding\": [\r\n            {\r\n              \"code\": \"39115611000001103\"\r\n            }\r\n          ]\r\n        },\r\n        \"occurrenceDateTime\": \"2020-12-05T23:20:04.000Z\",\r\n        \"lotNumber\": \"OBQUJKGQDBCLVDEFWUUQ\",\r\n        \"protocolApplied\": [ { \"doseNumberPositiveInt\": 1 } ]\r\n      }\r\n    }   \r\n  ]\r\n}\r\n ";
            return parser.Parse<Bundle>(data);
        }

        public static Bundle GetBundleWithInvalidImmunization()
        {
            var data = "{\r\n  \"resourceType\": \"Bundle\",\r\n  \"type\": \"collection\",  \r\n  \"entry\": [\r\n    {\r\n      \"resource\": {\r\n      \"resourceType\": \"Patient\",   \r\n      \"name\": [\r\n        {                       \r\n        \"family\": \"Jackson\",\r\n        \"given\": [\r\n          \"Jane\"\r\n        ]           \r\n        }\r\n      ],       \r\n      \"birthDate\": \"1952-05-31\"   \r\n      }\r\n    },      \r\n    {\r\n      \"resource\": {\r\n        \"resourceType\": \"Immunization\",      \r\n      \r\n        \"status\": \"completed\",\r\n        \"vaccineCode\": {\r\n          \"coding\": [\r\n            {\r\n              \"code\": \"39115611000001103\"\r\n            }\r\n          ]\r\n        },\r\n        \"occurrenceDateTime\": \"2020-12-05T23:20:04.000Z\",\r\n        \"lotNumber\": \"\",\r\n        \"protocolApplied\": [ { \"doseNumberPositiveInt\": 1 } ]\r\n      }\r\n    }  \r\n  ]\r\n}\r\n";
            return parser.Parse<Bundle>(data);
        }

        public static Bundle GetBundleWithInvalidLocation()
        {
            var data = "{\r\n    \"resourceType\": \"Bundle\",\r\n    \"type\": \"collection\",  \r\n    \"entry\": [\r\n        // Patient\r\n        {\r\n            \"fullUrl\": \"urn:uuid:1137e65f-a5c6-4037-9437-59dc0385214c\",\r\n            \"resource\": {\r\n                \"resourceType\": \"Patient\",   \r\n                \"name\": [\r\n                    {                       \r\n                        \"family\": \"TEAK\",\r\n                        \"given\": [\r\n                            \"Anne\"\r\n                        ]           \r\n                    }\r\n                ],       \r\n                \"birthDate\": \"1952-05-31\"   \r\n            }\r\n        },\r\n        // Location: France\r\n        {\r\n            \"fullUrl\": \"urn:uuid:ba2f3210-d08f-42ae-b766-020de38df482\",\r\n            \"resource\": {\r\n                \"resourceType\": \"Location\",\r\n                \"id\": \"ba2f3210-d08f-42ae-b766-020de38df482\",\r\n                \"address\": {\r\n                    \"country\": \"Wrong code\" // ISO3166-2 Code for France\r\n                }\r\n            }\r\n        },\r\n        // Immunization #1 (France)\r\n        {\r\n            \"resource\": {\r\n                \"resourceType\": \"Immunization\",      \r\n                \"id\": \"87cf548c-2a23-4b18-b0b7-8704a44fc25f\",   \r\n                \"status\": \"completed\",\r\n                \"vaccineCode\": {\r\n                    \"coding\": [\r\n                        {\r\n                            \"system\": \"http://snomed.info/sct\",\r\n                            \"code\": \"39115611000001103\",\r\n                            \"display\": \"COVID-19 mRNA Vaccine Pfizer-BioNTech BNT162b2 30micrograms/0.3ml dose concentrate for suspension for injection multidose vials (Pfizer Ltd) (product)\"\r\n                        }\r\n                    ]\r\n                },\r\n                \"occurrenceDateTime\": \"2020-12-05T23:20:04.000Z\",\r\n                \"lotNumber\": \"OBQUJKGQDBCLVDEFWUUQ\",\r\n                \"protocolApplied\": [ { \"doseNumberPositiveInt\": 1 } ],\r\n                \"location\": {\r\n                    \"reference\": \"urn:uuid:ba2f3210-d08f-42ae-b766-020de38df482\"\r\n                },\r\n                \"patient\": {\r\n                    \"reference\": \"urn:uuid:1137e65f-a5c6-4037-9437-59dc0385214c\"\r\n                }\r\n            }\r\n        }\r\n    ]\r\n}\r\n";

            return parser.Parse<Bundle>(data);
        }

        public static Bundle GetBundleWithValidLocation()
        {
            var data = "{\r\n    \"resourceType\": \"Bundle\",\r\n    \"type\": \"collection\",  \r\n    \"entry\": [\r\n        // Patient\r\n        {\r\n            \"fullUrl\": \"urn:uuid:1137e65f-a5c6-4037-9437-59dc0385214c\",\r\n            \"resource\": {\r\n                \"resourceType\": \"Patient\",   \r\n                \"name\": [\r\n                    {                       \r\n                        \"family\": \"TEAK\",\r\n                        \"given\": [\r\n                            \"Anne\"\r\n                        ]           \r\n                    }\r\n                ],       \r\n                \"birthDate\": \"1952-05-31\"   \r\n            }\r\n        },\r\n        // Location: France\r\n        {\r\n            \"fullUrl\": \"urn:uuid:ba2f3210-d08f-42ae-b766-020de38df482\",\r\n            \"resource\": {\r\n                \"resourceType\": \"Location\",\r\n                \"id\": \"ba2f3210-d08f-42ae-b766-020de38df482\",\r\n                \"address\": {\r\n                    \"country\": \"FR\" // ISO3166-2 Code for France\r\n                }\r\n            }\r\n        },\r\n        // Immunization #1 (France)\r\n        {\r\n            \"resource\": {\r\n                \"resourceType\": \"Immunization\",      \r\n                \"id\": \"87cf548c-2a23-4b18-b0b7-8704a44fc25f\",   \r\n                \"status\": \"completed\",\r\n                \"vaccineCode\": {\r\n                    \"coding\": [\r\n                        {\r\n                            \"system\": \"http://snomed.info/sct\",\r\n                            \"code\": \"39115611000001103\",\r\n                            \"display\": \"COVID-19 mRNA Vaccine Pfizer-BioNTech BNT162b2 30micrograms/0.3ml dose concentrate for suspension for injection multidose vials (Pfizer Ltd) (product)\"\r\n                        }\r\n                    ]\r\n                },\r\n                \"occurrenceDateTime\": \"2020-12-05T23:20:04.000Z\",\r\n                \"lotNumber\": \"OBQUJKGQDBCLVDEFWUUQ\",\r\n                \"protocolApplied\": [ { \"doseNumberPositiveInt\": 1 } ],\r\n                \"location\": {\r\n                    \"reference\": \"urn:uuid:ba2f3210-d08f-42ae-b766-020de38df482\"\r\n                },\r\n                \"patient\": {\r\n                    \"reference\": \"urn:uuid:1137e65f-a5c6-4037-9437-59dc0385214c\"\r\n                }\r\n            }\r\n        }\r\n    ]\r\n}\r\n";

            return parser.Parse<Bundle>(data);
        }

        public static Bundle GetBundleWithoutLocation()
        {
            var data = "{\r\n  \"resourceType\": \"Bundle\",\r\n  \"type\": \"collection\",   \r\n  \"entry\": [\r\n    {\r\n      \"resource\": {\r\n      \"resourceType\": \"Patient\",    \r\n      \"name\": [\r\n        {                        \r\n        \"family\": \"Jackson\",\r\n        \"given\": [\r\n          \"Jane\"\r\n        ]            \r\n        }\r\n      ],        \r\n      \"birthDate\": \"1952-05-31\"    \r\n      }\r\n    },       \r\n    {\r\n      \"resource\": {\r\n        \"resourceType\": \"Immunization\",       \r\n        \"id\": \"87cf548c-2a23-4b18-b0b7-8704a44fc25f\",    \r\n        \"status\": \"completed\",\r\n        \"vaccineCode\": {\r\n          \"coding\": [\r\n            {\r\n              \"code\": \"39115611000001103\",\r\n            }\r\n          ]\r\n        },\r\n        \"occurrenceDateTime\": \"2020-12-05T23:20:04.000Z\",\r\n        \"lotNumber\": \"OBQUJKGQDBCLVDEFWUUQ\",\r\n        \"protocolApplied\": [ { \"doseNumberPositiveInt\": 1 } ]\r\n      }\r\n    },\r\n    {\r\n      \"resource\": {\r\n        \"resourceType\": \"Immunization\",       \r\n        \"id\": \"55275435-9b4d-47c5-81df-b25f6d612768\",    \r\n        \"status\": \"completed\",\r\n        \"vaccineCode\": {\r\n          \"coding\": [\r\n            {\r\n              \"code\": \"39115611000001103\"\r\n            }\r\n          ]\r\n        },\r\n        \"occurrenceDateTime\": \"2021-02-08T14:33:04.000Z\",\r\n        \"lotNumber\": \"OBQUJKGQDBCLVDEFWUUQ\",\r\n        \"protocolApplied\": [ { \"doseNumberPositiveInt\": 2 } ]\r\n      }\r\n    }    \r\n  ]\r\n}\r\n";

            return parser.Parse<Bundle>(data);
        }

        public static Bundle GetBundleWithoutImmunizations()
        {
            var data = "{\r\n  \"resourceType\": \"Bundle\",\r\n  \"type\": \"collection\",  \r\n  \"entry\": [\r\n    {\r\n      \"resource\": {\r\n      \"resourceType\": \"Patient\",   \r\n      \"name\": [\r\n        {                       \r\n        \"family\": \"Jackson\",\r\n        \"given\": [\r\n          \"Jane\"\r\n        ]           \r\n        }\r\n      ],       \r\n      \"birthDate\": \"1952-05-31\"   \r\n      }\r\n    } ]\r\n}\r\n ";
            return parser.Parse<Bundle>(data);
        }
    }
}
