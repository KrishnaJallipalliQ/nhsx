﻿using CovidCertificate.Backend.Models.DataModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IDiagnosticTestResultsService
    {
        public Task<IEnumerable<TestResultNhs>> GetDiagnosticTestResults(string idToken);
        
    }
}
