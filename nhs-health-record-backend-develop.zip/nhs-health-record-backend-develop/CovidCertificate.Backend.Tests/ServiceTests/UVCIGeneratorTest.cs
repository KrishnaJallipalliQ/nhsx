using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Services.Certificates;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CovidCertificate.Backend.Models.Commands.UvciGeneratorCommands;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class UVCIGeneratorTest
    {
        private readonly Mock<ILogger<UvciGenerator>> logger = new Mock<ILogger<UvciGenerator>>();
        private readonly Mock<IMongoRepository<UvciGeneratorModel>> mongoRepository = new Mock<IMongoRepository<UvciGeneratorModel>>();
        private readonly Mock<IMongoRepository<RegionUvciGeneratorModel>> regionMongoRepository = new Mock<IMongoRepository<RegionUvciGeneratorModel>>();
        private readonly Mock<IConfiguration> configuration = new Mock<IConfiguration>();
        public UVCIGeneratorTest()
        {
            configuration.SetupGet<string>(m => m["UVCIVersion"]).Returns("01");
            configuration.SetupGet<string>(m => m["UVCIPrefix"]).Returns("URN:UVCI");
            configuration.SetupGet<string>(m => m["CountryOfIssuer"]).Returns("GB");
        }

        [Fact]
        public async Task Test_GenerateUvciString()
        {
            // Arrange
            var issuer = "NHS Digital";
            var country = "GB";
            var command = new DomesticGenerateAndInsertUvciCommand(issuer, country, "someHash", CertificateType.Vaccination,
                CertificateScenario.International, DateTime.Now.AddDays(30));

            UvciGeneratorModel document = null;
            mongoRepository.Setup(r => r.InsertOneAsync(It.IsAny<UvciGeneratorModel>())).Callback<UvciGeneratorModel>((obj) => document = obj);

            var uvciGenerator = new UvciGenerator(configuration.Object, logger.Object, mongoRepository.Object, regionMongoRepository.Object);

            // Act
            var result = await uvciGenerator.TryGenerateAndInsertUvci(command);
            

            // Assert
            Assert.NotNull(result);
            Assert.Contains("URN:UVCI:01:GB:", result);
            mongoRepository.Verify(m => m.InsertOneAsync(It.IsAny<UvciGeneratorModel>()), Times.Once);
            Assert.Equal(issuer, document.CertificateIssuer);
            Assert.Equal(CertificateType.Vaccination, document.CertificateType);
            Assert.Equal(CertificateScenario.International, document.CertificateScenario);
            Assert.Equal(result, document.UniqueCertificateId);
        }

        [Fact]
        public async Task Test_GenerateUvciString_Region()
        {
            // Arrange
            var issuer = "NHS Digital";
            var country = "JE";
            var command = new RegionalGenerateAndInsertUvciCommand(issuer, country, "someHash", CertificateType.Vaccination,
                CertificateScenario.International, DateTime.Now.AddDays(30));

            RegionUvciGeneratorModel document = null;
            regionMongoRepository.Setup(r => r.InsertOneAsync(It.IsAny<RegionUvciGeneratorModel>())).Callback<RegionUvciGeneratorModel>((obj) => document = obj);

            var uvciGenerator = new UvciGenerator(configuration.Object, logger.Object, mongoRepository.Object, regionMongoRepository.Object);

            // Act
            var result = await uvciGenerator.TryGenerateAndInsertUvci(command);


            // Assert
            Assert.NotNull(result);
            Assert.Contains("URN:UVCI:01:JE:", result);
            regionMongoRepository.Verify(m => m.InsertOneAsync(It.IsAny<RegionUvciGeneratorModel>()), Times.Once);
            Assert.Equal(issuer, document.CertificateIssuer);
            Assert.Equal(CertificateType.Vaccination, document.CertificateType);
            Assert.Equal(CertificateScenario.International, document.CertificateScenario);
            Assert.Equal(result, document.UniqueCertificateId);
        }

        [Fact]
        public async void UVCIGeneratorTest_UVCIExistsForUser_NoResults()
        {
            // Arrange
            mongoRepository.Setup(x => x.FindOneAsync(It.IsAny<Expression<Func<UvciGeneratorModel, bool>>>())).ReturnsAsync((UvciGeneratorModel)null);
            var mockUser = new CovidPassportUser("name", DateTime.UtcNow, "email", "phone");

            var uvciGenerator = new UvciGenerator(configuration.Object, logger.Object, mongoRepository.Object, regionMongoRepository.Object);

            // Act
            var result = await uvciGenerator.UvciExistsForUser(mockUser, CertificateScenario.Domestic);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async void UVCIGeneratorTest_UVCIExistsForUser_SomeResults()
        {
            // Arrange
            mongoRepository
                .Setup(x => x.FindOneAsync(It.IsAny<Expression<Func<UvciGeneratorModel, bool>>>()))
                .ReturnsAsync(new UvciGeneratorModel("Uvci"));
            
            var mockUser = new CovidPassportUser("name", DateTime.UtcNow, "email", "phone");

            var uvciGenerator = new UvciGenerator(configuration.Object, logger.Object, mongoRepository.Object, regionMongoRepository.Object);
            
            // Act
            var result = await uvciGenerator.UvciExistsForUser(mockUser, CertificateScenario.Domestic);

            // Assert
            Assert.True(result);
        }
    }
}
