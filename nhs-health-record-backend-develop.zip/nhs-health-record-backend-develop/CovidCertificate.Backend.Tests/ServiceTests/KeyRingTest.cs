﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Azure.Security.KeyVault.Keys;
using CovidCertificate.Backend.Services.KeyServices;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Memory;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class KeyRingTest
    {
        [Fact]
        public async Task KeyRingCanCorrectlySignAndVerifyData()
        {
            // Arrange
            var provider = new MemoryConfigurationProvider(new MemoryConfigurationSource());
            var configuration = new ConfigurationRoot(new List<IConfigurationProvider> { provider });
            configuration["VaultUri"] = "https://localhost";

            var ecKey = ECDsa.Create();
            var sut = new KeyRing(configuration, () =>
                new Dictionary<string, KeyRing.KeyOps>
                {
                    {
                        "1",
                        new KeyRing.KeyOps(
                            extract: null,
                            sign: data => Task.FromResult(ecKey.SignData(data, HashAlgorithmName.SHA256)),
                            verify: (data, signature) => ecKey.VerifyData(data, signature, HashAlgorithmName.SHA256),
                            extractSubjectPublicKeyInfo: null)
                    }
                }
            );

            var testData = "Hello, World!";
            var keyId = sut.GetRandomKey();

            // Act
            var fut = await sut.SignData(keyId, Encoding.Unicode.GetBytes(testData));
            var result = sut.VerifyData(keyId, Encoding.Unicode.GetBytes(testData), fut);

            // Assert
            Assert.True(result);
            Assert.NotEqual(testData, System.Text.Encoding.Unicode.GetString(fut));
        }

        [Fact]
        public void KeyRingCanExtractPublicKeysFromItsKeys()
        {
            // Arrange
            var provider = new MemoryConfigurationProvider(new MemoryConfigurationSource());
            var configuration = new ConfigurationRoot(new List<IConfigurationProvider> { provider });
            configuration["VaultUri"] = "https://localhost";

            var privKey = "MHcCAQEEIIL4nF16xy7DomYdpBJYAlmKtO3NqPoVXgmjbtpurc0joA" +
                          "oGCCqGSM49AwEHoUQDQgAE9o1Z2+bghGSWZsuk6gmkmHrjelrZBJ3c" +
                          "ej1tJH2VYlRd+uGhBfBfRa8q09W3hOjfb4nvr32Yv3iTor7/gsrjjg==";

            var ecKey = ECDsa.Create();
            ecKey.ImportECPrivateKey(Convert.FromBase64String(privKey), out _);
            var jwk = new JsonWebKey(ecKey);
            var sut = new KeyRing(configuration, () =>
                new Dictionary<string, KeyRing.KeyOps>
                {
                    {
                        "1",
                        new KeyRing.KeyOps(
                            extract: () => jwk,
                            sign: null,
                            verify: null,
                            extractSubjectPublicKeyInfo: null)
                    }
                }
            );

            // Act
            var result = sut.ExtractPublicKeys();

            // Assert
            Assert.NotEmpty(result);
            Assert.Equal("9o1Z2+bghGSWZsuk6gmkmHrjelrZBJ3cej1tJH2VYlQ=", Convert.ToBase64String(result.Single().X));
            Assert.Equal("XfrhoQXwX0WvKtPVt4To32+J7699mL94k6K+/4LK444=", Convert.ToBase64String(result.Single().Y));
        }

        [Fact]
        public async Task AddingAnotherKeyIsAddedToExtraction()
        {
            // Arrange
            var provider = new MemoryConfigurationProvider(new MemoryConfigurationSource());
            var configuration = new ConfigurationRoot(new List<IConfigurationProvider> { provider });
            configuration["VaultUri"] = "https://localhost";

            var ecKey1 = ECDsa.Create();
            var ecKey2 = ECDsa.Create();
            var jwk1 = new JsonWebKey(ecKey1);
            var jwk2 = new JsonWebKey(ecKey2);
            var sut = new KeyRing(configuration, () =>
                new Dictionary<string, KeyRing.KeyOps>
                {
                    {
                        "1",
                        new KeyRing.KeyOps(
                            extract: () => jwk1,
                            sign: null,
                            verify: null,
                            extractSubjectPublicKeyInfo: null)
                    }
                }
            );

            // Act
            var result = sut.ExtractPublicKeys();

            // Assert
            Assert.True(result.Count() == 1);

            // Act
            await sut.ReinitializeKeys(() =>
                new Dictionary<string, KeyRing.KeyOps>
                {
                    {
                        "1",
                        new KeyRing.KeyOps(
                            extract: () => jwk1,
                            sign: null,
                            verify: null,
                            extractSubjectPublicKeyInfo: null)
                    },
                    {
                        "2",
                        new KeyRing.KeyOps(
                            extract: () => jwk2,
                            sign: null,
                            verify: null,
                            extractSubjectPublicKeyInfo: null)
                    }
                });

            // Assert
            result = sut.ExtractPublicKeys();
            Assert.True(result.Count() == 2);
        }
    }
}
