﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.BlobService;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Services.PdfGeneration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class HtmlGeneratorServiceTest
    {
        private readonly Mock<ILogger<HtmlGeneratorService>> loggerMock = new Mock<ILogger<HtmlGeneratorService>>();
        private readonly Mock<IQrImageGenerator> qrMock = new Mock<IQrImageGenerator>();
        private readonly Mock<IBlobService> blobStorageMock = new Mock<IBlobService>();
        private readonly Mock<IGetTimeZones> mockGetTimeZones;
        private readonly IConfiguration configuration;

        public HtmlGeneratorServiceTest()
        {
            var inMemorySettings = new Dictionary<string, string> {
                {"TestKey", "TestValue"},
                {"PdfBlobStorageConnectionString", "Test2"}
            };

            configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();

            qrMock.Setup(c => c.GenerateQrCodeString(It.IsAny<string>(), It.IsAny<int>())).Returns("012101210210");
            mockGetTimeZones = new Mock<IGetTimeZones>();
            mockGetTimeZones.Setup(x => x.GetTimeZoneInfo()).Returns(TimeZoneInfo.Utc);
            blobStorageMock.Setup(m => m.GetStringFromBlob(It.Is<string>(s => s == null), It.IsAny<string>())).Throws(new ArgumentNullException());
        }

        [Fact]
        public void HtmlGeneratorService_Configuration_Null()
        {
            var result = Assert.Throws<ArgumentNullException>(() => new HtmlGeneratorService(null , null, null, null, null));
            Assert.IsType<ArgumentNullException>(result);
            Assert.Equal("configuration",result.ParamName);
        }

        [Fact]
        public void HtmlGeneratorService_QR_Null()
        {
            var result = Assert.Throws<ArgumentNullException>(() => new HtmlGeneratorService(configuration , null, null, null, null));
            Assert.IsType<ArgumentNullException>(result);
            Assert.Equal("qrImageGenerator",result.ParamName);
        }

        [Fact]
        public void HtmlGeneratorService_Logger_Null()
        {
            var result = Assert.Throws<ArgumentNullException>(() => new HtmlGeneratorService(configuration , qrMock.Object, null, null, null));
            Assert.IsType<ArgumentNullException>(result);
            Assert.Equal("logger",result.ParamName);
        }

        
        [Fact]
        public void GenerateHtml_Configuration_MissingKey()
        {
            var inMemorySettings = new Dictionary<string, string> {
                {"TestKey", "TestValue"},
                {"connectionString", "Test2"}
            };

            var config = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();

            var uat = new HtmlGeneratorService(config , qrMock.Object, loggerMock.Object, mockGetTimeZones.Object, blobStorageMock.Object);
            var result = Assert.ThrowsAsync<ArgumentNullException>(() => uat.GenerateHtml(new GetHtmlRequestDto(), ""));
            Assert.IsType<ArgumentNullException>(result.Result);
        }

        [Fact]
        public void GenerateHtml_No_Connection_Blob()
        {
            var result = Assert.Throws<ArgumentNullException>(() => new HtmlGeneratorService(configuration, qrMock.Object, loggerMock.Object, mockGetTimeZones.Object, null));
            Assert.IsType<ArgumentNullException>(result);
        }

    }
}
