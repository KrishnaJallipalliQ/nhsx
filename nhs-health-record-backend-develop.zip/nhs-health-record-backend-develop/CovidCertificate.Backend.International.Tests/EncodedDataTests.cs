﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.International.Services;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.EuCertJsonSchema;
using CovidCertificate.Backend.Services.KeyServices;
using CovidCertificate.Backend.Utils;
using FluentAssertions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using PeterO.Cbor;
using Xunit;

namespace CovidCertificate.Backend.International.Tests
{
    // This class contains functional tests for encoding correct data to base45
    public class EncodedDataTests
    {
        [Theory]
        [InlineData("Firstname Middlename Middlename", "Lastname", "Firstname Middlename Middlename", "Lastname", "FIRSTNAME<MIDDLENAME<MIDDLENAME", "LASTNAME")]
        [InlineData("Firstname Middlename", "L'astname", "Firstname Middlename", "L'astname", "FIRSTNAME<MIDDLENAME", "L<ASTNAME")]
        [InlineData("Firstname Middlename", "L-astname", "Firstname Middlename", "L-astname", "FIRSTNAME<MIDDLENAME", "L<ASTNAME")]
        [InlineData("Mike O'Leary", "Smith-Johnson", "Mike O'Leary", "Smith-Johnson", "MIKE<O<LEARY", "SMITH<JOHNSON")]
        [InlineData("Firstname Middle-name Another-MiddleName", "L-astname SecondLastName", "Firstname Middle-name Another-MiddleName", "L-astname SecondLastName", "FIRSTNAME<MIDDLE<NAME<ANOTHER<MIDDLENAME", "L<ASTNAME<SECONDLASTNAME")]
        // Other inlinedata can be tested if NHS login allows non english alphabetical characters, still to be confirmed
        [InlineData("Jiřina-Maria Alena", "d'Červenková Panklová", "Jiřina-Maria Alena", "d'Červenková Panklová", "JIRINA<MARIA<ALENA", "D<CERVENKOVA<PANKLOVA")]
        [InlineData("Gabriele", "Musterfrau-Gößinger", "Gabriele", "Musterfrau-Gößinger", "GABRIELE", "MUSTERFRAU<GOSINGER")]
        [InlineData("Elith Nåd", "Møy", "Elith Nåd", "Møy", "ELITH<NAD", "MOY")]
        public async Task Base45EncodedData_DecodedData_MustMatchInputData(
            string givenName, 
            string familyName, 
            string expectedGN, 
            string expectedFN, 
            string expectedGNT, 
            string expectedFNT)
        {
            // Arrange
            var user = new DAUser("name", familyName, givenName, DateTime.Now.AddYears(-20));

            var certificateGenerationTime = DateTimeOffset.Now.ToUnixTimeSeconds();

            var vaccine = CreateVaccine();

            var vaccines = new List<Vaccine>
            {
                vaccine
            };

            var uvci = "someUVCI";
            var barcodeIssuerCountry = "GB";

            var validityEndDate = DateTime.Now.AddDays(6 * 30);

            var keyRingMock = new Mock<IKeyRing>();
            keyRingMock.Setup(x => x.GetRandomKey()).Returns("keyId");
            keyRingMock.Setup(x => x.SignData(It.IsAny<string>(), It.IsAny<byte[]>()))
                .ReturnsAsync((string keyId, byte[] data) =>
                {
                    return data;
                });

            var condensorLoggerMock = new Mock<ILogger<CondensorService>>();

            var configurationMock = new Mock<IConfiguration>();

            var getTimeZonesInfoMock = new Mock<IGetTimeZones>();
            getTimeZonesInfoMock.Setup(x => x.GetTimeZoneInfo()).Returns(TimeZoneInfo.Utc);

            var condensorService =
                new CondensorService(condensorLoggerMock.Object, configurationMock.Object, getTimeZonesInfoMock.Object);

            var cborFlowLoggerMock = new Mock<ILogger<CBORFlow>>();

            var cborFlowMock = new CBORFlow(cborFlowLoggerMock.Object, keyRingMock.Object);

            var encoderService = new EncoderService(condensorService, cborFlowMock,
                keyRingMock.Object);

            // Act
            var encodedString = await encoderService.EncodeFlowAsync(user, certificateGenerationTime, vaccines, uvci,
                validityEndDate, 0, barcodeIssuerCountry);

            // Decode and decompress data to check if data is correct
            var encodedStringWithRemovedPrefix = encodedString.Remove(0, 4);

            var decodedBytes = Base45Encoding.Decode(encodedStringWithRemovedPrefix);

            var unzippedBytes = ZlibCompression.DecompressData(decodedBytes);

            var cborObject = CBORObject.DecodeFromBytes(unzippedBytes);

            // Data is on third place (index=2) of CBORObject
            var cborContentObjectString = CBORObject.DecodeFromBytes(cborObject[2].GetByteString()).ToJSONString();

            var euCovidCertData = JsonConvert.DeserializeObject<EuCovidCert>(cborContentObjectString);

            // Assert
            encodedString.Should().StartWith("HC1:");
            euCovidCertData._1.Should().Be(barcodeIssuerCountry);
            euCovidCertData._6.Should().Be(certificateGenerationTime);
            euCovidCertData._4.Should().Be(new DateTimeOffset(validityEndDate).ToUnixTimeSeconds());
            euCovidCertData._260._1.dob.Should().Be(user.DateOfBirth.ToString(DateUtils.FHIRDateFormat));
            euCovidCertData._260._1.nam.fn.Should().Be(expectedFN);
            euCovidCertData._260._1.nam.gn.Should().Be(expectedGN);
            euCovidCertData._260._1.nam.fnt.Should().Be(expectedFNT);
            euCovidCertData._260._1.nam.gnt.Should().Be(expectedGNT);

            var v = euCovidCertData._260._1.v.First();
            v.ci.Should().Be(uvci);
            v.co.Should().Be(vaccine.CountryOfVaccination);
            v.dn.Should().Be(vaccine.DoseNumber);
            v.dt.Should().Be(vaccine.VaccinationDate.ToString(DateUtils.FHIRDateFormat));
            v._is.Should().Be(vaccine.Authority);
            v.ma.Should().Be(vaccine.VaccineManufacturer.Item1);
            v.mp.Should().Be(vaccine.Product.Item1);
            v.sd.Should().Be(vaccine.TotalSeriesOfDoses);
            v.tg.Should().Be(vaccine.DiseaseTargeted.Item1);
            v.vp.Should().Be(vaccine.VaccineType.Item1);
        }

        private static Vaccine CreateVaccine()
        {
            return new Vaccine(
                1,
                DateTime.Now.AddDays(-20),
                Tuple.Create("manufacturer1", "m1"),
                Tuple.Create("disease1", "d1"),
                Tuple.Create("vaccineType1", "vt1"),
                Tuple.Create("produce1", "p1"),
                "NLZMVQEATNZQBXLVHUCG",
                "GI",
                "Gibraltar",
                2,
                "Site",
                "Display Name",
                "Snomed Code",
                DateTime.MinValue
            );
        }
    }
}
