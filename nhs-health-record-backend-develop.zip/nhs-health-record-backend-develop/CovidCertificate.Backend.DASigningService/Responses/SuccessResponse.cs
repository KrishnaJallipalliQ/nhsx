﻿using System.Collections.Generic;

namespace CovidCertificate.Backend.DASigningService
{
    public class SuccessResponse
    {
        public List<string> Barcodes { get; set; }
    }
}
