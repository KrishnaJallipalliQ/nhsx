﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CovidCertificate.Backend.NhsApiIntegration.Interfaces;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Utils;
using Microsoft.Extensions.Configuration;
using System.Linq;

namespace CovidCertificate.Backend.Services
{
    public class AntibodyResultsService : IAntibodyResultsService
    {
        private readonly ILogger<AntibodyResultsService> logger;
        private readonly INhsdFhirApiService nhsdFhirApiService;
        private readonly IFhirBundleMapper<AntibodyResultNhs> fhirBundleMapper;
        private readonly IRedisCacheService redisCacheService;
        private readonly IConfiguration configuration;

        public AntibodyResultsService(
            ILogger<AntibodyResultsService> logger,
            INhsdFhirApiService nhsdFhirApiService,
            IFhirBundleMapper<AntibodyResultNhs> fhirBundleMapper,
            IRedisCacheService redisCacheService,
            IConfiguration configuration)
        {
            this.logger = logger;
            this.nhsdFhirApiService = nhsdFhirApiService;
            this.fhirBundleMapper = fhirBundleMapper;
            this.redisCacheService = redisCacheService;
            this.configuration = configuration;
        }

        public async Task<IEnumerable<AntibodyResultNhs>> GetAntibodyResults(string idToken)
        {
            if (configuration["GetAntibodyResultsFlag"].FlagEqualsFalse())
            {
                logger.LogInformation($"GetAntibodyResultsFlag is {configuration["GetAntibodyResultsFlag"]} so returning empty list");
                return Enumerable.Empty<AntibodyResultNhs>();
            }

            string key = $"GetAntibodyResults:{JwtTokenUtils.CalculateHashFromIdToken(idToken)}";

            IEnumerable<AntibodyResultNhs> cachedResults;
            bool cachedResponseExists;

            // If Redis is disabled for test results, do not get data from Redis
            if (configuration["DisableRedisForTestResults"].FlagEqualsTrue())
            {
                (cachedResults, cachedResponseExists) = (Enumerable.Empty<AntibodyResultNhs>(), false);
            }
            else
            {
                (cachedResults, cachedResponseExists) =
                    await redisCacheService.GetKeyValueAsync<IEnumerable<AntibodyResultNhs>>(key);
            }
            

            if (cachedResponseExists)
            {
                return cachedResults;
            }

            var bundle = await nhsdFhirApiService.GetAntibodyTestResults(idToken);
            var results = await fhirBundleMapper.ConvertBundle(bundle);

            // If Redis is disabled for test results, do not save data to Redis
            if (!configuration["DisableRedisForTestResults"].FlagEqualsTrue())
            {
                await redisCacheService.AddKeyAsync(key, results, RedisLifeSpanLevel.Medium);
            }

            return results;
        }
    }
}
