﻿using FluentValidation;

namespace CovidCertificate.Backend.Models.Validators
{
    public class PhoneNumberValidator : AbstractValidator<string>
    {
        public PhoneNumberValidator()
        {
            RuleFor(x => x).NotEmpty();
            RuleFor(x => x).Matches(ValidatorConsts.PhoneRegex);
        }
    }
}
