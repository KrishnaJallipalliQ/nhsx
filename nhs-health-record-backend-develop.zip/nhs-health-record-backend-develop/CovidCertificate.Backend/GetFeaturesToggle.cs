using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using System;
using SendGrid.Helpers.Errors.Model;

namespace CovidCertificate.Backend
{
    public class GetFeaturesToggle
    {
        private readonly IConfiguration configuration;
        private readonly ILogger<GetCertificateFunction> logger;

        public GetFeaturesToggle( IConfiguration configuration,
            ILogger<GetCertificateFunction> logger)
        {
           this.configuration = configuration;
           this.logger = logger;
        }
        [FunctionName("GetFeaturesToggle")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "GetFeaturesToggle")] HttpRequest req)
        {
            try
            {
                logger.LogInformation("GetFeaturesToggle was invoked");

                var p5plusEnabled = configuration["EnableP5PlusUsers"];

                return new OkObjectResult(p5plusEnabled);
            }
            catch (Exception e) when (e is BadRequestException || e is ArgumentException)
            {
                logger.LogError(e, e.Message);
                return new BadRequestObjectResult("There seems to be a problem: bad request");
            }
            catch (UnauthorizedException e)
            {
                logger.LogWarning(e, e.Message);
                return new UnauthorizedObjectResult("There seems to be a problem: unauthorized");
            }
            catch (Exception e)
            {
                logger.LogError(e, e.Message);
                var result = new ObjectResult(e.Message);
                result.StatusCode = 500;
                return result;
            }
        }
    }
}
