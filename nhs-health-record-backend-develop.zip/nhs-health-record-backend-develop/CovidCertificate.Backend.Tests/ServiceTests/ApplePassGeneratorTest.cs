﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.BlobService;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Passbook.Generator;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class ApplePassGeneratorTest
    {
        private readonly Mock<ICovidCertificateCreator> covidCertificateCreator = new Mock<ICovidCertificateCreator>(MockBehavior.Strict);
        private ApplePassGenerator applePassGenerator;
        private readonly Mock<IConfiguration> configurationMock = new Mock<IConfiguration>();
        private readonly Mock<IBlobService> blobStorageMock = new Mock<IBlobService>();
        private readonly Mock<ILogger<ApplePassGenerator>> loggerMock = new Mock<ILogger<ApplePassGenerator>>();
        private readonly string idToken = "dummytoken";
        private readonly Mock<IGeneratePassData> passDataMock = new Mock<IGeneratePassData>();
        private readonly Mock<IHtmlGeneratorService> htmlGeneratorMock = new Mock<IHtmlGeneratorService>();
        PassSettings testSettings = new PassSettings
        {
            PassProvider = "NHS",
            PassName = "Covid Status",
            PassOrigins = "Department of Health & Social Care"
        };


        /*[Fact]
        public async Task TestCreateCode_IsSuccessful()
        {
            applePassGenerator = new ApplePassGenerator(configurationMock.Object, covidCertificateCreator.Object, blobStorageMock.Object, loggerMock.Object, testSettings, passDataMock.Object);
            var covidUser = new CovidPassportUser("john test", DateTime.UtcNow, "john.test@test.com", "43888472647");
            var cert = new Certificate("Test Test", new DateTime(2000, 11, 20, 0, 0, 0, DateTimeKind.Utc), DateTime.UtcNow.AddDays(7), DateTime.UtcNow.AddDays(14), CertificateType.Vaccination, CertificateScenario.International);
            var passCertReturn = Convert.ToBase64String(Encoding.UTF8.GetBytes("passCert"));
            byte[] appleCertReturn = Encoding.UTF8.GetBytes("appleCert");
            var imageReturn = Encoding.UTF8.GetBytes("imageReturn");
            var qrResponse = new QRcodeResponse(DateTime.MinValue.ToString(), new List<IGenericResult>(), "URN:UVCI:01:GB:162392580000095ED1234#P", "");

            //Arrange
            configurationMock.SetupGet<string>(m => m["AppleWalletPassCert"]).Returns(passCertReturn);
            covidCertificateCreator.Setup(m => m.GetDomesticCertificate(covidUser, idToken)).ReturnsAsync(cert);
            blobStorageMock.Setup(m => m.GetImageFromBlob("pubkeys", "AppleWWDRCA.cer")).ReturnsAsync(appleCertReturn);
            blobStorageMock.Setup(m => m.GetImageFromBlob("images", "nhs_covid_status.png")).ReturnsAsync(imageReturn);
            passDataMock.Setup(m => m.GetPassDataAsync(covidUser, idToken, QRType.Domestic)).ReturnsAsync(Tuple.Create(qrResponse, cert));
            //Act
            var result = await applePassGenerator.PrepareRequestObject(covidUser, idToken, QRType.Domestic);
            //Assert
            Assert.IsType<PassGeneratorRequest>(result);
            Assert.True(Encoding.UTF8.GetString(result.Certificate) == "passCert");
            Assert.True(Encoding.UTF8.GetString(result.AppleWWDRCACertificate) == "appleCert");
            Assert.True(Encoding.UTF8.GetString(result.Images[PassbookImage.Icon]) == "imageReturn");
        }*/

        [Fact]
        public async Task TestCreateCode_NotSuccessful_InvalidCert()
        {
            applePassGenerator = new ApplePassGenerator(configurationMock.Object, covidCertificateCreator.Object, blobStorageMock.Object, loggerMock.Object, testSettings, passDataMock.Object,htmlGeneratorMock.Object);
            var covidUser = new CovidPassportUser("john test", DateTime.UtcNow, "john.test@test.com", "43888472647");

            var cert = new Certificate("Test Test", new DateTime(2000, 11, 20, 0, 0, 0, DateTimeKind.Utc), DateTime.UtcNow.AddDays(-1), DateTime.UtcNow.AddDays(2), CertificateType.Vaccination, CertificateScenario.International);
            var passCertReturn = Convert.ToBase64String(Encoding.UTF8.GetBytes("passCert"));
            byte[] appleCertReturn = Encoding.UTF8.GetBytes("appleCert");
            var imageReturn = Encoding.UTF8.GetBytes("imageReturn");

            //Arrange
            configurationMock.SetupGet<string>(m => m["AppleWalletPassCert"]).Returns(passCertReturn);
            covidCertificateCreator.Setup(m => m.GetDomesticCertificate(covidUser, idToken)).ReturnsAsync(() => default);
            blobStorageMock.Setup(m => m.GetImageFromBlobWithRetryAsync("pubkeys", "AppleWWDRCA.cer")).ReturnsAsync(appleCertReturn);
            blobStorageMock.Setup(m => m.GetImageFromBlobWithRetryAsync("images", "nhs_logo_white.png")).ReturnsAsync(imageReturn);

            //Assert
            await Assert.ThrowsAsync<InvalidDataException>(() => applePassGenerator.GeneratePass(covidUser, (QRType)7));
        }
    }
}
