﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using FluentValidation;

namespace CovidCertificate.Backend.Models.Validators
{
    public class EligibilityRulesValidator : AbstractValidator<EligibilityRules>
    {
        public EligibilityRulesValidator()
        {
            RuleForEach(x => x.Conditions).SetValidator(new EligibilityConditionValidator());

            RuleFor(x => x.ConfigurationName).NotEmpty().OnFailure(x =>
            {
                throw new ValidationException("configurationName was not specified.");
            });

            RuleFor(x => x.ConfigurationName.Length).LessThanOrEqualTo(255).OnFailure(x =>
            {
                throw new ValidationException("configurationName must not exceed the character limit of 255.");
            });

            RuleFor(x => x.CertificateType).NotNull().OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.CertificateType)} was not specified.");
            });
            RuleFor(x => CheckValidCertificateType(x.CertificateType)).Equal(true).OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.CertificateType)} must be a valid certificate type, must not be \"None\"");
            });

            RuleFor(x => x.Scenario).NotNull().OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.Scenario)} was not specified.");
            });

            RuleFor(x => x.ValidityPeriodHours).NotNull().OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.ValidityPeriodHours)} was not specified");
            });
            RuleFor(x => x.ValidityPeriodHours).GreaterThan(0).OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.ValidityPeriodHours)} cannot be less than or equal to 0");
            });

            RuleFor(x => x.FormatExpiry).NotNull().OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.FormatExpiry)} was not specified.");
            });
        }

        static bool CheckValidCertificateType(CertificateType? input)
        {
            return (input != CertificateType.None);
        }
    }
}
