﻿using System;
using System.Globalization;
using System.Threading.Tasks;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using Hl7.Fhir.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Linq;
using CovidCertificate.Backend.Models.Exceptions;
using System.Collections.Generic;
using CovidCertificate.Backend.Utils.Extensions;
using System.Text;

namespace CovidCertificate.Backend.Services.Mappers
{
    public class VaccinationMapper
    {
        private readonly IVaccineMapping _mapping;
        private readonly IConfiguration _configuration;
        private readonly ILogger<VaccinationMapper> _logger;
        private readonly IFhirLookupApi _fhirLookupApi;

        public VaccinationMapper(IVaccineMapping mapping, IConfiguration configuration, IFhirLookupApi fhirLookupApi, ILogger<VaccinationMapper> logger)
        {
            _mapping = mapping;
            _logger = logger;
            _configuration = configuration;
            _fhirLookupApi = fhirLookupApi;
        }

        /// <summary>
        /// Takes a vaccine in the Immunization format (from the Hl7.Fhir.R4 NuGet package)
        /// and maps it to the internal data model
        /// </summary>
        /// <param name="immunization"></param>
        /// <returns></returns>
        public async Task<Vaccine> MapFhirToVaccine(Immunization immunization, string issuer = null, string countryOverride = null)
        {
            var snomedCode = immunization.VaccineCode?.Coding?.FirstOrDefault()?.Code;
            var vaccineMap = await MapRawValue(snomedCode);
            var occurrenceString = immunization.Occurrence?.ToString();

            if (occurrenceString == null)
            {
                throw new VaccineMappingException("Occurrence of the immunization may not be null.");
            }

            var odsCode = FindOdsCode(immunization.Performer);
            var site = _fhirLookupApi.ConvertOdsCodeToName(odsCode);
            var stringDoseNumber = immunization.ProtocolApplied?.FirstOrDefault()?.DoseNumber?.ToString();
            var doseNumber = int.TryParse(stringDoseNumber, out var d)
                           ? d : throw new VaccineMappingException($"Parsing doseNumber '{stringDoseNumber}' failed in VaccinationMapper");
            var dateTime = DateTime.Parse(occurrenceString, CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal);
            var manufacturer = Tuple.Create<string, string>(vaccineMap.Manufacturer[0], vaccineMap.Manufacturer[1]);
            var country = countryOverride != null ? countryOverride : _configuration["CountryOfVaccination"];
            var disease = Tuple.Create<string, string>(vaccineMap.Disease[0], vaccineMap.Disease[1]);
            var vaccine = Tuple.Create<string, string>(vaccineMap.Vaccine[0], vaccineMap.Vaccine[1]);
            var product = Tuple.Create<string, string>(vaccineMap.Product[0], vaccineMap.Product[1]);
            var displayName = vaccineMap.Product.ElementAtOrDefault<string>(2);
            var batchNumber = immunization.LotNumber;
            var authority = issuer ?? _configuration["VaccinationAuthority"];
            var totalSeriesOfDoses = vaccineMap.TotalSeriesOfDoses;

            var dateEnteredString = immunization.Recorded?.ToString();
            var dateEntered = DateTime.MinValue;
            if (dateEnteredString != null)
            {
                dateEntered = DateTime.Parse(dateEnteredString, CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal);
            }

            return new Vaccine(doseNumber, dateTime, manufacturer, disease, vaccine, product, batchNumber, country, authority, totalSeriesOfDoses, await site, displayName, snomedCode, dateEntered);
        }

        /// <summary>
        /// Fetches the mappings for a vaccine code
        /// </summary>
        /// <param name="rawValue"></param>
        /// <returns></returns>
        public async Task<VaccineMap> MapRawValue(string rawValue)
        {
            if (string.IsNullOrEmpty(rawValue))
            {
                throw new VaccineMappingException("No SNOMED code for vaccine record");
            }
            var inMapping = (await _mapping.GetMappings()).TryGetValue(rawValue, out var b);
            //if this is an unknown code, return the raw value
            if (!inMapping)
            {
                _logger.LogError("Failed to map vaccine - unmapped SNOMED code: " + rawValue);
                throw new VaccineMappingException("Vaccine SNOMED code is not mapped");
            }
            _logger.LogInformation("MapRawValue has finished");
            return b;
        }

        /// <summary>
        /// Finds the ODS code for the administering centre.
        /// Tries to find the performer labeled as administering provider ("AP").
        /// If not present takes the first performer
        /// </summary>
        /// <param name="performers"></param>
        /// <returns></returns>
        public string FindOdsCode(List<Immunization.PerformerComponent> performers)
        {
            var administeringPerformer =
                performers.FirstOrDefault(perf => perf.Function?.Coding?.Any(y => y.Code.Equals("AP")) ?? false);
            if (administeringPerformer == default)
            {
                administeringPerformer = performers.FirstOrDefault();
            }

            return administeringPerformer?.Actor?.Identifier?.Value;
        }

        public DAUser DAUserFromPatient(Patient patient)
        {            
            var familyName = patient.Name[0].Family;

            var givenSB = new StringBuilder();
            foreach (var name in patient.Name[0].Given)
            {
                givenSB.Append(name);
                givenSB.Append(" ");
            }
            var givenName = givenSB.ToString();

            var nameSB = new StringBuilder();
            nameSB.Append(givenSB);
            nameSB.Append(familyName);

            var dob = DateTime.Parse(patient.BirthDate);

            return new DAUser(nameSB.ToString(), familyName, givenName.Trim(), dob);
        }
    }
}
