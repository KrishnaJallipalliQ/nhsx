﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.DataModels
{
    [Collection("ThirdParties")]
    public class ThirdParty : MongoDocument
    {
        public ThirdParty(string thirdPartyId, string thirdPartyName) : base()
        {
            ThirdPartyId = thirdPartyId;
            ThirdPartyName = thirdPartyName;
        }

        public string ThirdPartyId { get; set; }

        public string ThirdPartyName { get; set; }
    }
}
