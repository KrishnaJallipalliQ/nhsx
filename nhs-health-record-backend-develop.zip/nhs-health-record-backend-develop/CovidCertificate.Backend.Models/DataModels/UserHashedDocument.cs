﻿using System;
using CovidCertificate.Backend.Models.Interfaces;
using CovidCertificate.Backend.Utils;
using Newtonsoft.Json;
using System.Security.Cryptography;
using System.Text;

namespace CovidCertificate.Backend.Models.DataModels
{
    public class UserHashedDocument : MongoDocument, IUserHashedDocument
    {
        public UserHashedDocument(string name, DateTime dateOfBirth, string phoneNumber, string emailAddress, string nhsNumber)
        {
            PartitionKey = StringUtils.GetValueHash(name, dateOfBirth);
            PhoneHash = string.IsNullOrEmpty(phoneNumber) ? string.Empty : StringUtils.GetValueHash(phoneNumber, name, dateOfBirth);
            EmailHash = string.IsNullOrEmpty(emailAddress) ? string.Empty : StringUtils.GetValueHash(emailAddress, name, dateOfBirth);
            NhsNumberHash = string.IsNullOrEmpty(nhsNumber) ? string.Empty : StringUtils.GetValueHash(nhsNumber, dateOfBirth);
        }

        [JsonConstructor]
        protected UserHashedDocument(string id,
            [JsonProperty("PartitionKey")] string keyHash,
            [JsonProperty("PhoneHash")] string phoneNameAndDateOfBirthHash,
            [JsonProperty("EmailHash")] string emailNameAndDateOfBirthHash,
            [JsonProperty("NhsNumberHash")] string nhsNumberAndDateOfBirthHash) : base(id)
        {
            PartitionKey = keyHash;
            PhoneHash = phoneNameAndDateOfBirthHash;
            EmailHash = emailNameAndDateOfBirthHash;
            NhsNumberHash = nhsNumberAndDateOfBirthHash;
        }

        /// <summary>
        /// A concatenated <see cref="SHA256"/> <see cref="string"/> of the user's PhoneNumber, Name and DateOfBirth.
        /// </summary>
        public string PhoneHash { get; private set; }
        /// <summary>
        /// A concatenated <see cref="SHA256"/> <see cref="string"/> of the user's EmailAddress, Name and DateOfBirth.
        /// </summary>
        public string EmailHash { get; private set; }
        /// <summary>
        /// A concatenated <see cref="SHA256"/> <see cref="string"/> of the user's NhsNumber, Name and DateOfBirth.
        /// </summary>
        public string NhsNumberHash { get; private set; }
        /// <summary>
        /// A concatenated <see cref="SHA256"/> <see cref="string"/> of the user's Name and DateOfBirth.
        /// </summary>
        public string PartitionKey { get; private set; }

        public PilotUser ToPilotUser() => new PilotUser(this);
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("EmailHash:").Append(this.EmailHash??"").AppendLine();
            sb.Append("PartitionKey:").Append(this.PartitionKey??"").AppendLine();
            sb.Append("PhoneHash:").Append(this.PhoneHash??"").AppendLine();
            sb.Append("NhsNumberHash:").Append(this.NhsNumberHash??"").AppendLine();
          
            return base.ToString();
        }
    }
}
