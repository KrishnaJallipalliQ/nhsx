﻿using CovidCertificate.Backend.Models.Interfaces;
using CovidCertificate.Backend.Models.RequestDtos;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IEmailService
    {
        /// <summary>
        /// Sends an email from a template using the input model, we get the extra properties we need for the email from the 
        /// input interface
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="emailContent"></param>
        /// <param name="templateId"></param>
        /// <returns></returns>
        public Task SendEmail<T>(T emailContent, string templateId) where T : IEmailModel;
    }
}
