﻿
namespace CovidCertificate.Backend.Models.Settings
{
    public class PublicKeySaverSettings
    {
        public string FileName { get; set; }

        public string Container { get; set; }

        public bool ExportAsSubjectKeyInfo { get; set; } = false;
    }
}
