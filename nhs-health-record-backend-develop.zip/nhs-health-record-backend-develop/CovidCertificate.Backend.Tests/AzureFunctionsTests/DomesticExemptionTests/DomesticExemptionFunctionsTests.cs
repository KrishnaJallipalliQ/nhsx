﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Settings;
using Microsoft.Extensions.Logging;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace CovidCertificate.Backend.Tests.AzureFunctionsTests
{
    public class DomesticExemptionFunctionsTests : IClassFixture<AzureFunctionFixture<DomesticExemption>>
    {
        private readonly Mock<ILogger<DomesticExemptionFunctions>> logger;
        private readonly Mock<IDomesticExemptionService> domesticExemptionService;
        private readonly Mock<IDomesticExemptionParser> domesticExemptionParser;
        private readonly DomesticExemptionSettings settings;
        private readonly Mock<IQueueService> queueService;

        public DomesticExemptionFunctionsTests(AzureFunctionFixture<DomesticExemption> fixture)
        {
            this.queueService = fixture.QueueServiceMock;
            this.settings = new DomesticExemptionSettings();
            this.domesticExemptionParser = new Mock<IDomesticExemptionParser>();
            this.domesticExemptionService = new Mock<IDomesticExemptionService>();
            this.logger = new Mock<ILogger<DomesticExemptionFunctions>>();
        }

        [Fact]
        public async Task SaveExemptionBulk_EmptyRequest_ReturnsSuccess()
        {
            // Arrange
            queueService.Invocations.Clear();
            var request = AzureFunctionTestHelper.CreateRequest("abc");
            
            settings.SaveQueueName = "some queue name";

            var exemptions = new List<DomesticExemption>()
            {
            };

            var domesticExemptionFunctions = new DomesticExemptionFunctions(domesticExemptionService.Object, logger.Object, domesticExemptionParser.Object, settings, queueService.Object);

            domesticExemptionParser.Setup(x => x.ParseStringInputToDomesticExemptions(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync((exemptions,new List<string>()));

            queueService
                .Setup(x => x.SendMessage(It.IsAny<string>(), It.IsAny<DomesticExemption>()))
                .ReturnsAsync(true)
                .Verifiable();

            // Act 
            var result = await domesticExemptionFunctions.SaveDomesticExemptionBulk(request);

            // Assert
            queueService.Verify(x => x.SendMessage(It.IsAny<string>(), It.IsAny<DomesticExemption>()), Times.Never);
            Assert.Equal(typeof(OkObjectResult), result.GetType());
        }

        [Fact]
        public async Task SaveExemptionBulk_SaveOne_ReturnsSuccess()
        {
            // Arrange
            queueService.Invocations.Clear();
            var request = AzureFunctionTestHelper.CreateRequest("abc");

            settings.SaveQueueName = "some queue name";

            var hash = "hash";
            var reason = "some reason";
            var exemptions = new List<DomesticExemption>(){
                    new DomesticExemption(hash, reason)
                };

            var domesticExemptionFunctions = new DomesticExemptionFunctions(domesticExemptionService.Object, logger.Object, domesticExemptionParser.Object, settings, queueService.Object);

            domesticExemptionParser.Setup(x => x.ParseStringInputToDomesticExemptions(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync((exemptions, new List<string>()));

            queueService
                .Setup(x => x.SendMessage(It.IsAny<string>(), It.IsAny<DomesticExemption>()))
                .ReturnsAsync(true)
                .Verifiable();

            // Act 
            var result = await domesticExemptionFunctions.SaveDomesticExemptionBulk(request);

            // Assert
            queueService.Verify(x => x.SendMessage(It.IsAny<string>(), It.IsAny<DomesticExemption>()), Times.Once);
            Assert.Equal(typeof(OkObjectResult), result.GetType());
        }

        [Fact]
        public async Task SaveExemptionBulk_SaveMultiple_ReturnSuccess()
        {
            // Arrange
            queueService.Invocations.Clear();
            var request = AzureFunctionTestHelper.CreateRequest("abc");

            settings.SaveQueueName = "some queue name";

            var hash = "hash";
            var differentHash = "differentHash";
            var reason = "some reason";
            var exemptions = new List<DomesticExemption>(){
                    new DomesticExemption(hash, reason),
                    new DomesticExemption(differentHash, reason)
                };

            var domesticExemptionFunctions = new DomesticExemptionFunctions(domesticExemptionService.Object, logger.Object, domesticExemptionParser.Object, settings, queueService.Object);

            domesticExemptionParser.Setup(x => x.ParseStringInputToDomesticExemptions(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync((exemptions, new List<string>()));

            queueService
                .Setup(x => x.SendMessage(It.IsAny<string>(), It.IsAny<DomesticExemption>()))
                .ReturnsAsync(true)
                .Verifiable();

            // Act 
            var result = await domesticExemptionFunctions.SaveDomesticExemptionBulk(request);
            
            // Assert
            queueService.Verify(x => x.SendMessage(It.IsAny<string>(), It.IsAny<DomesticExemption>()), Times.Exactly(2));
            Assert.Equal(typeof(OkObjectResult), result.GetType());
        }



        [Fact]
        public async Task SaveExemptionBulk_SaveMultiple_SameHash_OnlySentOnce_ReturnSuccess()
        {
            // Arrange
            queueService.Invocations.Clear();
            var request = AzureFunctionTestHelper.CreateRequest("abc");

            settings.SaveQueueName = "some queue name";

            var hash = "hash";
            var reason = "some reason";
            var exemptions = new List<DomesticExemption>(){
                    new DomesticExemption(hash, reason),
                    new DomesticExemption(hash, reason)
                };

            var domesticExemptionFunctions = new DomesticExemptionFunctions(domesticExemptionService.Object, logger.Object, domesticExemptionParser.Object, settings, queueService.Object);

            domesticExemptionParser.Setup(x => x.ParseStringInputToDomesticExemptions(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync((exemptions, new List<string>()));

            queueService.Setup(x => x.SendMessage(It.IsAny<string>(), It.IsAny<DomesticExemption>()))
                .ReturnsAsync(true)
                .Verifiable();

            // Act 
            var result = await domesticExemptionFunctions.SaveDomesticExemptionBulk(request);

            // Assert
            queueService.Verify(x => x.SendMessage(It.IsAny<string>(), It.IsAny<DomesticExemption>()), Times.Exactly(1));
            Assert.Equal(typeof(OkObjectResult), result.GetType());
        }

        [Fact]
        public async Task RemoveExemptionBulk_EmptyRequest_ReturnsSuccess()
        {
            // Arrange
            queueService.Invocations.Clear();
            var request = AzureFunctionTestHelper.CreateRequest("abc");

            settings.RemoveQueueName = "some queue name";

            var exemptions = new List<DomesticExemption>()
            {
            };

            var domesticExemptionFunctions = new DomesticExemptionFunctions(domesticExemptionService.Object, logger.Object, domesticExemptionParser.Object, settings, queueService.Object);

            domesticExemptionParser.Setup(x => x.ParseStringInputToDomesticExemptions(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync((exemptions, new List<string>()));

            queueService
                .Setup(x => x.SendMessage(It.IsAny<string>(), It.IsAny<DomesticExemption>()))
                .ReturnsAsync(true)
                .Verifiable();

            // Act 
            var result = await domesticExemptionFunctions.RemoveDomesticExemptionBulk(request);

            // Assert
            queueService.Verify(x => x.SendMessage(It.IsAny<string>(), It.IsAny<DomesticExemption>()), Times.Never);
            Assert.Equal(typeof(OkObjectResult), result.GetType());
        }

        [Fact]
        public async Task RemoveExemptionBulk_SaveOne_ReturnsSuccess()
        {
            // Arrange
            queueService.Invocations.Clear();
            var request = AzureFunctionTestHelper.CreateRequest("abc");

            settings.RemoveQueueName = "some queue name";

            var hash = "hash";
            var reason = "some reason";
            var exemptions = new List<DomesticExemption>(){
                    new DomesticExemption(hash, reason)
                };

            var domesticExemptionFunctions = new DomesticExemptionFunctions(domesticExemptionService.Object, logger.Object, domesticExemptionParser.Object, settings, queueService.Object);

            domesticExemptionParser.Setup(x => x.ParseStringInputToDomesticExemptions(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync((exemptions, new List<string>()));

            queueService
                .Setup(x => x.SendMessage(It.IsAny<string>(), It.IsAny<DomesticExemption>()))
                .ReturnsAsync(true)
                .Verifiable();

            // Act 
            var result = await domesticExemptionFunctions.RemoveDomesticExemptionBulk(request);

            // Assert
            queueService.Verify(x => x.SendMessage(It.IsAny<string>(), It.IsAny<DomesticExemption>()), Times.Once);
            Assert.Equal(typeof(OkObjectResult), result.GetType());
        }

        [Fact]
        public async Task RemoveExemptionBulk_SaveMultiple_ReturnSuccess()
        {
            // Arrange
            queueService.Invocations.Clear();
            var request = AzureFunctionTestHelper.CreateRequest("abc");

            settings.RemoveQueueName = "some queue name";

            var hash = "hash";
            var differentHash = "differentHash";
            var reason = "some reason";
            var exemptions = new List<DomesticExemption>(){
                    new DomesticExemption(hash, reason),
                    new DomesticExemption(differentHash, reason)
                };

            domesticExemptionParser.Setup(x => x.ParseStringInputToDomesticExemptions(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync((exemptions, new List<string>()));

            var domesticExemptionFunctions = new DomesticExemptionFunctions(domesticExemptionService.Object, logger.Object, domesticExemptionParser.Object, settings, queueService.Object);

            queueService
                .Setup(x => x.SendMessage(It.IsAny<string>(), It.IsAny<DomesticExemption>()))
                .ReturnsAsync(true)
                .Verifiable();

            // Act 
            var result = await domesticExemptionFunctions.RemoveDomesticExemptionBulk(request);

            // Assert
            queueService.Verify(x => x.SendMessage(It.IsAny<string>(), It.IsAny<DomesticExemption>()), Times.Exactly(2));
            Assert.Equal(typeof(OkObjectResult), result.GetType());
        }

        [Fact]
        public async Task RemoveExemptionBulk_SaveMultiple_SameHash_ReturnSuccess()
        {
            // Arrange
            queueService.Invocations.Clear();
            var request = AzureFunctionTestHelper.CreateRequest("abc");

            settings.RemoveQueueName = "some queue name";

            var hash = "hash";
            var reason = "some reason";
            var exemptions = new List<DomesticExemption>(){
                    new DomesticExemption(hash, reason),
                    new DomesticExemption(hash, reason)
                };

            var domesticExemptionFunctions = new DomesticExemptionFunctions(domesticExemptionService.Object, logger.Object, domesticExemptionParser.Object, settings, queueService.Object);

            domesticExemptionParser.Setup(x => x.ParseStringInputToDomesticExemptions(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync((exemptions, new List<string>()));

            queueService
                .Setup(x => x.SendMessage(It.IsAny<string>(), It.IsAny<DomesticExemption>()))
                .ReturnsAsync(true)
                .Verifiable();

            // Act 
            var result = await domesticExemptionFunctions.RemoveDomesticExemptionBulk(request);

            // Assert
            queueService.Verify(x => x.SendMessage(It.IsAny<string>(), It.IsAny<DomesticExemption>()), Times.Exactly(1));
            Assert.Equal(typeof(OkObjectResult), result.GetType());
        }


        [Fact]
        public async Task SaveExemptionBulk_MissingQueueName_Returns500()
        {
            // Arrange
            var request = AzureFunctionTestHelper.CreateRequest("abc");

            var domesticExemptionFunctions = new DomesticExemptionFunctions(domesticExemptionService.Object, logger.Object, domesticExemptionParser.Object, settings, queueService.Object);

            // Act 
            var result = await domesticExemptionFunctions.RemoveDomesticExemptionBulk(request);

            // Assert
            Assert.Equal(500, ((StatusCodeResult)result).StatusCode);
        }

        [Fact]
        public async Task SaveExemptionBulk_SaveOne_QueueServiceFails_ReturnsSuccess()
        {
            // Arrange
            queueService.Invocations.Clear();
            var request = AzureFunctionTestHelper.CreateRequest("abc");

            settings.SaveQueueName = "some queue name";

            var hash = "hash";
            var reason = "some reason";
            var exemptions = new List<DomesticExemption>(){
                    new DomesticExemption(hash, reason)
                };

            var domesticExemptionFunctions = new DomesticExemptionFunctions(domesticExemptionService.Object, logger.Object, domesticExemptionParser.Object, settings, queueService.Object);

            domesticExemptionParser.Setup(x => x.ParseStringInputToDomesticExemptions(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync((exemptions, new List<string>()));

            queueService
                .Setup(x => x.SendMessage(It.IsAny<string>(), It.IsAny<DomesticExemption>()))
                .ReturnsAsync(false)
                .Verifiable();

            // Act 
            var result = await domesticExemptionFunctions.SaveDomesticExemptionBulk(request);

            // Assert
            queueService.Verify(x => x.SendMessage(It.IsAny<string>(), It.IsAny<DomesticExemption>()), Times.Once);
            Assert.Equal(typeof(OkObjectResult), result.GetType());
        }
    }
}
