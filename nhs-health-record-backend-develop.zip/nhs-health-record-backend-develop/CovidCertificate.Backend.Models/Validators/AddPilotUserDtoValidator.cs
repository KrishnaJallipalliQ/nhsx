﻿using CovidCertificate.Backend.Models.RequestDtos;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.Validators
{
    public class AddPilotUserDtoValidator : AbstractValidator<AddPilotUserDto>
    {
        public AddPilotUserDtoValidator()
        {
            RuleFor(x => x.Name).NotEmpty();
            RuleFor(x => x.DateOfBirth).NotEmpty();
           
        }
    }
}
