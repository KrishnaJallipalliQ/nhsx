﻿using CovidCertificate.Backend.DASigningService.Interfaces;
using CovidCertificate.Backend.DASigningService.Models;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using Microsoft.Extensions.Logging;
using System;
using System.Net;
using System.Threading.Tasks;


namespace CovidCertificate.Backend.DASigningService.Services
{
    public class LogService : ILogService
    {
        private readonly IMongoRepository<Region2DBarcodeResult> mongoRepository;

        public LogService(IMongoRepository<Region2DBarcodeResult> mongoRepository)
        {            
            this.mongoRepository = mongoRepository;            
        }

        public async Task LogResult(ILogger logger, string uvci, string apiName, HttpStatusCode httpCode, RegionConfig regionConfig)
        {
            string regionCode = "Unrecognized";

            if (regionConfig != null)
            {
                regionCode = regionConfig.RegionCode;
            }
            const string formatString = "{regionCode}:{className}:{message}";
            string messageString = $"Returned HTTP code: {httpCode}";

            switch (httpCode)
            {
                case HttpStatusCode.OK:
                    logger.LogInformation(formatString, regionCode, apiName, messageString);
                    break;
                case HttpStatusCode.BadRequest:
                    logger.LogWarning(formatString, regionCode, apiName, messageString);
                    break;
                default:
                    logger.LogError(formatString, regionCode, apiName, messageString);
                    break;
            }
            
            await SaveResultToCosmosDB(uvci, (int)httpCode, DateTime.Now, regionCode);
        }

        private async Task SaveResultToCosmosDB(string uvci, int httpStatus, DateTime timstamp, string regionCode)
        {
            var document = new Region2DBarcodeResult(uvci, httpStatus, timstamp, regionCode);

            await mongoRepository.InsertOneAsync(document);
        }
    }
}
