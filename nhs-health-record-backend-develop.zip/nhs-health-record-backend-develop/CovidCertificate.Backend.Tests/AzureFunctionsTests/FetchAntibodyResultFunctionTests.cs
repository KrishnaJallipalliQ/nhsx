﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Delegates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Services;
using CovidCertificate.Backend.Tests.TestHelpers;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Tests.AzureFunctionsTests
{
    public class FetchAntibodyResultFunctionTests : IClassFixture<AzureFunctionFixture<AntibodyResult>>, IDisposable
    {
        public readonly Action ClearCollection;

        private readonly IJwtGenerator jwtGenerator;
        private readonly FetchAntibodyResultFunction fetchAntibodyResultFunction;
        private readonly Mock<ILogger<FetchAntibodyResultFunction>> loggerMock;
        private readonly string bearerTokenPrefix;
        private readonly JwtValidatorResolver jwtValidatorResolver;
        private readonly Mock<IPilotFilterService> mockPilotFilter = new Mock<IPilotFilterService>();
        private readonly Mock<IConfiguration> mockConfig = new Mock<IConfiguration>();
        private readonly Mock<AntibodyResultsService> mockAntibodyResultsService = new Mock<AntibodyResultsService>();
        private readonly Mock<IGetTimeZones> mockGetTimeZones;

        public FetchAntibodyResultFunctionTests(AzureFunctionFixture<AntibodyResult> fixture)
        {
            this.ClearCollection = fixture.Dispose;
            this.jwtGenerator = fixture.JwtGenerator;
            this.loggerMock = new Mock<ILogger<FetchAntibodyResultFunction>>();
            this.jwtValidatorResolver = Mock.Of<JwtValidatorResolver>();
            this.fetchAntibodyResultFunction = new FetchAntibodyResultFunction(this.jwtValidatorResolver, mockPilotFilter.Object,mockConfig.Object, mockAntibodyResultsService.Object, loggerMock.Object, mockGetTimeZones.Object);
            this.bearerTokenPrefix = "bearer ";
            mockConfig.SetupGet<string>(m => m["TimeZoneWindows"]).Returns("GMT Standard Time");
            mockConfig.SetupGet<string>(m => m["TimeZoneLinux"]).Returns("Europe/London");
            mockGetTimeZones = new Mock<IGetTimeZones>();
            mockGetTimeZones.Setup(x => x.GetTimeZoneInfo()).Returns(TimeZoneInfo.Local);
        }

        public void Dispose() => ClearCollection();

        #region Tests

        [Fact(Skip = "Disabled during work on nhs login integration")]
        public async Task FetchAntibodyResultFunction_RequestWithNoToken()
        {
            // Arrange
            var request = AzureFunctionTestHelper.CreateRequestWithHeaderDictionaryAndQuery(null, null, null);
            var expectedErrorMessage = "Does not contain authorization token";

            // Act
            var actualResponse = await fetchAntibodyResultFunction.Run(request) as UnauthorizedObjectResult;

            // Assert
            Assert.NotNull(actualResponse);
            Assert.Equal(expectedErrorMessage, actualResponse.Value);
        }

        [Fact(Skip = "Disabled during work on nhs login integration")]
        public async Task FetchAntibodyResultFunction_RequestWithInvalidTokenFormat()
        {
            // Arrange
            var jwtToken = "Invalid Token Format";
            var request = AzureFunctionTestHelper.CreateRequest(string.Empty, jwtToken);
            var expectedErrorMessage = "Invalid token";
            var expectedLogMessage = "IDX12741: JWT: 'System.String' must have three segments (JWS) or five segments (JWE).";

            // Act
            var actualResponse = await fetchAntibodyResultFunction.Run(request) as UnauthorizedObjectResult;

            // Assert
            loggerMock.Verify(x => x.Log(
                LogLevel.Warning,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((obj, type) => string.Equals(expectedLogMessage, obj.ToString(), StringComparison.InvariantCultureIgnoreCase)),
                It.IsAny<ArgumentException>(),
                (Func<It.IsAnyType, Exception, string>)It.IsAny<object>()),
                Times.Once());
            Assert.NotNull(actualResponse);
            Assert.Equal(expectedErrorMessage, actualResponse.Value);
        }

        [Theory(Skip = "Disabled during work on nhs login integration")]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public async Task FetchAntibodyResultFunction_RequestUsingHeadersForTokenStartingWithBearer_ShouldReturnOneResults(CovidPassportUser user)
        {
            // Arrange
            var antibodyResult = AntibodyTestHelper.CreateAntibodyResult(user);
            var jwtToken = bearerTokenPrefix + (await jwtGenerator.Issue(user)).Token;
            var request = AzureFunctionTestHelper.CreateRequest(string.Empty, jwtToken);
            var expectedResponse = new List<AntibodyResultResponse>() { new AntibodyResultResponse(antibodyResult, mockGetTimeZones.Object) } as IEnumerable<AntibodyResultResponse>;

            // Act
            var actualResponse = await fetchAntibodyResultFunction.Run(request) as OkObjectResult;
            var actualResponseValue = actualResponse.Value as IEnumerable<AntibodyResultResponse>;

            // Assert
            Assert.NotNull(actualResponse);
            Assert.NotNull(actualResponseValue);
            Assert.True(actualResponseValue.SequenceEqual(expectedResponse));
        }
  
        [Theory(Skip = "Disabled during work on nhs login integration")]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public async Task FetchAntibodyResultFunction_RequestUsingQueryForTokenStartingWithBearer_ShouldReturnOneResults(CovidPassportUser user)
        {
            // Arrange
            var antibodyResult = AntibodyTestHelper.CreateAntibodyResult(user);
            var jwtToken = bearerTokenPrefix + (await jwtGenerator.Issue(user)).Token;
            var queryStore = new Dictionary<string, StringValues>();
            queryStore.Add(AzureFunctionTestHelper.TokenQueryKey, jwtToken);
            var queryCollection = new QueryCollection(queryStore);
            var request = AzureFunctionTestHelper.CreateRequestWithHeaderDictionaryAndQuery(null, null, queryCollection);
            var expectedResponse = new List<AntibodyResultResponse>() { new AntibodyResultResponse(antibodyResult, mockGetTimeZones.Object) } as IEnumerable<AntibodyResultResponse>;

            // Act
            var actualResponse = await fetchAntibodyResultFunction.Run(request) as OkObjectResult;
            var actualResponseValue = actualResponse?.Value as IEnumerable<AntibodyResultResponse>;

            // Assert
            Assert.NotNull(actualResponse);
            Assert.NotNull(actualResponseValue);
            Assert.True(actualResponseValue.SequenceEqual(expectedResponse));
        }

        [Theory(Skip = "Disabled during work on nhs login integration")]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public async Task FetchAntibodyResultFunction_RequestUsingHeadersForToken_ShouldReturnOneResults(CovidPassportUser user)
        {
            // Arrange
            var antibodyResult = AntibodyTestHelper.CreateAntibodyResult(user);
            var jwtToken = (await jwtGenerator.Issue(user)).Token;
            var request = AzureFunctionTestHelper.CreateRequest(string.Empty, jwtToken);
            var expectedResponse = new List<AntibodyResultResponse>() { new AntibodyResultResponse(antibodyResult, mockGetTimeZones.Object) } as IEnumerable<AntibodyResultResponse>;

            // Act
            var actualResponse = await fetchAntibodyResultFunction.Run(request) as OkObjectResult;
            var actualResponseValue = actualResponse.Value as IEnumerable<AntibodyResultResponse>;

            // Assert
            Assert.NotNull(actualResponse);
            Assert.NotNull(actualResponseValue);
            Assert.True(actualResponseValue.SequenceEqual(expectedResponse));
        }

        [Theory(Skip = "Disabled during work on nhs login integration")]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public async Task FetchAntibodyResultFunction_RequestUsingQueryForToken_ShouldReturnOneResults(CovidPassportUser user)
        {
            var antibodyResult = AntibodyTestHelper.CreateAntibodyResult(user);
            var jwtToken = (await jwtGenerator.Issue(user)).Token;
            var queryStore = new Dictionary<string, StringValues>();
            queryStore.Add(AzureFunctionTestHelper.TokenQueryKey, jwtToken);
            var queryCollection = new QueryCollection(queryStore);
            var request = AzureFunctionTestHelper.CreateRequestWithHeaderDictionaryAndQuery(null, null, queryCollection);
            var expectedResponse = new List<AntibodyResultResponse>() { new AntibodyResultResponse(antibodyResult, mockGetTimeZones.Object) } as IEnumerable<AntibodyResultResponse>;

            // Act
            var actualResponse = await fetchAntibodyResultFunction.Run(request) as OkObjectResult;
            var actualResponseValue = actualResponse?.Value as IEnumerable<AntibodyResultResponse>;

            // Assert
            Assert.NotNull(actualResponse);
            Assert.NotNull(actualResponseValue);
            Assert.True(actualResponseValue.SequenceEqual(expectedResponse));
        }

        [Theory(Skip = "Disabled during work on nhs login integration")]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public async Task FetchAntibodyResultFunction_RequestUsingHeadersForToken_ShouldReturnMultipleResults(CovidPassportUser user)
        {
            // Arrange
            var antibodyResults = new List<AntibodyResult>(AntibodyTestHelper.CreateAntibodyResult(user, 3));
            var jwtToken = (await jwtGenerator.Issue(user)).Token;
            var request = AzureFunctionTestHelper.CreateRequest(string.Empty, jwtToken);
            var expectedResponse = antibodyResults.Select(x => new AntibodyResultResponse(x, mockGetTimeZones.Object));

            // Act
            var actualResponse = await fetchAntibodyResultFunction.Run(request) as OkObjectResult;
            var actualResponseValue = actualResponse.Value as IEnumerable<AntibodyResultResponse>;

            // Assert
            Assert.NotNull(actualResponse);
            Assert.NotNull(actualResponseValue);
            Assert.True(actualResponseValue.SequenceEqual(expectedResponse));
        }

        [Theory(Skip = "Disabled during work on nhs login integration")]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public async Task FetchAntibodyResultFunction_RequestUsingQueryForToken_ShouldReturnMultipleResults(CovidPassportUser user)
        {
            // Arrange
            var antibodyResults = new List<AntibodyResult>(AntibodyTestHelper.CreateAntibodyResult(user, 3));
            var jwtToken = (await jwtGenerator.Issue(user)).Token;
            var queryStore = new Dictionary<string, StringValues>();
            queryStore.Add(AzureFunctionTestHelper.TokenQueryKey, jwtToken);
            var queryCollection = new QueryCollection(queryStore);
            var request = AzureFunctionTestHelper.CreateRequestWithHeaderDictionaryAndQuery(null, null, queryCollection);
            var expectedResponse = antibodyResults.Select(x => new AntibodyResultResponse(x, mockGetTimeZones.Object));

            // Act
            var actualResponse = await fetchAntibodyResultFunction.Run(request) as OkObjectResult;
            var actualResponseValue = actualResponse.Value as IEnumerable<AntibodyResultResponse>;

            // Assert
            Assert.NotNull(actualResponse);
            Assert.NotNull(actualResponseValue);
            Assert.True(actualResponseValue.SequenceEqual(expectedResponse));
        }

        [Theory(Skip = "Disabled during work on nhs login integration")]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public async Task FetchAntibodyResultFunction_RequestUsingHeadersForToken_ShouldReturnNoResults(CovidPassportUser user)
        {
            // Arrange
            var fakeUserUsingEmailAdresss = CovidTestUserTestHelper.CreateUserUsingEmailAddress();
            var fakeUserUsingPhoneNumber = CovidTestUserTestHelper.CreateUserUsingPhoneNumber();
            var emailUserAntibodyResult = AntibodyTestHelper.CreateAntibodyResult(fakeUserUsingEmailAdresss);
            var phoneUserAntibodyResult = AntibodyTestHelper.CreateAntibodyResult(fakeUserUsingPhoneNumber);
            var antibodyResults = new List<AntibodyResult>() { emailUserAntibodyResult, phoneUserAntibodyResult };
            var jwtToken = (await jwtGenerator.Issue(user)).Token;
            var request = AzureFunctionTestHelper.CreateRequest(string.Empty, jwtToken);
            var expectedResponse = new List<AntibodyResultResponse>() as IEnumerable<AntibodyResultResponse>;

            // Act
            var actualResponse = await fetchAntibodyResultFunction.Run(request) as OkObjectResult;
            var actualResponseValue = actualResponse.Value as IEnumerable<AntibodyResultResponse>;

            // Assert
            Assert.NotNull(actualResponse);
            Assert.NotNull(actualResponseValue);
            Assert.True(actualResponseValue.SequenceEqual(expectedResponse));
        }

        [Theory(Skip = "Disabled during work on nhs login integration")]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public async Task FetchAntibodyResultFunction_RequestUsingQueryForToken_ShouldReturnNoResults(CovidPassportUser user)
        {
            // Arrange
            var fakeUserUsingEmailAdresss = CovidTestUserTestHelper.CreateUserUsingEmailAddress();
            var fakeUserUsingPhoneNumber = CovidTestUserTestHelper.CreateUserUsingPhoneNumber();
            var emailUserAntibodyResult = AntibodyTestHelper.CreateAntibodyResult(fakeUserUsingEmailAdresss);
            var phoneUserAntibodyResult = AntibodyTestHelper.CreateAntibodyResult(fakeUserUsingPhoneNumber);
            var antibodyResults = new List<AntibodyResult>() { emailUserAntibodyResult, phoneUserAntibodyResult };
            var jwtToken = (await jwtGenerator.Issue(user)).Token;
            var queryStore = new Dictionary<string, StringValues>();
            queryStore.Add(AzureFunctionTestHelper.TokenQueryKey, jwtToken);
            var queryCollection = new QueryCollection(queryStore);
            var request = AzureFunctionTestHelper.CreateRequestWithHeaderDictionaryAndQuery(null, null, queryCollection);
            var expectedResponse = new List<AntibodyResultResponse>() as IEnumerable<AntibodyResultResponse>;

            // Act
            var actualResponse = await fetchAntibodyResultFunction.Run(request) as OkObjectResult;
            var actualResponseValue = actualResponse.Value as IEnumerable<AntibodyResultResponse>;

            // Assert
            Assert.NotNull(actualResponse);
            Assert.NotNull(actualResponseValue);
            Assert.True(actualResponseValue.SequenceEqual(expectedResponse));
        }

        #endregion
    }
}
