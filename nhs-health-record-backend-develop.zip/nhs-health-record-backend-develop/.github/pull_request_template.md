Hi Developer! The purpose of this template is to get your code reviewed and merged as quickly as possible. Please spend a few minutes to fill it out, as it helps set the stage for the reviewer. Follow the instructions in the life cycle below. (You can delete this intro-message)

# Life cycle
- [x] Understand how to check off an item in this list
- [ ] Fill out this template and submit PR as draft
- [ ] Link your work item(s) (link to Jira story or task)
- [ ] Add Jira story number to PR title (e.g. [CHRP-7184])
- [ ] Pass all policies except approval from reviewer (unit tests should pass)
- [ ] Submit PR
- [ ] Assign a reviewer
- [ ] Assign yourself as 'assignee'

# Additional Checks
- [ ] Has the solution been reviewed with an Architect
- [ ] Have you considered all NFRs that may pertain to this, especially performance
- [ ] Is there sufficient test coverage for the solution

- Do not mark any comments as resolved. The reviewer will do this!

# Current state
*Here you should describe how the system is currently behaving, regarding the area you are changing.*

# Goal state
*Here you should describe how you intend the the system to behave, once your changes are merged.*
