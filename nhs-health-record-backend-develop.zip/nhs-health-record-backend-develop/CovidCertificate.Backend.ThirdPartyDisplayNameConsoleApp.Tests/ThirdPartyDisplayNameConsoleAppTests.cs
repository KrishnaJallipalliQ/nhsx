using CovidCertificate.Backend.ThirdPartyDisplayNameConsoleApp;
using Xunit;

namespace CovidCertificate.Backend.ThirdPartyDisplayNameConsoleApps
{
    public class ThirdPartyDisplayNameConsoleAppTests
    {
        [Fact]
        public void TooManyArgs()
        {
            string[] args = { "5ebd7246d2b0d6003887a8f4", "BritishAirways", "dev","dev2"};
            int response = DisplayNameConsoleApp.Main(args);
            Assert.Equal(1, response);
        }

        [Fact]
        public void TooLittleArgs()
        {
            string[] args = { "5ebd7246d2b0d6003887a8f4", "BritishAirways"};
            int response = DisplayNameConsoleApp.Main(args);
            Assert.Equal(1, response);
        }

        [Fact]
        public void EmptyValues()
        {
            string[] args = new string[3];
            int response = DisplayNameConsoleApp.Main(args);
            Assert.Equal(1, response);
        }

        [Fact]
        public void ObjectIdInvalid()
        {
            string[] args = new string[3] { "wrongObjectId", "BritishAirways", "dev" };
            int response = DisplayNameConsoleApp.Main(args);
            Assert.Equal(1, response);
        }

        [Fact]
        public void DisplayNameInvalid()
        {
            string[] args = new string[3] { "5ebd7246d2b0d6003887a8f4", null, "dev" };
            int response = DisplayNameConsoleApp.Main(args);
            Assert.Equal(1, response);
        }

        [Fact]
        public void EnvInvalid()
        {
            string[] args = new string[3] { "5ebd7246d2b0d6003887a8f4", "BritishAirways", null };
            int response = DisplayNameConsoleApp.Main(args);
            Assert.Equal(1, response);
        }
    }
}
