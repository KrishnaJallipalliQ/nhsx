﻿using Hl7.Fhir.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.DASigningService.Tests.ValidatorTests.TestHelpers
{
    public class FhirPatientValidatorTestHelper
    {
        public static Patient CreateValidMockPatient()
        {
            var mockPatient = new Patient();
            var fullName = new HumanName().WithGiven("John").AndFamily("Smith");

            mockPatient.Name.Add(fullName);
            mockPatient.BirthDate = "1952-05-31";

            return mockPatient;
        }
    }
}
