﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Exceptions;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Services;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class TwoFactorAuthenticatorServiceTest
    {
        private readonly TwoFactorAuthenticatorService service;
        private readonly Mock<ITableStorageService> tableStorageServiceMock = new Mock<ITableStorageService>(MockBehavior.Strict);
        private readonly Mock<ILogger<TwoFactorAuthenticatorService>> loggerMock = new Mock<ILogger<TwoFactorAuthenticatorService>>();
        private readonly Mock<ITableNameGenerator> tableNameGeneratorMock = new Mock<ITableNameGenerator>();
        private readonly TwoFactorSettings tableStorageSettingsMock;
       
        public TwoFactorAuthenticatorServiceTest()
        {
            service = new TwoFactorAuthenticatorService(tableStorageServiceMock.Object, tableStorageSettingsMock, loggerMock.Object, tableNameGeneratorMock.Object);
        }

        [Fact]
        public async void TestCreateCode_IsSuccessful()
        {
            //Arrange
            var destination = "test@test.com";
            
            var isError = false;
            
            
            tableStorageServiceMock.Setup(m => m.AddToTable<TwoFactorAuth>(It.IsAny<string>(),It.IsAny<TwoFactorAuth>())).ReturnsAsync(true);
           
            //Act

            
            var created = await service.CreateCode(destination);
           

            //Assert
            Assert.False(isError);
            Assert.NotNull(created.AuthCode);
            Assert.NotNull(created.Destination);
        }

        [Fact]
        public async void TestValidateCode_IsSuccessful()
        {
            //Arrange 
            tableStorageServiceMock.Setup(m => m.AddToTable<TwoFactorAuth>(It.IsAny<string>(), It.IsAny<TwoFactorAuth>())).ReturnsAsync(true);
            var destination = "test@test.com";
            var storedTwoFactorAuth = await service.CreateCode(destination);
            tableNameGeneratorMock.Setup(m => m.GetTableName()).Returns($"FA{DateTime.UtcNow:ddMMyyHH}");
            var validationDto = new TwoFactorAuthValidationDto
            {
                AuthCode = storedTwoFactorAuth.AuthCode,
                Destination = storedTwoFactorAuth.Destination
            };
            tableStorageServiceMock.Setup(m => m.FetchFromTable<TwoFactorAuth>(tableNameGeneratorMock.Object.GetTableName(), validationDto.GetTableKey())).ReturnsAsync(storedTwoFactorAuth);
            tableStorageServiceMock.Setup(m => m.RemoveFromStorage<TwoFactorAuthValidationDto>(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(true);
            //Act 

            var isValidated = await service.ValidateCode(validationDto);

            //Assert

            Assert.True(isValidated);


        }

        [Fact]
        public async void TestValidateCode_InvalidDto()
        {
            //Arrange
            var validationDto = new TwoFactorAuthValidationDto
            {
                AuthCode = "ABC123",
                Destination = "test@test.com"
            };
            tableStorageServiceMock.Setup(m => m.AddToTable<TwoFactorAuth>(It.IsAny<string>(), It.IsAny<TwoFactorAuth>())).ReturnsAsync(true);
            tableNameGeneratorMock.Setup(m => m.GetTableName()).Returns($"FA{DateTime.UtcNow:ddMMyyHH}");
            tableNameGeneratorMock.Setup(m => m.GetTableName(It.IsAny<DateTime>())).Returns($"FA{DateTime.UtcNow:ddMMyyHH}");
            tableStorageServiceMock.Setup(m => m.RemoveFromStorage<TwoFactorAuthValidationDto>(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(true);
            tableStorageServiceMock.Setup(m => m.FetchFromTable<TwoFactorAuth>(It.IsAny<string>(), validationDto.GetTableKey())).ReturnsAsync((TwoFactorAuth)null);
            //Act 

            var isValidated = await service.ValidateCode(validationDto);

            //Assert

            Assert.False(isValidated);
        }

    }
}
