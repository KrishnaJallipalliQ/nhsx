﻿using CovidCertificate.Backend.Models.DataModels;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CovidCertificate.Backend.Models.Settings 
{
    public class CertificateValiditySettings
    {
        public int ConfigurationTimeout { get; set; }
    }
}

