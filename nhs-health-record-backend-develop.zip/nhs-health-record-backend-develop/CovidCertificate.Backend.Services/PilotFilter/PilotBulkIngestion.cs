﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.RequestDtos;

using Microsoft.AspNetCore.Http;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace CovidCertificate.Backend.Services.PilotFilter
{
    public class PilotBulkIngestion
    {
        private readonly ILogger<PilotBulkIngestion> logger;

        public PilotBulkIngestion(ILogger<PilotBulkIngestion> logger)
        {
            this.logger = logger;
        }
       
        public List<PilotUser> IngestFromRequestString(string request)
        {
            logger.LogInformation("IngestFromRequestString was invoked");

            List<PilotUser> ingestedUsers = new List<PilotUser>();
            
            var splitResult = request.Trim().Split("\n");
            foreach(string user in splitResult)
            {
                if (!user.Contains(','))
                {
                    logger.LogWarning("Incorrect data format, must be Name,DateOfBirth");
                    continue;
                }
                var splitUser = user.Split(",");
                var userName = splitUser[0].Trim();
                var userDOB = splitUser[1].Trim();
                DateTime DOB = DateTime.ParseExact(userDOB,"dd-MM-yyyy",CultureInfo.InvariantCulture);
                
                ingestedUsers.Add(new AddPilotUserDto(userName,DOB).ToPilotUser());
            }

            logger.LogInformation("IngestFromRequestString has finished");
            return ingestedUsers;
        }
    }
}
