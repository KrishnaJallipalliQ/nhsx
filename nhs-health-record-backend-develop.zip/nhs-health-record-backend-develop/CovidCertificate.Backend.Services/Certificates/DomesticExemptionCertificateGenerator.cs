﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Utils.Extensions;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using CovidCertificate.Backend.Models.Commands.UvciGeneratorCommands;
using CovidCertificate.Backend.Utils;
using Microsoft.Extensions.Configuration;

namespace CovidCertificate.Backend.Services.Certificates
{
    public class DomesticExemptionCertificateGenerator : IDomesticExemptionCertificateGenerator
    {
        private readonly IQRCodeGenerator qRCodeGenerator;
        private readonly IBlobFilesInMemoryCache<EligibilityConfiguration> blobCache;
        private readonly ILogger<DomesticExemptionCertificateGenerator> logger;
        private readonly IUvciGenerator uvciGenerator;
        private readonly IConfiguration configuration;

        public DomesticExemptionCertificateGenerator(
            ILogger<DomesticExemptionCertificateGenerator> logger,
            IQRCodeGenerator qRCodeGenerator,
            IBlobFilesInMemoryCache<EligibilityConfiguration> blobCache,
            IUvciGenerator uvciGenerator,
            IConfiguration configuration)
        {
            this.qRCodeGenerator = qRCodeGenerator;
            this.blobCache = blobCache;
            this.logger = logger;
            this.uvciGenerator = uvciGenerator;
            this.configuration = configuration;
        }

        public async Task<Certificate> GenerateCertificate(CovidPassportUser user)
        {
            logger.LogInformation("GenerateDomesticExemptionCertificate was invoked");
            var configuration = await blobCache.GetFile();
            var eligibilityDate = DateTime.UtcNow.AddDays(10000); // Exemptions should not have any end-date, but last until removed from list of exempt users.
            var certificateExpiresInHours = configuration.DomesticExemptions.CertificateExpiresInHours;
            var certificateExpiryDate = DateTime.UtcNow.AddHours(certificateExpiresInHours);

            var certificate = new Certificate(user.Name, user.DateOfBirth, certificateExpiryDate, eligibilityDate, CertificateType.Exemption, CertificateScenario.Domestic);
            var qrCode = await qRCodeGenerator.GenerateQRCodeForCertificate(certificate);
            certificate.QrCodeTokens.Add(qrCode);
            certificate.UniqueCertificateIdentifier = await uvciGenerator.TryGenerateAndInsertUvci(
                new DomesticGenerateAndInsertUvciCommand(
                    this.configuration["DomesticAuthority"],
                    this.configuration["CountryOfIssuer"],
                    StringUtils.GetValueHash(certificate.Name, certificate.DateOfBirth),
                    certificate.CertificateType,
                    certificate.CertificateScenario,
                    certificateExpiryDate));

            logger.LogTraceAndDebug($"certificate: {certificate?.ToString()}");
            logger.LogInformation("GenerateDomesticExemptionCertificate has finished");

            return certificate;
        }
    }
}
