﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.Settings;
using Microsoft.Extensions.Configuration;
using SendGrid;
using SendGrid.Helpers.Mail;
using System;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services
{
    public class EmailSender : IEmailSender
    {
        private readonly EmailSenderCredentialSettings emailSenderCredential;
        private readonly IConfiguration configuration;

        public EmailSender(EmailSenderCredentialSettings emailSenderCredential,
            IConfiguration configuration)
        {
            this.emailSenderCredential = emailSenderCredential;
            this.configuration = configuration;
        }

        public async Task SendEmail(string email, string subject, string emailContent)
        {
            var client = new SendGridClient(emailSenderCredential.SendGridApiKey);

            var from = new EmailAddress(emailSenderCredential.FromEmail, emailSenderCredential.FromEmailName);
            var to = new EmailAddress(email);
            var plainTextContent = "";
            var htmlContent = emailContent;

            var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
            Response response = await client.SendEmailAsync(msg);

            if (response.StatusCode != System.Net.HttpStatusCode.Accepted)
            {
                throw new Exception("Response code: " + response.StatusCode + "  Unable to send email");
            }
        }
    }
}
