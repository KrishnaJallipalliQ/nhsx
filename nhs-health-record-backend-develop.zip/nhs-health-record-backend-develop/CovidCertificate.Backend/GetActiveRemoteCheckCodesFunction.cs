using CovidCertificate.Backend.Configuration.Bases.BaseFunctions;
using CovidCertificate.Backend.Interfaces.Delegates;
using CovidCertificate.Backend.Interfaces.RemoteAccessCodeService;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.ResponseDtos;
using CovidCertificate.Backend.Utils.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using SendGrid.Helpers.Errors.Model;
using System;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace CovidCertificate.Backend
{
    public class GetActiveRemoteCheckCodesFunction : BaseSecureFunction
    {
        private readonly IRemoteAccessCodeService remoteAccess;

        public GetActiveRemoteCheckCodesFunction(IRemoteAccessCodeService remoteAccess, JwtValidatorResolver jwtValidatorResolver, IConfiguration configuration, ILogger<GetActiveRemoteCheckCodesFunction> logger) : base(jwtValidatorResolver, configuration, logger)
        {
            this.remoteAccess = remoteAccess;
        }

        [FunctionName("GetActiveRemoteCheckCodes")]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "get", Route = "GetActiveRemoteCheckCodes")] HttpRequest req)
        {
            try
            {
                logger.LogInformation("GetActiveRemoteCheckCodes (endpoint) was invoked");
                var validationResult = await base.AuthoriseEndpoint(req);
                logger.LogTraceAndDebug($"validationResult: IsValid {validationResult?.IsValid}, Response is {validationResult?.Response}, TokenClaims are {validationResult?.TokenClaims}");
                if (base.responseInvalid(validationResult))
                {
                    logger.LogInformation("GetActiveRemoteCheckCodes (endpoint) has finished");
                    return validationResult.Response;
                }
                var covidUser = new CovidPassportUser(validationResult.TokenClaims);
                logger.LogTraceAndDebug($"covidUser: {covidUser?.ToString()}");
                logger.LogInformation($"covidUser: {covidUser?.ToNhsNumberAndDobHashKey()}");

                var activeRemoteCheckCodes = await remoteAccess.GetActiveRemoteCheckCodes(covidUser);
                logger.LogTraceAndDebug($"Active Remote Check codes: {activeRemoteCheckCodes}");
                logger.LogInformation("GetActiveRemoteCheckCodes (endpoint) has finished");

                return new OkObjectResult(activeRemoteCheckCodes.Select(x => new RemoteCheckCodesResponseDto(x)));
            }
            catch (Exception e) when (e is BadRequestException || e is ArgumentNullException)
            {
                logger.LogWarning(e, e.Message);
                return new BadRequestObjectResult("There seems to be a problem: bad request");
            }
            catch (UnauthorizedException e)
            {
                logger.LogWarning(e, e.Message);
                return new UnauthorizedObjectResult("There seems to be a problem: unauthorized");
            }
            catch (ForbiddenException e)
            {
                logger.LogWarning(e, e.Message);
                return new ObjectResult("There seems to be a problem: forbidden") { StatusCode = StatusCodes.Status403Forbidden };
            }
            catch (HttpRequestException e)
            {
                logger.LogCritical(e, e.Message);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
            catch (Exception e)
            {
                logger.LogError(e, e.Message);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}
