﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.NhsApiIntegration.Interfaces;
using CovidCertificate.Backend.Services;
using Hl7.Fhir.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class DiagnosticTestResultsServiceTests
    {
        private readonly string identityToken = "eyJzdWIiOiI0Y2JkZThkZC00NjA2LTRiNjUtYThhYy0wM2JiZjMwMTNkNWIiLCJhdWQiOiJoZWFsdGhyZWNvcmRzIiwia2lkIjoiZjYwZWI0NmZmOGFiZjBiZjllOTE3ZWVlNjA4NmM1ZmE0YTE2MmE1ZCIsImlzcyI6Imh0dHBzOi8vYXV0aC5hb3Muc2lnbmluLm5ocy51ayIsInR5cCI6IkpXVCIsImV4cCI6MTYyMTMzMzIyOSwiaWF0IjoxNjIxMzI5NjI5LCJhbGciOiJSUzUxMiIsImp0aSI6ImNjODNjYTYxLWM0MDQtNDY0OC05NDljLTZkYjNkOTVhOTNhOCJ9.eyJzdWIiOiI0Y2JkZThkZC00NjA2LTRiNjUtYThhYy0wM2JiZjMwMTNkNWIiLCJiaXJ0aGRhdGUiOiIxOTE4LTA2LTI4IiwibmhzX251bWJlciI6Ijk2NTg0Nzc4NjAiLCJpc3MiOiJodHRwczovL2F1dGguYW9zLnNpZ25pbi5uaHMudWsiLCJ2dG0iOiJodHRwczovL2F1dGguYW9zLnNpZ25pbi5uaHMudWsvdHJ1c3RtYXJrL2F1dGguYW9zLnNpZ25pbi5uaHMudWsiLCJhdWQiOiJoZWFsdGhyZWNvcmRzIiwiaWRfc3RhdHVzIjoidmVyaWZpZWQiLCJ0b2tlbl91c2UiOiJpZCIsInN1cm5hbWUiOiJHQU5URVMiLCJhdXRoX3RpbWUiOjE2MjEzMjk2MjYsInZvdCI6IlA5LkNwLkNkIiwiaWRlbnRpdHlfcHJvb2ZpbmdfbGV2ZWwiOiJQOSIsImV4cCI6MTYyMTMzMzIyOSwiaWF0IjoxNjIxMzI5NjI5LCJmYW1pbHlfbmFtZSI6IkdBTlRFUyIsImp0aSI6ImNjODNjYTYxLWM0MDQtNDY0OC05NDljLTZkYjNkOTVhOTNhOCJ9.rTwK5-m1RLciOYKaDj2StAPF1C5IuBaTQV9BARNxXTKisraGXrbKs1jAyfY3iZOofmfbCMjC3vfFCE1hxrM9ZrZHhN--ZEkzx8xASF12JbLQ5Qpidq_GFnYQhIM49BxrmW4y7ojp2VEuMbrDjinJ8NcnIOtIrgknMevmRp-PkJgUkbVVe3jKmn6w-zboW9nYm0v0xi2-D--HFtRIld-0yJf_bISY_sxuVDivSiQ6A9bda7QCiN9SAOPi_rCt-1s9yZ9ShXPZ1LTpz6mXDHUQTtQZlZo_ZXqQRI4E9DMEBxFkC86U5vqZszB6EyurexDcpp3NHdc32hEjO1YPEm6VWw";
        private readonly Mock<IConfiguration> mockConfiguration = new Mock<IConfiguration>();

        [Fact]
        public async void GetDiagnosticTestResults_NoTestResults_CachedValueExists()
        {
            // Arrange
            var loggerMock = new Mock<ILogger<DiagnosticTestResultsService>>();

            var mappingCache = new Mock<IMappingCache>();
            var nhsdFhirApiServiceMock = new Mock<INhsdFhirApiService>();
            nhsdFhirApiServiceMock.Setup(x => x.GetDiagnosticTestResults(It.IsAny<string>())).Verifiable();

            var fhirBundleMapperMock = new Mock<IFhirBundleMapper<TestResultNhs>>();

            var redisCacheServiceMock = new Mock<IRedisCacheService>();
            var cacheResponse = new List<TestResultNhs>() { };
            redisCacheServiceMock.Setup(x => x.GetKeyValueAsync<IEnumerable<TestResultNhs>>(It.IsAny<string>())).ReturnsAsync((cacheResponse, true)).Verifiable();

            var diagnosticTestResultsService = new DiagnosticTestResultsService(loggerMock.Object, nhsdFhirApiServiceMock.Object, fhirBundleMapperMock.Object, redisCacheServiceMock.Object, mockConfiguration.Object);

            var covidPassportUser = new CovidPassportUser("name", DateTime.Now, "emailAddress", "phoneNumber", "nhsNumber", "familyName", "givenName");

            // Act
            var diagnosticTestResults = await diagnosticTestResultsService.GetDiagnosticTestResults(identityToken);

            // Assert
            redisCacheServiceMock.Verify(x => x.GetKeyValueAsync<IEnumerable<TestResultNhs>>(It.IsAny<string>()), Times.Once);
            nhsdFhirApiServiceMock.Verify(x => x.GetDiagnosticTestResults(It.IsAny<string>()), Times.Never);
            Assert.Empty(diagnosticTestResults);
        }

        [Fact]
        public async void GetDiagnosticTestResults_NoTestResults_NoCachedValueExists()
        {
            // Arrange
            var loggerMock = new Mock<ILogger<DiagnosticTestResultsService>>();

            var mappingCache = new Mock<IMappingCache>();

            var nhsdFhirApiServiceMock = new Mock<INhsdFhirApiService>();
            nhsdFhirApiServiceMock.Setup(x => x.GetDiagnosticTestResults(It.IsAny<string>())).ReturnsAsync(new Bundle()).Verifiable();

            var testResults = new List<TestResultNhs>();
            var fhirBundleMapperMock = new Mock<IFhirBundleMapper<TestResultNhs>>();
            fhirBundleMapperMock.Setup(x => x.ConvertBundle(It.IsAny<Bundle>())).ReturnsAsync(testResults);

            var redisCacheServiceMock = new Mock<IRedisCacheService>();
            redisCacheServiceMock.Setup(x => x.AddKeyAsync(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<RedisLifeSpanLevel>())).Verifiable();
            redisCacheServiceMock.Setup(x => x.GetKeyValueAsync<IEnumerable<TestResultNhs>>(It.IsAny<string>())).ReturnsAsync((null, false)).Verifiable();

            var diagnosticTestResultsService = new DiagnosticTestResultsService(loggerMock.Object, nhsdFhirApiServiceMock.Object, fhirBundleMapperMock.Object, redisCacheServiceMock.Object, mockConfiguration.Object);

            var covidPassportUser = new CovidPassportUser("name", DateTime.Now, "emailAddress", "phoneNumber", "nhsNumber", "familyName", "givenName");

            // Act
            var diagnosticTestResults = await diagnosticTestResultsService.GetDiagnosticTestResults(identityToken);

            // Assert
            redisCacheServiceMock.Verify(x => x.GetKeyValueAsync<IEnumerable<TestResultNhs>>(It.IsAny<string>()), Times.Once);
            nhsdFhirApiServiceMock.Verify(x => x.GetDiagnosticTestResults(It.IsAny<string>()), Times.Once);
            redisCacheServiceMock.Verify(x => x.AddKeyAsync(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<RedisLifeSpanLevel>()), Times.Once);
            Assert.Empty(diagnosticTestResults);
        }

        [Fact]
        public async void GetDiagnosticTestResults_1TestResult_CachedValueExists()
        {
            // Arrange
            var loggerMock = new Mock<ILogger<DiagnosticTestResultsService>>();

            var mappingCache = new Mock<IMappingCache>();
            var nhsdFhirApiServiceMock = new Mock<INhsdFhirApiService>();
            nhsdFhirApiServiceMock.Setup(x => x.GetDiagnosticTestResults(It.IsAny<string>())).Verifiable();

            var fhirBundleMapperMock = new Mock<IFhirBundleMapper<TestResultNhs>>();

            var redisCacheServiceMock = new Mock<IRedisCacheService>();
            var cachedResponse = new List<TestResultNhs>() {
                    new TestResultNhs(DateTime.Now, "result", "validityType", "processingCode", "testKit", null, "authority", "countryOfAuthority"),
                };
            redisCacheServiceMock.Setup(x => x.GetKeyValueAsync<IEnumerable<TestResultNhs>>(It.IsAny<string>())).ReturnsAsync((cachedResponse, true)).Verifiable();

            var diagnosticTestResultsService = new DiagnosticTestResultsService(loggerMock.Object, nhsdFhirApiServiceMock.Object, fhirBundleMapperMock.Object, redisCacheServiceMock.Object, mockConfiguration.Object);

            var covidPassportUser = new CovidPassportUser("name", DateTime.Now, "emailAddress", "phoneNumber", "nhsNumber", "familyName", "givenName");

            // Act
            var diagnosticTestResults = await diagnosticTestResultsService.GetDiagnosticTestResults(identityToken);

            // Assert
            redisCacheServiceMock.Verify(x => x.GetKeyValueAsync<IEnumerable<TestResultNhs>>(It.IsAny<string>()), Times.Once);
            nhsdFhirApiServiceMock.Verify(x => x.GetDiagnosticTestResults(It.IsAny<string>()), Times.Never);
            Assert.Single(diagnosticTestResults);
        }

        [Fact]
        public async void GetDiagnosticTestResults_1TestResult_NoCachedValueExists()
        {
            // Arrange
            var loggerMock = new Mock<ILogger<DiagnosticTestResultsService>>();

            var mappingCache = new Mock<IMappingCache>();

            var nhsdFhirApiServiceMock = new Mock<INhsdFhirApiService>();
            nhsdFhirApiServiceMock.Setup(x => x.GetDiagnosticTestResults(It.IsAny<string>())).ReturnsAsync(new Bundle()).Verifiable();

            var testResults = new List<TestResultNhs>(){
                    new TestResultNhs(DateTime.Now, "result", "validityType", "processingCode", "testKit", null, "authority", "countryOfAuthority"),
                };
            var fhirBundleMapperMock = new Mock<IFhirBundleMapper<TestResultNhs>>();
            fhirBundleMapperMock.Setup(x => x.ConvertBundle(It.IsAny<Bundle>())).ReturnsAsync(testResults);

            var redisCacheServiceMock = new Mock<IRedisCacheService>();
            redisCacheServiceMock.Setup(x => x.AddKeyAsync(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<RedisLifeSpanLevel>())).Verifiable();
            redisCacheServiceMock.Setup(x => x.GetKeyValueAsync<IEnumerable<TestResultNhs>>(It.IsAny<string>())).ReturnsAsync((null, false)).Verifiable();

            var diagnosticTestResultsService = new DiagnosticTestResultsService(loggerMock.Object, nhsdFhirApiServiceMock.Object, fhirBundleMapperMock.Object, redisCacheServiceMock.Object, mockConfiguration.Object);

            var covidPassportUser = new CovidPassportUser("name", DateTime.Now, "emailAddress", "phoneNumber", "nhsNumber", "familyName", "givenName");

            // Act
            var diagnosticTestResults = await diagnosticTestResultsService.GetDiagnosticTestResults(identityToken);

            // Assert
            redisCacheServiceMock.Verify(x => x.GetKeyValueAsync<IEnumerable<TestResultNhs>>(It.IsAny<string>()), Times.Once);
            nhsdFhirApiServiceMock.Verify(x => x.GetDiagnosticTestResults(It.IsAny<string>()), Times.Once);
            redisCacheServiceMock.Verify(x => x.AddKeyAsync(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<RedisLifeSpanLevel>()), Times.Once);
            Assert.Single(diagnosticTestResults);
        }
    }
}
