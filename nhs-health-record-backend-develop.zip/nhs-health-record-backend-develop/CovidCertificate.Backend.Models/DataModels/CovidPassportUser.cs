﻿using CovidCertificate.Backend.Models.Interfaces;
using CovidCertificate.Backend.Models.Validators;
using CovidCertificate.Backend.Utils;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using CovidCertificate.Backend.Models.Interfaces.UserInterfaces;

namespace CovidCertificate.Backend.Models.DataModels
{
    public class CovidPassportUser : IUser, IJwtTokenData, IUserCBORInformation
    {
        [JsonConstructor]
        public CovidPassportUser(string name, DateTime dateOfBirth, string emailAddress, string phoneNumber,
                                 string nhsNumber = null, string familyName = null, string givenName = null,
                                 string identityProofingLevel = null)
        {
            this.Name = name;
            this.DateOfBirth = dateOfBirth;
            this.EmailAddress = emailAddress;
            this.PhoneNumber = phoneNumber;
            this.NhsNumber = nhsNumber;
            this.FamilyName = familyName;
            this.GivenName = givenName;
            this.IdentityProofingLevel = identityProofingLevel;
        }

        public CovidPassportUser(ClaimsPrincipal claimsPrincipal)
        {
            var nameClaim = claimsPrincipal.FindFirst(ClaimTypes.Name);
            var familyNameClaim = claimsPrincipal.FindFirst(ClaimTypes.Surname);
            var givenNameClaim = claimsPrincipal.FindFirst(ClaimTypes.GivenName);
            var dobClaim = claimsPrincipal.FindFirst(ClaimTypes.DateOfBirth);
            var emailClaim = claimsPrincipal.FindFirst(ClaimTypes.Email);
            var phoneClaim = claimsPrincipal.FindFirst(ClaimTypes.MobilePhone);
            var nhsNumberClaim = claimsPrincipal.FindFirst("NHSNumber");
            var identityProofingLevel = claimsPrincipal.FindFirst("IdentityProofingLevel");

            if (dobClaim != default)
            {
                var isLong = long.TryParse(dobClaim.Value, out var dobResult);
                if (isLong)
                    DateOfBirth = DateTime.FromFileTimeUtc(dobResult);
            }

            if (nameClaim != default)
                Name = nameClaim.Value;
            if (emailClaim != default)
                EmailAddress = emailClaim.Value;
            if (phoneClaim != default)
                PhoneNumber = phoneClaim.Value;
            if (nhsNumberClaim != default)
                NhsNumber = nhsNumberClaim.Value;
            if (familyNameClaim != default)
                FamilyName = familyNameClaim.Value;
            if (givenNameClaim != default)
                GivenName = givenNameClaim.Value;
            if (identityProofingLevel != default)
            {
                IdentityProofingLevel = identityProofingLevel.Value;
            }
        }

        public string Name { get; }
        public DateTime DateOfBirth { get; }
        public string EmailAddress { get; }
        public string PhoneNumber { get; }
        public string NhsNumber { get; }
        public string FamilyName { get; }
        public string GivenName { get; }
        public string IdentityProofingLevel { get; set; }
        public virtual IEnumerable<Claim> GetClaims()
        {
            var claims = new List<Claim>();
            claims.Add(new Claim(ClaimTypes.Name, Name));
            if (!string.IsNullOrEmpty(EmailAddress))
                claims.Add(new Claim(ClaimTypes.Email, EmailAddress));

            if (!string.IsNullOrEmpty(PhoneNumber))
                claims.Add(new Claim(ClaimTypes.MobilePhone, PhoneNumber));

            if (DateOfBirth != default)
                claims.Add(new Claim(ClaimTypes.DateOfBirth, DateOfBirth.ToFileTimeUtc().ToString()));

            if (NhsNumber != default)
                claims.Add(new Claim("NHSNumber", NhsNumber));

            if (!string.IsNullOrEmpty(FamilyName))
                claims.Add(new Claim(ClaimTypes.Surname, FamilyName));

            if (!string.IsNullOrEmpty(GivenName))
                claims.Add(new Claim(ClaimTypes.GivenName, GivenName));


            return claims;
        }


        /// <summary>
        /// Gets the <see cref="Expression{TDelegate}"/> used to calculate the data identifier for database operations concerning objects of type <typeparamref name="T"/> for the instance.
        /// </summary>
        /// <exception cref="ArgumentException">Thrown on both <see cref="this.EmailAddress"/> , <see cref="this.PhoneNumber"/> and <see cref="this.NhsNumber"/> being null or empty.</exception>
        /// <returns>An <see cref="Expression{TDelegate}"/> of type <see cref="Func{T, TResult}"/> that compiles() to the calculation of the data identifier for the instance.</returns>
        public Expression<Func<T, bool>> GetDataIdentifierExpression<T>() where T : IUserHashedDocument
        {
            if (string.IsNullOrEmpty(EmailAddress) && string.IsNullOrEmpty(PhoneNumber) && string.IsNullOrEmpty(NhsNumber))
                throw new ArgumentNullException($"The '{nameof(EmailAddress)}', '{nameof(PhoneNumber)}', and '{nameof(NhsNumber)}' was all empty or null for the instance.");

            return x => x.PartitionKey == StringUtils.GetValueHash(Name, DateOfBirth) &&
                        (x.PhoneHash == StringUtils.GetValueHash(PhoneNumber, Name, DateOfBirth) ||
                          x.EmailHash == StringUtils.GetValueHash(EmailAddress, Name, DateOfBirth) ||
                          x.NhsNumberHash == StringUtils.GetValueHash(NhsNumber, DateOfBirth));
        }


        public virtual async Task ValidateObjectAndThrowOnFailuresAsync()
        {
            await new UserInformationValidator().ValidateAndThrowAsync(this);
            await new UserContactInformationValidator().ValidateAndThrowAsync(this);
        }

        public PilotUser ToPilotUser() => new PilotUser(this);
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Name:").Append(this.Name ?? "").AppendLine();
            sb.AppendLine("EmailAddress:").Append(this.EmailAddress ?? "").AppendLine();
            sb.AppendLine("FamilyName:").Append(this.FamilyName ?? "").AppendLine();
            sb.AppendLine("GivenName").Append(this.GivenName ?? "").AppendLine();
            sb.AppendLine("NhsNumber:").Append(this.NhsNumber ?? "").AppendLine();
            sb.AppendLine("PhoneNumber:").Append(this.PhoneNumber ?? "").AppendLine();
            sb.AppendLine("DOB:").Append(this.DateOfBirth).AppendLine();

            return base.ToString();
        }

        public string ToNhsNumberAndDobHashKey()
        {
            if(NhsNumber == null || DateOfBirth == default)
            {
                return "Unknown";
            }

            return HashUtils.GenerateHash(NhsNumber, DateOfBirth);
        }
    }
}
