﻿using System;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using System.Security.Cryptography.X509Certificates;
using CovidCertificate.Backend.DASigningService.ErrorHandling;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;

namespace CovidCertificate.Backend.DASigningService
{
    public class ClientCertificateValidator : IClientCertificateValidator
    {
        private readonly ILogger<ClientCertificateValidator> logger;
        private readonly TrustedCertificateCache trustedCertificateCache;

        public ClientCertificateValidator(IConfiguration configuration, ILogger<ClientCertificateValidator> logger)
        {
            this.logger = logger;
            this.trustedCertificateCache = new TrustedCertificateCache(configuration);
        }

        public void ValidateRequest(HttpRequest request, ErrorHandler errorHandler)
        {
            StringValues clientCertificate;
            Boolean clientCertificateRetrieved = request.Headers.TryGetValue("X-ARR-ClientCert", out clientCertificate);
            if (clientCertificateRetrieved)
            {
                logger.LogInformation($"clientCertificate value: {clientCertificate[0]}");
                ValidateClientCertificate(clientCertificate[0], errorHandler);
            }
            else
            {
                logger.LogInformation("No clientCertificate found");
                errorHandler.AddError(ErrorCode.INVALID_CLIENT_CERTIFICATE);
            }
        }

        private void ValidateClientCertificate(string base64CertificateHeaderValue, ErrorHandler errorHandler)
        {
            try
            {
                X509Certificate2 certificate = null;
                byte[] clientCertBytes = Convert.FromBase64String(base64CertificateHeaderValue);
                certificate = new X509Certificate2(clientCertBytes);
                if (!IsValidClientCertificate(certificate))
                {
                    logger.LogInformation("Invalid clientCertificate");
                    errorHandler.AddError(ErrorCode.INVALID_CLIENT_CERTIFICATE);
                }
            }
            catch (Exception ex)
            {
                errorHandler.AddError(ErrorCode.INVALID_CLIENT_CERTIFICATE);
            }
        }

        private bool IsValidClientCertificate(X509Certificate2 certificate)
        {
            if (certificate == null)
            {
                logger.LogInformation("certificate null");
                return false;
            }

            // 1. Check time validity of certificate
            if (DateTime.Compare(DateTime.Now, certificate.NotBefore) < 0 || DateTime.Compare(DateTime.Now, certificate.NotAfter) > 0)
            {
                logger.LogInformation("certificate out of datetime range");
                return false;
            }

            // 2. Check certificate is trusted
            if (IsTrustedCertificate(certificate))
            {
                //TODO: Perform certificate chain validation using below code rather than just return true
                //return certificate.Verify();          
                logger.LogInformation("trusted certificate");
                return true;
            }

            logger.LogInformation("certificate not trusted");

            return false;
        }

        private bool IsTrustedCertificate(X509Certificate2 certificate)
        {
            return trustedCertificateCache.GetCertificate(certificate.Thumbprint) != null;
        }
    }
}

