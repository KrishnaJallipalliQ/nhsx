﻿using System;
using System.Collections.Generic;
using System.Text;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Utils;
using FluentValidation;
using Microsoft.Extensions.Configuration;

namespace CovidCertificate.Backend.Models.Validators
{
    public class DomesticExemptionDtoValidator : AbstractValidator<DomesticExemptionDto>
    {
        public DomesticExemptionDtoValidator()
        {
            RuleFor(x => x.DateOfBirth).NotEmpty();
            RuleFor(x => x.NhsNumber).NotEmpty().Matches(StringUtils.NhsNumberRegex);
        }
    }
}
