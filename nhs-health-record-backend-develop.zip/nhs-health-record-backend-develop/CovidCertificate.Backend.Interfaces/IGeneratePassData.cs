﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IGeneratePassData
    {
        public Task<(QRcodeResponse qr, Certificate cert)> GetPassDataAsync(CovidPassportUser user, string idToken, QRType type);
    }
}
