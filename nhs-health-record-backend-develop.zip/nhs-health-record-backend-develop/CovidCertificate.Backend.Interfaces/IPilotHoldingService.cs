﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.RequestDtos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IPilotHoldingService
    {
        Task AddHoldingTest(TestResult testResult);

        Task<IEnumerable<HoldingTestResult>> GetHoldingTests(CovidPassportUser user);
    }
}
