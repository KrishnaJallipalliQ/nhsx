﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using Microsoft.Extensions.Configuration;

namespace CovidCertificate.Backend.DASigningService
{
    public class TrustedCertificateCache
    {
        private static DateTime cacheExpirationTime;
        private static readonly Dictionary<string, X509Certificate2> cachedCertificates = new Dictionary<string, X509Certificate2>();
        private int CACHE_DURATION_MINUTES;

        public TrustedCertificateCache(IConfiguration configuration)
        {
            if (!int.TryParse(configuration["TrustedCertificateCacheTimeout"], out CACHE_DURATION_MINUTES))
            {
                CACHE_DURATION_MINUTES = 30; //Set default
            }
        }

        public X509Certificate2 GetCertificate(string thumbprint)
        {
            if (cacheExpirationTime < DateTime.UtcNow)
            {
                RefreshCache();
            }

            X509Certificate2 result;

            if (cachedCertificates.TryGetValue(thumbprint, out result))
            {
                return result;
            }
            return null;
        }

        //Method is synchronized to avoid multiple threads trying to update static cache data at the same time
        [MethodImpl(MethodImplOptions.Synchronized)]
        private void RefreshCache()
        {
            //TODO: Replace this code with our async lock class
            //Thread could have been waiting in queue to enter this synchronized method
            //and in the mean time another thread could have updated the cache. Check if we still need to update it
            if (cacheExpirationTime >= DateTime.UtcNow)
            {
                return; //Cache already fresh
            }
            using (X509Store certStore = new X509Store(StoreName.My, StoreLocation.CurrentUser))
            {
                certStore.Open(OpenFlags.ReadOnly);

                X509Certificate2Enumerator enumerator = certStore.Certificates.GetEnumerator();

                cachedCertificates.Clear();

                while (enumerator.MoveNext())
                {
                    X509Certificate2 certificate = enumerator.Current;
                    cachedCertificates.Add(certificate.Thumbprint, certificate);
                }
            }
            cacheExpirationTime = DateTime.UtcNow.AddMinutes(CACHE_DURATION_MINUTES);
        }
    }
}
