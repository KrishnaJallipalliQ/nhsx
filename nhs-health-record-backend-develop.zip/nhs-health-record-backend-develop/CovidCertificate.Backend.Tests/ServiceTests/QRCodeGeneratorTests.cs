﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.ResponseDtos;
using CovidCertificate.Backend.Services.QrCodes;
using Moq;
using System;
using System.Threading.Tasks;
using CovidCertificate.Backend.Models.Enums;
using Xunit;
using Microsoft.Extensions.Logging;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class QRCodeGeneratorTests
    {
        private readonly Mock<ILogger<QRCodeGenerator>> logger;
        private readonly IQRCodeGenerator QRCodeGenerator;
        private readonly Mock<IJwtGenerator> jwtMock = new Mock<IJwtGenerator>();

        public QRCodeGeneratorTests()
        {
            this.logger = new Mock<ILogger<QRCodeGenerator>>();
            QRCodeGenerator = new QRCodeGenerator(logger.Object, jwtMock.Object);
        }

        [Fact]
        public async Task GenerateQrCodeGenerator_Valid_IsSuccessful()
        {
            var certificate = new Certificate("Test", new DateTime(2020,1,1).ToUniversalTime(), new DateTime(2020,12,1).ToUniversalTime(), new DateTime(2020, 12, 1).ToUniversalTime(), CertificateType.Diagnostic, CertificateScenario.International);

            jwtMock.Setup(x => x.Issue(It.IsAny<Certificate>())).ReturnsAsync(() => new ValidateTwoFactorResponseDto() { Token = "Test response" });

            var result = await QRCodeGenerator.GenerateQRCodeForCertificate(certificate);

            Assert.NotNull(result);
            Assert.Equal("Test response", result);
        }

        [Fact]
        public void GenerateQrCodeGenerator_Invalid_IsFailure()
        {
            var certificate = new Certificate("Test", new DateTime(2020, 1, 1).ToUniversalTime(), new DateTime(2020, 12, 1).ToUniversalTime(), new DateTime(2020, 12, 1).ToUniversalTime(), CertificateType.Diagnostic, CertificateScenario.International);

            var result = Assert.ThrowsAsync<NullReferenceException>(() => QRCodeGenerator.GenerateQRCodeForCertificate(certificate));
        }
    }
}
