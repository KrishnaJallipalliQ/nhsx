﻿namespace CovidCertificate.Backend.Models.ResponseDtos
{
    public class ValidateTwoFactorResponseDto
    {
        public string Token { get; set; }
    }
}
