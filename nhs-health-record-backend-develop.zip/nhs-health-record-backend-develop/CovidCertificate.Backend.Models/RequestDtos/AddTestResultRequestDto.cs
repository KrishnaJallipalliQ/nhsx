﻿using CovidCertificate.Backend.Models.DataModels;
using FluentValidation;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Models.RequestDtos
{
    public class AddTestResultRequestDto : UserRequestDto
    {
        [JsonConstructor]
        public AddTestResultRequestDto(string name, DateTime dateOfBirth, string emailAddress, string phoneNumber, DateTime dateTimeOfTest, string result, string testKit,string processingCode, string testType=null)
            : base(name, dateOfBirth, emailAddress, phoneNumber)
        {
            //Time comes in as universal so it needs to be reconverted back into British local time
            var reconvertedTime = DateTime.SpecifyKind(dateTimeOfTest.ToUniversalTime(), DateTimeKind.Unspecified);
            //Assume test is in British local time and convert to UTC- need different time zone systems for Linux and Windows
            var timeZones = TimeZoneInfo.GetSystemTimeZones().Select(x => x.Id);
            var timeZone = (TimeZoneInfo)default;
            if (timeZones.Contains("GMT Standard Time"))
                timeZone = TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time");
            if (timeZones.Contains("Europe/London"))
                timeZone = TimeZoneInfo.FindSystemTimeZoneById("Europe/London");

            if (timeZone == default)
            {
                this.DateTimeOfTest = DateTime.SpecifyKind(reconvertedTime.AddHours(-1), DateTimeKind.Utc);
            }
            else
            {
                this.DateTimeOfTest = TimeZoneInfo.ConvertTimeToUtc(reconvertedTime, timeZone);
            }            
            this.Result = result;
            this.TestKit = testKit;
            this.ValidityType = testKit;
            this.TestType = testType;
            this.ProcessingCode = processingCode;
        }

        [JsonRequired]
        public DateTime DateTimeOfTest { get; set; }
        [JsonRequired]
        public string Result { get; set; }
        
        public string ValidityType { get; set; }
        public string TestKit { get; set; }        
        
        public string TestType { get; set; }

        public string ProcessingCode { get; set; }
        public override async Task ValidateObjectAndThrowOnFailuresAsync()
        {
            await base.ValidateObjectAndThrowOnFailuresAsync();
            await new AddTestResultRequestDtoValidator().ValidateAndThrowAsync(this);
        }


        private class AddTestResultRequestDtoValidator : AbstractValidator<AddTestResultRequestDto>
        {
            public AddTestResultRequestDtoValidator()
            {
                #region DateTimeOfTest Rules
                RuleFor(x => x.DateTimeOfTest).GreaterThanOrEqualTo(new DateTime(2020, 1, 1, 0, 0, 0, DateTimeKind.Utc)).OnFailure(x =>
                {
                    throw new ValidationException($"The date of the test cannot be before the year 2020. Supplied UTC DateTimeOfTest: {x.DateTimeOfTest}.");
                });

                RuleFor(x => x.DateTimeOfTest).LessThanOrEqualTo(DateTime.UtcNow).OnFailure(x =>
                {
                    throw new ValidationException($"The date of the test cannot be in the future. Supplied UTC DateTimeOfTest: {x.DateTimeOfTest}.");
                });
                #endregion

                #region TestType Rules
                RuleFor(x => x.Result).NotEmpty().OnFailure(x =>
                {
                    throw new ValidationException($"The {nameof(Result)} must be specified.");
                });
                #endregion

            }
        }
        public PilotUser ToPilotUser() => new PilotUser(this);

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("ProccessingCode:").Append(this.ProcessingCode??"").AppendLine();
            sb.Append("Result:").Append(this.Result??"").AppendLine();
            sb.Append("TestKit:").Append(this.TestKit??"").AppendLine();
            sb.Append("TestType:").Append(this.TestType??"").AppendLine();
            sb.Append("ValidityType:").Append(this.ValidityType??"").AppendLine();
            sb.Append("DateTimeOfTest:").Append(this.DateTimeOfTest).AppendLine();
            sb.Append("UserRequestDTO base class:").Append(base.ToString()).AppendLine();

            return sb.ToString();
        }
    }
}