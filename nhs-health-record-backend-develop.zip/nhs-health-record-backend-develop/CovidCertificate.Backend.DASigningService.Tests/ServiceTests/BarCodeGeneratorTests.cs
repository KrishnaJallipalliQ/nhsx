﻿using System;
using CovidCertificate.Backend.DASigningService.ErrorHandling;
using CovidCertificate.Backend.DASigningService.Models;
using CovidCertificate.Backend.DASigningService.Services;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.International.Interfaces;
using CovidCertificate.Backend.Models.Commands.UvciGeneratorCommands;
using CovidCertificate.Backend.Services.Mappers;
using CovidCertificate.Backend.Tests.TestHelpers;
using Hl7.Fhir.Model;
using Hl7.Fhir.Serialization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Interfaces.UserInterfaces;
using CovidCertificate.Backend.Utils;
using FluentAssertions;
using Xunit;
using Task = System.Threading.Tasks.Task;

namespace CovidCertificate.Backend.DASigningService.Tests.ServiceTests

{
    public class BarCodeGeneratorTests
    {
        private Mock<IUvciGenerator> uvciGenerator = new Mock<IUvciGenerator>();
        private Mock<IEncoderService> encoder = new Mock<IEncoderService>();
        private Mock<ILogger<BarcodeGenerator>> logger = new Mock<ILogger<BarcodeGenerator>>();
        private Mock<IConfiguration> configuration = new Mock<IConfiguration>();
        private readonly Mock<IVaccineMapping> mockVaccineMapping;


        public BarCodeGeneratorTests()
        {
            this.mockVaccineMapping = BarCodeGeneratorTestsHelper.CreateMockVaccineMapping();
        }

        [Fact]
        public async Task BarcodesFromFhirBundle_InvalidPatientNullPatient_ReturnsNoBarcodeResults()
        {
            // Arrange
            VaccinationMapper map = new VaccinationMapper(new Mock<IVaccineMapping>().Object, configuration.Object,
                new Mock<IFhirLookupApi>().Object, new Mock<ILogger<VaccinationMapper>>().Object);

            var generator = new BarcodeGenerator(
                uvciGenerator.Object,
                    map,
                encoder.Object,
                logger.Object,
                configuration.Object);

            var bundle = new Bundle();
            bundle.AddResourceEntry(new Patient() { Name = new List<HumanName>(), BirthDate = "date" }, "patient");
            var regionConfig = new RegionConfig();

            // Act
            var result = await generator.BarcodesFromFhirBundle(bundle, regionConfig);

            // Assert
            Assert.Empty(result.Barcodes);
        }
       
        [Fact]
        public async Task BarcodesFromFhirBundle_PatientValidationSuccessImmunizationValidationFail_ReturnsBarCodeResultsWithErrors()
        {
            // Arrange
            var inMemorySettings = SetupInMemorySettings();

            IConfiguration configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();
            VaccinationMapper map = new VaccinationMapper(new Mock<IVaccineMapping>().Object, configuration,
                new Mock<IFhirLookupApi>().Object, new Mock<ILogger<VaccinationMapper>>().Object);

            uvciGenerator.Setup(x => x.TryGenerateAndInsertUvci(It.IsAny<RegionalGenerateAndInsertUvciCommand>()))
                .ReturnsAsync("uvci");

            var generator = new BarcodeGenerator(
                    uvciGenerator.Object,
                    map,
                    encoder.Object,
                    logger.Object,
                    configuration);

            var bundle = BarCodeGeneratorTestHelper.GetCorrectBundle();
            var regionConfig = new RegionConfig();

            // Act
            var result = await generator.BarcodesFromFhirBundle(bundle, regionConfig);

            // Assert
            Assert.NotNull(result.Barcodes[0].Error);
        }

        [Fact]
        public async Task BarcodesFromFhirBundle_LocationNotValid_ReturnsBarCodeResulsWithErrors()
        {
            // Arrange
            var inMemorySettings = SetupInMemorySettings();

            IConfiguration configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();

            VaccinationMapper map = new VaccinationMapper(new Mock<IVaccineMapping>().Object, configuration,
                new Mock<IFhirLookupApi>().Object, new Mock<ILogger<VaccinationMapper>>().Object);

            var uvciGeneratorMock = new Mock<IUvciGenerator>();
            uvciGeneratorMock.Setup(x => x.TryGenerateAndInsertUvci(It.IsAny<RegionalGenerateAndInsertUvciCommand>()))
                .ReturnsAsync("uvci");

            var barcodeGenerator = new BarcodeGenerator(
                uvciGeneratorMock.Object,
                map,
                encoder.Object,
                logger.Object,
                configuration);

            var bundle = BarCodeGeneratorTestHelper.GetBundleWithInvalidLocation();
            var regionConfig = new RegionConfig();

            // Act
            var result = await barcodeGenerator.BarcodesFromFhirBundle(bundle, regionConfig);

            // Assert
            var error = result.Barcodes.First().Error;

            error.Code.Should()
                .Be(ErrorCode.FHIR_LOCATION_ADDRESS_COUNTRY_NOTONISOLIST.ToString(StringUtils
                    .NumberFormattedEnumFormat));
        }

        [Fact]
        public async Task BarcodesFromFhirBundle_LocationValid_ReturnsBarCodeResultsWithoutErrors_CountryFromFhirPayload()
        {
            // Arrange
            var inMemorySettings = SetupInMemorySettings();

            IConfiguration configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();

            var vaccineMappingMock = new Mock<IVaccineMapping>();
            vaccineMappingMock.Setup(x => x.GetMappings()).ReturnsAsync(new Dictionary<string, VaccineMap>
            {
                { "39115611000001103" , new VaccineMap
                {
                    Manufacturer = new List<string>{"ORG-100030215", "Biontech Manufacturing GmbH"},
                    Disease = new List<string>{"840539006", "COVID-19"},
                    TotalSeriesOfDoses = 2,
                    Product = new List<string>{"EU/1/20/1528", "Comirnaty", "Pfizer/BioNTech COVID-19 vaccine"},
                    Vaccine = new List<string>{"1119349007", "SARS Cov-2 mRNA Vaccine"}
                }}
            });

            VaccinationMapper map = new VaccinationMapper(vaccineMappingMock.Object, configuration,
                new Mock<IFhirLookupApi>().Object, new Mock<ILogger<VaccinationMapper>>().Object);

            var uvciGeneratorMock = new Mock<IUvciGenerator>();
            uvciGeneratorMock.Setup(x => x.TryGenerateAndInsertUvci(It.IsAny<RegionalGenerateAndInsertUvciCommand>()))
                .ReturnsAsync("uvci");

            var barcodeGenerator = new BarcodeGenerator(
                uvciGeneratorMock.Object,
                map,
                encoder.Object,
                logger.Object,
                configuration);

            var bundle = BarCodeGeneratorTestHelper.GetBundleWithValidLocation();
            var regionConfig = new RegionConfig();

            // Act
            var result = await barcodeGenerator.BarcodesFromFhirBundle(bundle, regionConfig);

            // Assert
            result.Barcodes.First().Error.Should().BeNull();
            encoder.Verify(x => x.EncodeFlowAsync(
                It.IsAny<IUserCBORInformation>(), 
                It.IsAny<long>(), 
                It.IsAny<IEnumerable<Vaccine>>(), 
                It.IsAny<string>(),
                It.IsAny<DateTime?>(),
                It.IsAny<int>(),
                It.Is<string>(s => s == "GB")
            ), Times.Once);
        }

        [Fact]
        public async Task BarcodesFromFhirBundle_NoLocation_ReturnsBarCodeResultsWithoutErrors_CountryFromRegionConfig()
        {
            // Arrange
            var inMemorySettings = SetupInMemorySettings();

            IConfiguration configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();

            var vaccineMappingMock = new Mock<IVaccineMapping>();
            vaccineMappingMock.Setup(x => x.GetMappings()).ReturnsAsync(new Dictionary<string, VaccineMap>
            {
                { "39115611000001103" , new VaccineMap
                {
                    Manufacturer = new List<string>{"ORG-100030215", "Biontech Manufacturing GmbH"},
                    Disease = new List<string>{"840539006", "COVID-19"},
                    TotalSeriesOfDoses = 2,
                    Product = new List<string>{"EU/1/20/1528", "Comirnaty", "Pfizer/BioNTech COVID-19 vaccine"},
                    Vaccine = new List<string>{"1119349007", "SARS Cov-2 mRNA Vaccine"}
                }}
            });

            VaccinationMapper map = new VaccinationMapper(vaccineMappingMock.Object, configuration,
                new Mock<IFhirLookupApi>().Object, new Mock<ILogger<VaccinationMapper>>().Object);

            var uvciGeneratorMock = new Mock<IUvciGenerator>();
            uvciGeneratorMock.Setup(x => x.TryGenerateAndInsertUvci(It.IsAny<RegionalGenerateAndInsertUvciCommand>()))
                .ReturnsAsync("uvci");

            var barcodeGenerator = new BarcodeGenerator(
                uvciGeneratorMock.Object,
                map,
                encoder.Object,
                logger.Object,
                configuration);

            var bundle = BarCodeGeneratorTestHelper.GetBundleWithoutLocation();
            var regionConfig = new RegionConfig
            {
                RegionCode = "GG",
                Issuer = "NHS Digital",
                CountryCode = "GG",
                MemberState = "GG"
            };

            // Act
            var result = await barcodeGenerator.BarcodesFromFhirBundle(bundle, regionConfig);

            // Assert
            result.Barcodes.First().Error.Should().BeNull();
            encoder.Verify(x => x.EncodeFlowAsync(
                It.IsAny<IUserCBORInformation>(), 
                It.IsAny<long>(), 
                It.IsAny<IEnumerable<Vaccine>>(), 
                It.IsAny<string>(),
                It.IsAny<DateTime?>(),
                It.IsAny<int>(),
                It.Is<string>(s => s == "GB")
            ), Times.Exactly(2));
        }

        [Fact]
        public async Task BarcodesFromFhirBundle_PatientValidationSuccessImmunizationValidationFail_ReturnsBarcodeResultsWithNoImmunizations()
        {
            //Arrange
            var inMemorySettings = SetupInMemorySettings();
            IConfiguration configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();

            VaccinationMapper map = new VaccinationMapper(mockVaccineMapping.Object, configuration, new Mock<IFhirLookupApi>().Object, new Mock<ILogger<VaccinationMapper>>().Object);
            uvciGenerator.Setup(x => x.TryGenerateAndInsertUvci(It.IsAny<RegionalGenerateAndInsertUvciCommand>())).ReturnsAsync("uvci");
            var generator = new BarcodeGenerator(
                    uvciGenerator.Object,
                    map,
                    encoder.Object,
                    logger.Object,
                    configuration);
            var regionConfig = new RegionConfig();
            var bundle = BarCodeGeneratorTestHelper.GetCorrectBundle();

            //Act
            var result = await generator.BarcodesFromFhirBundle(bundle, regionConfig);

            //Assert
            Assert.Equal(ErrorCode.FHIR_IMMUNIZATION_MISSING.GetHashCode().ToString(), result.Barcodes[0].Error.Code);
            Assert.Equal("Immunization Missing.", result.Barcodes[0].Error.Message);
        }

        [Fact]
        public async Task BarcodesFromFhirBundle_PatientValidationSuccessImmunizationValidationSuccess_ReturnsBarCodeResultsWithoutError()
        {
            //Arrange
            var inMemorySettings = SetupInMemorySettings();
            IConfiguration configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();

            VaccinationMapper map = new VaccinationMapper(mockVaccineMapping.Object, configuration, new Mock<IFhirLookupApi>().Object, new Mock<ILogger<VaccinationMapper>>().Object);
            uvciGenerator.Setup(x => x.TryGenerateAndInsertUvci(It.IsAny<RegionalGenerateAndInsertUvciCommand>())).ReturnsAsync("uvci");
            var generator = new BarcodeGenerator(
                    uvciGenerator.Object,
                    map,
                    encoder.Object,
                    logger.Object,
                    configuration);
            var regionConfig = new RegionConfig();
            var bundle = BarCodeGeneratorTestHelper.GetCorrectBundle();
            bundle.Entry[1].Resource.Id = "12345";

            //Act
            var result = await generator.BarcodesFromFhirBundle(bundle, regionConfig);

            //Assert
            Assert.Null(result.Barcodes[0].Error);
        }

        [Fact]
        public async Task BarcodesFromFhirBundle_PatientValidationSuccessImmunizationValidationSuccess_ReturnsBarcodeResultsWithAtLeastOneImmunization()
        {
            //Arrange
            var inMemorySettings = SetupInMemorySettings();
            IConfiguration configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();

            VaccinationMapper map = new VaccinationMapper(mockVaccineMapping.Object, configuration, new Mock<IFhirLookupApi>().Object, new Mock<ILogger<VaccinationMapper>>().Object);
            uvciGenerator.Setup(x => x.TryGenerateAndInsertUvci(It.IsAny<RegionalGenerateAndInsertUvciCommand>())).ReturnsAsync("uvci");
            var generator = new BarcodeGenerator(
                    uvciGenerator.Object,
                    map,
                    encoder.Object,
                    logger.Object,
                    configuration);
            var regionConfig = new RegionConfig();
            var bundle = BarCodeGeneratorTestHelper.GetCorrectBundle();
            bundle.Entry[1].Resource.Id = "12345";

            //Act
            var result = await generator.BarcodesFromFhirBundle(bundle, regionConfig);

            //Assert
            Assert.NotEmpty(result.Barcodes);
            Assert.Null(result.Barcodes[0].Error);
        }

        [Fact]
        public async Task BarcodesFromFhirBundle_PatientValidationSuccessImmunizationValidationFail_ReturnsBarcodeResultsWithErrorImmunizationMissing()
        {
            //Arrange
            var inMemorySettings = SetupInMemorySettings();
            IConfiguration configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();

            VaccinationMapper map = new VaccinationMapper(mockVaccineMapping.Object, configuration, new Mock<IFhirLookupApi>().Object, new Mock<ILogger<VaccinationMapper>>().Object);
            uvciGenerator.Setup(x => x.TryGenerateAndInsertUvci(It.IsAny<RegionalGenerateAndInsertUvciCommand>())).ReturnsAsync("uvci");
            var generator = new BarcodeGenerator(
                    uvciGenerator.Object,
                    map,
                    encoder.Object,
                    logger.Object,
                    configuration);
            var regionConfig = new RegionConfig();
            var bundle = BarCodeGeneratorTestHelper.GetBundleWithoutImmunizations();

            //Act
            var result = await generator.BarcodesFromFhirBundle(bundle, regionConfig);

            //Assert
            Assert.Equal(ErrorCode.FHIR_IMMUNIZATION_MISSING.GetHashCode().ToString(), result.Barcodes[0].Error.Code);
            Assert.Equal("Immunization Missing.", result.Barcodes[0].Error.Message);
        }

        private Dictionary<string, string> SetupInMemorySettings()
        {
            return new Dictionary<string, string> { { "ValidityTimeForVaccinationBarcodeFromNowInHours", "10" } };;
        }
    }
}

