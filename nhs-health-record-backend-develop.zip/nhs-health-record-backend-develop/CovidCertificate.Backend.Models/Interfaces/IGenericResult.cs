﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Interfaces
{
    //Interface for diagnostic, antibody and vaccination models to inherit so that they can be worked
    // on as a whole in the eligibility configuration business rules
    public interface IGenericResult
    {
        public DateTime DateTimeOfTest { get; }
        public string ValidityType { get; }
        public string Result { get; }
    }
}