﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class GooglePassJwtTest
    {
        private readonly Mock<IGeneratePassData> passDataMock = new Mock<IGeneratePassData>();
        private GooglePassJwt googlePassJwt;
        private readonly Mock<IConfiguration> configMock = new Mock<IConfiguration>();
        private readonly Mock<ILogger<GooglePassJwt>> loggerMock;


        PassSettings testSettings = new PassSettings
        {
            PassProvider = "NHS",
            PassName = "Covid Status",
            PassOrigins = "Department of Health & Social Care",
            IssuerId= "3388000000014008333",
            Audience="google",

            BackgroundColour="#123456",
            JwtType="savetogooglepay",
            GoogleImageUrl= "https://www.gstatic.com/images/icons/material/system_gm/2x/healing_black_48dp.png",
            UniqueId= "103680298697648115575",
            Iss= "covidpass-googlewallet@covidpass-317908.iam.gserviceaccount.com",

        };
        CovidPassportUser ValidUser;
        private readonly string key = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDJ2IKpjxiccNVQ\n/3NspNGAhHZcbajpaPCnAz1IZ+Ib8blE16Vx/bmzBFHf65KxMJpeN073ccJ7Wxag\n/BgDXn3yKJHfo+uDAe9FpWWLojCz0B1u8UGdSC+KAmgqYPfrhQyV8OeSGT+vM/SJ\n1Bhedzsp0aDs2MnH99p+IBSoyKGavlfyyEha/Z53dDZaIk10ePl2EYqEbVLVnIEo\n5UpCGBpIfhVxyt7k21S3CcACTCuya1dwn3d7CMnBGduztQ8ZxCNYJm0e63FuL/Kz\nwITMXzPFKChdG7ExQ+U5ML/2bW7wyK/ZHA4qPeL31ZyMTETDL4w/76KBR4IfGtxx\nEyo9DPu1AgMBAAECggEAC0X7bkBJbfC4s/sV1Zs9qZbnDByCfZ7Yf2DP8GuqQPNM\nQgsP+NY5+USkKgR8lJw+qEUgikjL8EXTIA9UbAPADGFgXFmfEsRt5Q7qz/9cBv74\nVd+a/DoxkDINjVMN0GqwRu5F5hlg6YaBAZ2woBNlYN2OG7cJS2Y4HtPoiNDD2Izw\nQfe7SupG6sYk6+HNS7tnatHf0ikKjLVl+u4K6GJjPYNUpDsxAiNuGbNGV8aYpU1U\nLeqVWJRoUQWVx0MKDqyPl/VbK5u5NEo1SLiwYqtozhHPiHe64/zPbHNbKrQUd5HB\nGgs2eR7nu3nyhxO5uiT7zdTZhLvQJfEP4L5k+a+RQQKBgQDvBDU1lnwNreJloBj3\nADpG0hiV4fH7/hHeSZ0lZBPLBkFFtMg7zEJnlqnMM9N1MW5mIWXkiHmkXifj9xzt\n9YA3LZhYIsTiyghKRdnFGZ0cf1cwYZT+PBhzbNcq6T80Viifm4PgqttIVms8REwJ\nloYmQmfTcRIDIgO37ifnqTqtxQKBgQDYMCebAphsji/mFF7QY+xqcqUlrsz6cl3l\npBapcRPuqBlFi9ThV470dgAiCFypROmJLS5jhHgYxHhniIChhedN+XwTSR0+vyVV\nRtqeW+KOWGZ6ucPe4DV8qstsS9QitZsw0q6va8Cit331b6N7gQ06bmm16hej7v6h\nRdfcKGdlMQKBgD7v47b1pjrP48KQ0qIPvEizv+ePtHF/aGMZDTkwTgny3rMlNGiS\nk5XFVXbA2tiMKJ7aAoOX8Df41xYvFr4OHDHrXqcumJuDSYWNOReuc/FyEppZx6re\nVi3mpg3Vl2AHo/DLOYGqW82De/9FmKQZr79ZUw+ZQX3zsfj3zCgzJpFlAoGAWjGM\n9IDasr+HgEgTXoGxyp9WAyiwX/SC9CHHSp3goPsEwB0cjX8IJzlryMcQUZZskEyH\nRAGqUTr2uMscT0ccP03M1Ab26oy4uKE86ECRfq2m46DI9R05c2+WOvJP6MM3oeDj\n/E/KKJjBNjqDTC2FJVGXTMwDXOOC3CnVawZ4TKECgYEAgajFlJWhSqnehPTlF7CV\nnSPsE+o14s/sG6xCk/nT+OWe1XeehRN+Aaf66eMrtjVprd4IpX7YhGzpAtXroJiA\nb85QOdHesujylMqrNFidZmaPWhmw403cvf+j/j7ht4GFuXmsgTAzfBlp3zdUbzeD\njmqhM7L3xo/eHUK10mh2QDc=";
        public GooglePassJwtTest()
        {
            this.loggerMock = new Mock<ILogger<GooglePassJwt>>();
            configMock.SetupGet<string>(m => m["GooglePrivateKey"]).Returns(key);
            googlePassJwt = new GooglePassJwt(loggerMock.Object, passDataMock.Object, configMock.Object, testSettings);
            ValidUser = new CovidPassportUser("Test McTestPerson", DateTime.UtcNow.AddYears(-20), "test@test.com", "447111111111");

        }

        [Fact]
        public async Task TestGenerateJwt()
        {
            //Arrange
            var ValidCert = new Certificate("Test McTestPerson", DateTime.UtcNow, DateTime.UtcNow.AddYears(1), DateTime.UtcNow.AddYears(1), CertificateType.Vaccination, CertificateScenario.Domestic);
            ValidCert.QrCodeTokens = new List<string> { "S2V5MQ==.MTIxMDczMDEwMDlFdmFuIEdBTlRFUw.OgJuJ1G_7t0sXtLKz6NO3zK0nXeiLK5bLAKTwA0uQfJEhN9IbaEN1BjeY8SaGAdqAgcMTDIy9vQbJYhq-blikQ" };
            var validQRResponse = new QRcodeResponse(DateTime.UtcNow.AddDays(30).ToString(), null, null);
            passDataMock.Setup( x =>  x.GetPassDataAsync(ValidUser, "", QRType.Domestic)).ReturnsAsync((validQRResponse, ValidCert));
            //Act
            var jwt= await googlePassJwt.GenerateJwt(ValidUser,0);
            //Assert
            Assert.IsType<string>(jwt);            
        }

        [Fact]
        public async Task TestGenerateJwt_InvalidCert()
        {
            //Arrange/Act
            var ex = await Assert.ThrowsAsync<InvalidDataException>(() => googlePassJwt.GenerateJwt(ValidUser,(QRType)88));
            //Assert
            Assert.Equal("Invalid pass type", ex.Message);
        }
        //Trying to generate JWT
        /*[Fact]
        public async Task TestGenerateJwt_IsSuccessful()
        {

            hostingMock.Setup(m => m.ContentRootPath).Returns(AppDomain.CurrentDomain.BaseDirectory);
            hostingMock.Setup(m => m.EnvironmentName).Returns(Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT"));
            hostingMock.Setup(m => m.ApplicationName).Returns(AppDomain.CurrentDomain.FriendlyName);
            hostingMock.Setup(m => m.ContentRootFileProvider).Returns(new PhysicalFileProvider(AppDomain.CurrentDomain.BaseDirectory));
            var ValidCert = new Certificate("Test McTestPerson", DateTime.UtcNow, DateTime.UtcNow.AddYears(1),CertificateType.Vaccination);

            certMock.Setup(m => m.GetDomesticCertificate(ValidUser)).ReturnsAsync(ValidCert);
            var result = await googlePassJwt.GenerateJwt(ValidUser);
            Assert.IsType<string>(result);
        }*/
    }
}
