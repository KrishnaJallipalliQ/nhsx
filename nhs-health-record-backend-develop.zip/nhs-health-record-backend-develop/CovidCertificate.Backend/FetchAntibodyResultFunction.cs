using CovidCertificate.Backend.Configuration.Bases.BaseFunctions;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Delegates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Services;
using CovidCertificate.Backend.Utils.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SendGrid.Helpers.Errors.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace CovidCertificate.Backend
{
    public class FetchAntibodyResultFunction : BaseSecureFunction
    {
        private readonly IConfiguration configuration;
        private readonly IPilotFilterService pilotFilterService;
        private readonly IAntibodyResultsService antibodyResultsService;
        private readonly IGetTimeZones timeZones;

        public FetchAntibodyResultFunction(JwtValidatorResolver jwtTokenValidator,
            IPilotFilterService pilotFilterService,
            IConfiguration configuration,
            IAntibodyResultsService antibodyResultsService,
            ILogger<FetchAntibodyResultFunction> logger, 
            IGetTimeZones timeZones) : base(jwtTokenValidator, configuration, logger)
        {
            this.configuration = configuration;
            this.pilotFilterService = pilotFilterService;
            this.antibodyResultsService = antibodyResultsService;
            this.timeZones = timeZones;
        }

        [FunctionName("GetAntibodyResults")]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "get", Route = "GetAntibodyResults")] HttpRequest request)
        {
            try
            {
                logger.LogInformation("GetAntibodyResults was invoked");

                IEnumerable<AntibodyResultResponse> results = new List<AntibodyResultResponse>();

                var validationResult = await base.AuthoriseEndpoint(request);
                logger.LogTraceAndDebug($"validationResult: IsValid {validationResult?.IsValid}, Response is {validationResult?.Response}, TokenClaims are {validationResult?.TokenClaims}");
                if (base.responseInvalid(validationResult))
                {
                    logger.LogInformation("GetAntibodyResults has finished");
                    return validationResult.Response;
                }

                var covidUser = new CovidPassportUser(validationResult.TokenClaims);
                logger.LogTraceAndDebug($"covidUser: {covidUser?.ToString()}");
                logger.LogInformation($"covidUser: {covidUser?.ToNhsNumberAndDobHashKey()}");

                if (Environment.GetEnvironmentVariable("ViewOnlyPilotUsersData") == "true" && !await pilotFilterService.IsPilotUser(covidUser.ToPilotUser()))
                {
                    logger.LogWarning("This user is not a pilot user");
                    logger.LogInformation("User Hash" + covidUser.ToPilotUser().UserHash);
                    logger.LogInformation("GetAntibodyResults has finished");
                    return new OkObjectResult(results);
                }
                var nhsResults = await antibodyResultsService.GetAntibodyResults(base.GetIdToken(request));
                results = nhsResults.Select(x => new AntibodyResultResponse(x, timeZones));
                logger.LogTraceAndDebug($"antibody results are {nhsResults}");
                
                logger.LogInformation("GetAntibodyResults has finished");

                return new OkObjectResult(results);
            }
            catch (Exception e) when (e is BadRequestException || e is ArgumentNullException || e is ArgumentException)
            {
                logger.LogWarning(e, e.Message);
                return new BadRequestObjectResult("There seems to be a problem; bad request");
            }
            catch (UnauthorizedException e)
            {
                logger.LogWarning(e, e.Message);
                return new UnauthorizedObjectResult("There seems to be a problem: unauthorized");
            }
            catch (ForbiddenException e)
            {
                logger.LogWarning(e, e.Message);
                return new ObjectResult("There seems to be a problem; forbidden") { StatusCode = StatusCodes.Status403Forbidden };
            }
            catch (HttpRequestException e)
            {
                logger.LogCritical(e, e.Message);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
            catch (Exception e)
            {
                logger.LogError(e, e.Message);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}
