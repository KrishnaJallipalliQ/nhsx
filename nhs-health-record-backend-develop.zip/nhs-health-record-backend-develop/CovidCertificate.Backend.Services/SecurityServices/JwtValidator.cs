﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Delegates;
using CovidCertificate.Backend.Models.Settings;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services
{
    public class JwtValidator : IJwtValidator
    {
        private readonly ValidationServiceResolver validationParamResolver;
        private readonly ILogger<JwtValidator> logger;

        public JwtValidator(ValidationServiceResolver serviceResolver, 
            ILogger<JwtValidator> logger)
        {
            this.validationParamResolver = serviceResolver;
            this.logger = logger;
        }

        /// <summary>
        /// Checks if a validation token is valid based off the current app settings
        /// </summary>
        /// <param name="token">The input JWT</param>
        /// <returns>If the token is valid</returns>
        public async Task<bool> IsValidToken(string token, string authSchema = "CovidCertificate")
        {
            var validationService = validationParamResolver(authSchema);
            var validationParameters = await validationService.GetValidationParameters();
            var tokenHandler = new JwtSecurityTokenHandler();
            try
            {
                var claims = tokenHandler.ValidateToken(token, validationParameters, out var validatedToken);
                return true;
            }
            catch (SecurityTokenException e)
            {
                logger.LogCritical(e, "Failed to validate token: " + token);
                //If the validate token throws an exception this means the token isn't valid
                return false;
            }
            catch (Exception e)
            {
                logger.LogCritical(e, e.Message);
                throw;
            }
        }

        /// <summary>
        /// Fetches the claims for a token if it's valid
        /// </summary>
        /// <param name="token">the jwt token</param>
        /// <returns>The tokens claims</returns>
        public async Task<ClaimsPrincipal> GetClaims(string token, string authSchema = "CovidCertificate")
        {
            logger.LogInformation("GetClaims was invoked");
            var validationService = validationParamResolver(authSchema);
            var validationParameters = await validationService.GetValidationParameters();
            var tokenHandler = new JwtSecurityTokenHandler();

            try
            {
                logger.LogInformation("GetClaims has finished");
                return tokenHandler.ValidateToken(token, validationParameters, out var validatedToken);
            }
            catch (SecurityTokenException e)
            {
                logger.LogCritical(e, "Failed to validate token: " + token);
                //If the validate token throws an exception this means the token isn't valid
                return default;
            }
            catch(AggregateException e)
            {
                logger.LogCritical(e, "Invalid Key vault: " + token);
                //If the validate token throws an exception this means the token isn't valid
                return default;
            }
            catch (Exception e)
            {
                var type = e.GetType();
                logger.LogCritical(e, e.Message);
                throw;
            }
        }
    }
}