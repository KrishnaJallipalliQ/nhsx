﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.RequestDtos;
using System;

namespace CovidCertificate.Backend.Tests.TestHelpers
{
    public static class TestResultTestHelper
    {
        public static TestResultNhs CreateTestResultUsingRandomUser(DateTime dateTimeOfTest, string result, string validityType,string testKit)
        {
            var user = CovidTestUserTestHelper.CreateUserUsingBothEmailAddressAndPhoneNumber();
            return new TestResultNhs(dateTimeOfTest, result, validityType, "", "", new Tuple<string, string>("", ""), "", "");
        }
    }
}
