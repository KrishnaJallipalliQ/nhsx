﻿using CovidCertificate.Backend.DASigningService.ErrorHandling;
using CovidCertificate.Backend.DASigningService.Requests;
using CovidCertificate.Backend.Utils;
using FluentValidation;

namespace CovidCertificate.Backend.DASigningService.Validators
{
    public class Create2DVaccinationBarcodeRequestValidator : AbstractValidator<Create2DVaccinationBarcodeRequest>
    {
        public Create2DVaccinationBarcodeRequestValidator()
        {
            RuleFor(x => x.Type).Cascade(CascadeMode.Stop)
                .Must(t => t == "international")
                .When(x => x.Type != null)
                .WithMessage("Unsupported type.")
                .WithErrorCode(ErrorCode.UNSUPPORTED_TYPE.ToString(StringUtils.NumberFormattedEnumFormat));            

            RuleFor(x => x.Body).Cascade(CascadeMode.Stop)
                .NotEmpty()
                .WithMessage("Request should not be empty.")
                .WithErrorCode(ErrorCode.FHIR_INVALID.ToString(StringUtils.NumberFormattedEnumFormat));

            RuleFor(x => x.RegionSubscriptionNameHeader).Cascade(CascadeMode.Stop)
                .NotEmpty()
                .WithMessage(
                    $"Missing header '{DevolvedAdministrationBarcodeGeneratorFunction.RegionSubscriptionNameHeader}'")
                .WithErrorCode(ErrorCode.UNEXPECTED_SYSTEM_ERROR.ToString(StringUtils.NumberFormattedEnumFormat));
        }
    }
}
