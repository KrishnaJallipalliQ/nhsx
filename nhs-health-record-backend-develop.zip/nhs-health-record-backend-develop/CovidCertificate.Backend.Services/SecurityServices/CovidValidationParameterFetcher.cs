﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Services.KeyServices;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services
{
    public class CovidValidationParameterFetcher : IJwtValidationParameterFetcher
    {
        private readonly CovidJwtSettings covidJwtSettings;
        private readonly IKeyRing keyRing;

        public CovidValidationParameterFetcher(CovidJwtSettings covidJwtSettings, IKeyRing keyRing)
        {
            this.covidJwtSettings = covidJwtSettings ?? throw new ArgumentNullException(nameof(covidJwtSettings));
            this.keyRing = keyRing ?? throw new ArgumentNullException(nameof(keyRing));
        }

        public async Task<TokenValidationParameters> GetValidationParameters()
        {
            return new TokenValidationParameters
            {
                ValidIssuer = covidJwtSettings.Issuer,
                ValidAudience = covidJwtSettings.Audience,
                // Microsoft won't get off their arses and implement async delegates https://github.com/AzureAD/azure-activedirectory-identitymodel-extensions-for-dotnet/issues/468
               // IssuerSigningKeyResolver = (token, securityToken, kid, validationParameters) => GetKey(kid),
                SignatureValidator = (token, validationParameters) => ValidateToken(token),
                ValidateIssuer = true,
                ValidateAudience = true,
                RequireExpirationTime = false,
                ValidateLifetime = false
            };
        }
        
        /// <summary>
        /// Validates the token manually, 
        /// 1: reads the keyId from the header
        /// 2: calculates the digest from the encoded header and payload
        /// 3: Checks if the signature is valid
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        protected SecurityToken ValidateToken(string token) {

            var tokenParts = token.Split('.');
            if (tokenParts.Length != 3)
                return default;

            var header = tokenParts[0];
            var payload = tokenParts[1];
            var signature = tokenParts[2];

            var headerString = Base64UrlEncoder.Decode(header);
            var headerObject = JsonConvert.DeserializeObject<JwtHeader>(headerString);
            var kid = headerObject.Kid;

            var valid = keyRing.VerifyData(kid, Encoding.Unicode.GetBytes($"{header}.{payload}"), Base64UrlEncoder.DecodeBytes(signature));
            
            return valid ? new JwtSecurityToken(token) : default(SecurityToken);
        }
    }
}
