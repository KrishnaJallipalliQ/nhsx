using CovidCertificate.Backend.Configuration.Bases.BaseFunctions;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.ResponseDtos;
using CovidCertificate.Backend.Utils.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using SendGrid.Helpers.Errors.Model;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Auth
{
    public class Token : BaseFunction
    {
        public Token(INhsLoginService nhsLoginService, ILogger<Token> logger) : base(logger) => _nhsLoginService = nhsLoginService;

        private readonly INhsLoginService _nhsLoginService;

        [FunctionName("Token")]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "post", Route = "Token")] HttpRequest request)
        {
            try
            {
                logger.LogInformation("Token was invoked");

                if (!request.Query.TryGetValue("code", out var queryCode))
                    throw new ArgumentNullException("No authorization code was specified.");
                if (!request.Query.TryGetValue("redirectUri", out var queryRedirectUri))
                    throw new ArgumentNullException("No redirect uri was specified.");

                var nhsLoginToken = await _nhsLoginService.GetAccessTokenAsync(queryCode, queryRedirectUri);
                logger.LogTraceAndDebug($"nhsLoginToken: {nhsLoginToken?.ToString()}");

                var nhsLoginTokenResponse = new NhsLoginTokenResponse(nhsLoginToken);
                logger.LogTraceAndDebug($"nhsLoginTokenResponse:{nhsLoginTokenResponse?.ToString()}");
                    
                logger.LogInformation("Token has finished");
                return new OkObjectResult(nhsLoginTokenResponse);
            }
            catch (Exception e) when (e is BadRequestException || e is ArgumentNullException)
            {
                logger.LogWarning(e, e.Message);
                return new BadRequestObjectResult("There seems to be a problem: bad request");
            }
            catch (UnauthorizedException e)
            {
                logger.LogWarning(e, e.Message);
                return new UnauthorizedObjectResult("There seems to be a problem: unauthorized");
            }
            catch (HttpRequestException e)
            {
                logger.LogCritical(e, e.Message);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
            catch (Exception e)
            {
                logger.LogError(e, e.Message);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}
