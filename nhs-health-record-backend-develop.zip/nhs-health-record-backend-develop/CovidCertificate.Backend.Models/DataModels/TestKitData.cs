﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.DataModels
{
    public class TestKitData
    {
        //TO: TestType to map this TestKit value to
        public string To { get; set; }
        //USE: Can tests/antibodies with this TestKit value be used in get test/antibody requests?
        public bool Use { get; set; }
        //SAVE: Can tests/antibodies with this TestKit value be used in save test/antibody requests?
        public bool Save { get; set; }
    }
}
