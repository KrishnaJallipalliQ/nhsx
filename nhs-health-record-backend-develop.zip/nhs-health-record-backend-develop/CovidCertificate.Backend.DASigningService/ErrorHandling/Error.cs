﻿namespace CovidCertificate.Backend.DASigningService.ErrorHandling
{
    public class Error
    {
        public string Code { get; set; }
        public string Message { get; set; }
    }
}
