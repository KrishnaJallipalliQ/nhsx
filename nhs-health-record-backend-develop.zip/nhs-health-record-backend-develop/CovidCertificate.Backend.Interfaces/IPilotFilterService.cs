﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.RequestDtos; 
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IPilotFilterService
    {
        Task<bool> IsPilotUser(PilotUser pilotUser);
    }
}
