﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.International.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using Microsoft.Extensions.Configuration;
using PeterO.Cbor;
using System.Text.RegularExpressions;
using CovidCertificate.Backend.Models.Enums;
using System.Text;
using Org.BouncyCastle.Utilities.Collections;
using CovidCertificate.Backend.Models.Interfaces.UserInterfaces;
using System.Collections;
using System.Collections.Generic;

namespace CovidCertificate.Backend.International.Services
{
    public class CondensorService : ICondensorService
    {
        private readonly ILogger<CondensorService> logger;
        private readonly IConfiguration configuration;
        private readonly TimeZoneInfo timeZoneInfo;

        public CondensorService(ILogger<CondensorService> logger, IConfiguration configuration, IGetTimeZones timeZones)
        {
            this.logger = logger;
            this.configuration = configuration;
            timeZoneInfo = timeZones.GetTimeZoneInfo();
        }

        public CBORObject CondenseCBOR<T>(IUserCBORInformation user, long certifiateGenerationTime, IEnumerable<T> results, string uniqueCertificateIdentifier, DateTime? validityEndDate, int resultIndex, string barcodeIssuerCountry = null)
        {
            try
            {
                CBORObject outsideLayer = CBORObject.NewMap();
                CBORObject hcertLayer = CBORObject.NewMap();
                CBORObject euHcertV1SchemaLayer = CBORObject.NewMap();
                // Please refer to https://ec.europa.eu/health/sites/default/files/ehealth/docs/digital-green-certificates_v1_en.pdf (Section 3.3.1)
                // Please do not change key value integers for CBOR maps and arrays
                // outsideLayer setup
                string field1Value = barcodeIssuerCountry != null ? barcodeIssuerCountry : configuration["CountryOfVaccination"];
                outsideLayer.Add(1, field1Value);
                outsideLayer.Add(6, certifiateGenerationTime); // Date of issue
                outsideLayer.Add(-260, hcertLayer);
                hcertLayer.Add(1, euHcertV1SchemaLayer);
                //euHcertV1SchemaLayer setup
                CBORObject cborArray = CBORObject.NewArray();
                if (results.ElementAt(resultIndex) is Vaccine vaccine)
                {
                    cborArray.Add(ToVaccineCBOR(vaccine, uniqueCertificateIdentifier));

                    if(validityEndDate != null)
                    {
                        var dateTimeOffset = new DateTimeOffset(validityEndDate.Value);
                        // outsideLayer setup
                        outsideLayer.Add(4, dateTimeOffset.ToUnixTimeSeconds());
                    }
                    
                    // Please refer to https://github.com/ehn-digital-green-development/ehn-dgc-schema/blob/main/DGC.combined-schema.json
                    // All fields key values are following official EU schema
                    euHcertV1SchemaLayer.Add("v", cborArray);

                }
                else if(results.ElementAt(resultIndex) is TestResultNhs testResult)
                {
                    cborArray.Add(ToRecoveryCBOR(testResult, validityEndDate, uniqueCertificateIdentifier));

                    if(validityEndDate != null)
                    {
                        var dateTimeOffset = new DateTimeOffset(validityEndDate.Value);
                        outsideLayer.Add(4, dateTimeOffset.ToUnixTimeSeconds());
                    }
                    
                    // Please refer to https://github.com/ehn-digital-green-development/ehn-dgc-schema/blob/main/DGC.combined-schema.json
                    // All fields key values are following official EU schema
                    euHcertV1SchemaLayer.Add("r", cborArray);

                }
                euHcertV1SchemaLayer.Add("dob", user.DateOfBirth.ToString("yyyy-MM-dd"));
                euHcertV1SchemaLayer.Add("nam", ToNameCBOR(user));
                euHcertV1SchemaLayer.Add("ver", configuration["SchemaVersion"]);
                return outsideLayer;
            }
            catch (Exception e)
            {
                logger.LogError(e, e.Message);
                throw new ArgumentException("Error in Condensor: " + e.Message);
            }
        }

        private CBORObject ToVaccineCBOR(Vaccine vaccine, string uniqueCertificateIdentifier)
        {
            // Please refer to https://github.com/ehn-digital-green-development/ehn-dgc-schema/blob/main/DGC.combined-schema.json
            // All fields key values are following official EU schema
            CBORObject vaccineObj = CBORObject.NewMap();
            vaccineObj.Add("ci", uniqueCertificateIdentifier);
            vaccineObj.Add("co", vaccine.CountryOfVaccination);
            vaccineObj.Add("dn", vaccine.DoseNumber);
            vaccineObj.Add("dt", TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(vaccine.VaccinationDate, DateTimeKind.Unspecified), timeZoneInfo).ToString("yyyy-MM-dd"));
            vaccineObj.Add("is", vaccine.Authority);
            vaccineObj.Add("ma", vaccine.VaccineManufacturer.Item1);
            vaccineObj.Add("mp", vaccine.Product.Item1); // ProductCode
            vaccineObj.Add("sd", vaccine.TotalSeriesOfDoses);
            vaccineObj.Add("tg", vaccine.DiseaseTargeted.Item1);
            vaccineObj.Add("vp", vaccine.VaccineType.Item1);
            //Administering centre is only part of the WHO interim standard, not the EU standard
            //https://www.who.int/publications/m/item/core-data-set-for-the-smart-vaccination-certificate
            //For now the key has been set to "ac", unclear what it should actually be. Has been commented out until certain what it should be
            //vaccineObj.Add("ac", vaccine.Site);

            return vaccineObj;
        }

        private CBORObject ToRecoveryCBOR(TestResultNhs diagnosticResult, DateTime? validityEndDate, string uniqueCertificateIdentifier)
        {
            // Please refer to https://github.com/ehn-digital-green-development/ehn-dgc-schema/blob/main/DGC.combined-schema.json
            // All fields key values are following official EU schema
            CBORObject recoveryObj = CBORObject.NewMap();
            recoveryObj.Add("tg", diagnosticResult.DiseaseTargeted.Item1); // disease-agent-targeted
            recoveryObj.Add("fr",
                TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(diagnosticResult.DateTimeOfTest, DateTimeKind.Unspecified), timeZoneInfo).ToString("yyyy-MM-dd"));
            // ISO 8601 Date of First Positive Test Result
            recoveryObj.Add("co", String.IsNullOrEmpty(diagnosticResult.CountryOfAuthority) ? configuration["RecoveryCountry"] : diagnosticResult.CountryOfAuthority); // Country of Test
            recoveryObj.Add("is", String.IsNullOrEmpty(diagnosticResult.Authority) ? configuration["RecoveryAuthority"] : diagnosticResult.Authority); // Certificate Issuer
            recoveryObj.Add("df", TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Unspecified), timeZoneInfo).ToString("yyyy-MM-dd")); // ISO 8601 Date: Certificate Valid From
            if(validityEndDate != null)
                recoveryObj.Add("du", TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(validityEndDate.Value, DateTimeKind.Unspecified), timeZoneInfo).ToString("yyyy-MM-dd")); // Certificate Valid Until
            recoveryObj.Add("ci", String.IsNullOrEmpty(uniqueCertificateIdentifier) ? String.Empty : uniqueCertificateIdentifier); // Unique Certificate Identifier, UVCI
            return recoveryObj;
        }

        private static CBORObject ToNameCBOR(IUserCBORInformation user)
        {
            if (string.IsNullOrEmpty(user.GivenName) || string.IsNullOrEmpty(user.FamilyName))
                return GetByParsingFullName(user);
            return GetFromFamilyAndGivenNames(user);
        }

        private static CBORObject GetFromFamilyAndGivenNames(IUserCBORInformation user)
        {
            var userNamesObj = CBORObject.NewMap();
            userNamesObj.Add("fn", user.FamilyName);
            userNamesObj.Add("gn", user.GivenName);

            var familyNameUpper = user.FamilyName?.ToUpper() ?? "";
            var givenNameUpper = user.GivenName?.ToUpper() ?? "";

            var transliterationResults = GetTransliterationResults(familyNameUpper, givenNameUpper);

            return GetNameRegex(userNamesObj, transliterationResults);
        }

        private static CBORObject GetNameRegex(CBORObject userNamesObj, List<string> transliterationResults)
        {
            var fnt = transliterationResults[0].Replace("-", "<").Replace(" ", "<").Replace("'", "<");
            var gnt = transliterationResults[1].Replace("-", "<").Replace(" ", "<").Replace("'", "<");

            var regex = new Regex(@"^[A-Z<]*$");
            if (regex.IsMatch(fnt) && regex.IsMatch(gnt))
            {
                userNamesObj.Add("fnt", fnt);
                userNamesObj.Add("gnt", gnt);
            }
            else
            {
                userNamesObj.Add("fnt", transliterationResults[0]);
                userNamesObj.Add("gnt", transliterationResults[1]);
            }
            return userNamesObj;
        }

        public static List<string> GetTransliterationResults(string familyNameUpper, string givenNameUpper)
        {
            var transliterationList = TransliterationModelList.TransliterationList();
            var replaceArray = familyNameUpper.ToArray();
            var result = new List<string>();

            for (var j = 0; j < 2; j++) //We are running through this once for the familyname and once for the givenname
            {
                for (var i = 0; i < replaceArray.Length; i++)
                {
                    var unicodeCheck = $"{(int)replaceArray[i]:x4}";
                    if (!transliterationList.Any(x =>
                        x.Unicode.Contains(unicodeCheck, StringComparison.OrdinalIgnoreCase))) continue;
                    {
                        var transliterationSelect = transliterationList.Where(x => x.Unicode.Contains(unicodeCheck, StringComparison.OrdinalIgnoreCase))
                            .Select(m => m.RecommendedTransliteration);
                        var toCharArray = transliterationSelect.First().ToCharArray();
                        replaceArray[i] = toCharArray[0];
                    }
                }
                result.Add(new string(replaceArray));
                replaceArray = givenNameUpper.ToArray();
            }

            return result;
        }

        private static CBORObject GetByParsingFullName(IUserCBORInformation user)
        {
            var userNamesObj = CBORObject.NewMap();
            var fullName = user.Name.Split(' ');

            var firstAndMiddleNames = string.Join(' ', fullName.Take(fullName.Length - 1));
            var lastName = fullName.Last();
            var transliterationResults = GetTransliterationResults(lastName.ToUpper(), firstAndMiddleNames.ToUpper());

            userNamesObj.Add("fn", lastName.ToLower());
            userNamesObj.Add("gn", firstAndMiddleNames.ToLower());

            return GetNameRegex(userNamesObj, transliterationResults);
        }
    }
}
