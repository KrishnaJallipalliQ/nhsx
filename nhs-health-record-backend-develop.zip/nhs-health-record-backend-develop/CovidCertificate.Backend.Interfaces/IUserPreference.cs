﻿using CovidCertificate.Backend.Models.ResponseDtos;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IUserPreference
    {
        public Task UpdateTermsAndConditions(string id);
        public Task updateLanguageCodeAsync(string id, string lang);
        public Task<UserPreferenceResponse> getPreferences(string id);
    }
}
