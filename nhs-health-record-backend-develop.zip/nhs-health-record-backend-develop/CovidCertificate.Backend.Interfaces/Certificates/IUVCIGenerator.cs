﻿using CovidCertificate.Backend.Models.Enums;
using System.Threading.Tasks;
using CovidCertificate.Backend.Models.Commands.UvciGeneratorCommands;
using CovidCertificate.Backend.Models.DataModels;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IUvciGenerator
    {
        Task<bool> UvciExistsForUser(CovidPassportUser user, CertificateScenario scenario);

        Task<string> TryGenerateAndInsertUvci(GenerateAndInsertUvciCommand command);
    }
}