﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Interfaces.UserInterfaces;
using PeterO.Cbor;
using System;
using System.Collections.Generic;


namespace CovidCertificate.Backend.International.Interfaces
{
    public interface ICondensorService
    {
        CBORObject CondenseCBOR<T>(IUserCBORInformation user, long certifiateGenerationTime, IEnumerable<T> results, string uniqueCertificateIdentifier, DateTime? validityEndDate, int resultIndex, string barcodeIssuerCountry = null);
    }
}
