﻿using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Security.Authentication;
using CovidCertificate.Backend.Models.DataModels;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Reflection;

namespace CovidCertificate.Backend.ThirdPartyDisplayNameConsoleApp
{
    public class DisplayNameConsoleApp
    {
        public static int Main(string[] args)
        {
            if (args.Length != 3)
            {
                Console.WriteLine("Please enter parameters: <thirdPartyId> <mobileAppDisplayName> <env>");
                return 1;
            }
            string thirdPartyId = args[0];

            if (Guid.TryParse(thirdPartyId, out _))
            {
                Console.WriteLine("ThirdPartyId format correct:" + thirdPartyId);
            }
            else
            {
                Console.WriteLine("ThirdPartyId seems to be in incorrect format, please try again..");
                Console.WriteLine("Correct format is 36 characters long, example: 2af3478a-27da-4837-a387-b22b3fb236a7");
                return 1;
            }

            string thirdPartyName = args[1];

            if (!string.IsNullOrEmpty(thirdPartyName))
            {
                Console.WriteLine("ThirdPartyName format correct:" + thirdPartyName);
            }
            else
            {
                Console.WriteLine("ThirdPartyName seems to be in incorrect format, please try again..");
                Console.WriteLine("Correct format example: BritishAirways");
                return 1;
            }

            string environment = args[2];

            if (!string.IsNullOrEmpty(environment))
            {
                Console.WriteLine("env format correct:" + environment);
            }
            else
            {
                Console.WriteLine("env seems to be in incorrect format, please try again..");
                Console.WriteLine("Correct format example: dev");
                return 1;
            }
            
            var path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "..", "..", ".." ,"Settings");

            var config = new ConfigurationBuilder()
                .SetBasePath(path)
                .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
                .Build();

            // connectionString secret needs to be changed to what is on HALO Azure key vault
            string secretValueKey = $"{environment}ConnectionString";
            string keyVaultUri = config["keyVaultUri"];
            string databaseName = config["databaseName"];
            string collectionName = config["collectionName"];

            try
            {
                SecretClient client = new SecretClient(vaultUri: new Uri(keyVaultUri), credential: new DefaultAzureCredential());
                KeyVaultSecret secret = client.GetSecret(secretValueKey);
                //In local environment change secret.Value to connection string for emulator
                MongoCRUD db = new MongoCRUD(databaseName, secret.Value);
                db.InsertRecord(collectionName, new ThirdParty (thirdPartyId, thirdPartyName));
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            return 0;
        }
    }

    public class MongoCRUD
    {
        private IMongoDatabase db;

        public MongoCRUD(string database, string connectionString)
        {
            MongoClientSettings settings = MongoClientSettings.FromUrl(
                new MongoUrl(connectionString)
            );
            settings.SslSettings =
                new SslSettings() { EnabledSslProtocols = SslProtocols.Tls12 };

            MongoClient mongoClient = new MongoClient(settings);
            db = mongoClient.GetDatabase(database);
        }

        public void InsertRecord<T>(string table, T record)
        {
            try
            {
                IMongoCollection<T> collection = db.GetCollection<T>(table);
                collection.InsertOne(record);
                Console.WriteLine("Added:" + record.ToJson().ToString());
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}
