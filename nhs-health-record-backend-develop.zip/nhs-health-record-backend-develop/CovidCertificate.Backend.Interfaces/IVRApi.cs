﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IVRApi
    {
        Task<HttpResponseMessage> GetFHIRVaccines(string idToken);
    }
}
