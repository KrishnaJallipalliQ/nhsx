﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SendGrid.Helpers.Errors.Model;
using System;
using System.Collections.Generic;
using System.Net.Http;

namespace CovidCertificate.Backend.Auth.Tests.TestHelpers
{
    public static class DataInjector
    {
        /// <summary>
        /// Gets the <see cref="Exception"/> scenarios that should return an <see cref="ObjectResult"/> for an endpoint.
        /// </summary>
        public static IEnumerable<object[]> GetObjectResultExceptionScenarios()
        {
            var errorMessage = $"MyErrorMessage";

            return new List<object[]>
            {
                new object[] { new BadRequestException(errorMessage), LogLevel.Warning, new BadRequestObjectResult("There seems to be a problem: bad request") },
                new object[] { new ArgumentNullException(errorMessage), LogLevel.Warning, new BadRequestObjectResult("There seems to be a problem: bad request")  },
                new object[] { new UnauthorizedException(errorMessage), LogLevel.Warning, new UnauthorizedObjectResult("There seems to be a problem: unauthorized")  }
            };
        }

        /// <summary>
        /// Gets the <see cref="Exception"/> scenarios that should return a <see cref="StatusCodeResult"/> for an endpoint.
        /// </summary>
        public static IEnumerable<object[]> GetStatusCodeResultExceptionScenarios()
        {
            return new List<object[]>
            {
                new object[] { new HttpRequestException(), LogLevel.Critical, StatusCodes.Status500InternalServerError },
                new object[] { new Exception(), LogLevel.Error, StatusCodes.Status500InternalServerError }
            };
        }
    }
}
