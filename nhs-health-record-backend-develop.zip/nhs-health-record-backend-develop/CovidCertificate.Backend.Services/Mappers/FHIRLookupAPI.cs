﻿using System;
using System.Linq;
using System.Net.Http;
using System.Runtime.Caching;
using System.Threading.Tasks;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Utils;
using Hl7.Fhir.Model;
using Hl7.Fhir.Rest;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Polly;

namespace CovidCertificate.Backend.Services.Mappers
{
    public class FhirLookupApi : IFhirLookupApi
    {
        private readonly FhirClient _fhirClient;
        private readonly IConfiguration _configuration;
        private int _retryCount;
        private int _retryDelay;
        private int _timeout;
        private readonly MemoryCache _cache = MemoryCache.Default;
        private ILogger<FhirLookupApi> _logger;

        public FhirLookupApi(IConfiguration configuration, ILogger<FhirLookupApi> logger)
        {
            _logger = logger;
            _configuration = configuration;
            //The FhirLookupApi class is added as a singleton to avoid issues with socket starvation
            _fhirClient = new FhirClient(configuration["FHIRLookUpServiceRootUrl"]);
        }

        public async Task<string> ConvertOdsCodeToName(string odsCode)
        {
            if (string.IsNullOrEmpty(odsCode)) return null;

            var key = $"ConvertOdsCodeToName:{odsCode}";

            if (_cache.Contains(key))
            {
                return _cache.Get(key) as string;
            }

            var retryPolicy = HttpRetryPolicyUtils.CreateRetryPolicy(_configuration.GetValue<int>("FhirLookupRetryCount"), _configuration.GetValue<int>("FhirLookupRetryDelaySeconds"), _configuration.GetValue<int>("FhirLookupTimeout"), "Failed to lookup FHIR organisation codes.", _logger);
            var bundle = new Bundle();
            await retryPolicy.ExecuteAsync(async () => {
                bundle = await _fhirClient.SearchByIdAsync("Organization", odsCode);
            });
            var organization = bundle.Entry.FirstOrDefault()?.Resource as Organization;
            var name = organization?.Name;

            if (!_cache.Contains(key) && !string.IsNullOrEmpty(name))
                _cache.Add(key, name, DateTimeOffset.UtcNow.AddHours(1));

            return name;
        }
    }
}
