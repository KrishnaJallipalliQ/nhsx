﻿namespace CovidCertificate.Backend.Models.Interfaces
{
    public interface IUserContactInformation : IValidator
    {
        string EmailAddress { get; }
        string PhoneNumber { get; }
    }
}