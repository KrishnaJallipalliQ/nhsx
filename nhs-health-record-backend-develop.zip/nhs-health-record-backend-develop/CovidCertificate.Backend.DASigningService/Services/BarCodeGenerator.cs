﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CovidCertificate.Backend.DASigningService.ErrorHandling;
using CovidCertificate.Backend.DASigningService.Interfaces;
using CovidCertificate.Backend.DASigningService.Models;
using CovidCertificate.Backend.DASigningService.Responses;
using CovidCertificate.Backend.DASigningService.Validators;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.International.Interfaces;
using CovidCertificate.Backend.Models.Commands.UvciGeneratorCommands;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Services.Mappers;
using CovidCertificate.Backend.Utils;
using FluentValidation.Results;
using Hl7.Fhir.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Task = System.Threading.Tasks.Task;

namespace CovidCertificate.Backend.DASigningService.Services
{
    public class BarcodeGenerator : IBarcodeGenerator
    {
        private readonly VaccinationMapper vaccinationMapper;
        private readonly IUvciGenerator uvciGenerator;
        private readonly IEncoderService encoder;
        private readonly ILogger<BarcodeGenerator> logger;
        private readonly IConfiguration configuration;

        private static readonly FhirPatientValidator fhirPatientValidator = new FhirPatientValidator();
        private static readonly FhirImmunizationValidator fhirImmunizationValidator = new FhirImmunizationValidator();
        private static readonly FhirLocationValidator fhirLocationValidator = new FhirLocationValidator();

        public BarcodeGenerator(
            IUvciGenerator uvciGenerator,
            VaccinationMapper vaccinationMapper,
            IEncoderService encoder,
            ILogger<BarcodeGenerator> logger,
            IConfiguration configuration)
        {
            this.uvciGenerator = uvciGenerator;
            this.vaccinationMapper = vaccinationMapper;
            this.encoder = encoder;
            this.logger = logger;
            this.configuration = configuration;
        }

        public async Task<BarcodeResults> BarcodesFromFhirBundle(Bundle bundle, RegionConfig regionConfig)
        {
            logger.LogInformation("Obtaing and validating patient from FHIR bundle.");

            Patient patient = GetPatient(bundle);
            var patientValidationResult = fhirPatientValidator.Validate(patient);

            var immunizations = GetImmunizations(bundle);

            // If patient is not valid, return response with errors
            if (!patientValidationResult.IsValid)
            {
                logger.LogWarning($"Patient is not valid. PatientValidationResult: '{patientValidationResult}'.");

                return GenerateBarcodeResultsWithErrors(immunizations, patientValidationResult);
            }

            logger.LogInformation("DAUser from Patient.");

            DAUser user = vaccinationMapper.DAUserFromPatient(patient);

            var validityEndDate =
                DateTime.UtcNow.AddHours(configuration.GetValue<int>("ValidityTimeForVaccinationBarcodeFromNowInHours"));

            logger.LogInformation("Generation of UVCI for Regional.");

            var uvci = await uvciGenerator.TryGenerateAndInsertUvci(new RegionalGenerateAndInsertUvciCommand(
                regionConfig.Issuer,
                regionConfig.MemberState,
                StringUtils.GetValueHash(user.Name, user.DateOfBirth),
                CertificateType.Vaccination,
                CertificateScenario.International,
                validityEndDate));

            if (!immunizations.Any())
            {
                var immunizationValidationResult = fhirImmunizationValidator.Validate(new Immunization());

                logger.LogWarning($"No Immunizations found");

                return GenerateBarcodeResultsForNullImmunization(immunizationValidationResult);
            }
            
            var immunizationLocationPairs = GetImmunizationLocationPairs(bundle, immunizations);

            var tasks = CreateListOfTasksForBarcodeResultGeneration(regionConfig, immunizationLocationPairs, user, uvci, validityEndDate);

            var barcodeResults = (await Task.WhenAll(tasks)).ToList();

            var result = new BarcodeResults
            {
                Barcodes = barcodeResults,
                UVCI = uvci
            };

            return result;
        }

        private List<Task<BarcodeResult>> CreateListOfTasksForBarcodeResultGeneration(RegionConfig regionConfig,
            Dictionary<Immunization, Location> immunizationLocationPairs, DAUser user, string uvci, DateTime validityEndDate)
        {
            var dateTimeOffset = DateTimeOffset.Now.ToUnixTimeSeconds();

            var tasks = new List<Task<BarcodeResult>>();

            foreach (var immunizationLocationPair in immunizationLocationPairs)
            {
                var command = new GenerateBarcodeResultFromFhirCommand(
                    immunizationLocationPair.Key,
                    user,
                    regionConfig.Issuer,
                    regionConfig.MemberState,
                    "GB", // As UK is signing the barcode, "GB" should be set in "1" field as issuer
                    dateTimeOffset,
                    uvci,
                    validityEndDate);

                if (immunizationLocationPair.Value == null)
                {
                    tasks.Add(GenerateBarcodeResultFromFhir(command));

                    continue;
                }

                var locationValidationResult = fhirLocationValidator.Validate(immunizationLocationPair.Value);

                if (locationValidationResult.IsValid)
                {
                    command.CountryOfVaccination = immunizationLocationPair.Value.Address.Country;

                    tasks.Add(GenerateBarcodeResultFromFhir(command));

                    continue;
                }

                tasks.Add(Task.FromResult(GenerateBarcodeResultForNotValidLocation(immunizationLocationPair.Key,
                    locationValidationResult)));
            }

            return tasks;
        }

        private static Dictionary<Immunization, Location> GetImmunizationLocationPairs(Bundle bundle, List<Immunization> immunizations)
        {
            var immunizationLocationPairs = new Dictionary<Immunization, Location>();

            foreach (var immunization in immunizations)
            {
                var potentialLocation =
                    bundle.Entry.FirstOrDefault(x => x.FullUrl == immunization.Location?.Reference)?.Resource;

                immunizationLocationPairs.Add(immunization, potentialLocation as Location);
            }

            return immunizationLocationPairs;
        }

        private BarcodeResults GenerateBarcodeResultsWithErrors(List<Immunization> immunizations, ValidationResult patientValidationResult)
        {
            var validationError = patientValidationResult.Errors.FirstOrDefault();

            var barcodeResults = new List<BarcodeResult>(immunizations.Count);

            foreach (var immunization in immunizations)
            {
                var barCodeResult = new BarcodeResult
                {
                    Id = immunization.Id,
                    CanProvide = false,
                    CertificateType = "v",
                    Error = new Error
                    {
                        Message = validationError?.ErrorMessage,
                        Code = validationError?.ErrorCode
                    }
                };

                barcodeResults.Add(barCodeResult);
            }

            var result = new BarcodeResults
            {
                Barcodes = barcodeResults
            };

            return result;
        }

        private BarcodeResult GenerateBarcodeResultForNotValidLocation(Immunization immunization,
            ValidationResult locationValidationResult)
        {
            var validationError = locationValidationResult.Errors.FirstOrDefault();

            var barCodeResult = new BarcodeResult
            {
                Id = immunization.Id,
                CanProvide = false,
                CertificateType = "v",
                Error = new Error
                {
                    Message = validationError?.ErrorMessage,
                    Code = validationError?.ErrorCode
                }
            };

            return barCodeResult;
        }

        private BarcodeResults GenerateBarcodeResultsForNullImmunization(ValidationResult immunizationValidationResult)
        {
            var barcodeResults = new List<BarcodeResult>(1);

            var validationError = immunizationValidationResult.Errors.FirstOrDefault();

            var barCodeResult = new BarcodeResult
            {
                Id = null,
                CanProvide = false,
                CertificateType = "v",
                Error = new Error
                {
                    Message = validationError?.ErrorMessage,
                    Code = validationError?.ErrorCode
                }
            };

            barcodeResults.Add(barCodeResult);

            var result = new BarcodeResults
            {
                Barcodes = barcodeResults
            };

            return result;
        }

        private async Task<BarcodeResult> GenerateBarcodeResultFromFhir(GenerateBarcodeResultFromFhirCommand command)
        {
            var barcodeResult = new BarcodeResult
            {
                Id = command.Immunization.Id,
                CanProvide = false,
                CertificateType = "v"
            };

            var immunizationValidationResult = fhirImmunizationValidator.Validate(command.Immunization);

            if (!immunizationValidationResult.IsValid)
            {
                logger.LogWarning($"Immunization not valid. Validation error: '{immunizationValidationResult.Errors}'.");

                var validationError = immunizationValidationResult.Errors.FirstOrDefault();

                barcodeResult.Error = new Error
                {
                    Code = validationError?.ErrorCode,
                    Message = validationError?.ErrorMessage
                };

                return barcodeResult;
            }

            try
            {
                List<Vaccine> vaccines = new List<Vaccine>
                {
                    await vaccinationMapper.MapFhirToVaccine(command.Immunization, command.Issuer, command.CountryOfVaccination)
                };

                barcodeResult.Barcode = await encoder.EncodeFlowAsync(
                    command.User,
                    command.DateTimeOffset,
                    vaccines,
                    command.Uvci,
                    command.ValidityEndDate,
                    0,
                    command.BarcodeIssuerCountry);
                barcodeResult.CanProvide = true;
            }
            catch (Exception e)
            {
                logger.LogError(e, $"Unexpected error. Exception message: '{e.Message}'.");

                barcodeResult.Error = new Error
                {
                    Code = ErrorCode.UNEXPECTED_SYSTEM_ERROR.ToString(StringUtils.NumberFormattedEnumFormat),
                    Message = "Barcode generation failed."
                };
            }

            return barcodeResult;
        }

        private List<Immunization> GetImmunizations(Bundle bundle)
        {
            var immunizations = new List<Immunization>();

            foreach (var entry in bundle.Entry)
            {
                if (entry?.Resource is Immunization immunization)
                {
                    immunizations.Add(immunization);
                }
            }

            return immunizations;
        }

        private Patient GetPatient(Bundle bundle)
        {
            foreach (var entry in bundle.Entry)
            {
                if (entry?.Resource is Patient patient)
                {
                    return patient;
                }
            }

            return null;
        }

        public class GenerateBarcodeResultFromFhirCommand
        {
            public Immunization Immunization { get; }
            public DAUser User { get; }
            public string Issuer { get; }
            public string BarcodeIssuerCountry { get; }
            public string CountryOfVaccination { get; set; }
            public long DateTimeOffset { get; }
            public string Uvci { get; }
            public DateTime ValidityEndDate { get; }

            public GenerateBarcodeResultFromFhirCommand(
                Immunization immunization,
                DAUser user,
                string issuer,
                string countryOfVaccination,
                string barcodeIssuerCountry,
                long dateTimeOffset,
                string uvci,
                DateTime validityEndDate)
            {
                this.Immunization = immunization;
                this.User = user;
                this.Issuer = issuer;
                this.CountryOfVaccination = countryOfVaccination;
                this.BarcodeIssuerCountry = barcodeIssuerCountry;
                this.DateTimeOffset = dateTimeOffset;
                this.Uvci = uvci;
                this.ValidityEndDate = validityEndDate;
            }
        }
    }
}
