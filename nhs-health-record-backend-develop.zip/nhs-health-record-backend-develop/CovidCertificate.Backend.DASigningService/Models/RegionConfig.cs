﻿namespace CovidCertificate.Backend.DASigningService.Models
{
    public class RegionConfig
    {
        public string RegionCode { get; set; }
        public string Issuer { get; set; }
        public string MemberState { get; set; }
        public string CountryCode { get; set; }
    }
}
