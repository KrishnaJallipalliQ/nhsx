﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Tests.TestHelpers;
using System;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.ResponseDtos;
using Microsoft.Extensions.Configuration;
using Moq;
using Xunit;

namespace CovidCertificate.Backend.Tests.ModelTest
{
    public class TestResultResponseTests
    {
        private readonly Mock<IConfiguration> mockConfig;
        private readonly Mock<IGetTimeZones> mockGetTimeZones;

        public TestResultResponseTests()
        {
            mockConfig = new Mock<IConfiguration>();
            mockConfig.SetupGet<string>(m => m["TimeZoneWindows"]).Returns("GMT Standard Time");
            mockConfig.SetupGet<string>(m => m["TimeZoneLinux"]).Returns("Europe/London");
            mockGetTimeZones = new Mock<IGetTimeZones>();
            mockGetTimeZones.Setup(x => x.GetTimeZoneInfo()).Returns(TimeZoneInfo.Local);
        }
        [Fact]
        public void TestResultNhsResponse_InstantiateTestResultResponse()
        {
            // Arrange
            var testResult = new TestResultNhs(DateTime.Today, "Positive", "LFT", "kit", "LFTSelfTest", null, null, null);

            // Act
            var testResultResponse = new TestResultResponse(testResult, mockGetTimeZones.Object);

            // Assert
            Assert.NotNull(testResultResponse);
        }

        [Fact]
        public void TestResultNhsResponse_GetHashCode()
        {
            // Arrange
            var testResultOne = new TestResultNhs(DateTime.Today, "Positive", "LFT", "kit", "LFTSelfTest", null, null, null);
            var testResultTwo = new TestResultNhs(DateTime.Today, "Positive", "LFT", "kit", "LFTSelfTest", null, null, null);
            var testResultResponseOne = new TestResultResponse(testResultOne, mockGetTimeZones.Object);
            var testResultResponseTwo = new TestResultResponse(testResultTwo, mockGetTimeZones.Object);

            // Act
            var testResultResponseOneHashCodeOne = testResultResponseOne.GetHashCode();
            var testResultResponseOneHashCodeTwo = testResultResponseOne.GetHashCode();
            var testResultResponseTwoHashCode = testResultResponseTwo.GetHashCode();

            // Assert
            Assert.Equal(testResultResponseOneHashCodeOne, testResultResponseOneHashCodeTwo);
            Assert.NotEqual(testResultResponseOneHashCodeOne, testResultResponseTwoHashCode);
        }

        [Fact]
        public void TestResultNhsResponse_Equals_ShouldReturnFalse()
        {
            // Arrange
            var testResultOne = new TestResultNhs(DateTime.Today, "Positive", "LFT", "kit", "LFTSelfTest", null, null, null);
            var testResultTwo = new TestResultNhs(DateTime.Today, "Positive", "LFT", "kit", "LFTSelfTest", null, null, null);
            var testResultResponseOne = new TestResultResponse(testResultOne, mockGetTimeZones.Object);
            var testResultResponseTwo = new TestResultResponse(testResultTwo, mockGetTimeZones.Object);
            var obj = new object();

            // Act & Assert
            Assert.False(testResultResponseOne.Equals(testResultResponseTwo));
            Assert.False(testResultResponseOne.Equals(obj));
        }
    }
}
