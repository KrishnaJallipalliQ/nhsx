﻿using System.Linq;
using CovidCertificate.Backend.DASigningService.ErrorHandling;
using CovidCertificate.Backend.Tests.TestHelpers;
using CovidCertificate.Backend.Utils;
using FluentValidation;
using FluentValidation.Results;
using Hl7.Fhir.Model;
using Xunit;

namespace CovidCertificate.Backend.DASigningService.Validators.Tests
{
    public class FhirImmunizationValidatorTest
    {
        private Immunization immunization;
        private FhirImmunizationValidator validator;

        public FhirImmunizationValidatorTest()
        {
            immunization = VaccinationMapperHelper.CreateImmunization(0, 0);
            validator = new FhirImmunizationValidator();
        }

        [Fact]
        public void Validate_ValidImmunization_ReturnNoErrors()
        {
            //Arrange

            //Act
            var result = validator.Validate(immunization);

            //Assert
            Assert.Empty(result.Errors);
        }

        [Fact]
        public void Pre_Validate_ImmunizationIdIsNull_ReturnImmunizationMissingError()
        {
            //Arrange
            immunization.Id = null;

            //Act
            var result = validator.Validate(immunization);

            //Assert
            Assert.Equal(ErrorCode.FHIR_IMMUNIZATION_MISSING.GetHashCode().ToString(), result.Errors.First().ErrorCode);
            Assert.Equal("Immunization Missing.", result.Errors[0].ErrorMessage);
        }
        [Fact]
        public void Validate_VaccineCodeIsNull_ReturnVaccineCodeMissingError()
        {
            //Arrange
            immunization.VaccineCode = null;

            //Act
            var result = validator.Validate(immunization);

            //Assert
            Assert.Equal(ErrorCode.FHIR_IMMUNIZATION_VACCINECODE_MISSING.GetHashCode().ToString(), result.Errors.First().ErrorCode);
            Assert.Equal("Immunization.VaccineCode missing.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void Validate_VaccineCodeCodingEmpty_ReturnVaccineCodeMissingError()
        {
            //Arrange
            immunization.VaccineCode.Coding.Clear();

            //Act
            var result = validator.Validate(immunization);

            //Assert
            Assert.Equal(result.Errors.First().ErrorCode, ErrorCode.FHIR_IMMUNIZATION_VACCINECODE_MISSING.GetHashCode().ToString());
            Assert.Equal("Immunization.VaccineCode.Coding missing or empty.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void Validate_VaccineCodeCodingMissing_ReturnVaccineCodeCodeMissingError()
        {
            //Arrange
            immunization.VaccineCode.Coding = null;

            //Act
            var result = validator.Validate(immunization);

            //Assert
            Assert.Equal(result.Errors.First().ErrorCode, ErrorCode.FHIR_IMMUNIZATION_VACCINECODE_MISSING.GetHashCode().ToString());
            Assert.Equal("Immunization.VaccineCode.Coding missing or empty.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void Validate_VaccineCodeCodingPresent_FirstCodingPresent_FirstCodingCodeMissing_ReturnVaccineCodeCodeMissingError()
        {
            //Arrange
            immunization.VaccineCode.Coding.First().Code = null;

            //Act
            var result = validator.Validate(immunization);

            //Assert
            Assert.Equal(result.Errors.First().ErrorCode, ErrorCode.FHIR_IMMUNIZATION_VACCINECODE_CODE_MISSING.GetHashCode().ToString());
            Assert.Equal("Immunization.VaccineCode.Coding[0].Code missing.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void Validate_OccuranceMissing_ReturnOccuranceMissingError()
        {
            //Arrange
            immunization.Occurrence = null;

            //Act
            var result = validator.Validate(immunization);

            //Assert
            Assert.Equal(result.Errors.First().ErrorCode, ErrorCode.FHIR_IMMUNIZATION_OCCURENCEDATETIME_MISSING.GetHashCode().ToString());
            Assert.Equal("Immunization.Occurence missing.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void Validate_LotNumberMissing_ReturnLotNumberMissingError()
        {
            //Arrange
            immunization.LotNumber = null;

            //Act
            var result = validator.Validate(immunization);

            //Assert
            Assert.Equal(result.Errors.First().ErrorCode, ErrorCode.FHIR_IMMUNIZATION_LOTNUMBER_MISSING.GetHashCode().ToString());
            Assert.Equal("Immunization.LotNumber missing.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void Validate_ProtocolAppliedMissing_ReturnProtocolAppliedDoseNumberMissing()
        {
            //Arrange
            immunization.ProtocolApplied = null;

            //Act
            var result = validator.Validate(immunization);

            //Assert
            Assert.Equal(result.Errors.First().ErrorCode, ErrorCode.FHIR_IMMUNIZATION_PROTOCOLAPPLIED_DOSENUMBER_MISSING.GetHashCode().ToString());
            Assert.Equal("Immunization.ProtocolApplied missing or empty.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void Validate_ProtocolAppliedPresent_ProtocolAppliedFirstMissing_ReturnProtocolAppliedDoseNumberMissing()
        {
            //Arrange
            immunization.ProtocolApplied[0] = null;

            //Act
            var result = validator.Validate(immunization);

            //Assert
            Assert.Equal(result.Errors.First().ErrorCode, ErrorCode.FHIR_IMMUNIZATION_PROTOCOLAPPLIED_DOSENUMBER_MISSING.GetHashCode().ToString());
            Assert.Equal("Immunization.ProtocolApplied[0] missing or empty.", result.Errors[0].ErrorMessage);
        }

        [Fact]
        public void Validate_ProtocolAppliedPresent_ProtocolAppliedFirstPresent_ProtocolAppliedFirstDoseNumberMissing_ReturnProtocolAppliedDoseNumberMissing() 
        {
            //Arrange
            immunization.ProtocolApplied[0].DoseNumber = null;

            //Act
            var result = validator.Validate(immunization);

            //Assert
            Assert.Equal(result.Errors.First().ErrorCode, ErrorCode.FHIR_IMMUNIZATION_PROTOCOLAPPLIED_DOSENUMBER_MISSING.GetHashCode().ToString());
            Assert.Equal("Immunization.ProtocolApplied[0].DoseNumber missing or empty.", result.Errors[0].ErrorMessage);
        }
    }
}
