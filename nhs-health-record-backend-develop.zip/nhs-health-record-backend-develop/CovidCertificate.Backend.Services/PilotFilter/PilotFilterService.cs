﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Models.Settings;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services.PilotFilter
{
    public class PilotFilterService : IPilotFilterService
    {
        private readonly ILogger<PilotFilterService> logger;
        private readonly IMongoRepository<PilotUser> mongoRepository;

        public PilotFilterService(
            ILogger<PilotFilterService> logger,
            IMongoRepository<PilotUser> mongoRepository)
        {
            this.logger = logger;
            this.mongoRepository = mongoRepository;
        }

        public async Task<bool> IsPilotUser(PilotUser pilotUser)
        {
            logger.LogInformation("IsPilotUser was invoked");

            Expression<Func<PilotUser, bool>> isPilotUserExpr = getExpression(pilotUser);
            if(isPilotUserExpr == null)
            {
                throw new Exception("User lacks identifiable data");
            }
            var results = await mongoRepository.FindOneAsync(isPilotUserExpr);

            logger.LogInformation("IsPilotUser has finished");

            if (results == null)
                return false;
            return true;
        }
        private Expression<Func<PilotUser,bool>> getExpression(PilotUser user)
        {
            logger.LogInformation("getExpression was invoked");

            if (!string.IsNullOrWhiteSpace(user.UserHash))
            {
                logger.LogInformation("getExpression has finished");
                return p => p.UserHash == user.UserHash;
            }

            logger.LogInformation("getExpression has finished");
            return null;
        }

        public async Task AddPilotUser(PilotUser pilotUser)
        {
            await mongoRepository.InsertOneAsync(pilotUser);
        }

        public async Task<bool> RemovePilotUser(PilotUser pilotUser)
        {
            Expression<Func<PilotUser, bool>> isPilotUserExpr = getExpression(pilotUser);
            if (isPilotUserExpr == null)
            {
                throw new Exception("User lacks identifiable data");
            }
            var result = await mongoRepository.DeleteOneAsync(isPilotUserExpr);
            return result != default;
        }
    }
}
