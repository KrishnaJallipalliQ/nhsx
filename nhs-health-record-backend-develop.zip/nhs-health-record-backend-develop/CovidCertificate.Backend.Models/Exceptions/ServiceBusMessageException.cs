﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.Exceptions
{
    public class ServiceBusMessageException : Exception
    {
        public ServiceBusMessageException(string message) : base(message)
        {
        }
    }
}
