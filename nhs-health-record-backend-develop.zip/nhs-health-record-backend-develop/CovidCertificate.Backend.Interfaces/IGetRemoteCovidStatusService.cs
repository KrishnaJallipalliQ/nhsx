﻿namespace CovidCertificate.Backend.Interfaces
{
    public interface IGetRemoteCovidStatusService
    {

    }
}
