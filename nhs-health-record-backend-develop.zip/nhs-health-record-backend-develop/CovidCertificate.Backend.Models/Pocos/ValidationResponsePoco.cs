﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Text;

namespace CovidCertificate.Backend.Models.Pocos
{
    public class ValidationResponsePoco
    {
        public ValidationResponsePoco(string invalidMessage)
        {
            Response = new UnauthorizedObjectResult(invalidMessage);
            IsValid = false;
        }

        public ValidationResponsePoco(bool isForbidden)
        {
            Response = new ObjectResult("P5 Users are forbidden to use this service.") { StatusCode = 403 };
            IsValid = true;
            IsForbidden = isForbidden;
        }

        public ValidationResponsePoco(ClaimsPrincipal claims)
        {
            if (claims == default)
            {
                Response = new UnauthorizedObjectResult("Invalid Claims in token");
                IsValid = false;
                return;
            }

            TokenClaims = claims;
            IsValid = true;
        }

        public IActionResult Response { get; set; }

        public ClaimsPrincipal TokenClaims { get; set; }

        public bool IsValid { get; set; }

        public bool IsForbidden { get; set; }
    }
}
