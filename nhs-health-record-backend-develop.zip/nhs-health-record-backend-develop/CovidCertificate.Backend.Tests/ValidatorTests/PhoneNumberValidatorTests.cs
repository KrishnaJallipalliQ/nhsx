﻿using System.Threading.Tasks;
using CovidCertificate.Backend.Models.Validators;
using Xunit;

namespace CovidCertificate.Backend.Tests.ValidatorTests
{
    public class PhoneNumberValidatorTests
    {
        private readonly PhoneNumberValidator validator;
        public PhoneNumberValidatorTests()
        {
            validator = new PhoneNumberValidator();
        }

        //Arrange
        [Theory()]
        [InlineData("07707123456")]
        [InlineData("+447707123456")]
        public async Task Validate_WithProperPhoneNumbers_ShouldBeSuccesful(string phoneNumber)
        {
            //Act
            var result = await validator.ValidateAsync(phoneNumber);

            //Assert
            Assert.NotNull(result);
            Assert.True(result.IsValid);
            Assert.Equal(0, result.Errors.Count);
        }

        //Arrange
        [Theory()]
        [InlineData("abc")]
        [InlineData("+() -")]
        [InlineData("")]
        [InlineData("700=400+300*1")]
        [InlineData("5552465+80")]
        [InlineData("123456")]
        public async Task Validate_WithIncorrectPhoneNumbers_ShouldFail(string phoneNumber)
        {            
            //Act
            var result = await validator.ValidateAsync(phoneNumber);

            //Assert
            Assert.NotNull(result);
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Count > 0);
        }
    }
}