using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using CovidCertificate.Backend.Configuration.Bases.BaseFunctions;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Interfaces.Delegates;
using Microsoft.Extensions.Configuration;
using SendGrid.Helpers.Errors.Model;
using CovidCertificate.Backend.Utils.Extensions;
using CovidCertificate.Backend.Models.ResponseDtos;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.Enums;

namespace CovidCertificate.Backend
{
    public class GetCertificateFunction : BaseSecureFunction
    {
        private readonly ICovidCertificateCreator covidCertificateCreator;

        public GetCertificateFunction(ICovidCertificateCreator covidCertificateCreator,
            JwtValidatorResolver jwtValidator, IConfiguration configuration,
            ILogger<GetCertificateFunction> logger) : base(jwtValidator, configuration, logger)
        {
            this.covidCertificateCreator = covidCertificateCreator;
        }

        [FunctionName("GetCertificate")]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "get", Route = "GetCertificate")] HttpRequest req)
        {
            try
            {
                logger.LogInformation("GetCertificate (endpoint) was invoked");
                var validationResult = await base.AuthoriseEndpoint(req);
                logger.LogTraceAndDebug($"validationResult: IsValid {validationResult?.IsValid}, Response is {validationResult?.Response}, TokenClaims are {validationResult?.TokenClaims}");
                if (base.responseInvalid(validationResult))
                {
                    logger.LogInformation("GetCertificate (endpoint) has finished");
                    return validationResult.Response;
                }

                var covidUser = new CovidPassportUser(validationResult.TokenClaims);
                logger.LogTraceAndDebug($"covidUser: {covidUser}");
                logger.LogInformation($"covidUser: {covidUser?.ToNhsNumberAndDobHashKey()}");

                var certificate = await covidCertificateCreator.GetDomesticCertificate(covidUser, base.GetIdToken(req, true));
                var expiredCertificateExists = await covidCertificateCreator.ExpiredCertificateExists(covidUser, certificate);
                
                logger.LogTraceAndDebug($"certificate: {certificate}");

                var certificateResponse = new DomesticCertificateResponse(certificate, expiredCertificateExists);

                logger.LogInformation("GetCertificate (endpoint) has finished");
                return new OkObjectResult(certificateResponse);
            }
            catch (Exception e) when (e is BadRequestException || e is ArgumentException)
            {
                logger.LogError(e, e.Message);
                return new BadRequestObjectResult("There seems to be a problem: bad request");
            }
            catch (UnauthorizedException e)
            {
                logger.LogWarning(e, e.Message);
                return new UnauthorizedObjectResult("There seems to be a problem: unauthorized");
            }
            catch (Exception e)
            {
                logger.LogError(e, e.Message);
                var result = new ObjectResult(e.Message);
                result.StatusCode = 500;
                return result;
            }
        }
    }
}
