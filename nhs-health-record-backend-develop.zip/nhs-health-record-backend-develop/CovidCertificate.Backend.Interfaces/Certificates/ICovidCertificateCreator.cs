﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Models.RequestDtos;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces.Certificates
{
    public interface ICovidCertificateCreator
    {
        /// <summary>
        /// Creates a certificate for a user if they have valid tests or vaccines
        /// </summary>
        /// <param name="user"></param>
        /// <param name="idToken"></param>
        /// <returns></returns>
        Task<Certificate> GetDomesticCertificate(CovidPassportUser user, string idToken);

        /// <summary>
        /// Checks whether a user has ever generated a Certificate
        /// </summary>
        /// <param name="user"></param>
        /// <param name="certificate"></param>
        /// <returns></returns>
        Task<bool> ExpiredCertificateExists(CovidPassportUser user, Certificate certificate);

        /// <summary>
        /// Creates a certificate for a user if they meet the international ruleset and the certificate type
        /// </summary>
        /// <param name="user"></param>
        /// <param name="idToken"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        Task<Certificate> GetInternationalCertificate(CovidPassportUser user, string idToken, CertificateType type);


        /// <summary>
        /// Creates a certificate if user has valid tests or vaccines
        /// </summary>
        /// <param name="remoteCode"></param>
        /// <param name="requestDto"></param>
        /// <returns></returns>
        Task<Certificate> GetCertificateByHash(Models.DataModels.RemoteAccessCode remoteCode, FetchRemoteCovidStatusDto requestDto, string idToken = "");
    }
}
