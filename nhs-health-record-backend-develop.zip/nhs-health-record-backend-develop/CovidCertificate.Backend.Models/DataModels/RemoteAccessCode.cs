﻿using System;

namespace CovidCertificate.Backend.Models.DataModels
{
    [Collection("RemoteAccessCode")]
    public class RemoteAccessCode : UserHashedDocument
    {
        public string AccessHash { get; set; }
        public string AccessCode { get; set; }
        public int Uses { get; set; }
        public DateTime ExpiryDateTime { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public string ThirdPartyName { get; set; }
        public string ThirdPartyID { get; set; }
        public CodeStatusType CodeStatus { get; set; }

        public RemoteAccessCode(string accessCode, int uses, DateTime expiryDateTime, string accessHash, CovidPassportUser covidUser) : 
            base(covidUser.Name, covidUser.DateOfBirth, covidUser.PhoneNumber, covidUser.EmailAddress, covidUser.NhsNumber)
        {
            AccessHash = accessHash;
            AccessCode = accessCode;
            Uses = uses;
            ExpiryDateTime = DateTime.SpecifyKind(expiryDateTime.AddDays(30), DateTimeKind.Utc);
            CreatedDateTime = DateTime.UtcNow;
            ThirdPartyName = null;
            ThirdPartyID = null;
            CodeStatus = CodeStatusType.Unused;
        }
    }

    public enum CodeStatusType { Unused = 0, Unregistered = 1, Registered = 2, Revoked = 3}
}
