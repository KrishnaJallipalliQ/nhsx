﻿using CovidCertificate.Backend.Models.RequestDtos.InternationalScenarios;
using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.RequestDtos
{
    public class AddInternationalRecoveryPdfRequestDto
    {
        public IEnumerable<AddInternationalPdfRecoveryTestsRequestDto> RecoveryTest { get; set; }
        public string RecoveryUniqueCertificateIdentifer { get; set; }
    }
}
