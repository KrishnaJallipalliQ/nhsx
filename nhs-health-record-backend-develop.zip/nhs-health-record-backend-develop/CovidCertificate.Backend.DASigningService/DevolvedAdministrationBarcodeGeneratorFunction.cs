using CovidCertificate.Backend.Configuration.Bases.BaseFunctions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System;
using System.Net;
using CovidCertificate.Backend.DASigningService.ErrorHandling;
using CovidCertificate.Backend.DASigningService.Interfaces;
using CovidCertificate.Backend.DASigningService.Requests;
using CovidCertificate.Backend.DASigningService.Models;
using Hl7.Fhir.Model;
using CovidCertificate.Backend.Models.Deserializers;
using BarcodeResults = CovidCertificate.Backend.DASigningService.Responses.BarcodeResults;

namespace CovidCertificate.Backend.DASigningService
{
    public class DevolvedAdministrationBarcodeGeneratorFunction : BaseFunction
    {
        private const string VACCINATION_API_NAME = "Create2DVaccinationBarcode";
        public const string RegionSubscriptionNameHeader = "Region-Subscription-Name";

        private readonly IBarcodeGenerator barcodeGenerator;
        private readonly IRegionConfigService regionConfigService;
        private readonly ILogService logService;

        public DevolvedAdministrationBarcodeGeneratorFunction(
            IBarcodeGenerator barcodeGenerator,
            IRegionConfigService regionConfigService,
            ILogService logService,
            ILogger<DevolvedAdministrationBarcodeGeneratorFunction> logger) : base(logger)
        {
            this.barcodeGenerator = barcodeGenerator;
            this.regionConfigService = regionConfigService;
            this.logService = logService;
        }

        [FunctionName(VACCINATION_API_NAME)]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "post", Route = "vaccinations/2dbarcode")] HttpRequest req)
        {
            logger.LogInformation("Create2DBarcode was invoked");

            ErrorHandler errorHandler = new ErrorHandler();

            using StreamReader streamReader = new StreamReader(req.Body);
            string rawRequestBody = await streamReader.ReadToEndAsync();

            var request = new Create2DVaccinationBarcodeRequest
            {
                Type = req.Query["type"],
                RegionSubscriptionNameHeader = req.Headers[RegionSubscriptionNameHeader],
                Body = rawRequestBody
            };

            var regionConfig =
                regionConfigService.GetRegionConfig(request.RegionSubscriptionNameHeader, errorHandler);

            try
            {
                //Mututal TLS is out of scope for initial version. The below code validating an incoming client certificate is thus disabled intentionally
                //clientCertificateValidator.ValidateRequest(request, errorHandler);

                (bool isValid, BadRequestObjectResult badRequestResult) = ValidateRequest(request);

                if (!isValid)
                {
                    return await GetBadRequestResult(regionConfig, VACCINATION_API_NAME, badRequestResult);
                }

                var bundle = FHIRDeserializer.Deserialize<Bundle>(rawRequestBody);

                BarcodeResults barcodeResult = await barcodeGenerator.BarcodesFromFhirBundle(bundle, regionConfig);

                return await GetOKResult(regionConfig, VACCINATION_API_NAME, barcodeResult);
            }
            catch (FormatException ex)
            {
                logger.LogError(ex, "Cannot parse FHIR payload.");

                var result = new BadRequestObjectResult(new Error
                {
                    Code = ((ushort)ErrorCode.FHIR_INVALID).ToString(),
                    Message = ex.Message,
                });

                return await GetBadRequestResult(regionConfig, VACCINATION_API_NAME, result);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                errorHandler.AddError(ErrorCode.UNEXPECTED_SYSTEM_ERROR);

                return await GetErrorResult(regionConfig, VACCINATION_API_NAME, errorHandler);
            }
        }

        private async Task<IActionResult> GetOKResult(RegionConfig regionConfig, string apiName, BarcodeResults barcodeResult)
        {
            await logService.LogResult(logger, barcodeResult.UVCI, apiName, HttpStatusCode.OK, regionConfig);

            return new OkObjectResult(barcodeResult);
        }

        private async Task<IActionResult> GetBadRequestResult(RegionConfig regionConfig, string apiName, BadRequestObjectResult result)
        {
            await logService.LogResult(logger, null, apiName, HttpStatusCode.BadRequest, regionConfig);

            return result;
        }

        private async Task<IActionResult> GetErrorResult(RegionConfig regionConfig, string apiName, ErrorHandler errorHandler)
        {
            var result = new ObjectResult(GetErrorResult(errorHandler))
            {
                StatusCode = (int)HttpStatusCode.InternalServerError
            };

            await logService.LogResult(logger, null, apiName, HttpStatusCode.InternalServerError, regionConfig);

            return result;
        }

        private BarcodeResults GetErrorResult(ErrorHandler errorHandler)
        {
            return new BarcodeResults
            {
                Errors = errorHandler.Errors
            };
        }

        private Tuple<bool, BadRequestObjectResult> ValidateRequest(Create2DVaccinationBarcodeRequest request)
        {
            var validationResult = request.Validate();

            if (!validationResult.IsValid)
            {
                var badRequestResult = new BadRequestObjectResult(new BarcodeResults
                {
                    Errors = validationResult.Errors.Select(e => new Error
                    {
                        Code = e.ErrorCode,
                        Message = e.ErrorMessage
                    }).ToList()
                });

                return new Tuple<bool, BadRequestObjectResult>(false, badRequestResult);
            }

            return new Tuple<bool, BadRequestObjectResult>(true, null);
        }
    }
}