﻿using CovidCertificate.Backend.Interfaces;
using Hl7.Fhir.ElementModel.Types;
using System.Collections.Generic;

namespace CovidCertificate.Backend.Models.DataModels
{
    public class QRcodeResponse
    {
        public string ValidityEndDate { get; set; }
        public string EligibilityEndDate { get; set; }
        public string UniqueCertificateIdentifier { get; set; }
        public IEnumerable<IGenericResult> ResultData { get; private set; }

        public QRcodeResponse(string validityEndDate, IEnumerable<IGenericResult> resultData, string uniqueCertificateIdentifier, string eligibilityEndDate = "")
        {
            ValidityEndDate = validityEndDate;
            EligibilityEndDate = eligibilityEndDate;
            UniqueCertificateIdentifier = uniqueCertificateIdentifier;
            ResultData = resultData;
            
        }
    }
}
