﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Exceptions;
using Hl7.Fhir.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services
{
    public class DiagnosticTestFhirBundleMapper : IFhirBundleMapper<TestResultNhs>
    { 
        private readonly IMappingCache mappingCache;
        private readonly ILogger<DiagnosticTestFhirBundleMapper> logger;

        public DiagnosticTestFhirBundleMapper(IMappingCache mappingCache, ILogger<DiagnosticTestFhirBundleMapper> logger)
        { 
            this.mappingCache = mappingCache;
            this.logger = logger;
        }

        public async Task<IEnumerable<TestResultNhs>> ConvertBundle(Bundle bundle)
        {
            var testResults = new List<TestResultNhs>();

            if (bundle != null)
            {
                var mappings = await mappingCache.GetMappings();

                foreach (var entry in bundle.Entry)
                {
                    try
                    {
                        if (entry?.Resource is Observation observation)
                        {
                            (string testKit, string validityType) = GetTestKitAndValidityType(observation.Device?.Identifier, mappings);                            

                            var fhirDateTimeOfTest = (FhirDateTime)observation.Effective;
                            var dateTimeOfTestNullable = fhirDateTimeOfTest?.ToDateTimeOffset(TimeZoneInfo.Utc.GetUtcOffset(DateTime.Now)).DateTime;
                            if(!dateTimeOfTestNullable.HasValue)
                            {
                                throw new DiagnosticTestMappingException($"{nameof(DiagnosticTestFhirBundleMapper)}: DateTimeOfTest needs to have a value.");
                            }
                            var dateTimeOfTest = dateTimeOfTestNullable.Value;

                            var codeableConcept = (CodeableConcept)observation.Value;
                            var successful = mappings.TryGetValue("result", out var mapping);
                            if (!successful)
                            {
                                throw new Exception($"{nameof(DiagnosticTestFhirBundleMapper)}: Result mapping does not exist.");
                            }
                            var codeableConceptCoding = codeableConcept.Coding?.FirstOrDefault()?.Code;
                            if(codeableConceptCoding == null)
                            {
                                throw new DiagnosticTestMappingException($"{nameof(DiagnosticTestFhirBundleMapper)}: CodeableConcept code is null.");
                            }
                            var result = mapping.TryGetValue(codeableConceptCoding, out var b) ? b : null;
                            if(result == null)
                            {
                                throw new DiagnosticTestMappingException($"{nameof(DiagnosticTestFhirBundleMapper)}: CodeableConcept code with SNOMED value {codeableConceptCoding} does not exist in mapping file.");
                            }

                            successful = mappings.TryGetValue("selfTestValues", out mapping);
                            if (!successful)
                            {
                                throw new Exception($"{nameof(DiagnosticTestFhirBundleMapper)}: Self Test mapping does not exist.");
                            }
                            var processingCode = observation.Performer != null ? GetProcessingCode(validityType, observation.Performer, mapping) : "LAB_RESULT";

                            successful = mappings.TryGetValue("staticValues", out mapping);
                            if (!successful)
                            {
                                throw new Exception($"{nameof(DiagnosticTestFhirBundleMapper)}: Static values mapping does not exist.");
                            }
                            var diseaseTargetedCode = mapping.TryGetValue("DiseaseTargetedCode", out var c) ? c : string.Empty;
                            var diseaseTargetedValue = mapping.TryGetValue("DiseaseTargetedValue", out var d) ? d : string.Empty;
                            var countryOfAuthority = mapping.TryGetValue("Country", out var e) ? e : string.Empty; ;
                            var authority = mapping.TryGetValue("Authority", out var f) ? f : string.Empty;

                            testResults.Add(new TestResultNhs(dateTimeOfTest, result, validityType, processingCode, testKit, new Tuple<string, string>(diseaseTargetedCode, diseaseTargetedValue), authority, countryOfAuthority));
                        }
                    }
                    catch(DiagnosticTestMappingException e)
                    {
                        logger.LogError(e, e.Message);
                    }
                }
            }

            return testResults;
        }

        private Tuple<string, string> GetTestKitAndValidityType(Identifier identifier, Dictionary<string, Dictionary<string, string>> mappings)
        {
            String testKit;
            String validityType;

            if (identifier == null)
            {
                validityType = "UNKNOWN";
                testKit = null;
                logger.LogInformation($"{nameof(DiagnosticTestFhirBundleMapper)}: observation's device identifier null. Setting validityType to UNKNOWN");
            }
            else
            {
                //The identifer value could be intentionally empty and map to a value as per documentation
                testKit = identifier.Value?.ToUpper() ?? string.Empty;
                var testKitSuccessful = mappings.TryGetValue("type", out var testKitMapping);
                if (!testKitSuccessful)
                {
                    throw new Exception("Type mapping does not exist.");
                }

                if (testKitMapping.TryGetValue(testKit.ToUpperInvariant(), out var a))
                {
                    validityType = a;
                }
                else
                {
                    validityType = "UNKNOWN";
                    //Log warning as all known Test Kit values should be in mapping file
                    logger.LogWarning($"{nameof(DiagnosticTestFhirBundleMapper)}: Test Kit value {testKit} does not exist in mapping file. Mapping to UNKNOWN.");
                }
            }
            return new Tuple<string, string>(testKit, validityType);
        }

        private static string GetProcessingCode(string validityType, IEnumerable<ResourceReference> performers, Dictionary<string, string> mappings)
        {
            foreach(var performer in performers)
            {
                var performerValue = performer.Identifier?.Value;
                if(performerValue != null)
                {
                    var selfTestType = mappings.TryGetValue(performerValue.ToUpper(), out var a) ? a : string.Empty;
                    if (validityType == selfTestType &&
                       ((validityType == "PCR" && performer.Identifier?.Type?.Text?.Equals("Testing Centre", StringComparison.InvariantCultureIgnoreCase) == true) || validityType == "LFT"))
                    {
                        return "SelfTest";
                    }
                }                          
            }

            if(validityType == "LFT")
            {
                return "Assist";
            }

            return "LAB_RESULT";
        }
    }
}
