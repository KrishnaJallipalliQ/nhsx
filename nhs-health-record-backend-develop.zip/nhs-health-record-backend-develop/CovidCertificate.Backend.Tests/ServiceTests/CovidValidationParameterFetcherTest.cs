﻿using System;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Services;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class CovidValidationParameterFetcherTest
    {
        [Fact]
        public void CovidValidationParameterFetcher_Null_JWT()
        {
            var result = Assert.Throws<ArgumentNullException>(() => new CovidValidationParameterFetcher(null, null));
            Assert.IsType<ArgumentNullException>(result);
            Assert.Equal("covidJwtSettings", result.ParamName);
        }

        [Fact]
        public void CovidValidationParameterFetcher_Null_KeyRing()
        {
            var result = Assert.Throws<ArgumentNullException>(() => new CovidValidationParameterFetcher(new CovidJwtSettings(), null));
            Assert.IsType<ArgumentNullException>(result);
            Assert.Equal("keyRing", result.ParamName);
        }
    }
}
