﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using Microsoft.Extensions.Configuration;
using Moq;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace CovidCertificate.Backend.DASigningService.Tests.ServiceTests
{
    public static class BarCodeGeneratorTestsHelper
    {
        private const string json = @"{""39115611000001103"":{
                ""DISEASE"":[""840539006"",""COVID-19""],
                ""MANUFACTURER"":[""ORG-100030215"",""Biontech Manufacturing GmbH""],
	            ""PRODUCT"":[""EU/1/20/1528"",""Comirnaty"",""Pfizer/BioNTech COVID-19 vaccine""],
	            ""VACCINE"":[""1119349007"",""SARS Cov-2 mRNA Vaccine""]}
                }";

        public static Mock<IVaccineMapping> CreateMockVaccineMapping()
        {
            var map = JsonConvert.DeserializeObject<Dictionary<string, VaccineMap>>(json);
            Mock<IVaccineMapping> mockMapping = new Mock<IVaccineMapping>();
            mockMapping.Setup(m => m.GetMappings()).ReturnsAsync(map);
            return mockMapping;
        }
    }
}
