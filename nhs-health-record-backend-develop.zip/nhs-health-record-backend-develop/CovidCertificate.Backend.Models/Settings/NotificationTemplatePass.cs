﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.Settings
{
    public class NotificationTemplatePass
    {
        public Guid AppleEmailId { get; set; }

        public Guid GoogleEmailId { get; set; }
    }
}
