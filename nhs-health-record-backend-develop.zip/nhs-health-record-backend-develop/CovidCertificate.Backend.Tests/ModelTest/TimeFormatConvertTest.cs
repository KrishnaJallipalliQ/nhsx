﻿using CovidCertificate.Backend.Models.Helpers;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Tests.ModelTest
{
    public class TimeFormatConvertTest
    {
        [Fact]
        public async Task TimeZone_ExpectedBehaviour()
        {
            DateTime original = new DateTime(2012, 1, 1, 12, 22, 34, 666, DateTimeKind.Unspecified);
            var result = TimeFormatConvert.ToUniversal(original);
            DateTime expected = new DateTime(2012, 1, 1, 12, 22, 0, DateTimeKind.Utc);
            Assert.Equal(expected, result);
        }
        [Fact]
        public async Task TimeZone_EdgeTimes()
        {
            DateTime min = DateTime.MinValue;
            var minresult = TimeFormatConvert.ToUniversal(min);
            DateTime max = DateTime.MaxValue;
            var maxresult = TimeFormatConvert.ToUniversal(max);
            Assert.Equal(min, minresult);
            Assert.Equal(max, maxresult);
        }
    }
}
