﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Models.Settings;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services.PilotFilter
{
    public class PilotHoldingService : IPilotHoldingService
    {
        private readonly ILogger<PilotHoldingService> logger;
        private readonly IMongoRepository<HoldingTestResult> mongoRepository;

        public PilotHoldingService(
            ILogger<PilotHoldingService> logger,
            IMongoRepository<HoldingTestResult> mongoRepository)
        {
            this.logger = logger;
            this.mongoRepository = mongoRepository;
        }

        public async Task AddHoldingTest(TestResult testResult)
        {
            await mongoRepository.InsertOneAsync(new HoldingTestResult(testResult));
        }

        public Task<IEnumerable<HoldingTestResult>> GetHoldingTests(CovidPassportUser user)
        {
            return mongoRepository.FindAllAsync(user.GetDataIdentifierExpression<HoldingTestResult>());
        }

    }
}
