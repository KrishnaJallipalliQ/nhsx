﻿using CovidCertificate.Backend.Models.DataModels;
using System;
using Xunit;

namespace CovidCertificate.Backend.Tests.ModelTest
{
    public class TestResultNhsTests
    {
        [Fact]
        public void TestResult_IsPositive()
        {
            // Arrange
            var positiveTestResult = new TestResultNhs(DateTime.Today, "Positive", "LFT", "LFTSelfTest", "kit", null, null, null);
            var negativeTestResult = new TestResultNhs(DateTime.Today, "Negative", "LFT", "LFTSelfTest", "kit", null, null, null);
            var voidTestResult = new TestResultNhs(DateTime.Today, "Void", "LFT", "LFTSelfTest", "kit", null, null, null);

            // Act & Assert
            Assert.True(positiveTestResult.Result.Equals("Positive"));
            Assert.False(negativeTestResult.Result.Equals("Positive"));
            Assert.False(voidTestResult.Result.Equals("Positive"));
        }

        [Fact]
        public void TestResult_IsNegative()
        {
            // Arrange
            var positiveTestResult = new TestResultNhs(DateTime.Today, "Positive", "LFT", "LFTSelfTest", "kit", null, null, null);
            var negativeTestResult = new TestResultNhs(DateTime.Today, "Negative", "LFT", "LFTSelfTest", "kit", null, null, null);
            var voidTestResult = new TestResultNhs(DateTime.Today, "Void", "LFT", "LFTSelfTest", "kit", null, null, null);

            // Act & Assert
            Assert.False(positiveTestResult.Result.Equals("Negative"));
            Assert.True(negativeTestResult.Result.Equals("Negative"));
            Assert.False(voidTestResult.Result.Equals("Negative"));
        }

        [Fact]
        public void TestResult_Equals_ShouldReturnFalse()
        {
            // Arrange
            var testResultOne = new TestResultNhs(DateTime.Today, "Positive", "LFT", "LFTSelfTest", "kit", null, null, null);
            var testResultTwo = new TestResultNhs(DateTime.Today, "Positive", "LFT", "LFTSelfTest", "kit", null, null, null);
            var obj = new object();

            // Act & Assert
            Assert.False(testResultOne.Equals(testResultTwo));
            Assert.False(testResultOne.Equals(obj));
        }

        [Fact]
        public void TestResult_GetHashCode()
        {
            // Arrange
            var testResultOne = new TestResultNhs(DateTime.Today, "Positive", "LFT", "LFTSelfTest", "kit", null, null, null);
            var testResultTwo = new TestResultNhs(DateTime.Today, "Positive", "LFT", "LFTSelfTest", "kit", null, null, null);

            // Act
            var testResultOneHashCodeOne = testResultOne.GetHashCode();
            var testResultOneHashCodeTwo = testResultOne.GetHashCode();
            var testResultTwoHashCode = testResultTwo.GetHashCode();

            // Assert
            Assert.Equal(testResultOneHashCodeOne, testResultOneHashCodeTwo);
            Assert.NotEqual(testResultOneHashCodeOne, testResultTwoHashCode);
        }

        [Fact]
        public void TestResultDateTime()
        {
            var testResultOne = new TestResultNhs(DateTime.Today, "Positive", "LFT", "LFTSelfTest", "kit", null, null, null);

            Assert.Equal(DateTime.Today, testResultOne.DateTimeOfTest);
        }

        [Fact]
        public void TestResultValidityType()
        {
            var testResultOne = new TestResultNhs(DateTime.Today, "Positive", "LFT", "LFTSelfTest", "kit", null, null, null);

            Assert.Equal("LFT", testResultOne.ValidityType);
        }

        [Fact]
        public void TestResultTestKit()
        {
            var testResultOne = new TestResultNhs(DateTime.Today, "Positive", "LFT", "LFTSelfTest", "kit", null, null, null);

            Assert.Equal("kit", testResultOne.TestKit);
        }

        [Fact]
        public void TestResultProcessingCode()
        {
            var testResultOne = new TestResultNhs(DateTime.Today, "Positive", "LFT", "LFTSelfTest", "kit", null, null, null);

            Assert.Equal("LFTSelfTest", testResultOne.ProcessingCode);
        }
    }
}
