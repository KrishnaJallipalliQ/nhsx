﻿using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IGooglePassJwt
    {
        Task<string> GenerateJwt(CovidPassportUser user, QRType qrType,string idToken);
    }
}
