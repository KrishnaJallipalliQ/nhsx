﻿using Microsoft.Azure.WebJobs;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using CovidCertificate.Backend.NhsApiIntegration.Interfaces;
using CovidCertificate.Backend.Models.Settings;

namespace CovidCertificate.Backend
{
    public class FetchTestResultAccessTokenFunction
    {
        private readonly ILogger logger;
        private readonly INhsTestResultsHistoryApiAccessTokenService accessTokenService;
        private readonly NhsTestResultsHistoryApiSettings settings;

        public FetchTestResultAccessTokenFunction(ILogger<FetchTestResultAccessTokenFunction> logger,
            INhsTestResultsHistoryApiAccessTokenService accessTokenService,
            NhsTestResultsHistoryApiSettings settings)
        {
            this.logger = logger;
            this.accessTokenService = accessTokenService;
            this.settings = settings;
        }

        [FunctionName("FetchTestResultAccessTokenFunction")]
        public async Task Run([TimerTrigger(" 0 */1 * * * *")] TimerInfo myTimer)
        {
                logger.LogInformation("FetchTestResultAccessTokenFunction was invoked.");

                await accessTokenService.RefreshAccessTokenInRedisAsync();

                logger.LogInformation("FetchTestResultAccessTokenFunction has finished.");
        }
    }
}
