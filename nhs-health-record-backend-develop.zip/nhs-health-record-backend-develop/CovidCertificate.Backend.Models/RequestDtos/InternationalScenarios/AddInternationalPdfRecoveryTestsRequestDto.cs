﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.RequestDtos.InternationalScenarios
{
    public class AddInternationalPdfRecoveryTestsRequestDto
    {
        public string QRCodeToken { get; set; }
        public string DiseaseTargeted { get; set; }
        public string DateOfFirstPositiveTestResult { get; set; }
        public string CountryOfTest { get; set; }
        public string CertificateIssuer { get; set; }
        public string CertificateType { get; set; }
        public string CertificateValidFrom { get; set; }
        public string CertificateValidUntil { get; set; } 
    }
}
