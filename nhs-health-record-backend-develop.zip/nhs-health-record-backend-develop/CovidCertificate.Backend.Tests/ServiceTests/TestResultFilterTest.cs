﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Services;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class TestResultFilterTest
    {
        private readonly  Mock<IMappingCache> mappingMock = new Mock<IMappingCache>();
        private readonly TestResultFilter service;
        private readonly Mock<ILogger<TestResultFilter>> loggerMock = new Mock<ILogger<TestResultFilter>>();

        public TestResultFilterTest()
        {
            service = new TestResultFilter(loggerMock.Object);

        }

        [Fact]
        public async Task FilterOutHomeTests()
        {
            var time = new DateTime(2021, 01, 01);

            var homeTestLower = new TestResultNhs(new TestResult("test", time, "test", "test", "test", time, "test", "VALID", "LAMPORE", "SelfTest"));
            var homeTest = new TestResultNhs(new TestResult("test", time, "test", "test", "test", time, "test", "VALID", "LAMPORE", "SELFTEST"));
            var assist = new TestResultNhs(new TestResult("test", time, "test", "test", "test", time, "test", "VALID", "RNALAMP", "Assist"));
            var lab = new TestResultNhs(new TestResult("test", time, "test", "test", "test", time, "test", "VALID", "NONE", "LAB_RESULT"));
            var nullCode = new TestResultNhs(new TestResult("test", time, "test", "test", "test", time, "test", "VALID", "NONE", null));

            var allTests = new List<TestResultNhs>() { homeTestLower, homeTest, assist,lab,nullCode };
            var expected = new List<TestResultNhs>() { assist,lab,nullCode };
            var result = service.FilterOutHomeTest(allTests,"LAMPORE");

            Assert.Equal(expected, result);
        }
    }
}
