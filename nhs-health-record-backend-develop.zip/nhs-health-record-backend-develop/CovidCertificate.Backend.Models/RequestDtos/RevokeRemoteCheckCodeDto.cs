﻿using CovidCertificate.Backend.Models.Validators;
using FluentValidation;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Models.RequestDtos
{
    public class RevokeRemoteCheckCodeDto
    {
        public string RemoteCheckCode { get; set; }

        public async Task ValidateObjectAndThrowOnFailuresAsync() => await new RevokeRemoteCheckCodeDtoValidator().ValidateAndThrowAsync(this);

        private class RevokeRemoteCheckCodeDtoValidator : AbstractValidator<RevokeRemoteCheckCodeDto>
        {
            public RevokeRemoteCheckCodeDtoValidator()
            {
                #region RemoteCheckCode Rules
                RuleFor(x => x.RemoteCheckCode).NotEmpty().OnFailure(x =>
                {
                    throw new ValidationException("RemoteCheckCode must be specified");
                });

                RuleFor(x => x.RemoteCheckCode).Length(9).Matches(ValidatorConsts.RemoteCheckCodeRegex);
                #endregion;
            }
        }
    }
}
