﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidCertificate.Backend.Models.Settings
{
    public class PilotFilterSettings
    {
        public string AzureTableName { get; set; }
    }
}
