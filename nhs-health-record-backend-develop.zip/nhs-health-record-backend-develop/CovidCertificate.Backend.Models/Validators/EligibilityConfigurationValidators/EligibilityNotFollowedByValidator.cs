﻿using CovidCertificate.Backend.Models.DataModels;
using FluentValidation;

namespace CovidCertificate.Backend.Models.Validators
{
    public class EligibilityNotFollowedByValidator : AbstractValidator<EligibilityNotFollowedBy>
    {
        public EligibilityNotFollowedByValidator()
        {
            RuleFor(x => x.Name).NotEmpty().OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.Name)} was not specified.");
            });

            RuleFor(x => x.Name.Length).LessThanOrEqualTo(255).OnFailure(x =>
            {
                throw new ValidationException($"{nameof(x.Name)} must not exceed the character limit of 255.");
            });
        }
    }
}
