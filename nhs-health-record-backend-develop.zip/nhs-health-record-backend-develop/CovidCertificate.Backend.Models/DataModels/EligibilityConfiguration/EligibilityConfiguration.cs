﻿using CovidCertificate.Backend.Models.Validators;
using FluentValidation;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Models.DataModels
{
    public class EligibilityConfiguration
    {
        public IEnumerable<EligibilityRules> Rules { get; set; }
        public EligibilityDomesticExemptions DomesticExemptions {get; set;}

        [JsonConstructor]
        public EligibilityConfiguration() { }

        public EligibilityConfiguration(IEnumerable<EligibilityRules> rules, EligibilityDomesticExemptions domesticExemptions)
        {
            Rules = rules;
            DomesticExemptions = domesticExemptions;
        }

        public async Task ValidateObjectAndThrowOnFailuresAsync()
        {
            await new EligibilityConfigurationValidator().ValidateAndThrowAsync(this);
        }
    }
}
