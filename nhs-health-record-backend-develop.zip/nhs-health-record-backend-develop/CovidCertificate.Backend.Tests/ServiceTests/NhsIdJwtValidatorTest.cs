﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Moq;
using System;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class NhsIdJwtValidatorTest
    {
        private readonly Mock<ILogger<NhsIdJwtValidator>> mockLogger;
        private readonly Mock<IPublicKeyService> mockPublicKeyService;
        private ConfigurationRoot configuration;

        public NhsIdJwtValidatorTest()
        {
            mockLogger = new Mock<ILogger<NhsIdJwtValidator>>();
            mockPublicKeyService = new Mock<IPublicKeyService>();
        }
        
        [Fact]
        public async void IsValidToken_WhenValidationEnabledNotExplicitlyDeclared_InvalidToken_ReturnFalse()
        {
            //Arrange
            configuration = NhsIdJwtValidatorTestHelper.GetEmptyConfiguration(); //JwtValidationEnabled is never declared

            var invalidToken = NhsIdJwtValidatorTestHelper.InvalidToken;
            var incorrectPublicJwk = NhsIdJwtValidatorTestHelper.IncorrectPublicJwk;
            var nhsIdJwtValidator = GetNhsIdJwtValidator(incorrectPublicJwk);

            //Act
            var result = await nhsIdJwtValidator.IsValidToken(invalidToken, NhsIdJwtValidatorTestHelper.AuthSchema);

            //Assert
            Assert.False(result);
        }

        [Fact]
        public async void IsValidToken_WhenValidationIsDisabled_ReturnTrue()
        {
            //Arrange
            configuration = NhsIdJwtValidatorTestHelper.GetConfiguration(validationEnabled: false);

            var invalidToken = NhsIdJwtValidatorTestHelper.InvalidToken;
            var incorrectPublicJwk = NhsIdJwtValidatorTestHelper.IncorrectPublicJwk;
            var nhsIdJwtValidator = GetNhsIdJwtValidator(incorrectPublicJwk);

            //Act
            var result = await nhsIdJwtValidator.IsValidToken(invalidToken, NhsIdJwtValidatorTestHelper.AuthSchema);

            //Assert
            Assert.True(result);
        }

        [Fact]
        public async void IsValidToken_WhenValidationIsEnabled_ValidToken_ValidPublicKey_ReturnTrue()
        {
            //Arrange
            configuration = NhsIdJwtValidatorTestHelper.GetConfiguration(validationEnabled: true);

            var validToken = NhsIdJwtValidatorTestHelper.ValidToken;
            var validPublicJwk = NhsIdJwtValidatorTestHelper.ValidPublicJwk;
            var nhsIdJwtValidator = GetNhsIdJwtValidator(validPublicJwk);

            //Act
            var result = await nhsIdJwtValidator.IsValidToken(validToken, NhsIdJwtValidatorTestHelper.AuthSchema);

            //Assert
            Assert.True(result);
        }

        [Fact]
        public async void IsValidToken_WhenValidationIsEnabled_ValidToken_IncorrectPublicKey_RefreshAndReturnTrue()
        {
            //Arrange
            configuration = NhsIdJwtValidatorTestHelper.GetConfiguration(validationEnabled: true);

            var validToken = NhsIdJwtValidatorTestHelper.ValidToken;
            var validPublikJwk = NhsIdJwtValidatorTestHelper.ValidPublicJwk;
            var incorrectPublicJwk = NhsIdJwtValidatorTestHelper.IncorrectPublicJwk;
            var nhsIdJwtValidator = GetNhsIdJwtValidator(incorrectPublicJwk);

            mockPublicKeyService.Setup(x => x.RefreshPublicKey()).ReturnsAsync(validPublikJwk);

            //Act
            var result = await nhsIdJwtValidator.IsValidToken(validToken, NhsIdJwtValidatorTestHelper.AuthSchema);

            //Assert
            Assert.True(result);
        }

        [Fact]
        public async void IsValidToken_WhenValidationIsEnabled_InvalidToken_ValidPublicKey_ReturnFalse()
        {
            //Arrange
            configuration = NhsIdJwtValidatorTestHelper.GetConfiguration(validationEnabled: true);

            //Correct token format but expired or unauthorised token
            var invalidToken = NhsIdJwtValidatorTestHelper.InvalidToken;
            var validPublicJwk = NhsIdJwtValidatorTestHelper.ValidPublicJwk;
            var nhsIdJwtValidator = GetNhsIdJwtValidator(validPublicJwk);

            //Act
            var result = await nhsIdJwtValidator.IsValidToken(invalidToken, NhsIdJwtValidatorTestHelper.AuthSchema);

            //Assert
            Assert.False(result);
        }
         
        [Fact]
        public async void IsValidToken_WhenValidationIsEnabled_IncorrectToken_ReturnFalse()
        {
            //Arrange
            configuration = NhsIdJwtValidatorTestHelper.GetConfiguration(validationEnabled: true);

            var incorrectToken = NhsIdJwtValidatorTestHelper.IncorrectToken; //Wrong token format
            var validPublicJwk = NhsIdJwtValidatorTestHelper.ValidPublicJwk;
            var nhsIdJwtValidator = GetNhsIdJwtValidator(validPublicJwk);

            //Act
            var result = await Assert.ThrowsAsync<ArgumentException>(() => nhsIdJwtValidator.IsValidToken(incorrectToken, NhsIdJwtValidatorTestHelper.AuthSchema));

            //Assert
            Assert.IsType<ArgumentException>(result);
        }


        [Fact]
        public async void IsValidToken_WhenValidationIsEnabled_NoValidationParams_ReturnFalse()
        {
            //Arrange
            configuration = NhsIdJwtValidatorTestHelper.GetConfiguration(validationEnabled: true);

            var validToken = NhsIdJwtValidatorTestHelper.ValidToken;
            //Passing null jwk will give validator with no validation params
            var nhsIdJwtValidator = GetNhsIdJwtValidator(null); 

            //Act
            var result = await nhsIdJwtValidator.IsValidToken(validToken, NhsIdJwtValidatorTestHelper.AuthSchema);

            //Assert
            Assert.False(result);
        }

        private NhsIdJwtValidator GetNhsIdJwtValidator(JsonWebKey publicJwk)
        {
            var tokenValidationParameters = publicJwk != null ? NhsIdJwtValidatorTestHelper.GetValidationParameters(publicJwk) : null;
            return new NhsIdJwtValidator(
                configuration,
                NhsIdJwtValidatorTestHelper.GetValidationServiceResolverMock(tokenValidationParameters).Object,
                mockLogger.Object,
                mockPublicKeyService.Object
                );
        }
    }
}
