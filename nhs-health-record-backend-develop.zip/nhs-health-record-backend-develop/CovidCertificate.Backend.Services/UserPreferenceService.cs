﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.Exceptions;
using CovidCertificate.Backend.Models.ResponseDtos;
using CovidCertificate.Backend.Utils.Extensions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services
{
    public class UserPreferenceService : IUserPreference
    {
        private readonly IMongoRepository<UserPreferenceResponse> mongoRepository;
        private readonly ILogger<UserPreferenceService> logger;
        private readonly IConfiguration configuration;

        public UserPreferenceService(IMongoRepository<UserPreferenceResponse> mongoRepository, IConfiguration config,ILogger<UserPreferenceService> logger)
        {
            this.mongoRepository = mongoRepository;
            this.logger = logger;
            this.configuration = config;
        }


        public async Task UpdateTermsAndConditions(string id)
        {
            if (id == null)
            {
                logger.LogError("User does not have an NHS ID");
                throw new ArgumentNullException("User does not have an NHS ID");
            }
            var result = await mongoRepository.FindOneAsync(x => x.NHSID == id);

            

            if (result is null)
            {
                var document = new UserPreferenceResponse(id, DateTime.UtcNow);
                logger.LogInformation("New preference data was created");
                await mongoRepository.InsertOneAsync(document);
                logger.LogTraceAndDebug($"Preference data{document}");

            }
            else
            {
                result.TCAcceptanceDateTime = DateTime.UtcNow;
                await mongoRepository.ReplaceOneAsync(result, x => x.NHSID == id);
                logger.LogInformation("T&C data updated");
                logger.LogTraceAndDebug($"User with id {id} updated their T&C acceptance at {result.TCAcceptanceDateTime}");
            }
        }

        public async Task updateLanguageCodeAsync(string id, string lang)
        {
            if (id == null)
            {
                logger.LogError("User does not have an NHS ID");
                throw new ArgumentNullException("User does not have an NHS ID");
            }
            if (lang.Length != 2)
            {
                logger.LogError("Incorrect language format, must be Two Letter ISO Name");
                throw new ArgumentException("Incorrect Language Format");
            }
            if (lang != "en") // RegionInfo expects this as 'gb' but keep it as 'en' for template names etc
            {
                try
                {
                    RegionInfo info = new RegionInfo(lang);
                }
                catch (ArgumentException e)
                {
                    //doesn't recognise language string as a valid language code
                    logger.LogWarning(e, e.Message);
                    logger.LogWarning($"{lang} is not a valid language code");
                    throw new ArgumentException("Not a valid language code");
                }
            }
            var userPreferences = await mongoRepository.FindOneAsync(x => x.NHSID == id);
            if (userPreferences == null)
            {
                var newPreferences = new UserPreferenceResponse(id, lang);
                await mongoRepository.InsertOneAsync(newPreferences);
                logger.LogInformation("New preference data was created");
                logger.LogTraceAndDebug($"Preference data{newPreferences}");
            }
            else
            {
                userPreferences.LanguagePreference = lang;
                await mongoRepository.ReplaceOneAsync(userPreferences, x => x.NHSID == id);
                logger.LogInformation("Language code updated");
                logger.LogTraceAndDebug($"User with id {id} now has language preference {lang}");
            }
        }

        public async Task<UserPreferenceResponse> getPreferences(string id)
        {
            if (id == null)
            {
                logger.LogError("User does not have an NHS ID");
                throw new ArgumentNullException("User does not have an NHS ID");
            }
            var userPreferences = await mongoRepository.FindOneAsync(x => x.NHSID == id);
            if (userPreferences == null)
            {
                logger.LogWarning("No preference data found for this user");
                throw new NoResultsException("No user preference data found");
            }
            var TCDate = Environment.GetEnvironmentVariable("TCDate"); //the date the latest T&C have been updated
            logger.LogTraceAndDebug($"T&C last updated {TCDate}");
            if (userPreferences.TCAcceptanceDateTime > DateTime.Parse(TCDate))
            {
                userPreferences.AcceptedLatestTC = true;
            }
            return userPreferences;
        }
    }
}
