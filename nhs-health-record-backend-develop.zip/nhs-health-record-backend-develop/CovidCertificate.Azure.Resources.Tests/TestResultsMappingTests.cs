﻿using Newtonsoft.Json;
using System.Collections.Generic;
using Xunit;

namespace CovidCertificate.Azure.Resources.Tests
{
    public class TestResultsMappingTests
    {
        private readonly Dictionary<string, Dictionary<string, string>> mappings;
        public TestResultsMappingTests()
        {
            var mappingJson = AzureResourceTestHelper.GetJsonFromAzureResourcesProject("test-results-mapping.json");
            mappings = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, string>>>(mappingJson);
        }

        [Theory]
        [InlineData("result")]
        [InlineData("type")]
        [InlineData("staticValues")]
        [InlineData("selfTestValues")]
        public void TestResultsMappingTest_AllMappingsContainedInFile(string mappingKey)
        {
            Assert.True(mappings.ContainsKey(mappingKey));
        }
    }
}
