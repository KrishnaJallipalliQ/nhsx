﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.International;
using CovidCertificate.Backend.International.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Models.Exceptions;
using CovidCertificate.Backend.Utils;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Services
{
    public class GeneratePassData : IGeneratePassData
    {
        private readonly ILogger<GeneratePassData> logger;
        private readonly ICovidCertificateCreator covidCertificateCreator;
        private readonly TimeZoneInfo timeZoneInfo;

        public GeneratePassData(ILogger<GeneratePassData> logger, IGetTimeZones timeZones, ICovidCertificateCreator covidCertificateCreator)
        {
            this.logger = logger;
            this.covidCertificateCreator = covidCertificateCreator;
            timeZoneInfo = timeZones.GetTimeZoneInfo();
        }

        public async Task<(QRcodeResponse qr,Certificate cert)> GetPassDataAsync(CovidPassportUser user, string idToken, QRType type)
        {
            switch (type)
            {
                case QRType.Domestic:
                    var domesticCert = await covidCertificateCreator.GetDomesticCertificate(user, idToken);
                    
                    var QRResponse = new QRcodeResponse(StringUtils.GetFormattedDateTime(TimeZoneInfo.ConvertTimeFromUtc(domesticCert.validityEndDate, timeZoneInfo)),
                                                        domesticCert.EligibilityResults,
                                                        domesticCert.UniqueCertificateIdentifier,
                                                        StringUtils.GetFormattedDate(TimeZoneInfo.ConvertTimeFromUtc(domesticCert.eligibilityEndDate,timeZoneInfo)));
                    return (QRResponse, domesticCert);

                case QRType.International:
                    var vaccinationCertificate = await covidCertificateCreator.GetInternationalCertificate(user, idToken, CertificateType.Vaccination);
                    if (vaccinationCertificate == null)
                        throw new NoResultsException("No vaccine certificate to generate International QR");

                    QRResponse = new QRcodeResponse(StringUtils.GetFormattedDate(TimeZoneInfo.ConvertTimeFromUtc(vaccinationCertificate.validityEndDate,timeZoneInfo)),
                                                    vaccinationCertificate.EligibilityResults,
                                                    vaccinationCertificate.UniqueCertificateIdentifier,
                                                    StringUtils.GetFormattedDate(TimeZoneInfo.ConvertTimeFromUtc(vaccinationCertificate.eligibilityEndDate,timeZoneInfo)));

                    return (QRResponse, vaccinationCertificate);

                case QRType.Recovery:
                    var recoveryCertificate = await covidCertificateCreator.GetInternationalCertificate(user, idToken, CertificateType.Recovery);

                    if (recoveryCertificate == null)
                        throw new NoResultsException("No recovery certificate to generate Recovery QR");

                    QRResponse = new QRcodeResponse(StringUtils.GetFormattedDate(TimeZoneInfo.ConvertTimeFromUtc(recoveryCertificate.validityEndDate,timeZoneInfo)),
                                                    recoveryCertificate.EligibilityResults,
                                                    recoveryCertificate.UniqueCertificateIdentifier,
                                                    StringUtils.GetFormattedDate(TimeZoneInfo.ConvertTimeFromUtc(recoveryCertificate.eligibilityEndDate,timeZoneInfo)));

                    return (QRResponse, recoveryCertificate);

                default:
                    return (null,null);
            }
        }
    }
}
