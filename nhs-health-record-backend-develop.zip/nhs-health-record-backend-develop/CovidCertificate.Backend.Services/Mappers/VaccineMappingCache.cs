﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.BlobService;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Utils;
using CovidCertificate.Backend.Utils.Extensions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Task = System.Threading.Tasks.Task;

namespace CovidCertificate.Backend.Services.Mappers
{
    public class VaccineMappingCache : IVaccineMapping
    {
        private readonly IConfiguration configuration;
        private readonly ILogger<VaccineMappingCache> logger;
        private readonly IBlobService blobService;
        private static IDictionary<string, VaccineMap> _mappings = new Dictionary<string, VaccineMap>();
        private DateTime _cacheExpiry;
        private static readonly AsyncLock Mutex = new AsyncLock();
        private const string VaccineMappingLocation = "vaccine-results-mapping.json";
        private const string VaccineConfigContainer = "vaccine-results-configuration";

        public VaccineMappingCache(IConfiguration configuration, ILogger<VaccineMappingCache> logger, IBlobService blobService)
        { ;
            this.configuration = configuration;
            this.logger = logger;
            this.blobService = blobService;
        }

        private bool CacheExpired()
            => _cacheExpiry < DateTime.UtcNow;

        private async Task UpdateCache()
        {
            using(await Mutex.LockAsync())
            {
                if (!CacheExpired())
                    return;

                try
                {
                    var mappings = await GetVaccineResultsMappingFromBlobStorage();
                    _cacheExpiry = DateTime.UtcNow.AddMinutes(int.TryParse(configuration["VaccineMapperCacheTime"], out var cacheTime) ? cacheTime : 10);
                    Interlocked.Exchange(ref _mappings, mappings);
                }
                catch (Exception e)
                {
                    logger.LogError(e, e.Message);
                }

            }
        }

        public async Task<Dictionary<string, VaccineMap>> GetMappings()
        {
            logger.LogInformation("GetMappings was invoked");

            if (CacheExpired())
                await UpdateCache();

            logger.LogInformation("GetMappings has finished");
            return (Dictionary<string, VaccineMap>)_mappings;
        }

        private async Task<Dictionary<string, VaccineMap>> GetVaccineResultsMappingFromBlobStorage()
        {
            return await blobService.GetObjectFromBlob<Dictionary<string, VaccineMap>>(VaccineConfigContainer,
                VaccineMappingLocation);
        }
    }
}
