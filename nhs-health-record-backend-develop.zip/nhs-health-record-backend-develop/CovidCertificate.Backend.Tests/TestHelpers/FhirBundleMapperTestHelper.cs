﻿using Hl7.Fhir.Model;
using System.Collections.Generic;

namespace CovidCertificate.Backend.Tests.TestHelpers
{
    public class FhirBundleMapperTestHelper
    {
        public static Bundle.EntryComponent CreateObservationEntryComponentWithTestKit(string resultCode, string testKit, string processingLabCode)
        {
            var identifier = new Identifier
            {
                Value = testKit
            };
            return CreateObservationEntryComponentBase(resultCode, identifier, processingLabCode, FhirDateTime.Now());
        }

        public static Bundle.EntryComponent CreateObservationEntryComponentWithIdentifier(string resultCode, Identifier identifier, string processingLabCode)
        {
            return CreateObservationEntryComponentBase(resultCode, identifier, processingLabCode, FhirDateTime.Now());
        }

        public static Bundle.EntryComponent CreateObservationEntryComponentWithDateTime(string resultCode, string testKit, string processingLabCode, FhirDateTime dateTime)
        {
            var identifier = new Identifier
            {
                Value = testKit
            };
            return CreateObservationEntryComponentBase(resultCode, identifier, processingLabCode, dateTime);
        }

        public static Bundle.EntryComponent CreateObservationEntryComponentBase(string resultCode, Identifier identifier, string processingLabCode, FhirDateTime dateTime)
        {
            Bundle.EntryComponent entryComponent = new Bundle.EntryComponent();

            Observation observation = new Observation
            {
                Effective = dateTime,
                Device = new ResourceReference
                {
                    Identifier = identifier
                },
                Performer = new List<ResourceReference>
                {
                    new ResourceReference
                    {
                        Identifier = new Identifier
                        {
                            Value = processingLabCode
                        }
                    }
                },
                Value = new CodeableConcept
                {
                    Coding = new List<Coding>
                    {
                        new Coding
                        {
                            Code = resultCode
                        }
                    }
                }
            };

            entryComponent.Resource = observation;

            return entryComponent;
        }

        public static string GetMapperJson()
        {
            return @"{
                       ""result"": {
                           ""1240581000000104"": ""Positive"",
                           ""1321541000000108"": ""Positive"",
                           ""1322781000000102"": ""Positive"",
                           ""1324601000000106"": ""Positive"",
                           ""1324881000000100"": ""Positive"",
                           ""1240591000000102"": ""Negative"",
                           ""1321571000000102"": ""Negative"",
                           ""1322791000000100"": ""Negative"",
                           ""1324581000000102"": ""Negative"",
                           ""1322821000000105"": ""Void"",
                           ""1321641000000107"": ""Void""
                       },
                       ""type"": {
                           ""PCR"": ""PCR"",
                           ""EPCR"": ""PCR"",
                           ""RTPCR"": ""PCR"",
                           ""LFT"": ""LFT"",
                           ""LAMPORE"": ""LAMP"",
                           ""RNALAMP"": ""LAMP"",
                           ""DIRECTRTLAMP"": ""LAMP"",
                           ""ELISA"": ""ATB"",
                           """": ""PCR""
                       },
                       ""staticValues"": {
                           ""DiseaseTargetedCode"": ""840539006"",
                           ""DiseaseTargetedValue"": ""COVID-19"",
                           ""Country"": ""GB"",
                           ""Authority"" : ""NHS Digital""
                         },
                      ""selfTestValues"": {
                        ""LFDSELFTEST"": ""LFT"",
                        ""LFTSELFTEST"": ""LFT"",
                        ""SELFSERVE"": ""LFT"",
                        ""LFDSELFIMAGEREADER"": ""LFT"",
                        ""HOM"": ""PCR"",
                        ""NTS"":  ""PCR""
                      }
    }";
        }
    }
}
