﻿using CovidCertificate.Backend.DASigningService.Validators;
using FluentValidation.Results;

namespace CovidCertificate.Backend.DASigningService.Requests
{
    public class Create2DVaccinationBarcodeRequest
    {
        private static readonly Create2DVaccinationBarcodeRequestValidator validator = new Create2DVaccinationBarcodeRequestValidator();
                
        public string Type { get; set; }
        public string RegionSubscriptionNameHeader { get; set; }
        public string Body { get; set; }

        public ValidationResult Validate()
        {
            return validator.Validate(this);
        }
    }
}
