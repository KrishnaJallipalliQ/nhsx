﻿using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IEmailSender
    {
        public Task SendEmail(string email, string subject, string emailcontent);
    }
}
