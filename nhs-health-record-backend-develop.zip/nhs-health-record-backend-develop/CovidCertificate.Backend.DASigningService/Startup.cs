﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Services;
using CovidCertificate.Backend.Configuration.Bases;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics.CodeAnalysis;
using CovidCertificate.Backend.DASigningService;
using CovidCertificate.Backend.Services.Certificates;
using CovidCertificate.Backend.Services.Mappers;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Services.RemoteAccessCode;
using CovidCertificate.Backend.Services.PilotFilter;
using CovidCertificate.Backend.Services.DomesticExemptions;
using CovidCertificate.Backend.International.Services;
using CovidCertificate.Backend.International.Interfaces;
using CovidCertificate.Backend.Services.BlobService;
using CovidCertificate.Backend.Interfaces.BlobService;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Configuration.Extensions;
using CovidCertificate.Backend.DASigningService.Interfaces;
using CovidCertificate.Backend.DASigningService.Services;
using CovidCertificate.Backend.Services.KeyServices;
using CovidCertificate.Backend.International;

[assembly: FunctionsStartup(typeof(Startup))]
namespace CovidCertificate.Backend.DASigningService
{
    [ExcludeFromCodeCoverage]
    public class Startup : StartupBase
    {
        public override void SetupDI(IFunctionsHostBuilder builder)
        {
            builder.Services.AddScoped<VaccinationMapper, VaccinationMapper>();
            builder.Services.AddSingleton<IVaccineMapping, VaccineMappingCache>();
            builder.Services.AddSingleton<IFhirLookupApi, FhirLookupApi>();
            builder.Services.AddSingleton<IGetTimeZones, GetTimeZones>();
            builder.Services.AddSingleton<IUvciGenerator, UvciGenerator>();
            builder.Services.AddSingleton<IEncoderService, EncoderService>();
            builder.Services.AddSingleton<ICondensorService, CondensorService>();
            builder.Services.AddSingleton<IBlobService, BlobService>();
            builder.Services.AddSingleton(typeof(IMongoRepository<>), typeof(MongoRepository<>));
            builder.AddSetting<MongoDbSettings>(Configuration, "MongoDbSettings");
            AddMongoDBClient(builder, Configuration);
            builder.AddSetting<CertificateValiditySettings>(Configuration, "CertificateValidity");
            builder.Services.AddSingleton<IRedisCacheService, RedisCacheService>();
            builder.AddSetting<RedisCacheSettings>(Configuration, "RedisCacheSettings");
            builder.Services.AddSingleton<IKeyRing, KeyRing>();
            builder.Services.AddSingleton<ICBORFlow, CBORFlow>();
            builder.Services.AddSingleton<IClientCertificateValidator, ClientCertificateValidator>();
            builder.Services.AddScoped<IBarcodeGenerator, BarcodeGenerator>();
            builder.Services.AddSingleton<IRegionConfigService, RegionConfigService>();
            builder.Services.AddScoped<ILogService, LogService>();
        }
    }
}