﻿using CovidCertificate.Backend.Models.ResponseDtos;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Notify.Exceptions;
using System;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class NHSEmailServiceTest
    {
        private readonly NHSEmailService service;
        private readonly NotificationTemplates notificationTemplates;
        private readonly Mock<ILogger<NHSEmailService>> loggerMock = new Mock<ILogger<NHSEmailService>>();
        private readonly Mock<IConfiguration> configurationMock = new Mock<IConfiguration>();

        public NHSEmailServiceTest()
        {
            notificationTemplates = new NotificationTemplates
            {
                TwoFactor = new NotificationTemplate
                {
                    EmailTemplateId = new Guid("3982fcc3-5f51-4334-aeb6-99b837b154c6"),
                }
            };

            configurationMock.SetupGet(m => m["NHSNotifcationAPIKey"]).Returns("covidhealthrecordappmock-8ffa4967-ff8a-486e-93da-e6608274fc12-7ba62d4d-2c54-4063-94e0-68edc24a922f");

            service = new NHSEmailService(loggerMock.Object, configurationMock.Object);
        }
    }
}
