﻿using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Models.Validators;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace CovidCertificate.Backend.Tests.ValidatorTests
{
    public class AddTestResultRequestDtoValidatorTests
    {
        private readonly AddTestResultRequestDtoValidator validator;
        public AddTestResultRequestDtoValidatorTests()
        {
            validator = new AddTestResultRequestDtoValidator();
        }

        [Theory]
        [MemberData(nameof(ValidResults))]
        public async void AddTest_ValidData_IsSuccessful(string name, string phone, string email, string result, string validityType, string testType)
        {
            var dto = new AddTestResultRequestDto(name, new DateTime(1994, 10, 23), email, phone, default, result, validityType, testType);
            var validatorResult = await validator.ValidateAsync(dto);

            Assert.True(validatorResult.IsValid);
            Assert.Equal(0, validatorResult.Errors.Count);
        }

        [Theory]
        [MemberData(nameof(InvalidResults))]
        public async void AddTest_InvalidData_IsFailure(string name, string phone, string email, string result, string validityType, string testType)
        {
            var dto = new AddTestResultRequestDto(name, default, email, phone, new DateTime(2021, 1, 1), result, validityType, testType);
            var validatorResult = await validator.ValidateAsync(dto);

            Assert.False(validatorResult.IsValid);
            Assert.True(validatorResult.Errors.Count > 0);
        }


        public static IEnumerable<object[]> ValidResults =>
        new List<object[]>
        {
            new object[] { "Test name", "+44786312312", "test@test.com", "Test result", "Validity type", "testType" },
            new object[] { "Test name", null, "test@test.com", "Test result", "Validity type" , "testType" },
            new object[] { "Test name", "+44786312312", null, "Test result", "Validity type", "testType" },
        };

        public static IEnumerable<object[]> InvalidResults =>
        new List<object[]>
        {
        new object[] { null, "+44786312312", "test@test.com", "Test result", "Validity type", "testType" },
        new object[] { "Test name", "+44786312312", "test@test.com", null, "Validity type", "testType" },
        new object[] { "Test name", "+44786312312", "test@test.com", "Test result", null, "testType" },
        new object[] { "Test name", "+44786312312", "invalid email", "Test result", "Validity type", "testType" },
        new object[] { "Test name", "123", "test@test.com", "Test result", "Validity type", "testType" },
        };
        [Fact]
        public void Validate_Valid_Phone_Number_Test_Expect_Success()
        {
            //Arrange 
            var validator = new AddTestResultRequestDtoValidator();
            var dto = new AddTestResultRequestDto("John Test", new DateTime(1994, 10, 23), default, "0732342132", DateTime.UtcNow.AddDays(-2), "Positive", "PCR", "anti-gen");

            //Act
            var result = validator.Validate(dto);
            //Assert
            Assert.True(result.IsValid);
            Assert.Equal(0, result.Errors.Count);
        }

        [Fact]
        public void Validate_Valid_Phone_Number_With_DOB_Test_Expect_Success()
        {
            //Arrange 
            var validator = new AddTestResultRequestDtoValidator();
            var dto = new AddTestResultRequestDto("John Test", new DateTime(1992, 10, 12), default, "0732342132", DateTime.UtcNow.AddDays(-2), "Positive", "PCR", "anti-gen");

            //Act
            var result = validator.Validate(dto);
            //Assert
            Assert.True(result.IsValid);
            Assert.Equal(0, result.Errors.Count);
        }

        [Fact]
        public void Validate_Valid_Email_With_DOB_Test_Expect_Success()
        {
            //Arrange 
            var validator = new AddTestResultRequestDtoValidator();
            var dto = new AddTestResultRequestDto("John Test", new DateTime(1992, 10, 12), "test@test.com", default, DateTime.UtcNow.AddDays(-2), "Positive", "PCR", "anti-gen");

            //Act
            var result = validator.Validate(dto);
            //Assert
            Assert.True(result.IsValid);
            Assert.Equal(0, result.Errors.Count);
        }

        [Fact]
        public void Validate_Valid_Email_Test_Expect_Success()
        {
            //Arrange 
            var validator = new AddTestResultRequestDtoValidator();
            var dto = new AddTestResultRequestDto("John Test", new DateTime(1992, 10, 12), "test@test.com", default, DateTime.UtcNow.AddDays(-2), "Positive", "PCR", "anti-gen");

            //Act
            var result = validator.Validate(dto);
            //Assert
            Assert.True(result.IsValid);
            Assert.Equal(0, result.Errors.Count);
        }



        [Fact]
        public void Valid_No_Phone_Or_Email_Expect_Failure()
        {
            //Arrange 
            var validator = new AddTestResultRequestDtoValidator();
            var dto = new AddTestResultRequestDto("John Test", new DateTime(1992, 10, 12), default, string.Empty, DateTime.UtcNow.AddDays(-2), "Positive", "PCR", "anti-gen");

            //Act
            var result = validator.Validate(dto);
            //Assert
            Assert.False(result.IsValid);
            Assert.Equal(2, result.Errors.Count);
        }

        [Fact]
        public void Validate_Invalid_Test_Type_Expect_Failure()
        {
            //Arrange 
            var validator = new AddTestResultRequestDtoValidator();
            var dto = new AddTestResultRequestDto("John Test", new DateTime(1994, 10, 23), default, string.Empty, DateTime.UtcNow.AddDays(-2), "Positive", "TEST", "anti-gen");

            //Act
            var result = validator.Validate(dto);
            //Assert
            Assert.False(result.IsValid);
            Assert.Equal(2, result.Errors.Count);
        }
    }
}
