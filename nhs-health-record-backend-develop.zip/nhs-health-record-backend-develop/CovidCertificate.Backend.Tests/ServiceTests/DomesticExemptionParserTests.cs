﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CovidCertificate.Backend.Services.DomesticExemptions;
using CovidCertificate.Backend.Utils;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class DomesticExemptionParserTests
    {
        private readonly DomesticExemptionParser domesticExemptionParser;
        private readonly Mock<ILogger<DomesticExemptionParser>> mockLogger = new Mock<ILogger<DomesticExemptionParser>>();
        private IConfiguration mockConfig; 
        private readonly string validDateTimeString = DateTime.Now.AddYears(-20).ToString(DateUtils.DomesticExemptionDateFormat);
        private readonly string invalidDateTimeString = DateTime.MinValue.ToString();
        private readonly string validReason = "reason";
        private readonly string invalidReason = "";
        private readonly string validNhsNumber = "1234567890";
        private readonly string invalidNhsNumber = "0";
        private readonly string defaultReason = "defaultReason";


        public DomesticExemptionParserTests()
        {

            var inMemorySettings = new Dictionary<string, string>
            {
                { "MinDateOfBirth", "1900-01-01"},
                { "MaxDateOfBirth", "2021-01-01"},
            };
            var config = new ConfigurationBuilder().AddInMemoryCollection(inMemorySettings).Build();

            domesticExemptionParser = new DomesticExemptionParser(mockLogger.Object, config);
        }

        [Fact]
        public async Task ParseStringInputToDomesticExemptions_ValidRequest_ReturnsExemptions()
        {
            //Assign
            var request = $"{validNhsNumber},{validDateTimeString},{validReason}";

            //Act
            var result = (await domesticExemptionParser.ParseStringInputToDomesticExemptions(request, defaultReason)).parsedExemptions;

            //Assert
            Assert.Equal(validReason, result.FirstOrDefault().Reason);
        }

        [Fact]
        public async Task ParseStringInputToDomesticExemptions_ValidRequest_ReturnsMultipleExemptions()
        {
            //Assign
            var request = $"{validNhsNumber},{validDateTimeString},{validReason}" +
                $"\r\n{validNhsNumber},{validDateTimeString},{validReason}" +
                $"\r\n{validNhsNumber},{validDateTimeString},{validReason}";

            //Act
            var result = (await domesticExemptionParser.ParseStringInputToDomesticExemptions(request, defaultReason)).parsedExemptions;

            //Assert
            Assert.Equal(3, result.Count);
        }

        [Fact]
        public async Task ParseStringInputToDomesticExemptions_TwoGoodOneBad_ReturnsTwoExemptions()
        {
            //Assign
            var request = $"{validNhsNumber},{validDateTimeString},{validReason}" +
                $"\r\n{invalidNhsNumber},{invalidDateTimeString},{invalidReason}" +
                $"\r\n{validNhsNumber},{validDateTimeString},{validReason}";

            //Act
            var result = (await domesticExemptionParser.ParseStringInputToDomesticExemptions(request, defaultReason)).parsedExemptions;

            //Assert
            Assert.Equal(2, result.Count);
        }

        [Fact]
        public async Task ParseStringInputToDomesticExemptions_InvalidDate_ReturnsEmptyList()
        {
            //Assign
            var request = $"{validNhsNumber},{invalidDateTimeString},{validReason}";

            //Act
            var result = (await domesticExemptionParser.ParseStringInputToDomesticExemptions(request, defaultReason)).parsedExemptions;

            //Assert
            Assert.Empty(result);
        }

        [Fact]
        public async Task ParseStringInputToDomesticExemptions_InvalidNhsNumber_ReturnsEmptyList()
        {
            //Assign
            var request = $"{invalidNhsNumber},{validDateTimeString},{validReason}";

            //Act
            var result = (await domesticExemptionParser.ParseStringInputToDomesticExemptions(request, defaultReason)).parsedExemptions;

            //Assert
            Assert.Empty(result);
        }

        [Fact]
        public async Task ParseStringInputToDomesticExemptions_EmptyRequest_ReturnsEmptyList()
        {
            //Assign
            var request = "";

            //Act
            var result = await domesticExemptionParser.ParseStringInputToDomesticExemptions(request, defaultReason);

            //Assert
            Assert.Empty(result.parsedExemptions);
        }

        [Fact]
        public async Task ParseStringInputToDomesticExemptions_ValidRequestWithQuotes_ReturnsExemptions()
        {
            //Assign
            var request = $"\"{validNhsNumber},{validDateTimeString},{validReason}\"";

            //Act
            var result = (await domesticExemptionParser.ParseStringInputToDomesticExemptions(request, defaultReason)).parsedExemptions;

            //Assert
            Assert.Equal(validReason, result.FirstOrDefault().Reason);
        }

    }
}
