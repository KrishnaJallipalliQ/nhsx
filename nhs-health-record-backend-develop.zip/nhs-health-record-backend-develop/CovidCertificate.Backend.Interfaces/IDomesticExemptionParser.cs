﻿using CovidCertificate.Backend.Models.DataModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IDomesticExemptionParser
    {
        Task<(List<DomesticExemption> parsedExemptions, List<string> failedUsers)> ParseStringInputToDomesticExemptions(string request, string defaultReason = "");
    }
}
