﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IVerifySignature
    {
        Task<bool> VerifySignature(string data, string expectedResult);
    }
}
