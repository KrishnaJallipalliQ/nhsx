﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using Moq;
using Newtonsoft.Json;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Tests.AzureFunctionsTests
{
    public static class AzureFunctionTestHelper
    {
        public static readonly string TokenQueryKey;
        public static readonly string TokenHeaderKey;

        static AzureFunctionTestHelper()
        {
            TokenQueryKey = "jwt";
            TokenHeaderKey = "Authorization";
        }

        /// <summary>
        /// Note this methods implicit adds a 'jwt' Query with the specefied token to the QueryCollection 
        /// </summary>
        /// <param name="body"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public static HttpRequest CreateRequest(object body = null, string token = "")
        {
            var memoryStream = new MemoryStream();
            if(body != null)
            {
                var json = JsonConvert.SerializeObject(body);
                var byteArray = Encoding.ASCII.GetBytes(json);
                memoryStream = new MemoryStream(byteArray);
            }

            memoryStream.Flush();
            memoryStream.Seek(0, SeekOrigin.Begin);

            var mockRequest = new Mock<HttpRequest>();
            var headers = new HeaderDictionary();
            headers.Add(TokenHeaderKey, token);
            mockRequest.Setup(x => x.Headers).Returns(headers);
            mockRequest.Setup(x => x.Body).Returns(memoryStream);
            mockRequest.Setup(x => x.Query[TokenQueryKey]).Returns(token);
            mockRequest.Setup(x => x.Query["DefaultReason"]).Returns("default reason");
            
                return mockRequest.Object;
        }

        public static HttpRequest CreateRequestWithHeaderDictionaryAndQuery(object body = null, HeaderDictionary headers = null, QueryCollection queryStrings = null)
        {
            var memoryStream = new MemoryStream();
            if (body != null)
            {
                var json = JsonConvert.SerializeObject(body);
                var byteArray = Encoding.ASCII.GetBytes(json);
                memoryStream = new MemoryStream(byteArray);
            }

            memoryStream.Flush();
            memoryStream.Seek(0, SeekOrigin.Begin);

            var mockRequest = new Mock<HttpRequest>();
            var headerDictionary = headers ?? new HeaderDictionary();
            var queryCollection = queryStrings ?? new QueryCollection();
            mockRequest.Setup(x => x.Headers).Returns(headerDictionary);
            mockRequest.Setup(x => x.Body).Returns(memoryStream);
            mockRequest.Setup(x => x.Query).Returns(queryCollection);

            return mockRequest.Object;
        }

        public static async Task<string> GetRequestBodyStringAsync(HttpRequest request)
        {
            var memoryStreamCopy = new MemoryStream();
            await request.Body.CopyToAsync(memoryStreamCopy);

            // Resetting the stream after it have been consumed. This allows us to reuse the 'request.Body' stream.
            request.Body.Seek(0, SeekOrigin.Begin);
            request.Body.Flush();
            // Resetting the copy stream, to actually return from the beginning.
            memoryStreamCopy.Flush();
            memoryStreamCopy.Seek(0, SeekOrigin.Begin);

            using var reader = new StreamReader(memoryStreamCopy);
            return await reader.ReadToEndAsync();
        }
    }
}
