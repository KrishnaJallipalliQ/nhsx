﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.BlobService;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Models.Enums;
using CovidCertificate.Backend.Models.Helpers;
using CovidCertificate.Backend.Models.RequestDtos;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Services;
using CovidCertificate.Backend.Services.Certificates;
using CovidCertificate.Backend.Services.PdfGeneration;
using CovidCertificate.Backend.Tests.TestHelpers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class PdfGeneratorServiceTest
    {
        private readonly Mock<ILogger<PdfGeneratorService>> _mockLogger = new Mock<ILogger<PdfGeneratorService>>();
        private readonly IConfiguration configuration;
        private readonly Mock<HtmlGeneratorSettings> _mockGeneratorSettings = new Mock<HtmlGeneratorSettings>();
        private readonly Mock<IBlobService> blobStorageMock = new Mock<IBlobService>();
        private readonly PdfGeneratorService pdfGeneratorService;
        private readonly HtmlGeneratorService htmlGeneratorService;
        private readonly TimeZoneInfo timeZoneInfo;
        private readonly CovidPassportUser covidUser;
        private readonly Certificate certificate;
        private readonly Mock<ILogger<HtmlGeneratorService>> loggerMock = new Mock<ILogger<HtmlGeneratorService>>();
        private readonly Mock<IQrImageGenerator> qrMock = new Mock<IQrImageGenerator>();
        private readonly Mock<IGetTimeZones> mockGetTimeZones;
        private readonly IConfigurationRoot iConfig = GetIConfigurationRoot();

        public PdfGeneratorServiceTest()
        {
            var inMemorySettings = new Dictionary<string, string> {
                {"TestKey", "TestValue"},
                {"PdfBlobStorageConnectionString", iConfig.GetSection("PdfBlobStorageConnectionString").Value},
                {"connectionString", "Test2"}
            };

            configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();
            timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time");
            covidUser = CovidTestUserTestHelper.CreateNewP9User();
            certificate = new Certificate("Test McTestPerson", DateTime.UtcNow.AddYears(-20), DateTime.UtcNow.AddDays(30), DateTime.UtcNow.AddDays(100), CertificateType.Diagnostic, CertificateScenario.Domestic);
            qrMock.Setup(c => c.GenerateQrCodeString(It.IsAny<string>(), It.IsAny<int>())).Returns("012101210210");
            mockGetTimeZones = new Mock<IGetTimeZones>();
            mockGetTimeZones.Setup(x => x.GetTimeZoneInfo()).Returns(TimeZoneInfo.Utc);
            blobStorageMock.Setup(m => m.GetStringFromBlob(
                    It.Is<string>(s => s.Equals("email-views")),
                    It.Is<string>(s => s.Equals("en"))))
                    .Returns(Task.FromResult("test"));

            htmlGeneratorService = new HtmlGeneratorService(configuration, qrMock.Object, loggerMock.Object, mockGetTimeZones.Object, blobStorageMock.Object);
            pdfGeneratorService = new PdfGeneratorService(_mockGeneratorSettings.Object, htmlGeneratorService, _mockLogger.Object);
        }

        private static IConfigurationRoot GetIConfigurationRoot()
        {
            var path = AppContext.BaseDirectory + "Settings/";

            return new ConfigurationBuilder()
                .SetBasePath(path)
                .AddJsonFile("appsettings.json", optional: true)
                .AddJsonFile("secrets.json", optional: true)
                .Build();
        }

        [Fact]
        public async Task GeneratePdfDocumentStream_IsSuccessful()
        {
            //Arrange
            certificate.UniqueCertificateIdentifier = "URN:UVCI:01:GB:1620401381701ABCDEFGH#L";
            certificate.QrCodeTokens.Add("012101210210");

            var utc = TimeFormatConvert.ToUniversal(certificate.validityEndDate);
            var dto = new AddPdfCertificateRequestDto
            {
                Name = covidUser.Name,
                DateOfBirth = covidUser.DateOfBirth,
                Email = covidUser.EmailAddress,
                TemplateName = "en",
                Expiry = TimeZoneInfo.ConvertTimeFromUtc(utc, timeZoneInfo),
                QrCodeToken = certificate.QrCodeTokens[0],
                CertificateType = certificate.CertificateType,
                UniqueCertificateIdentifier = certificate.UniqueCertificateIdentifier
            };

            //Act
            var emailHtml = await htmlGeneratorService.GenerateHtml(dto.GetHtmlDto(), "email-views");

            var emailPdfRequest = new PdfGenerationRequestDto
            {
                Email = covidUser.EmailAddress,
                Name = covidUser.Name,
                EmailContent = emailHtml
            };
            var result = pdfGeneratorService.GeneratePdfDocumentStream(emailPdfRequest);

            //Assert
            Assert.NotNull(result);
            _ = Assert.IsType<Task<Stream>>(result);
        }

        [Fact]
        public async Task GeneratePdfDocumentStream_EmailContentNull_ThrowsException()
        {
            //Arrange
            var emailPdfRequest = new PdfGenerationRequestDto
            {
                Email = covidUser.EmailAddress,
                Name = covidUser.Name,
                EmailContent = null
            };

            //Act
            var result = await Assert.ThrowsAsync<Exception>(() => pdfGeneratorService.GeneratePdfDocumentStream(emailPdfRequest));

            //Assert
            Assert.IsType<Exception>(result);
            Assert.Equal("Conversion error: Could not open url.", result.Message);
        }
    }
}
