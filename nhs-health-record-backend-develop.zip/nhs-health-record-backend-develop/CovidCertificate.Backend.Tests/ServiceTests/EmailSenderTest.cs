﻿using System;
using System.Collections.Generic;
using CovidCertificate.Backend.Models.Settings;
using CovidCertificate.Backend.Services;
using Microsoft.Extensions.Configuration;
using Xunit;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class EmailSenderTest
    {
        private readonly EmailSenderCredentialSettings fakeEmailSenderCredentials;
       
        private readonly IConfiguration configuration;

        public EmailSenderTest()
        {
            var inMemorySettings = new Dictionary<string, string> {
                {"TestKey", "TestValue"},
                {"Test2", "Test2"},
                {"SendGridApiKey", "456645645646465" }
            };

            configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();

            fakeEmailSenderCredentials = new EmailSenderCredentialSettings(configuration, "TestKey")
            {
                SendGridApiKey = "45612346578", FromEmail = "Test@test.com", FromEmailName = "Test Test", EmailViewsFolder = "Test View"
            };
        }

        [Fact]
        public void SendEmail_No_SendAPIKey()
        {
            fakeEmailSenderCredentials.SendGridApiKey = string.Empty;
            var uat = new EmailSender(fakeEmailSenderCredentials, configuration);
            var result = Assert.ThrowsAsync<ArgumentNullException>(() => uat.SendEmail("","",""));

            Assert.Equal("SendGridApiKey", result.Result.ParamName);
        }

        [Fact]
        public void SendEmail_No_FromAddress()
        {
            fakeEmailSenderCredentials.FromEmail = string.Empty;
            var uat = new EmailSender(fakeEmailSenderCredentials, configuration);
            var result = Assert.ThrowsAsync<ArgumentNullException>(() => uat.SendEmail("","",""));

            Assert.Equal("fromEmail", result.Result.ParamName);
        }

        [Fact]
        public void SendEmail_Unauthorised()
        {
            var uat = new EmailSender(fakeEmailSenderCredentials, configuration);
            var result = Assert.ThrowsAsync<System.Exception>(() => uat.SendEmail("test@test.com","",""));

            Assert.Equal("Response code: Unauthorized  Unable to send email", result.Result.Message);
        }
    }
}
