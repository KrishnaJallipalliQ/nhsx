﻿using CovidCertificate.Backend.Utils;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace CovidCertificate.Backend.Tests.UtilTests
{
    public class HttpRetryPolicyUtilsTests
    {
        [Fact]
        public void TestRetryPolicyCreation()
        {
            // Arrange
            int retryCount = 1;
            int retrySleepDuration = 2;
            int timeout = 3;
            string serviceName = "test";
            var loggerMock = new Mock<ILogger>();

            // Act
            var retryPolicy = HttpRetryPolicyUtils.CreateRetryPolicy(retryCount, retrySleepDuration, timeout, serviceName, loggerMock.Object);

            // Assert
            Assert.NotNull(retryPolicy);
        }
    }
}
