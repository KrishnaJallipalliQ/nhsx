﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.Interfaces;
using CovidCertificate.Backend.Models.Settings;
using Microsoft.Extensions.Logging;
using Notify.Client;
using Notify.Exceptions;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using CovidCertificate.Backend.Utils.Extensions;

namespace CovidCertificate.Backend.Services
{
    public class NHSEmailService : IEmailService
    {
        private readonly NotificationClient client;
        private readonly ILogger<NHSEmailService> logger;
        private readonly IConfiguration configuration;
        private readonly HttpClientWrapper httpClientWrapper = new HttpClientWrapper(new HttpClient {Timeout = TimeSpan.FromSeconds(30)});

        public NHSEmailService(ILogger<NHSEmailService> logger, IConfiguration configuration)
        {
            this.logger = logger;
            this.configuration = configuration;

            client = new NotificationClient(httpClientWrapper, configuration["NHSNotifcationAPIKey"]);
        }

        public async Task SendEmail<T>(T emailContent, string templateId) where T : IEmailModel
        {
            logger.LogInformation("SendEmail was invoked");
            if (configuration["AllowNotify"] != bool.TrueString)
            {
                logger.LogInformation("SendEmail has finished");
                return;
            }

            try
            {
                var personalisation = emailContent.GetPersonalisation();
                var response = await client.SendEmailAsync(emailContent.EmailAddress, templateId, personalisation);
                logger.LogInformation("SendEmail has finished");
            }
            catch (NotifyClientException e)
            {
                logger.LogTraceAndDebug($"Not able to send email to {emailContent.EmailAddress}. Received error: {e.Message}");
                throw;
            }
            catch (Exception e)
            {
                logger.LogTraceAndDebug($"Failed to send email to {emailContent.EmailAddress}. Received error: {e.Message}, {e.StackTrace}");
                throw;
            }
        }
    }
}
