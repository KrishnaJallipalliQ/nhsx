﻿
namespace CovidCertificate.Backend.Models.Settings
{
    public class NotificationTemplates
    {
        public NotificationTemplate TwoFactor { get; set; }
        public NotificationTemplate PdfGeneration { get; set; }
        public NotificationTemplate WelshPdfGeneration { get; set; }
        public NotificationTemplate PassGeneration { get; set; }
    }
}
