﻿using System.ComponentModel.DataAnnotations;

namespace CovidCertificate.Backend.Models.Settings
{
    public class TestResultIngestionServiceBusQueueSettings
    {
        [Required(AllowEmptyStrings = false)]
        public string AntibodyQueueName { get; set; }
        public string DiagnosticQueueName { get; set; }
    }
}
