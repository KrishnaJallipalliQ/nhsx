﻿using System.Threading.Tasks;
using CovidCertificate.Backend.Interfaces.Certificates;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.Utils;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using CovidCertificate.Backend.Services.KeyServices;
using System;
using System.Text;

namespace CovidCertificate.Backend.Services.Certificates
{
    public class ECQRCodeGenerator : IQRCodeGenerator
    {
        private readonly ILogger<ECQRCodeGenerator> logger;
        private readonly IKeyRing keyRing;

        public ECQRCodeGenerator(ILogger<ECQRCodeGenerator> logger, IKeyRing keyRing)
        {
            this.logger = logger;
            this.keyRing = keyRing;
        }

        public async Task<string> GenerateQRCodeForCertificate(Certificate certificate)
        {
            logger.LogInformation("GenerateQRCodeForCertificate was invoked");

            const int result = 1;
            var keyId = keyRing.GetRandomKey();
            
            var header = Convert.ToBase64String(Encoding.UTF8.GetBytes(keyId));
            var payload = Base64UrlEncoder.Encode($"{result}{certificate.validityEndDate:yyMMddHHmm}{certificate.Name.MaxLength(60)}");
            var signature = await keyRing.SignData(keyId, Encoding.Unicode.GetBytes($"{header}.{payload}"));

            logger.LogInformation("GenerateQRCodeForCertificate has finished");

            return $"{header}.{payload}.{Base64UrlEncoder.Encode(signature)}";
        }
    }
}
