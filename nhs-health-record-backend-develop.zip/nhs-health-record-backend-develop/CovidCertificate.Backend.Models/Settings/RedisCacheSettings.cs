﻿namespace CovidCertificate.Backend.Models.Settings
{
    public class RedisCacheSettings
    {
        public int RedisExpiryShort { get; set; }

        public int RedisExpiryMedium { get; set; }

        public int RedisExpiryLong { get; set; }

    }
}
