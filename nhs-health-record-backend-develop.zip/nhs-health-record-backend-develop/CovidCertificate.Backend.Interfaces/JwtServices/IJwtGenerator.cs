﻿using CovidCertificate.Backend.Models.Interfaces;
using CovidCertificate.Backend.Models.ResponseDtos;
using System.Threading.Tasks;

namespace CovidCertificate.Backend.Interfaces
{
    public interface IJwtGenerator
    {
        Task<ValidateTwoFactorResponseDto> Issue<T>(T user) where T : IJwtTokenData;
    }
}
