﻿using CovidCertificate.Backend.IngestionPipelines;
using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Models.DataModels;
using CovidCertificate.Backend.PilotFilter;
using CovidCertificate.Backend.Tests.TestHelpers;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Xunit;

namespace CovidCertificate.Backend.Tests.AzureFunctionsTests
{
    public class ProcessPilotUserMessageFunctionTests : IClassFixture<AzureFunctionFixture<PilotUser>>
    {
        public readonly Action ClearCollection;

        private readonly Mock<IMongoRepository<PilotUser>> mongoRepositoryMock;
        private readonly ProcessPilotUserMessageFunction processPilotUserMessageFunction;
        private readonly IPilotFilterService pilotFilterService;


        public ProcessPilotUserMessageFunctionTests(AzureFunctionFixture<PilotUser> fixture)
        {
            this.ClearCollection = fixture.Dispose;
            this.mongoRepositoryMock = fixture.MongoRepository;
            var logger = Mock.Of<ILogger<ProcessPilotUserMessageFunction>>();
            this.processPilotUserMessageFunction = new ProcessPilotUserMessageFunction(mongoRepositoryMock.Object, pilotFilterService, logger);
        }

        #region Tests

        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public async Task ProcessPilotUserMessageFunction_ValidRequest_ShouldInsertOneResult(CovidPassportUser user)
        {
            // Arrange
            var pilotUser = PilotUserTestHelper.CreatePilotUser(user);
            var request = AzureFunctionTestHelper.CreateRequest(pilotUser, string.Empty);
            var requestBodyString = await AzureFunctionTestHelper.GetRequestBodyStringAsync(request);

            // Act
            await processPilotUserMessageFunction.Run(requestBodyString);
            Expression<Func<PilotUser, bool>> exp = p => p.UserHash == user.ToPilotUser().UserHash;
            var insertedResult = await mongoRepositoryMock.Object.FindOneAsync(exp);

            // Assert
            Assert.NotNull(insertedResult);
            //Assert.Equal(insertedResult, pilotUser);
        }

        [Fact]
        public async Task ProcessPilotUserMessageFunction_NonValidRequest_ShouldThrowArgumentException()
        {
            // Arrange
            PilotUser PilotUser = null;
            var request = AzureFunctionTestHelper.CreateRequest(PilotUser, string.Empty);
            var requestBodyString = await AzureFunctionTestHelper.GetRequestBodyStringAsync(request);

            // Act
            Func<Task> act = async () => await processPilotUserMessageFunction.Run(requestBodyString);

            // Assert
            var ex = await Assert.ThrowsAsync<ArgumentException>(act);
            Assert.Equal($"Couldn't populate pilot user, please check format supplied: {requestBodyString}", ex.Message);
        }

        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public async Task ProcessPilotUserMessageFunction_RequestWithNonValidId_ShouldThrowArgumentException(CovidPassportUser user)
        {
            // Arrange
            string nonValidIdStr = "nonValidIdString";
            var pilotUser = PilotUserTestHelper.CreatePilotUser(user, 1);
            var pilotUserValuePair = ArrangeTestHelper.ObjectsToKeyValuePair(pilotUser);
            var pilotUserDictionary = new Dictionary<string, object>(pilotUserValuePair);
            pilotUserDictionary[nameof(PilotUser.Id)] = nonValidIdStr;

            var request = AzureFunctionTestHelper.CreateRequest(pilotUserDictionary, string.Empty);
            var requestBodyString = await AzureFunctionTestHelper.GetRequestBodyStringAsync(request);

            // Act
            Func<Task> act = async () => await processPilotUserMessageFunction.Run(requestBodyString);

            // Assert
            var ex = await Assert.ThrowsAsync<ArgumentException>(act);
            Assert.Equal($"Could not create a MongoDocument id from the specified id string: {nonValidIdStr}", ex.Message);
        }

        [Theory]
        [MemberData(nameof(CovidTestUserTestHelper.GetUserScenarios), MemberType = typeof(CovidTestUserTestHelper))]
        public async Task ProcessPilotUserMessageFunction_RequestWithMissingRequiredProperty_ShouldThrowJsonSerializationException(CovidPassportUser user)
        {
            // Arrange
            var pilotUser = PilotUserTestHelper.CreatePilotUser(user, 1);
            var pilotUserValuePair = ArrangeTestHelper.ObjectsToKeyValuePair(pilotUser);

            foreach (var requiredPropertyName in PilotUserTestHelper.GetRequiredPilotUserProperties())
            {
                // Arrange
                var pilotUserDictionary = new Dictionary<string, object>(pilotUserValuePair);
                pilotUserDictionary[requiredPropertyName] = null;
                var request = AzureFunctionTestHelper.CreateRequest(pilotUserDictionary, string.Empty);
                var requestBodyString = await AzureFunctionTestHelper.GetRequestBodyStringAsync(request);

                // Act
                Func<Task> act = async () => await processPilotUserMessageFunction.Run(requestBodyString);

                // Assert
                var ex = await Assert.ThrowsAsync<JsonSerializationException>(act);
                Assert.Contains($"Required property '{requiredPropertyName}' expects a value but got null.", ex.Message);
            }
        }

        #endregion
    }
}
