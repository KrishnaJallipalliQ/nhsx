﻿using CovidCertificate.Backend.Interfaces;
using System;

namespace CovidCertificate.Backend.Services
{
    public class TableNameGenerator : ITableNameGenerator
    {
        private const string DateFormat = "ddMMyyHH";
        
        /// <summary>
        /// Generates the PartitionKey based on current Utc date
        /// </summary>
        /// <returns></returns>
        public string GetTableName()
        {
            return $"FA{DateTime.UtcNow.ToString(DateFormat)}";
        }

        /// <summary>
        /// Generates the PartitionKey based on based on given date
        /// </summary>
        /// <param name="value">Value used to generate PartitionKey</param>
        /// <returns></returns>
        public string GetTableName(DateTime value)
        {
            return $"FA{value.ToUniversalTime().ToString(DateFormat)}";
        }
    }
}
