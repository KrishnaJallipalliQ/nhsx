﻿using CovidCertificate.Backend.Models.DataModels;
using Newtonsoft.Json;
using System.Collections.Generic;
using Xunit;

namespace CovidCertificate.Azure.Resources.Tests
{
    public class VaccineResultsMappingTests
    {
        private readonly IDictionary<string, VaccineMap> mappings;

        public VaccineResultsMappingTests()
        {
            var mappingJson = AzureResourceTestHelper.GetJsonFromAzureResourcesProject("vaccine-results-mapping.json");
            mappings = JsonConvert.DeserializeObject<IDictionary<string, VaccineMap>>(mappingJson);
        }

        [Fact]
        public void VaccineResultsMappingTest_ManufacturerCorrectLength()
        {
            foreach(var snomed in mappings.Keys)
            {
                Assert.Equal(2, mappings[snomed].Manufacturer.Count);
            }
        }

        [Fact]
        public void VaccineResultsMappingTest_DiseaseCorrectLength()
        {
            foreach (var snomed in mappings.Keys)
            {
                Assert.Equal(2, mappings[snomed].Disease.Count);
            }
        }

        [Fact]
        public void VaccineResultsMappingTest_ProductCorrectLength()
        {
            foreach (var snomed in mappings.Keys)
            {
                Assert.Equal(3, mappings[snomed].Product.Count);
            }
        }

        [Fact]
        public void VaccineResultsMappingTest_VaccineCorrectLength()
        {
            foreach (var snomed in mappings.Keys)
            {
                Assert.Equal(2, mappings[snomed].Vaccine.Count);
            }
        }

        [Fact]
        public void VaccineResultsMappingTest_TotalSeriesDosesCorrecet()
        {
            foreach (var snomed in mappings.Keys)
            {
                Assert.True(mappings[snomed].TotalSeriesOfDoses > 0);
            }
        }
    }
}
