﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Services;
using CovidCertificate.Backend.Tests.ServiceTests;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Moq;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.OpenSsl;
using Org.BouncyCastle.Security;
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;

namespace CovidCertificate.Backend.Tests.TestHelpers
{
    public static class NHSKeyRingTestHelper
    {
        private static Dictionary<string,string> inMemorySettings = new Dictionary<string, string> {
                {"NHSLoginKey", "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDDPafEDelOWBm8\n4efz2ouuP+CNKo3S5SuAK8gD1IupEhJhTK28yfG3k5ke4ZrTcWLa3xc20eMyCb0v\nhIr49RFD1j8FUQSqS7/bS8IrlufkMK781bsDT7iPw6BE9+FY9XgpBS5KK9K0FUFq\nSfwcTAfLxJE+Ryh4MbgbcN6fx1FOg6lrm57/8IL25zL0lLKsJEdUsUUrgeKC0gNq\n0787NKPtFCzpdb/7g//wYTIJnTTz1bJEO9Uh6x6mViLccuzz/446/Uv60gkyD+KU\nmALg2jYkYHly14EEFGrNFozc/MVId/UXJQaY0Wiz0vluoEJjV8E1zacRdUMAUA58\nOOpo64BrAgMBAAECggEATDbSOZ8wluufSHNrJ28FncTDtHeLG2toWsU8c/pRdnNe\nh2r2Wz79w6qzWDG7TZTygPwbRMQUC2Fv34++7EZGMhP9T+b7ijq9ry5YoslqxlIW\nzQ3lzfod0skL1EBrUF2qRWEHW97VhoTRn1s4Nheb53hZNlVyv9CwzM13qimVXK8r\n9z9HzJDMw95HKJfEFyyRS6EavgW3MOgxpW6+GutNVMUEzNuKiHNj/6JdFWHP58LN\nNke+ED7EuiTdevahMs/oYecCpgmm0rZZxj3K561EjYEhjCKb64sELLav1xEFJVx+\nQb6HGRubWuy1IU7OuMiLNHgadGrvZvL3B5166FX2MQKBgQDrpcMHWs6xgqdQsmV5\nGJPJBjXzlm95SbUUSCkaXdMpE6Qz6w4dfaOe1HV1NbZcjKfMHXHfl3acrVBVAbGD\nl0QAkWfKqWcwExS8Suje42Hfrhn8esc8MGdCtPaD++j+i3aM92AMi52UoRaNg0jy\n+O6hfDdGaMaioqsQ69i7r0R7qQKBgQDUGn1kLrKNDU+N0FHSMDjM6rOSg6Axa3j9\nXlzBxHCtbqcp4KGzCvNv/6sgpYWgvYeRn+PIaTb3lOuXKO+zYIEK5cKRzvpOBmcq\nmtKFylWaNZNWs2+4wJgnzocT2+UsWhp6KeiILfonzbCF6pnndfIVwhmYcNTGCC8f\nVzFQ8JSH8wKBgQCxEigQ+L1kSccsLkFt03gJkG8uERbGzwoQqYCpXWN09Fto3/IF\nWwl+Kivw3WGg/diA2odc+lWYuespVVJsjVf+DUUu1kjBqTTloGyIP9il2g+Q1zmr\nErwlNhIfb0XPMEDvAFveUXMh4kIuKD7CxSeblNl8QPMx9oYQ+wgrUDJnsQKBgDmu\nppE7PeWsTAlWMRpHcPsRjRp4X3VxM+s74V/062vPHvj9lRwbC09XKZPsT+YCBT9u\nS0Uyj/dO8a8fO+j9grqS95Itxta3WRE2H7Cw8QzKKzK2A9krz3Vr7kJRWAbyziaR\nBSMb1d9DShFxVr+izN5r9ggGD2d3zFDqpofLlalPAoGASjS2jruVYvHUxvdUI2kp\nK0zybAHAamlMA136Z1PvWbkTuJC18t+o6ZWNgbMbIcqHMhCZDKZgut/wCyhmzM6f\nfVgNjWuxzUWqb44bWlj3/OE/oZj+yptrOFMe5/futoxkq7aV/1z2d9qm3Ul/fX1Z\nXhGcIW0Dsq4P3qALYt7X6CM=\n-----END PRIVATE KEY-----"},
                {"TokenUrl", "https://login.microsoftonline.com/9a4eeda5-b6e3-4dfd-b631-a97fba18e829/oauth2/v2.0/token" },
                {"ClientID", "3f96fc30-4d1f-41af-80c0-2223990486eb"},
                {"TokenLifetime", "1"},
                {"JwtValidationEnabled", "true"},
            };

        public static Dictionary<string,string> InMemorySettings
        {
            get { return inMemorySettings; }
        }

        public static JsonWebKey GetValidPublicJwk()
        {
            using (var reader = new StringReader(inMemorySettings["NHSLoginKey"]))
            using (var rsa = new RSACryptoServiceProvider())
            {
                var key = (RsaPrivateCrtKeyParameters)new PemReader(reader)
                    .ReadObject();
                var rsaParams = DotNetUtilities.ToRSAParameters(key);
                rsa.ImportParameters(rsaParams);
                var exponent = Convert.ToBase64String(rsaParams.Exponent);
                var modulus = Convert.ToBase64String(rsaParams.Modulus);
                JsonWebKey validPublicJwk = new JsonWebKey() { Alg = "RS512", E = exponent, Use = "sig", Kid = "nhs-login", Kty = "RSA", N = modulus };

                return validPublicJwk;
            }
        }

        public static JsonWebKey GetInvalidPublicJwk()
        {
                JsonWebKey invalidPublicJwk = new JsonWebKey() { Alg = "RS512", E = "123", Use = "sig", Kid = "nhs-login", Kty = "RSA", N = "123" };
                return invalidPublicJwk;
        }

        public static NhsIdJwtValidator GetNhsIdJwtValidator(JsonWebKey publicJwk, IConfiguration configuration, Mock<ILogger<NhsIdJwtValidator>> mockLoggerValidator, Mock<IPublicKeyService> mockPublicKeyService)
        {
            var tokenValidationParameters = publicJwk != null ? NhsIdJwtValidatorTestHelper.GetValidationParameters(publicJwk) : null;

            return new NhsIdJwtValidator(
                configuration,
                NhsIdJwtValidatorTestHelper.GetValidationServiceResolverMock(tokenValidationParameters).Object,
                mockLoggerValidator.Object,
                mockPublicKeyService.Object
                );
        }
    }
}
