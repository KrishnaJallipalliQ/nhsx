﻿using CovidCertificate.Backend.Interfaces;
using CovidCertificate.Backend.Interfaces.Delegates;
using CovidCertificate.Backend.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Memory;
using Microsoft.IdentityModel.Tokens;
using Moq;
using System.Collections.Generic;

namespace CovidCertificate.Backend.Tests.ServiceTests
{
    public class NhsIdJwtValidatorTestHelper
    {
        public const string AuthSchema = "id-token";
        
        public const string InvalidToken = "eyJzdWIiOiI0Y2JkZThkZC00NjA2LTRiNjUtYThhYy0wM2JiZjMwMTNkNWIiLCJhdWQiOiJoZWFsdGhyZWNvcmRzIiwia2lkIjoiZjYwZWI0NmZmOGFiZjBiZjllOTE3ZWVlNjA4NmM1ZmE0YTE2MmE1ZCIsImlzcyI6Imh0dHBzOi8vYXV0aC5hb3Muc2lnbmluLm5ocy51ayIsInR5cCI6IkpXVCIsImV4cCI6MTYyNjQzMTcyOSwiaWF0IjoxNjI2NDI4MTI5LCJhbGciOiJSUzUxMiIsImp0aSI6ImIyYzQ0YjY2LTM0MWEtNDBmNy05NGU4LWQyNDYyMjZkM2JmMiJ9.eyJzdWIiOiI0Y2JkZThkZC00NjA2LTRiNjUtYThhYy0wM2JiZjMwMTNkNWIiLCJiaXJ0aGRhdGUiOiIxOTE4LTA2LTI4IiwibmhzX251bWJlciI6Ijk2NTg0Nzc4NjAiLCJpc3MiOiJodHRwczovL2F1dGguYW9zLnNpZ25pbi5uaHMudWsiLCJ2dG0iOiJodHRwczovL2F1dGguYW9zLnNpZ25pbi5uaHMudWsvdHJ1c3RtYXJrL2F1dGguYW9zLnNpZ25pbi5uaHMudWsiLCJhdWQiOiJoZWFsdGhyZWNvcmRzIiwiaWRfc3RhdHVzIjoidmVyaWZpZWQiLCJ0b2tlbl91c2UiOiJpZCIsInN1cm5hbWUiOiJHQU5URVMiLCJhdXRoX3RpbWUiOjE2MjY0MjgxMjcsInZvdCI6IlA1LkNwLkNkIiwiaWRlbnRpdHlfcHJvb2ZpbmdfbGV2ZWwiOiJQOSIsImV4cCI6MTYyNjQzMTcyOSwiaWF0IjoxNjI2NDI4MTI5LCJmYW1pbHlfbmFtZSI6IkdBTlRFUyIsImp0aSI6ImIyYzQ0YjY2LTM0MWEtNDBmNy05NGU4LWQyNDYyMjZkM2JmMiJ9.o6QO4644ZNPu3IkfnPv5n91em-CgyuTGsC0OLF4Kp21411ePLeGRRgdehENOT0lyNz70-pUfGam5TmLSm1O9fTknfUC6I-lXXyqU_oXbW_5hwCGDPZMoxnSvDfusBe1MnJkPyeTYkdfh5gQS2_Chu_e4tEBfD2B0NDg0Hny3csSoSdN1-szN4GnTvjsT2g15zhEw4BcfbFG9AgHcDlq3lE5AVeE9pT55VL7WkkltIXaw8dPYCMFlbJIjSNaF6UAt4337Yh0sl1aHmOtGSiUZOEfZ166HzAlpE1dY6iZf9yrUuYxtNHTJZwGkEOPHXJzyFdpz7LcexddhTb1jTpsU5w";
        
        public const string ValidToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzUxMiIsInN1YiI6IjgwMTQ0OTg5NjgiLCJhdWQiOiJBUElNLTEiLCJraWQiOiJuaHMtbG9naW4iLCJpc3MiOiJodHRwczovL3JlZi5hcGkuc2VydmljZS5uaHMudWsiLCJleHAiOjE2ODIxNjUyNTQsImlhdCI6MTYxOTA5MzI0NCwianRpIjoiNzYxMjVlMTItMDQyYi00Y2M3LTk0NjItMGUyNmM2ZDRkODdlIn0.eyJhdWQiOiJ0Zl8tQVBJTS0xIiwiaWRfc3RhdHVzIjoidmVyaWZpZWQiLCJ0b2tlbl91c2UiOiJpZCIsImF1dGhfdGltZSI6MTYxOTA5MzI1NCwiaXNzIjoiaHR0cHM6Ly9yZWYuYXBpLnNlcnZpY2UubmhzLnVrIiwidm90IjoiUDkuQ3AuQ2QiLCJleHAiOjE2ODIxNjUyNTQsImlhdCI6MTYxOTA5MzI0NCwidnRtIjoiaHR0cHM6Ly9hdXRoLnNhbmRwaXQuc2lnbmluLm5ocy51ay90cnVzdG1hcmsvYXV0aC5zYW5kcGl0LnNpZ25pbi5uaHMudWsiLCJqdGkiOiI3NjEyNWUxMi0wNDJiLTRjYzctOTQ2Mi0wZTI2YzZkNGQ4N2UiLCJpZGVudGl0eV9wcm9vZmluZ19sZXZlbCI6IlA5IiwiYmlydGhkYXRlIjoiMTkzOS0wOS0yNiIsIm5oc19udW1iZXIiOiI4MDE0NDk4OTY4Iiwibm9uY2UiOiJyYW5kb21ub25jZSIsInN1cm5hbWUiOiJURVNUSU5HIiwiZmFtaWx5X25hbWUiOiJURVNUSU5HIn0.drwkNahwI0M_Xdrwha1r6yQ0wfKui-GEDaHzMWIgilk7MEig4EIjliLnLTDuFkGqP5qa33AR46zDi_8b4TQdc2jVSA7CdHVnfl8SKNqoVaMXY08ATXvLPpbTjecpcek_etLbWR6RPmmq8CaCf3_x1nTmz1oXzeSOylm5bGKAiDeQ4ZX55BuWo2VFCt-F7XRCHdcjA-DyQWNRhQcYUFExAgUNUxyXTXM3O0Xi4Zgxq_bWRuF873JTzpQqotRhnOmNc3qHe5vrHH0SIFyL5_bdD2zF68oRr47GvLHJsqEqwdR9peu-w2CMzge-WqnGJ7FhRsEyoGLoNV1IPrvPJ8G0JS8iWFxfzsG7HW0ZLXciTTYaaHi8d3wMsDoXs2WR-YDbKsZciIp5ki2G8tkGLDNlgRKEZq7BJZxlo5XCadAPa5v45V6xP8ai9qQlnnAZ7Bd-7QZDETD7EqWsCe7Wz9LQyiKN6heeJPc1e7q8DQIftDkUXjbHynaubk_jVZp2y3U05yZvGv0lJxcYq4nept_t1l6idkgk8ZDtFexg_yIh0EtPfMQAD-AaORDQ4TcIonOtPqYD5vZ3QDMG8qlyn8lLDbSuAyDCmhOc4ZeCMkOltvMpXD7JDiYB-TAvTIfkAWil91wyA3prWuoILss_hhPd7uLAikvnUGQhwltrZzESsVY";
        public static JsonWebKey ValidPublicJwk = new JsonWebKey() { E = "AQAB", Use="sig", Kid = "nhs-login", Kty = "RSA", N = "wcSyzWPEEhgRBvFPDl-sdvh54PjU3PO639O4j-Siy1u9ooHTXa7dOY15h7kDUBxnmRwhfihxSGyNL8vqmvOMMZLJ51a13tegJQQvqS21Fn6ihi46FIwDh4PhKkz_1kVJPaYgEg21A75MCgBOkOmXF7e3VocFLEVhzT1jWcWDuyt7rqEs2ImZg8ZHlkYYweFaKW75D34QM96u7ZUKtg2HQGHhVaY3gkjRuj_FBzHh3A6rCxiXIPopVUR3pFH3nXE5d8-exdSphg90MfI4YtJxRq802Le-wlC8Vqbf0IUvf_e2preFPAKUH7v2Gv5OkktNDh_eO5LGAqrz4GjSnaZA-1Fk5_0Zf2_bEKiucKyxnej5SfpQmsGNXSdsYrG33b6WTL_9Jn5UqfKE3OKpMsLYhbPKKinJFaIVyjcBoQVuB28LGEefwOnplBZFknSxgLAki14d_sUKuW5grqj_7DnKSeDtUNMvbtob9utj1gzX5hK0afjoqLxJm3lgTjIK5zYGAzhKMdX-KCucudKNtVYyiKUp1B1vjnA8e-upUXLuJgnPiUXBOiMZuQSfTgdQ9yrf4C79C0_-n-_fjgZmnHAl1Cr_KbaedG2_GR78HKLcirwfeKalxMR33pouqp7sjfz3vfNyY-b9DcfWtU7lYMwdc1OOMfMooO1LnM1pZ6fpGa0" };
        
        public const string IncorrectToken = "abc";
        public static JsonWebKey IncorrectPublicJwk = new JsonWebKey();


        public static TokenValidationParameters GetValidationParameters(JsonWebKey publicJwk)
        {
            return new TokenValidationParameters()
            {
                ValidateAudience = false,
                ValidateActor = false,
                ValidateIssuer = false,
                ValidateLifetime = true,
                IssuerSigningKey = publicJwk
            };
        }

        public static Mock<ValidationServiceResolver> GetValidationServiceResolverMock(TokenValidationParameters tokenValidationParameters = null)
        {
            var JwtValidationParameterFetcherMock = new Mock<IJwtValidationParameterFetcher>(MockBehavior.Strict);

            var validationParams = tokenValidationParameters ?? new TokenValidationParameters();

            JwtValidationParameterFetcherMock.Setup(x => x.GetValidationParameters()).ReturnsAsync(validationParams);

            var ValidationServiceResolverMock = new Mock<ValidationServiceResolver>(MockBehavior.Strict);
            ValidationServiceResolverMock.Setup(x => x.Invoke(It.IsAny<string>())).Returns(JwtValidationParameterFetcherMock.Object);

            return ValidationServiceResolverMock;
        }

        public static ConfigurationRoot GetConfiguration(bool validationEnabled = true)
        {
            var provider = new MemoryConfigurationProvider(new MemoryConfigurationSource());
            var configuration = new ConfigurationRoot(new List<IConfigurationProvider> { provider });

            configuration["JwtValidationEnabled"] = validationEnabled.ToString().ToLower();
            return configuration;
        }
        
        public static ConfigurationRoot GetEmptyConfiguration()
        {
            var provider = new MemoryConfigurationProvider(new MemoryConfigurationSource());
            var configuration = new ConfigurationRoot(new List<IConfigurationProvider> { provider });
            
            return configuration;
        }
    }
}
